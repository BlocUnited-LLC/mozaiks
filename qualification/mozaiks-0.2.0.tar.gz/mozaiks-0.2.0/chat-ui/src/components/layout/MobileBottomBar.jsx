import React, { useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import { FiMessageCircle } from "react-icons/fi";
import { useNavigation } from "../../providers/NavigationProvider";
import { useNavigationActions } from "../../navigation/useNavigationActions";
import {
  deriveShellActionContext,
  filterPersonalAccountItems,
  isShellItemVisible,
  isSignInAvailable,
  resolveShellActions,
} from "../../navigation/shellActions";
import { useChatUI } from "../../context/ChatUIContext";
import { useAppEventBus } from "../../ui/hooks/useAppEventBus.js";
import { fetchNotificationCount } from "./notificationApi.js";
import ShellNavigationIcon, { hasNamedIcon } from "./ShellNavigationIcon.jsx";
import "./header-styles.css";

const buildAutoItems = ({ headerPages, header, notifications, profile, shellAuth, actionContext }) => {
  const items = [];
  const roles = actionContext?.roles || [];

  if (Array.isArray(headerPages)) {
    for (const item of filterPersonalAccountItems(headerPages, shellAuth)) {
      if (items.length >= 3) break;
      if (isShellItemVisible(item, roles) && item.path) {
        items.push({
          id: item.id || item.path,
          label: item.label || item.id || "Page",
          icon: item.icon,
          iconLabel: item.iconLabel,
          action: "navigate",
          path: item.path,
        });
      }
    }
  }

  const resolvedActions = filterPersonalAccountItems(
    Array.isArray(header?.actions) ? resolveShellActions(header.actions, actionContext) : [],
    shellAuth,
  );
  const primaryAction = resolvedActions.find((item) => item?.path || item?.href || item?.trigger);
  if (primaryAction) {
    items.push({
      id: primaryAction.id || primaryAction.path || primaryAction.href,
      label: primaryAction.label || "Action",
      icon: primaryAction.icon,
      iconLabel: primaryAction.iconLabel,
      action: "navigate",
      path: primaryAction.path,
      href: primaryAction.href,
      trigger: primaryAction.trigger,
    });
  }

  if (notifications?.show !== false && notifications?.path) {
    items.push({
      id: "notifications",
      label: "Alerts",
      icon: notifications.icon,
      action: "navigate",
      path: notifications.path,
    });
  }

  // The profile slot stands for the signed-in person; without sign-in there is no one to stand for.
  const profileItem = isSignInAvailable(shellAuth) && Array.isArray(profile?.menu)
    ? profile.menu.find((item) => (
      isShellItemVisible(item, roles) &&
      item.action !== "signout" &&
      item.action !== "signin" &&
      item.path
    ))
    : null;
  if (profile?.show !== false && profileItem) {
    items.push({
      id: profileItem.id || "profile",
      label: profileItem.label || "Account",
      icon: profileItem.icon || profile.icon,
      iconLabel: profileItem.iconLabel,
      action: "navigate",
      path: profileItem.path,
    });
  }

  const seen = new Set();
  return items.filter((item) => {
    const key = item.path || item.href || item.id;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 5);
};

const MobileBottomBar = ({ route = null, shellMode = null }) => {
  const location = useLocation();
  const handleNavigationItem = useNavigationActions();
  const {
    login,
    logout,
    user,
    isInWidgetMode,
    isWidgetVisible,
    isChatOverlayOpen,
    setIsChatOverlayOpen,
    unreadChatCount,
    setUnreadChatCount,
  } = useChatUI();
  const { mobile, headerPages, header, notifications, profile, auth: shellAuth } = useNavigation();
  const [notificationCount, setNotificationCount] = useState(0);
  const actionContext = useMemo(
    () => deriveShellActionContext({ location, route, shellMode, user }),
    [location.pathname, location.search, route, shellMode, user]
  );

  React.useEffect(() => {
    if (notifications?.show === false) return undefined;
    const controller = new AbortController();
    let mounted = true;

    const loadNotificationCount = () => {
      fetchNotificationCount({ signal: controller.signal })
        .then((payload) => {
          if (!mounted || !payload) return;
          const count = Number(payload.unread_count ?? payload.count ?? 0);
          if (Number.isFinite(count)) setNotificationCount(Math.max(0, count));
        })
        .catch(() => {
          if (mounted) setNotificationCount(0);
        });
    };

    loadNotificationCount();
    const intervalId = window.setInterval(loadNotificationCount, 15000);
    return () => {
      mounted = false;
      window.clearInterval(intervalId);
      controller.abort();
    };
  }, [notifications?.show]);

  useAppEventBus('notification.count_changed', () => {
    if (notifications?.show === false) return;
    fetchNotificationCount()
      .then((payload) => {
        if (!payload) return;
        const count = Number(payload?.unread_count ?? payload?.count ?? 0);
        if (Number.isFinite(count)) setNotificationCount(Math.max(0, count));
      })
      .catch(() => {});
  });

  const bottomBar = mobile?.bottomBar || {};
  const configuredItems = filterPersonalAccountItems(
    Array.isArray(bottomBar.items)
      ? bottomBar.items.filter((item) => isShellItemVisible(item, actionContext.roles || []))
      : [],
    shellAuth,
  );
  const items = useMemo(
    () => configuredItems.length > 0
      ? configuredItems.slice(0, 5)
      : buildAutoItems({ headerPages, header, notifications, profile, shellAuth, actionContext }),
    [actionContext, configuredItems, header, headerPages, notifications, profile, shellAuth]
  );

  if (bottomBar.visible === false || items.length === 0) return null;

  const showAssistant = isInWidgetMode && isWidgetVisible;

  const execute = async (item) => {
    if (item.action === "signout" || item.id === "signout") {
      await logout?.();
      return;
    }
    if (item.action === "signin" || item.id === "signin") {
      await login?.();
      return;
    }
    handleNavigationItem(item);
  };

  return (
    <nav className="shell-mobile-bottom-bar" aria-label="Mobile app navigation">
      {items.map((item) => {
        const active = item.path && location.pathname === item.path;
        const showBadge = item.id === "notifications" && notificationCount > 0;
        return (
          <button
            key={item.id || item.path || item.href || item.label}
            type="button"
            onClick={() => execute(item)}
            className={`shell-mobile-bottom-item${active ? " is-active" : ""}`}
          >
            <span className="shell-mobile-bottom-glyph" aria-hidden="true">
              <ShellNavigationIcon
                icon={item.icon || (!item.iconLabel && hasNamedIcon(item.id) ? item.id : null)}
                fallback={(item.iconLabel || item.label || item.id || "?").slice(0, 1).toUpperCase()}
              />
              {showBadge && <span className="shell-mobile-bottom-badge">{notificationCount > 9 ? "9+" : notificationCount}</span>}
            </span>
            <span className="shell-mobile-bottom-label">{item.label || item.id}</span>
          </button>
        );
      })}
      {showAssistant && (
        <button
          type="button"
          className={`shell-mobile-bottom-item${isChatOverlayOpen ? " is-active" : ""}`}
          onClick={() => {
            setIsChatOverlayOpen((open) => !open);
            setUnreadChatCount(0);
          }}
          aria-label={isChatOverlayOpen ? "Close assistant" : "Open assistant"}
          aria-expanded={isChatOverlayOpen}
          aria-controls="mozaiks-assistant-panel"
        >
          <span className="shell-mobile-bottom-glyph" aria-hidden="true">
            <FiMessageCircle className="shell-mobile-bottom-icon" />
            {unreadChatCount > 0 && <span className="shell-mobile-bottom-badge">{unreadChatCount > 9 ? "9+" : unreadChatCount}</span>}
          </span>
          <span className="shell-mobile-bottom-label">Assistant</span>
        </button>
      )}
    </nav>
  );
};

export default MobileBottomBar;
