/** Shared OIDC code flow. The host's validated auth contract owns configuration. */
const TRANSACTION_TTL_MS = 15 * 60 * 1000;

// Opt-in, numeric lifecycle evidence for the existing contained observer. Never
// pass credentials or let an observer alter authentication decisions or clocks.
function observeTransaction(event) {
  if (typeof window.__mozaiksAuthTransactionDiagnostic !== 'function') return;
  try { window.__mozaiksAuthTransactionDiagnostic(Object.freeze(event)); }
  catch { /* A diagnostic observer is not part of authentication control flow. */ }
}

export function safeReturnPath(value, fallback = '/') {
  if (typeof value !== 'string') return fallback;
  let decoded;
  try { decoded = decodeURIComponent(value); } catch { return fallback; }
  if (!decoded.startsWith('/') || decoded.startsWith('//')
      || /[\\\u0000-\u0020\u007f]/.test(decoded)) return fallback;
  const target = new URL(value, window.location.origin);
  return target.origin === window.location.origin ? target.pathname + target.search + target.hash : fallback;
}

function publicUrl(value, label) {
  let url;
  try { url = new URL(value); } catch { throw new Error(`${label} must be an absolute URL`); }
  const loopback = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && loopback))
      || url.username || url.password || url.hash) throw new Error(`${label} must use HTTPS`);
  return url;
}

function nativeRedirectUri(value, callbackRoute) {
  let url;
  try { url = new URL(value); } catch { throw new Error('Native OIDC redirect URI must be an absolute URL'); }
  if (!/^[a-z](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+:$/.test(url.protocol)
      || url.host || url.username || url.password || url.search || url.hash
      || url.pathname !== callbackRoute || value !== `${url.protocol}${callbackRoute}`) {
    throw new Error('Native OIDC redirect URI must use a reverse-domain scheme and the exact application callback path');
  }
  return value;
}

function randomValue() {
  const bytes = window.crypto.getRandomValues(new Uint8Array(32));
  return base64Url(bytes);
}

function base64Url(bytes) {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function jwtClaims(token) {
  if (typeof token !== 'string' || token.split('.').length !== 3) return null;
  try {
    const value = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const bytes = Uint8Array.from(atob(value), character => character.charCodeAt(0));
    const claims = JSON.parse(new TextDecoder().decode(bytes));
    return claims && typeof claims === 'object' && !Array.isArray(claims) ? claims : null;
  } catch { return null; }
}

function readJson(key) {
  try { return JSON.parse(sessionStorage.getItem(key)); } catch { return null; }
}

function fixedAdapter(user, routes) {
  return {
    routes,
    getCurrentUser: async () => user,
    getAccessToken: () => null,
    hasPendingAuthorization: () => false,
    onAuthStateChange: callback => { callback(user); return () => {}; },
    login: async () => {},
    logout: async () => { window.location.assign(routes.logout); },
    handleCallback: async () => { throw new Error('No OIDC sign-in is active'); },
  };
}

export function validateAuthBootstrap(authConfig) {
  const runtime = authConfig?.runtime;
  if (!runtime || typeof runtime.enabled !== 'boolean'
      || typeof runtime.local_development !== 'boolean' || typeof runtime.provider !== 'string' || !runtime.provider.trim()) {
    throw new Error('The host did not provide a valid authentication configuration');
  }
  if (typeof authConfig.required !== 'boolean'
      || (authConfig.required && authConfig.contract?.auth_required !== true)
      || (!authConfig.required && authConfig.contract !== null)) {
    throw new Error('The host did not provide consistent application authentication intent');
  }
  if (runtime.local_development && (runtime.enabled || runtime.provider !== 'none')) {
    throw new Error('Local development identity cannot be used with enabled authentication');
  }
  return runtime;
}

export function createAuthAdapter({ authConfig, appId = 'mozaiks', env = {}, authorizationTransport } = {}) {
  const runtime = validateAuthBootstrap(authConfig);
  const contract = authConfig.contract;
  const routes = contract?.routes || { login: '/login', callback: '/auth/callback', logout: '/login', post_login_default: '/' };
  for (const key of ['login', 'callback', 'logout', 'post_login_default']) {
    const path = routes[key];
    if (safeReturnPath(path, null) !== path) throw new Error('Authentication routes must be safe local paths');
  }
  if (runtime.local_development) {
    const user = runtime.user;
    if (!user || typeof user.id !== 'string' || !user.id) {
      throw new Error('The host did not provide its local development identity');
    }
    return fixedAdapter(user, routes);
  }
  if (!authConfig.required) return fixedAdapter(null, routes);
  if (!runtime.enabled) {
    throw new Error('Authentication is required but unavailable');
  }
  if (contract?.schema_version !== 'mozaiks.auth.v1' || contract.strategy !== 'oidc'
      || contract.frontend?.adapter !== 'oidc_pkce') throw new Error('A canonical OIDC contract is required');
  if (authorizationTransport !== undefined && typeof authorizationTransport?.open !== 'function') {
    throw new Error('Authorization transport must provide open');
  }

  // Build-time Vite values remain valid browser inputs. They never decide the
  // runtime's enabled/local mode; only the verified backend projection does.
  const frontend = Object.fromEntries(['authority', 'discovery_url', 'client_id', 'redirect_uri', 'scope'].map(key => {
    const publicValue = authConfig.frontend?.[key];
    const buildValue = env[contract.frontend[`${key}_env`]];
    return [key, (typeof publicValue === 'string' && publicValue.trim())
      || (typeof buildValue === 'string' && buildValue.trim()) || ''];
  }));
  if (!frontend.scope) frontend.scope = (contract.frontend.default_scopes || []).join(' ');
  const clientId = frontend?.client_id;
  if (typeof clientId !== 'string' || !clientId.trim()) throw new Error('OIDC client ID is missing');
  const authority = frontend.authority ? publicUrl(frontend.authority, 'OIDC authority').href.replace(/\/$/, '') : '';
  const discoveryUrl = publicUrl(frontend.discovery_url || (authority && `${authority}/.well-known/openid-configuration`), 'OIDC discovery URL').href;
  const redirectUri = authorizationTransport
    ? nativeRedirectUri(frontend.redirect_uri, routes.callback)
    : publicUrl(frontend.redirect_uri || new URL(routes.callback, window.location.origin).href, 'OIDC redirect URI').href;
  if (!authorizationTransport && redirectUri !== new URL(routes.callback, window.location.origin).href) {
    throw new Error('OIDC redirect URI must match this application callback route');
  }
  const scope = frontend.scope;
  if (typeof scope !== 'string' || !scope.split(/\s+/).includes('openid')) throw new Error('OIDC scope must include openid');

  const prefix = `mozaiks:${encodeURIComponent(appId)}:${encodeURIComponent(clientId)}:${encodeURIComponent(discoveryUrl)}`;
  const sessionKey = `${prefix}:session`;
  const transactionKey = `${prefix}:transactions`;
  const listeners = new Set();
  let metadataPromise;
  let callbackPromise;
  let callbackInProgress;
  let completedCallback;
  let authorizationPending = false;
  let sessionRevision = 0;
  let expirationTimer;

  function readSession() {
    const session = readJson(sessionKey);
    if (!session || typeof session.accessToken !== 'string' || !session.accessToken
        || !Number.isFinite(session.expiresAt) || session.expiresAt <= Date.now()
        || typeof session.user?.id !== 'string' || !session.user.id) {
      sessionStorage.removeItem(sessionKey);
      return null;
    }
    return session;
  }

  function notify() {
    clearTimeout(expirationTimer);
    const session = readSession();
    for (const callback of listeners) callback(session?.user || null);
    if (session && listeners.size) {
      expirationTimer = setTimeout(notify, Math.min(session.expiresAt - Date.now() + 1, 2147483647));
    }
  }

  function transactions(phase = 'pending-check', selectedState = null) {
    const stored = readJson(transactionKey);
    // Local duration clock, not issuer time. Cross-document epoch consistency
    // is required: an inconsistent/future timestamp fails closed below.
    // Token issuer timestamps still use Date.now().
    const timeOrigin = performance.timeOrigin;
    const performanceNow = performance.now();
    const now = timeOrigin + performanceNow;
    const pending = Object.create(null);
    const rejected = Object.create(null);
    for (const [state, entry] of Object.entries(stored && typeof stored === 'object' ? stored : {})) {
      const ageMs = Number.isFinite(entry?.createdAt) ? now - entry.createdAt : null;
      const reason = !entry || typeof entry.verifier !== 'string' || typeof entry.nonce !== 'string'
        || !Number.isFinite(entry.createdAt) ? 'malformed'
        : entry.createdAt > now ? 'future'
        : ageMs >= TRANSACTION_TTL_MS ? 'expired'
        : entry.redirectUri !== redirectUri ? 'redirect' : null;
      if (reason) rejected[state] = reason;
      else pending[state] = entry;
      observeTransaction({ event: 'transaction-checked', phase, timeOrigin, performanceNow,
        createdAt: Number.isFinite(entry?.createdAt) ? entry.createdAt : null,
        timestampType: typeof entry?.createdAt, comparisonTime: now, ageMs,
        reason: reason ?? 'valid', stateMatched: selectedState !== null && state === selectedState,
        futureThresholdMs: 0, ttlMs: TRANSACTION_TTL_MS });
    }
    return { pending, rejected };
  }

  async function metadata() {
    if (!metadataPromise) {
      metadataPromise = (async () => {
        const response = await fetch(discoveryUrl, { headers: { Accept: 'application/json' } });
        if (!response.ok) throw new Error(`OIDC discovery failed: HTTP ${response.status}`);
        const document = await response.json();
        const issuer = publicUrl(document.issuer, 'OIDC issuer').href.replace(/\/$/, '');
        if (authority && issuer !== authority) throw new Error('OIDC discovery issuer does not match the configured authority');
        publicUrl(document.authorization_endpoint, 'OIDC authorization endpoint');
        publicUrl(document.token_endpoint, 'OIDC token endpoint');
        if (document.end_session_endpoint) publicUrl(document.end_session_endpoint, 'OIDC logout endpoint');
        return document;
      })().catch(error => { metadataPromise = undefined; throw error; });
    }
    return metadataPromise;
  }

  function callbackParameters(value) {
    let url;
    try { url = new URL(value); } catch { throw new Error('Invalid authorization callback URL'); }
    if (typeof value !== 'string' || /[\u0000-\u0020\u007f]/.test(value)
        || value.includes('#') || value.split('?')[0] !== redirectUri) {
      throw new Error('Authorization callback URI does not match the configured redirect URI');
    }
    return url.searchParams;
  }

  async function exchangeCallback(callbackUrl) {
    const revision = sessionRevision;
    const params = callbackParameters(callbackUrl);
    const state = params.get('state');
    const { pending, rejected } = transactions('callback', state);
    const transaction = state && Object.hasOwn(pending, state) ? pending[state] : null;
    observeTransaction({ event: 'callback-state', stateMatched: Boolean(transaction),
      storedStateMatched: Boolean(state && (Object.hasOwn(pending, state) || Object.hasOwn(rejected, state))),
      reason: transaction ? 'valid' : rejected[state] || 'missing', pendingCount: Object.keys(pending).length });
    if (!transaction) throw new Error(`Login state is missing or expired. Restart sign-in. (state_failure=${rejected[state] || 'missing'})`);
    delete pending[state];
    sessionStorage.setItem(transactionKey, JSON.stringify(pending));
    observeTransaction({ event: 'transaction-consumed', createdAt: transaction.createdAt,
      pendingCount: Object.keys(pending).length });
    if (!authorizationTransport) {
      const cleanUrl = new URL(window.location.href);
      for (const key of ['code', 'state', 'error', 'error_description', 'session_state', 'iss']) cleanUrl.searchParams.delete(key);
      window.history.replaceState(window.history.state, '', cleanUrl.pathname + cleanUrl.search + cleanUrl.hash);
    }
    if (params.has('error')) throw new Error('Sign-in was not completed. Please try again.');
    const code = params.get('code');
    if (!code || params.getAll('code').length !== 1 || params.getAll('state').length !== 1) throw new Error('Invalid sign-in callback');
    const document = await metadata();
    if (params.has('iss') && params.get('iss') !== document.issuer) throw new Error('Sign-in callback issuer mismatch');
    const response = await fetch(document.token_endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'authorization_code', client_id: clientId, redirect_uri: redirectUri, code, code_verifier: transaction.verifier }).toString(),
    });
    if (!response.ok) throw new Error(`Token exchange failed: HTTP ${response.status}`);
    const data = await response.json();
    const claims = jwtClaims(data.id_token);
    let header;
    try { header = JSON.parse(atob(data.id_token.split('.')[0].replace(/-/g, '+').replace(/_/g, '/'))); } catch { header = null; }
    const now = Date.now() / 1000;
    const audiences = typeof claims?.aud === 'string' ? [claims.aud] : claims?.aud;
    // Tokens come directly from the configured HTTPS token endpoint. Validate
    // OIDC identity claims before using them; the API independently verifies access tokens.
    if (!claims || typeof header?.alg !== 'string' || header.alg === 'none' || !data.id_token.split('.')[2]
        || claims.iss !== document.issuer || !Array.isArray(audiences) || !audiences.includes(clientId)
        || (audiences.length > 1 && claims.azp !== clientId) || (claims.azp && claims.azp !== clientId)
        || typeof claims.sub !== 'string' || !claims.sub || claims.nonce !== transaction.nonce
        || !Number.isFinite(claims.exp) || claims.exp <= now
        || !Number.isFinite(claims.iat) || claims.iat > now + 60) throw new Error('Invalid OIDC identity token');
    if (typeof data.access_token !== 'string' || !data.access_token.trim()
        || typeof data.token_type !== 'string' || data.token_type.toLowerCase() !== 'bearer') throw new Error('Invalid OIDC access token response');
    const accessClaims = jwtClaims(data.access_token);
    const lifetime = Number.isFinite(data.expires_in) && data.expires_in > 0 ? now + data.expires_in : accessClaims?.exp;
    const expiresAt = Math.min(lifetime, claims.exp, Number.isFinite(accessClaims?.exp) ? accessClaims.exp : Infinity) * 1000;
    if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) throw new Error('OIDC token lifetime is missing or expired');
    const roles = claims.realm_access?.roles || claims.roles;
    const user = {
      id: claims.sub, user_id: claims.sub,
      email: typeof claims.email === 'string' ? claims.email : null,
      name: claims.name || claims.preferred_username || claims.email || claims.sub,
      firstName: claims.given_name || null, lastName: claims.family_name || null,
      roles: Array.isArray(roles) ? roles.filter(role => typeof role === 'string') : [],
    };
    if (sessionRevision !== revision) throw new Error('Sign-in was cancelled. Restart sign-in.');
    sessionStorage.setItem(sessionKey, JSON.stringify({ accessToken: data.access_token, idToken: data.id_token, expiresAt, user }));
    notify();
    return { returnPath: safeReturnPath(transaction.returnPath, routes.post_login_default) };
  }

  function handleCallback(callbackUrl) {
    const value = callbackUrl === undefined ? window.location.href : callbackUrl;
    if (callbackPromise) {
      if (callbackUrl === undefined || value === callbackInProgress) return callbackPromise;
      return Promise.reject(new Error('A different sign-in callback is already in progress'));
    }
    // Reject unrelated native links before consuming state or changing identity.
    try { callbackParameters(value); } catch (error) { return Promise.reject(error); }
    // A callback page may remount after auth notification. Its one-time state
    // is already consumed and scrubbed. Return only this document's completed
    // exchange, never a replayed URL or authority from a fresh/expired session.
    if (callbackUrl === undefined && completedCallback?.url === value
        && completedCallback.revision === sessionRevision
        && completedCallback.session === sessionStorage.getItem(sessionKey) && readSession()) {
      return Promise.resolve(completedCallback.result);
    }
    completedCallback = undefined;
    callbackInProgress = value;
    callbackPromise = exchangeCallback(value).then(result => {
      if (!authorizationTransport) completedCallback = {
        url: window.location.href, revision: sessionRevision,
        session: sessionStorage.getItem(sessionKey), result,
      };
      return result;
    }).catch(error => {
      sessionStorage.removeItem(sessionKey);
      notify();
      throw error;
    }).finally(() => { callbackPromise = undefined; callbackInProgress = undefined; });
    return callbackPromise;
  }

  return {
    routes,
    getCurrentUser: async () => readSession()?.user || null,
    getAccessToken: () => readSession()?.accessToken || null,
    onAuthStateChange: callback => {
      listeners.add(callback);
      notify();
      return () => { listeners.delete(callback); if (!listeners.size) clearTimeout(expirationTimer); };
    },
    login: async ({ returnPath } = {}) => {
      observeTransaction({ event: 'login-start', sessionRevision });
      completedCallback = undefined;
      if (authorizationTransport && authorizationPending) throw new Error('Authorization is already in progress');
      if (authorizationTransport) authorizationPending = true;
      const revision = sessionRevision;
      let state;
      try {
        const document = await metadata();
        const verifier = randomValue();
        const challenge = base64Url(new Uint8Array(await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))));
        if (sessionRevision !== revision) throw new Error('Sign-in was cancelled. Restart sign-in.');
        state = randomValue();
        const nonce = randomValue();
        const { pending } = transactions('login-prune');
        const timeOrigin = performance.timeOrigin;
        const performanceNow = performance.now();
        pending[state] = { verifier, nonce, createdAt: timeOrigin + performanceNow, redirectUri, returnPath: safeReturnPath(returnPath, routes.post_login_default) };
        const serialized = JSON.stringify(pending);
        sessionStorage.setItem(transactionKey, serialized);
        if (typeof window.__mozaiksAuthTransactionDiagnostic === 'function') {
          observeTransaction({ event: 'transaction-created', timeOrigin, performanceNow,
            createdAt: pending[state].createdAt, serializedCreatedAt: JSON.parse(serialized)[state].createdAt,
            pendingCount: Object.keys(pending).length, ttlMs: TRANSACTION_TTL_MS, futureThresholdMs: 0 });
        }
        const url = new URL(document.authorization_endpoint);
        for (const [key, value] of Object.entries({ client_id: clientId, redirect_uri: redirectUri, response_type: 'code', scope, code_challenge: challenge, code_challenge_method: 'S256', state, nonce })) url.searchParams.set(key, value);
        if (!authorizationTransport) { window.location.assign(url.href); return; }
        const callbackUrl = await authorizationTransport.open({ url: url.href, callbackUri: redirectUri });
        if (sessionRevision !== revision) throw new Error('Sign-in was cancelled. Restart sign-in.');
        if (callbackParameters(callbackUrl).get('state') !== state) throw new Error('Invalid sign-in callback state');
        return await handleCallback(callbackUrl);
      } finally {
        if (authorizationTransport) {
          const { pending } = transactions('native-cleanup');
          if (state) delete pending[state];
          sessionStorage.setItem(transactionKey, JSON.stringify(pending));
          observeTransaction({ event: 'native-cleanup', pendingCount: Object.keys(pending).length });
          authorizationPending = false;
        }
      }
    },
    hasPendingAuthorization: () => Object.keys(transactions().pending).length > 0,
    logout: async () => {
      completedCallback = undefined;
      const session = readSession();
      sessionRevision += 1;
      sessionStorage.removeItem(sessionKey);
      sessionStorage.removeItem(transactionKey);
      observeTransaction({ event: 'transactions-cleared', sessionRevision });
      notify();
      let document;
      try { document = await metadata(); } catch { /* Local logout still succeeds. */ }
      if (!document?.end_session_endpoint) { window.location.assign(routes.logout); return; }
      const url = new URL(document.end_session_endpoint);
      url.searchParams.set('client_id', clientId);
      url.searchParams.set('post_logout_redirect_uri', authorizationTransport ? redirectUri : new URL(routes.logout, window.location.origin).href);
      if (session?.idToken) url.searchParams.set('id_token_hint', session.idToken);
      if (!authorizationTransport) { window.location.assign(url.href); return; }
      if (authorizationPending) throw new Error('Authorization is already in progress');
      authorizationPending = true;
      try {
        const state = randomValue();
        const startedAt = Date.now();
        url.searchParams.set('state', state);
        const callbackUrl = await authorizationTransport.open({ url: url.href, callbackUri: redirectUri });
        const params = callbackParameters(callbackUrl);
        if (params.getAll('state').length !== 1 || params.get('state') !== state
            || params.has('code') || params.has('error') || Date.now() < startedAt
            || Date.now() - startedAt > TRANSACTION_TTL_MS) {
          throw new Error('Invalid sign-out callback');
        }
        window.location.assign(routes.logout);
      } finally {
        authorizationPending = false;
      }
    },
    handleCallback,
  };
}

/** One verified bootstrap, shared by shell navigation and the chosen auth adapter. */
export async function loadShellAuth({ apiBaseUrl = '', createAppAuthAdapter, env = {} } = {}) {
  const response = await fetch(`${apiBaseUrl.replace(/\/$/, '')}/api/shell-config`, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Application sign-in configuration failed: HTTP ${response.status}`);
  const shellConfig = await response.json();
  const runtime = validateAuthBootstrap(shellConfig.auth);
  const options = { authConfig: shellConfig.auth, appId: shellConfig.appId, env };
  const authAdapter = await (runtime.enabled && shellConfig.auth.required && typeof createAppAuthAdapter === 'function'
    ? createAppAuthAdapter(options) : createAuthAdapter(options));
  for (const name of ['getCurrentUser', 'getAccessToken', 'onAuthStateChange', 'login', 'logout']) {
    if (typeof authAdapter?.[name] !== 'function') throw new Error(`App authentication adapter is missing ${name}`);
  }
  return { authAdapter, shellConfig };
}
