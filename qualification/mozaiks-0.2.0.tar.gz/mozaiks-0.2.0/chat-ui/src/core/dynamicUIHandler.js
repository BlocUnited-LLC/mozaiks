// ==============================================================================
// FILE: chat-ui/src/core/dynamicUIHandler.js
// DESCRIPTION: Handles dynamic UI updates from backend transport system
// ==============================================================================

/**
 * Dynamic UI Handler
 * Processes backend UI events and triggers appropriate frontend updates
 * Bridges transport system with UI components (no duplication)
 */

import { appApi } from '../adapters/api';
import { createToolsLogger } from './toolsLogger';
import { UI_RENDER, UI_UPDATE, UI_DISMISS } from './ui/uiEventTypes';

export class DynamicUIHandler {
  constructor() {
    this.eventHandlers = new Map();
    this.uiUpdateCallbacks = new Set();
    this.workflowCache = new Map();
    // Track last speaker (agent) per chat_id or workflow to maintain correct attribution
    // Keyed by chat_id if available, else workflow_name
    this._lastSpeaker = new Map();
    this.setupDefaultHandlers();
  }

  /**
   * Setup default event handlers for backend UI events
   */
  setupDefaultHandlers() {
    // Register only canonical lowercase event types
    this.registerHandler('tool_call', this.handleToolCall.bind(this));
    this.registerHandler('component_update', this.handleComponentUpdate.bind(this));
    this.registerHandler('status', this.handleStatusUpdate.bind(this));

    // ui.* typed event contract (L2)
    this.registerHandler(UI_RENDER, this.handleUIRender.bind(this));
    this.registerHandler(UI_UPDATE, this.handleUIUpdate.bind(this));
    this.registerHandler(UI_DISMISS, this.handleUIDismiss.bind(this));

  }

  /**
   * Register a custom event handler
   * @param {string} eventType - Event type to handle
   * @param {Function} handler - Handler function
   */
  registerHandler(eventType, handler) {
    this.eventHandlers.set(eventType, handler);
  }

  /**
   * Process incoming UI event from transport layer
   * @param {Object} eventData - Event data from backend
   * @param {Function} sendResponse - Optional acknowledged response callback
   */
  async processUIEvent(eventData, sendResponse = null) {
    if (!eventData) return;

    const originalType = eventData?.type;
    let type = originalType;
    let data = eventData?.data;

    // Support transports that send payload fields at the top level instead of nested under data
    if (data === undefined || data === null) {
      const { type: _ignoredType, data: _ignoredData, ...rest } = eventData || {};
      data = Object.keys(rest).length ? rest : {};
    }

    if (typeof type !== 'string' || !type) {
      console.warn('⚠️ Received UI event with invalid type, ignoring:', eventData);
      return;
    }
    if (type !== type.toLowerCase()) {
      // Enforce strictness: reject mixed-case emissions instead of silently normalizing
      console.warn(`⚠️ Rejecting non-lowercase UI event type '${type}' (expected canonical lowercase)`);
      return;
    }

    // Resolve agent attribution in a workflow-agnostic way. Prefer explicit fields, then payload keys,
    // then previously tracked last speaker for the chat/workflow.
    const resolveAgentName = (evt) => {
      if (!evt) return null;
      const payload = evt.data || evt.payload || {};
      const candidates = [
        evt.agentName,
        evt.agent_name,
        evt.agent,
        payload?.agentName,
        payload?.agent_name,
        payload?.agent,
        payload?.speaker,
        payload?.sender,
      ];
      for (const c of candidates) {
        if (typeof c === 'string' && c.trim()) return c.trim();
      }

      // fallback to tracked last speaker for this chat_id or workflow_name
      const chatId = payload?.chat_id || evt?.chat_id || evt?.chatId || null;
      const wf = payload?.workflow_name || evt?.workflow_name || evt?.workflow || null;
      const key = chatId || wf || null;
      if (key && this._lastSpeaker.has(key)) return this._lastSpeaker.get(key);
      return null;
    };

    const resolvedAgent = resolveAgentName(eventData);
    if (resolvedAgent) {
      // Ensure both canonical keys are present on payload and top-level event for downstream consumers
      if (!data) data = {};
      data.agentName = data.agentName || resolvedAgent;
      data.agent_name = data.agent_name || resolvedAgent;
    }

    const handler = this.eventHandlers.get(type);
    if (!handler) {
      console.warn(`⚠️ No handler found for UI event type: ${type}`);
      return;
    }

    try {
      if (type === 'tool_call' || type === UI_RENDER) {
        await handler(data, sendResponse);
      } else {
        await handler(data, eventData);
      }
    } catch (error) {
      console.error(`❌ Error processing UI event ${type}:`, error);
    }
  }

  /**
   * Handle artifact routing events
   * @param {Object} data - Artifact event data
   */

  /**
   * Handle UI tool action events
   * @param {Object} data - Tool action data
   */

  /**
   * Handle component update events
   * @param {Object} data - Component update data
   */
  async handleComponentUpdate(data) {
    
    if (data.component_id && data.updates) {
      this.notifyUIUpdate({
        type: 'component_update',
        componentId: data.component_id,
        updates: data.updates,
        app_id: data.app_id
      });
    }
  }

  /**
   * Handle status update events
   * @param {Object} data - Status data
   */
  handleStatusUpdate(data) {
    
    this.notifyUIUpdate({
      type: 'status_update',
      status: data.status,
      message: data.message,
      progress: data.progress
    });
  }

  /**
   * Register a UI update callback
   * @param {Function} callback - Callback to notify of UI updates
   */
  onUIUpdate(callback) {
    this.uiUpdateCallbacks.add(callback);
    return () => this.uiUpdateCallbacks.delete(callback);
  }

  /**
   * Notify all registered callbacks of UI updates
   * @param {Object} updateData - Update data
   */
  notifyUIUpdate(updateData) {
    try {
      const toolName = updateData?.tool_name || updateData?.toolName || null;
      const componentType = updateData?.component_type || updateData?.component || null;
      const display = updateData?.display || updateData?.display_mode || updateData?.mode || null;
      const payload = updateData?.payload && typeof updateData.payload === 'object' ? updateData.payload : null;
      if (toolName || componentType || display) {
        const logger = createToolsLogger({ tool: toolName || componentType || 'ui_update' });
        logger.info('UI UPDATE DISPATCH', {
          type: updateData?.type || null,
          tool_name: toolName,
          component_type: componentType,
          display,
          payload_keys: payload ? Object.keys(payload).slice(0, 20) : [],
          has_structured_output: Boolean(payload?.structured_output && typeof payload.structured_output === 'object'),
        });
      }
    } catch (err) {
      try { console.debug('Failed to log UI update dispatch', err); } catch {}
    }
    for (const callback of this.uiUpdateCallbacks) {
      try {
        callback(updateData);
      } catch (error) {
        console.error('❌ Error in UI update callback:', error);
      }
    }
  }

  /**
   * Get workflow configuration from backend
   */
  async getWorkflowConfig(workflowname) {
    if (!workflowname) {
      throw new Error('Workflow name is required');
    }
    
    const cacheKey = workflowname;
    
    if (this.workflowCache.has(cacheKey)) {
      return this.workflowCache.get(cacheKey);
    }

    try {
      const response = await appApi.get(`/workflow/${workflowname}/config`);
      const config = response.data;
      
      this.workflowCache.set(cacheKey, config);
      
      return config;
      
    } catch (error) {
      console.error(`❌ Failed to load workflow config: ${workflowname}`, error);
      return { visual_agents: [] };
    }
  }

  /**
   * Get component definition from workflow config
   */
  async getComponentDefinition(componentName, workflowname) {
    if (!workflowname) {
      throw new Error('Workflow name is required');
    }
    
    try {
      const config = await this.getWorkflowConfig(workflowname);
      
      const agentCollections = [];
      if (Array.isArray(config?.inline_component_agents)) {
        agentCollections.push(config.inline_component_agents);
      }
      if (Array.isArray(config?.artifact_component_agents)) {
        agentCollections.push(config.artifact_component_agents);
      }
      if (Array.isArray(config?.visual_agents_metadata)) {
        agentCollections.push(config.visual_agents_metadata);
      }

      for (const collection of agentCollections) {
        for (const agent of collection) {
          if (!agent || typeof agent !== 'object') {
            continue;
          }
          const components = Array.isArray(agent.components) ? agent.components : [];
          const component = components.find(c => c?.name === componentName);
          if (component) {
            return {
              ...component,
              agentName: agent.name,
              agentRole: agent.role
            };
          }
        }
      }
      
      console.warn(`⚠️ Component ${componentName} not found in workflow ${workflowname}`);
      return null;
      
    } catch (error) {
      console.error(`❌ Failed to get component definition: ${componentName}`, error);
      return null;
    }
  }

  // ─── ui.* typed event handlers (L2 contract) ──────────────────────────────

  /**
   * Handle ``ui.render`` events — typed replacement for ``chat.tool_call`` for
   * tool-driven UI surface rendering.
   *
   * Reads from the typed UIRenderData contract fields and normalises them into
   * the same shape that notifyUIUpdate / ChatPage subscribers expect, so no
   * downstream consumer needs to change.
   *
   * @param {Object} eventData  Already-extracted inner data (type stripped).
   * @param {Function} responseCallback  Callback to send tool_call_response.
   */
  async handleUIRender(eventData, responseCallback) {
    try {
      // Typed contract fields (see UIRenderData in ui_events.py)
      const component = eventData.component || eventData.component_type || '';
      const toolName = eventData.tool_name || component;
      const toolCallId = eventData.tool_call_id || null;
      const workflowName = eventData.workflow_name || eventData.workflow || null;
      const display = eventData.display || eventData.display_mode || 'inline';
      const awaiting = eventData.awaiting_response !== false;
      const interactionType = eventData.interaction_type || (awaiting ? 'ui_tool' : 'ui_surface');
      const payload = { ...(eventData.payload || {}) };

      const agentName = eventData.agentName || eventData.agent_name || eventData.agent || null;
      if (agentName) {
        payload.agentName = payload.agentName || agentName;
        payload.agent_name = payload.agent_name || agentName;
        const chatKey = payload?.chat_id || eventData.chat_id || workflowName || null;
        if (chatKey) this._lastSpeaker.set(chatKey, agentName);
      }

      // Enrich payload with contract fields so WorkflowUIRouter can resolve
      // the component via its existing workflow:component registry key.
      payload.component_type = payload.component_type || component;
      payload.workflow_name = payload.workflow_name || workflowName;
      payload.awaiting_response = awaiting;
      payload.interaction_type = interactionType;
      if (display) payload.display = payload.display || display;

      if (!toolName) {
        console.error('❌ Missing component/tool_name in ui.render event');
        return null;
      }

      // Skip auto-tool events without an explicit display surface
      if (interactionType === 'auto_tool' && !display) {
        return true;
      }

      const onResponse = async (response) => {
        if (responseCallback && typeof responseCallback === 'function') {
          const accepted = await responseCallback({
            type: 'tool_call_response',
            tool_name: toolName,
            tool_call_id: toolCallId,
            workflow_name: workflowName,
            response,
          });
          if (accepted === false) throw new Error('The server has not accepted this response.');
        } else {
          throw new Error('The workflow response connection is unavailable.');
        }
      };

      this.notifyUIUpdate({
        type: UI_RENDER,
        tool_name: toolName,
        tool_call_id: toolCallId,
        component_type: component,
        payload,
        workflow_name: workflowName,
        display: display || 'inline',
        onResponse,
        agent_name: agentName || undefined,
        agentName: agentName || undefined,
        agent: agentName || undefined,
      });

      return true;
    } catch (error) {
      console.error('❌ DynamicUIHandler: Error handling ui.render event', error);
      return null;
    }
  }

  /**
   * Handle ``ui.update`` events — patch a live component's payload in place.
   * @param {Object} eventData  UIUpdateData fields.
   */
  async handleUIUpdate(eventData) {
    const toolCallId = eventData.tool_call_id || null;
    const patch = eventData.patch || {};
    if (!toolCallId) {
      console.warn('⚠️ DynamicUIHandler: ui.update missing tool_call_id');
      return;
    }
    this.notifyUIUpdate({ type: UI_UPDATE, tool_call_id: toolCallId, patch });
  }

  /**
   * Handle ``ui.dismiss`` events — signal that a rendered component should be
   * removed.
   * @param {Object} eventData  UIDismissData fields.
   */
  handleUIDismiss(eventData) {
    const toolCallId = eventData.tool_call_id || null;
    if (!toolCallId) {
      console.warn('⚠️ DynamicUIHandler: ui.dismiss missing tool_call_id');
      return;
    }
    this.notifyUIUpdate({ type: UI_DISMISS, tool_call_id: toolCallId });
  }

  // ─── chat.tool_call handler ───────────────────────────────────────────────

  /**
   * Handle workflow UI tool_call events
   * @param {Object} eventData - Event data from backend
   * @param {Function} responseCallback - Callback to send response to backend
   */
  async handleToolCall(eventData, responseCallback) {
    try {

      const {
        tool_name,
        payload = {},
        tool_call_id,
        workflow_name,
        component_type,
      } = eventData;
      const toolName = tool_name || payload.tool_name || component_type;
      const toolCallId = tool_call_id || payload.tool_call_id || eventData?.corr || null;
      const agentName = eventData?.agentName || eventData?.agent_name || eventData.agent_name || eventData.agent || null;
      // Logging: record how agent attribution was resolved for auditing/debugging
      try {
        const logger = createToolsLogger({ tool: toolName, toolCallId, workflowName: workflow_name, agentMessageId: payload?.agent_message_id });
        const provided = {
          top_level_agent: eventData.agentName || eventData.agent_name || eventData.agent || null,
          payload_agent: payload?.agentName || payload?.agent_name || payload?.agent || null,
          resolved: agentName || null,
        };
        const chatKey = payload?.chat_id || eventData.chat_id || eventData.chatId || workflow_name || eventData.workflow_name || null;
        logger.info('UI TOOL ATTRIBUTION', { tool_name: toolName, workflow_name, chatKey, ...provided });
      } catch (err) {
        try { console.debug('Failed to log UI tool attribution', err); } catch {}
      }
      if (agentName) {
        if (payload.agentName !== agentName) {
          payload.agentName = agentName;
        }
        if (payload.agent_name !== agentName) {
          payload.agent_name = agentName;
        }
        // Track last speaker for this chat/workflow
        const chatKey = payload?.chat_id || eventData.chat_id || eventData.chatId || workflow_name || eventData.workflow_name || null;
        if (chatKey) {
          this._lastSpeaker.set(chatKey, agentName);
          try {
            const logger = createToolsLogger({ tool: toolName, toolCallId, workflowName: workflow_name, agentMessageId: payload?.agent_message_id });
            logger.info('Updated last speaker', { chatKey, agentName });
          } catch (err) {
            try { console.debug('Failed to log last speaker update', err); } catch {}
          }
        }
      }

      if (!toolName) {
        console.error('❌ Missing tool_name in tool_call event');
        return null;
      }

      // Create response handler that sends data back to backend
      const onResponse = async (response) => {
        const tlog = createToolsLogger({ tool: toolName, toolCallId, workflowName: workflow_name, agentMessageId: payload?.agent_message_id });
        
        if (responseCallback && typeof responseCallback === 'function') {
          const accepted = await responseCallback({
            type: 'tool_call_response',
            tool_name: toolName,
            tool_call_id: toolCallId,
            workflow_name,
            response
          });
          if (accepted === false) throw new Error('The server has not accepted this response.');
        } else {
          throw new Error('The workflow response connection is unavailable.');
        }
        tlog.event('ui_response', response?.status || 'unknown');
      };

  // Determine display mode ('composer', 'inline', or 'artifact') with robust fallbacks
      const display = eventData.display || eventData.display_type || (payload && (payload.display || payload.mode)) || null;
      try {
        const logger = createToolsLogger({ tool: toolName, toolCallId, workflowName: workflow_name, agentMessageId: payload?.agent_message_id });
        logger.info('UI TOOL DISPATCH', {
          tool_name: toolName,
          component_type: component_type || payload?.component_type || toolName,
          workflow_name,
          display: display || 'inline',
          payload_keys: Object.keys(payload || {}).slice(0, 20),
          has_structured_output: Boolean(payload?.structured_output && typeof payload.structured_output === 'object'),
        });
      } catch (err) {
        try { console.debug('Failed to log UI tool dispatch', err); } catch {}
      }

      // CRITICAL: Skip rendering for auto-tool events without explicit display mode
      // Auto-tool events are followed by explicit tool calls with proper display settings
      if (payload?.interaction_type === 'auto_tool' && !display) {
        return true; // Successful processing, just not rendering yet
      }

      // Default to inline only if the tool call did not declare a surface
      const finalDisplay = display || 'inline';

      // SIMPLIFIED: Just notify UI callbacks - let ChatInterface handle rendering
      // This eliminates duplication with eventDispatcher
  this.notifyUIUpdate({
        type: 'tool_call',
        tool_name: toolName,
        tool_call_id: toolCallId,
        component_type: component_type || payload?.component_type || toolName,
        payload,
        workflow_name,
        display: finalDisplay,
        onResponse,
        agent_name: agentName || undefined,
        agentName: agentName || undefined,
        agent: agentName || undefined
      });


      return true; // Indicate successful processing

    } catch (error) {
      console.error('❌ DynamicUIHandler: Error handling tool_call event', error);
      return null;
    }
  }

}

// Export singleton instance
export const dynamicUIHandler = new DynamicUIHandler();
export default dynamicUIHandler;
