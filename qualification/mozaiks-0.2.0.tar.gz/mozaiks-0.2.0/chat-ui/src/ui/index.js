/**
 * @mozaiks/chat-ui/ui — web UI primitives layer
 *
 * Web-safe presentational primitives for Studio, app pages, and custom routes.
 * React Native screen components (MessageBubble, ChatScreen, etc.) are in
 * ui/screens/, ui/components/, and ui/navigation/ but are not exported here
 * to keep the web bundle free of react-native dependencies.
 */

export {
  ActionButton,
  Alert,
  AlertBanner,
  AnalyticsSummaryStrip,
  Button,
  ChatInput,
  ChatMessageBubble,
  ChatThread,
  CodeBlock,
  CollectionToolbar,
  DataTable,
  emitAppEvent,
  Empty,
  ErrorState,
  ContentRail,
  FileList,
  Form,
  Grid,
  ArtifactLoadingState,
  IconButton,
  InlineEmptyState,
  InsightList,
  LinkButton,
  LoadingState,
  Metric,
  MetricBridge,
  MetricSummaryStrip,
  Modal,
  PageHeader,
  Panel,
  PerformanceTileGrid,
  ProgressTracker,
  ResourceList,
  ResourceTable,
  SegmentedBar,
  SegmentedControl,
  SlideOver,
  Skeleton,
  StageFunnel,
  StatusPill,
  SummaryStrip,
  SurfaceCard,
  Timeline,
  UsageTrendPanel,
} from './primitives/index.js';

export { default as OnboardingTour } from './components/OnboardingTour.jsx';
export { parseOnboardingConfigSource } from './lib/onboardingConfig.js';
