/**
 * Form primitive — declarative form with validation and agent-controlled fields.
 *
 * Schema properties:
 *   id           {string}    — component id for event routing
 *   fields       {Field[]}   — field definitions (see below)
 *   layout       {string}    — "vertical" | "horizontal" | "grid"
 *   columns      {number}    — column count when layout=grid (default 2)
 *   submit_label {string}    — submit button text (default "Submit")
 *   onSubmit     {Function}  — (values: Record<string, any>) => void
 *   onCancel     {Function}
 *   cancel_label {string}
 *   disabled     {boolean}
 *
 * Field schema:
 *   name         {string}
 *   label        {string}
 *   type         {string}    — "text" | "email" | "password" | "number" | "textarea" | "select" | "checkbox"
 *   required     {boolean}
 *   placeholder  {string}
 *   default_value {string|number|boolean|null}
 *   options      {Array<{value, label}>}  — for select
 *
 * Agent event: ui.form.set_field
 *   payload: { component_id, field, value }
 */

import { useState, useCallback, useEffect, useRef } from 'react';
import { Input } from '../base/components/input.jsx';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../base/components/select.jsx';
import { Button } from './Button.jsx';
import { useAppEvent } from '../hooks/useAppEventBus.js';
import { cn } from '../lib/cn.js';

const GRID_COL_CLASS = {
  1: 'grid-cols-1',
  2: 'grid-cols-1 sm:grid-cols-2',
  3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
  4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4',
  5: 'grid-cols-1 sm:grid-cols-3 lg:grid-cols-5',
  6: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6',
};

function buildInitialValues(fields, initialValues) {
  return Object.fromEntries(
    fields.map((f) => [f.name, initialValues?.[f.name] ?? f.default_value ?? (f.type === 'checkbox' ? false : '')])
  );
}

// Inputs hand back strings, but a module action validates the submitted body
// against its declared input_schema, where a `number` field is a JSON number
// and a `select` option keeps the type it was declared with. Submit the values
// the declared field types describe; an empty optional number/select has no
// representable value and is left out of the body.
function coerceSubmittedValues(fields, values) {
  const out = { ...values };
  for (const f of fields) {
    const value = out[f.name];
    if (f.type === 'number') {
      if (value === '' || value === null || value === undefined) { delete out[f.name]; continue; }
      const parsed = typeof value === 'number' ? value : Number(value);
      if (Number.isFinite(parsed)) out[f.name] = parsed;
    } else if (f.type === 'select') {
      if (value === '' || value === null || value === undefined) { delete out[f.name]; continue; }
      const option = (f.options ?? []).find((opt) => String(opt.value) === String(value));
      if (option) out[f.name] = option.value;
    } else if (f.type === 'checkbox') {
      out[f.name] = !!value;
    }
  }
  return out;
}

function FieldRenderer({ field, value, onChange, disabled, fieldId }) {
  const baseClass = 'w-full';
  switch (field.type) {
    case 'textarea':
      return (
        <textarea
          id={fieldId}
          className={cn(
            baseClass,
            'min-h-[120px] rounded-[var(--shell-control-radius,1rem)] border border-input bg-transparent px-4 py-3 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:opacity-50'
          )}
          placeholder={field.placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          required={field.required}
        />
      );
    case 'select':
      return (
        <Select value={value} onValueChange={onChange} disabled={disabled}>
          <SelectTrigger id={fieldId} className={cn(baseClass, 'h-11 rounded-[var(--shell-control-radius,1rem)] px-4')}>
            <SelectValue placeholder={field.placeholder ?? `Select ${field.label}`} />
          </SelectTrigger>
          <SelectContent>
            {(field.options ?? []).map((opt) => (
              <SelectItem key={opt.value} value={String(opt.value)}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    case 'checkbox':
      return (
        <div className="flex items-center gap-2">
          <input
            id={fieldId}
            type="checkbox"
            checked={!!value}
            onChange={(e) => onChange(e.target.checked)}
            disabled={disabled}
            className="h-4 w-4 rounded border border-input"
          />
          {field.placeholder && <span className="text-sm text-muted-foreground">{field.placeholder}</span>}
        </div>
      );
    default:
      return (
        <Input
          id={fieldId}
          type={field.type ?? 'text'}
          placeholder={field.placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          required={field.required}
          className={cn(baseClass, 'h-11 rounded-[var(--shell-control-radius,1rem)] px-4')}
        />
      );
  }
}

export function Form({
  id,
  fields = [],
  initial_values = null,
  layout = 'vertical',
  columns = 2,
  submit_label = 'Submit',
  onSubmit,
  onCancel,
  cancel_label = 'Cancel',
  disabled = false,
  className,
}) {
  const [values, setValues]  = useState(() => buildInitialValues(fields, initial_values));
  const [errors, setErrors]  = useState({});
  const [loading, setLoading] = useState(false);
  const previousInitialValues = useRef(initial_values);
  useEffect(() => {
    // Initialization already happened in useState. Repeating it after paint
    // can erase an edit made before the first passive effect runs.
    if (previousInitialValues.current === initial_values) return;
    previousInitialValues.current = initial_values;
    setValues(buildInitialValues(fields, initial_values));
    setErrors({});
  }, [initial_values]);

  const setField = useCallback((name, value) => {
    setValues((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  }, []);

  // Agent-controlled field updates
  useAppEvent('ui.form.set_field', id, ({ field, value }) => {
    if (field) setField(field, value);
  });

  const validate = () => {
    const newErrors = {};
    for (const f of fields) {
      const value = values[f.name];
      if (f.required && ((typeof value === 'string' && !value.trim()) || (!value && value !== false))) {
        newErrors[f.name] = `${f.label} is required`;
      }
    }
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) { setErrors(newErrors); return; }
    setLoading(true);
    try { await onSubmit?.(coerceSubmittedValues(fields, values)); }
    finally { setLoading(false); }
  };

  const resolvedColumns = Number(columns) || 2;
  const gridClass = layout === 'grid'
    ? cn('grid gap-4', GRID_COL_CLASS[resolvedColumns] ?? GRID_COL_CLASS[2])
    : 'space-y-4';

  return (
    <form onSubmit={handleSubmit} className={cn(className)} noValidate>
      <div className={gridClass}>
        {fields.map((field) => {
          const fieldId = `${id || 'form'}-${field.name}`.replace(/[^A-Za-z0-9_-]/g, '-');
          return (
            <div key={field.name} className="space-y-1.5">
              <label htmlFor={fieldId} className="text-sm font-medium text-foreground">
                {field.label}
                {field.required && <span className="text-destructive ml-1">*</span>}
              </label>
              <FieldRenderer
                field={field}
                fieldId={fieldId}
                value={values[field.name]}
                onChange={(val) => setField(field.name, val)}
                disabled={disabled || loading}
              />
              {errors[field.name] && (
                <p className="text-xs text-destructive">{errors[field.name]}</p>
              )}
            </div>
          );
        })}
      </div>
      {(onSubmit || onCancel) && <div className="mt-6 flex flex-col-reverse gap-3 border-t border-border/60 pt-4 sm:flex-row sm:items-center sm:justify-end">
        {onSubmit && <Button
          type="submit"
          label={loading ? 'Saving…' : submit_label}
          variant="primary"
          className="w-full sm:w-auto"
          disabled={disabled || loading}
        />}
        {onCancel && (
          <Button
            type="button"
            label={cancel_label}
            variant="ghost"
            onClick={onCancel}
            className="w-full sm:w-auto"
            disabled={loading}
          />
        )}
      </div>}
    </form>
  );
}
