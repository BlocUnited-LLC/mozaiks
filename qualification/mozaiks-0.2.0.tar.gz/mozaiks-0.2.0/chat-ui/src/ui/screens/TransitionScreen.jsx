/**
 * TransitionScreen — shell-level transition renderer.
 *
 * Fetches a transition by id from /api/transitions/{id}, resolves the registered
 * React component from transition.ui.component, and mounts it with
 * { transition, onResolve } props.
 *
 * transition_type behavior:
 *   user_choice — renders transition.ui.component or falls back to LauncherScreen
 *   confirm     — renders transition.ui.component or falls back to ConfirmScreen
 *   condition   — asks the backend router to evaluate context_key and continue
 *   silent      — asks the backend router to continue immediately
 *
 * Subscribes to routing.transition.resolve bus for mid-flight transition chaining.
 *
 * Props:
 *   transitionId {string}   Transition id to fetch and render
 *   onNavigate   {Function} (option_id?: string|null, runtime_context?: object) => void
 *   context      {object}   Optional live runtime context (AG2 context_variables) merged
 *                           into transition.context before the component receives it.
 *                           Used by components like AppReviewScreen to read build_registry_id,
 *                           preview_url, validation results, and lifecycle_state.
 */

import { useState, useEffect, useCallback, useId } from 'react';
import { useNavigate } from 'react-router-dom';
import { getComponent, hasComponent } from '../../registry/componentRegistry';
import { LauncherScreen } from './LauncherScreen';
import { ConfirmScreen } from './ConfirmScreen';
import { TransitionOverlayFrame } from './TransitionOverlayFrame.jsx';
import { useAppEventBus } from '../hooks/useAppEventBus';

// ---------------------------------------------------------------------------
// Loading / error states
// ---------------------------------------------------------------------------

const TransitionLoading = () => (
  <div className="fixed inset-0 z-[70] flex items-center justify-center bg-background/78 px-4 backdrop-blur-md">
    <div className="flex w-full max-w-sm flex-col items-center gap-3 rounded-[1.75rem] border border-border/80 bg-background/90 px-8 py-10 text-center shadow-2xl shadow-black/35 backdrop-blur-xl">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      <p className="text-sm text-muted-foreground">Loading…</p>
    </div>
  </div>
);

const TransitionError = ({ message, onRetry }) => (
  <div className="fixed inset-0 z-[70] flex items-center justify-center bg-background/78 px-4 backdrop-blur-md">
    <div className="w-full max-w-md rounded-[1.75rem] border border-destructive/40 bg-background/90 p-8 text-center shadow-2xl shadow-black/35 backdrop-blur-xl">
      <h1 className="text-lg font-black text-destructive mb-3">Transition Error</h1>
      <p className="text-sm text-muted-foreground mb-5">{message}</p>
      {onRetry && (
        <button
          className="px-5 py-2 rounded-lg bg-muted text-muted-foreground text-sm font-semibold hover:bg-muted/70 transition-colors"
          onClick={onRetry}
        >
          Retry
        </button>
      )}
    </div>
  </div>
);

const asSafeInternalPath = (value) => {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed || !trimmed.startsWith('/') || trimmed.startsWith('//')) return null;
  if (/[\r\n]/.test(trimmed)) return null;
  return trimmed;
};

const getTransitionDismissPath = (transition) => {
  const props = transition?.ui?.props;
  if (!props || typeof props !== 'object' || Array.isArray(props)) return null;
  return asSafeInternalPath(props.dismiss_to ?? props.dismissTo);
};

// ---------------------------------------------------------------------------
// TransitionScreen
// ---------------------------------------------------------------------------

export function TransitionScreen({ transitionId, onNavigate, context }) {
  const navigate = useNavigate();
  const [transition, setTransition] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const titleId = useId();
  const descriptionId = useId();

  // Fetch transition from API — re-runs on transitionId change or explicit retry.
  // Only the response for the current transitionId may land: a run_complete
  // can set workflow_complete and then the journey's next transition within
  // milliseconds, and a slower response for the superseded id would otherwise
  // overwrite the screen while onNavigate resolves the current id.
  useEffect(() => {
    if (!transitionId) return undefined;
    let current = true;
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    setTransition(null);

    fetch(`/api/transitions/${encodeURIComponent(transitionId)}`, { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`Transition '${transitionId}' not found (${res.status})`);
        return res.json();
      })
      .then((data) => {
        if (!current) return;
        setTransition(data);
        setLoading(false);
      })
      .catch((err) => {
        if (!current || err?.name === 'AbortError') return;
        setError(err.message);
        setLoading(false);
      });

    return () => {
      current = false;
      controller.abort();
    };
  }, [transitionId, retryCount]);

  // Every resolution goes through here so no call site can forget to handle a
  // failure. Resolution is fire-and-forget at the click sites, so without this
  // the only other outcome is an unhandled rejection and a dead-looking button.
  const resolve = useCallback(
    (option_id = null, contextVariables = {}, launchOptions = {}) =>
      Promise.resolve()
        .then(() => onNavigate?.(option_id, contextVariables, launchOptions))
        .catch((err) => setError(err?.message || 'Failed to resolve transition')),
    [onNavigate]
  );

  useEffect(() => {
    if (!transition) return;

    if (
      ['silent', 'progress_view', 'prerequisite_redirect', 'chat_session'].includes(transition.transition_type)
    ) {
      const t = setTimeout(() => {
        resolve(null);
      }, 0);
      return () => clearTimeout(t);
    }

    if (transition.transition_type !== 'condition') return;

    if (!transition.context_key) {
      console.warn(`⚠️ [TransitionScreen] condition transition '${transition.id}' is missing context_key`);
      return;
    }

    if (!transition.routes?.length && !transition.default_route) {
      console.warn(`⚠️ [TransitionScreen] condition transition '${transition.id}' has no route`);
      return;
    }

    const t = setTimeout(() => {
      resolve(null);
    }, 0);

    return () => clearTimeout(t);
  }, [transition, resolve]);

  const onResolve = resolve;

  useAppEventBus('routing.transition.resolve', ({ option_id, context_variables }) => {
    resolve(option_id ?? null, context_variables ?? {});
  });

  const handleRetry = useCallback(() => setRetryCount((n) => n + 1), []);
  const handleDismiss = useCallback(() => {
    const dismissPath = getTransitionDismissPath(transition);
    if (dismissPath) {
      navigate(dismissPath);
      return;
    }
    if (typeof window !== 'undefined' && window.history.length > 1) {
      window.history.back();
    }
  }, [navigate, transition]);

  if (loading) return <TransitionLoading />;
  if (error) return <TransitionError message={error} onRetry={handleRetry} />;
  if (!transition) return null;

  if (
    ['condition', 'silent', 'progress_view', 'prerequisite_redirect', 'chat_session'].includes(transition.transition_type)
  ) {
    return null;
  }

  let body = null;

  // Merge live runtime context (from AG2 context_variables) into the static
  // transition definition so components like AppReviewScreen can read values
  // such as build_registry_id, preview_url, and validation results.
  const transitionWithContext = (context && typeof context === 'object' && Object.keys(context).length > 0)
    ? { ...transition, context }
    : transition;

  const componentName = transition.ui?.component;
  if (componentName && hasComponent(componentName)) {
    const TransitionComponent = getComponent(componentName);
    body = (
      <TransitionComponent
        transition={transitionWithContext}
        onResolve={onResolve}
        overlayTitleId={titleId}
        overlayDescriptionId={descriptionId}
      />
    );
  } else if (transition.transition_type === 'confirm') {
    body = (
      <ConfirmScreen
        transition={transitionWithContext}
        onResolve={onResolve}
        overlayTitleId={titleId}
        overlayDescriptionId={descriptionId}
      />
    );
  } else {
    body = (
      <LauncherScreen
        transition={transitionWithContext}
        onResolve={onResolve}
        overlayTitleId={titleId}
        overlayDescriptionId={descriptionId}
      />
    );
  }

  return (
    <TransitionOverlayFrame
      transition={transition}
      titleId={titleId}
      descriptionId={descriptionId}
      onDismiss={handleDismiss}
    >
      {body}
    </TransitionOverlayFrame>
  );
}

export default TransitionScreen;
