// ==============================================================================
// FILE: chat-ui/src/@chat-workflows/index.js
// DESCRIPTION: Registers the effective workflow UI supplied by the host build.
//
//   The consuming host resolves its active workflow bundle and any explicitly
//   inherited default registry at build time.
//
//   chat-ui stays workflow-agnostic: it only knows how to read
//   <workflow>/ui/index.{js,jsx} barrels from the injected root and register
//   their exports in the component registry.
// ==============================================================================

import workflowModules from 'virtual:mozaiks-workflow-ui';

// Build WORKFLOW_REGISTRY from the injected workflow root.
// Key   -> workflow folder name
// Value -> { components } map from the ui/index exports
const WORKFLOW_REGISTRY = {};

const normalizeWorkflowModule = (mod) => {
  const workflowModule = mod.default ?? mod;
  return workflowModule && typeof workflowModule === 'object'
    ? workflowModule
    : null;
};

for (const [workflowName, loadModule] of Object.entries(workflowModules)) {
  WORKFLOW_REGISTRY[workflowName] = {
    loadModule,
    module: null,
    components: null,
    loadPromise: null,
  };
}

export const getLoadedWorkflows = () => Object.keys(WORKFLOW_REGISTRY);

export const getWorkflow = (workflowName) =>
  WORKFLOW_REGISTRY[workflowName]?.module ?? null;

const loadWorkflow = async (workflowName) => {
  const entry = WORKFLOW_REGISTRY[workflowName];
  if (!entry) return null;
  if (entry.module) return entry.module;
  if (!entry.loadPromise) {
    entry.loadPromise = Promise.resolve(entry.loadModule())
      .then((mod) => {
        const workflowModule = normalizeWorkflowModule(mod);
        entry.module = workflowModule;
        entry.components = workflowModule;
        return workflowModule;
      })
      .catch((error) => {
        entry.loadPromise = null;
        throw error;
      });
  }
  await entry.loadPromise;
  return entry.module;
};

export const initializeWorkflows = async (registerComponent) => {
  if (typeof registerComponent !== 'function') return;
  for (const workflowName of Object.keys(WORKFLOW_REGISTRY)) {
    await loadWorkflow(workflowName);
    const { components } = WORKFLOW_REGISTRY[workflowName] ?? {};
    if (!components || typeof components !== 'object') continue;
    for (const [componentName, component] of Object.entries(components)) {
      // Namespaced registration is the deterministic lookup key for workflow UI tools.
      const namespacedComponentName = `${workflowName}:${componentName}`;
      registerComponent(namespacedComponentName, component, {
        description: `${workflowName} workflow component (namespaced)`,
        override: true,
      });
      // Plain registration is retained for route/transition components and developer ergonomics.
      registerComponent(componentName, component, {
        description: `${workflowName} workflow component`,
        override: true,
      });
    }
  }
};

const workflowRegistry = { getLoadedWorkflows, getWorkflow, initializeWorkflows };
export default workflowRegistry;
