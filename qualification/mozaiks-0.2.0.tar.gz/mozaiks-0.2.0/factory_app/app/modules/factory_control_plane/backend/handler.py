class FactoryControlPlaneModule:
    """Zero-action identity module for Studio module discovery.

    The real refinement harness does not live under
    `app/modules/factory_control_plane/backend/`.

    Canonical runtime paths:
    - `mozaiksai/control_plane/*`
    - `mozaiksai/builder_resources/refinement_profiles/factory_default/config/*`
    - `mozaiksai/builder_resources/refinement_profiles/factory_default/prompts/*`
    - `mozaiksai/builder/refinement/*`
    """
