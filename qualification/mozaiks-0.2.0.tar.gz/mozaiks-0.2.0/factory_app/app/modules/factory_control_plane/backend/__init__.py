"""Backend package for the factory_control_plane identity module.

The declarative module system mounts this zero-action module contract for
Studio identity. The refinement engine lives in `mozaiksai/control_plane/`;
generic tools live in `mozaiksai/builder/refinement/` and the installed Factory
profile in `mozaiksai/builder_resources/refinement_profiles/factory_default/`.
"""
