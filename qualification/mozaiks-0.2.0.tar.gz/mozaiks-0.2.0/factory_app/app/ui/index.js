/**
 * factory_app/app/ui — first-party workspace UI registration barrel.
 *
 * User-facing app pages (declarative schemas, custom app routes) live here.
 * Studio admin pages are co-located with the admin portal under app/admin/
 * and registered via registerAdminComponents from that module.
 *
 */

import { registerAdminComponents } from '../admin/index.js'
import { installOnboardingTour } from './installOnboardingTour.jsx'

export { AppsDirectory } from '../admin/pages/AppsPage.jsx'
export { default as DashboardPortalPage } from '../admin/pages/DashboardPortalPage.jsx'

export function register(registerComponent) {
  registerAdminComponents(registerComponent)
  installOnboardingTour()
}
