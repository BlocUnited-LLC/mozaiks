"""
Module contract quality gate tool for AppGenerator.

Called automatically after ModuleContractQualityAgent speaks.

Audits the current admitted artifact snapshot for module correctness and sets
``module_contract_quality_status`` for AG2 handoff routing.

Status values:
  passed  — canonical contracts and current cross-file references are valid.
  blocked — invalid contract, generated layout, or unresolved reference;
            the owning declaration must be repaired before generation continues.

Previous diagnostics are not current authority: a repaired admitted snapshot is
audited afresh. Historical failures remain in their existing execution evidence.
"""

from __future__ import annotations

from typing import Annotated, Any

from pydantic import Field

from factory_app.workflows.AppGenerator.tools.audit_module_contracts import (
    audit_admin_registry_file_map,
    audit_module_contracts,
)
from mozaiksai.core.workflow.context.frozen import detach


def _context_get(context_variables: Any | None, key: str, default: Any = None) -> Any:
    if context_variables is None:
        return default
    if hasattr(context_variables, "get"):
        try:
            value = context_variables.get(key)
            # Live containers freeze reads; detach planning and task-result
            # metadata before checking intermediate registry dependencies.
            return default if value is None else detach(value)
        except Exception:
            pass
    data = getattr(context_variables, "data", None)
    if isinstance(data, dict):
        return data.get(key, default)
    if isinstance(context_variables, dict):
        return context_variables.get(key, default)
    return default


def _context_set(context_variables: Any | None, key: str, value: Any) -> None:
    if context_variables is None:
        return
    if hasattr(context_variables, "set"):
        try:
            context_variables.set(key, value)
            return
        except Exception:
            pass
    data = getattr(context_variables, "data", None)
    if isinstance(data, dict):
        data[key] = value
        return
    if isinstance(context_variables, dict):
        context_variables[key] = value


def _dedupe(warnings: list[str]) -> list[str]:
    seen: set = set()
    out: list[str] = []
    for w in warnings:
        if w not in seen:
            seen.add(w)
            out.append(w)
    return out


def review_module_contract_quality(
    max_revision_attempts: Annotated[
        int,
        Field(
            description=(
                "Maximum automated revision loops before blocking. "
                "Reserved for future loop-back support; currently unused "
                "because ConfigMiddlewareAgent runs in task_run_mode and "
                "cannot be revisited from the main workflow."
            )
        ),
    ] = 1,
    agent_message: Annotated[
        str,
        Field(description="Concise message from ModuleContractQualityAgent (ignored by the tool)."),
    ] = "",
    context_variables: Annotated[
        Any | None,
        Field(description="AG2-injected workflow context variables."),
    ] = None,
) -> dict[str, Any]:
    """Audit module contract files in context and set module_contract_quality_status.

    Returns a deterministic status payload:
      - passed: no blocking issues; ModelAgent may proceed.
      - blocked: critical contract issues require user/operator review.
    """

    from .code_file_utils import admitted_module_file_map

    files = admitted_module_file_map(context_variables)
    code_files = [{"filename": path, "content": content} for path, content in files.items()]
    audit_warnings = audit_module_contracts(code_files)
    plan = _context_get(context_variables, "app_build_plan", {}) or {}
    results = _context_get(context_variables, "app_task_batch_results", {}) or {}
    registry_pending = any(
        task.get("task_type") == "page_bundle" and task.get("initial_agent") == "AppSchemaAgent"
        and "admin/admin_registry.yaml" in (task.get("owned_paths") or [])
        and task.get("task_id") not in results
        for task in plan.get("build_tasks", []) if isinstance(task, dict)
    )
    # This gate also runs before page tasks. A planned but not-yet-produced
    # registry is deferred here only; final snapshot diagnostics never defer.
    page_ref_warnings = (
        [] if registry_pending and "admin/admin_registry.yaml" not in files
        else audit_admin_registry_file_map(files)
    )

    all_warnings = _dedupe(audit_warnings + page_ref_warnings)

    module_contract_count = sum(
        1
        for f in code_files
        if isinstance(f, dict) and str(f.get("filename") or "").endswith("module.yaml")
    )

    # Each diagnostic from these deterministic validators is a contract defect,
    # not an advisory whose severity can depend on matching words in its text.
    if not all_warnings:
        status = "passed"
        revision_request = None
    else:
        status = "blocked"
        revision_request = (
            "Module contract quality gate blocked. Critical issues found in "
            f"{module_contract_count} module contract(s):\n- "
            + "\n- ".join(all_warnings)
        )

    result: dict[str, Any] = {
        "status": status,
        "warnings": all_warnings,
        "module_contract_count": module_contract_count,
        "revision_request": revision_request,
    }

    _context_set(context_variables, "module_contract_quality_status", status)
    _context_set(context_variables, "module_contract_quality_warnings", all_warnings)
    _context_set(context_variables, "module_contract_quality_result", result)

    return result


__all__ = ["review_module_contract_quality"]

