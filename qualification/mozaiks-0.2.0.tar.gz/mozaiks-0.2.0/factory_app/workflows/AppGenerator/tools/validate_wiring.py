"""
validate_wiring - Cross-reference page api_endpoint fields against known module actions
and platform-owned read endpoints.

Runs during the deterministic AppValidationAgent acceptance gate, after
AppSchemaAgent output and task-batch assembly are complete.

Algorithm
---------
1. Build the action registry from module.yaml files in generated_files.
   Before assembly, app_pages and planned/on-disk actions support standalone checks.
2. Extract page API references from that snapshot, including nested actions.
3. Cross-reference every referenced endpoint against the registry or the small
   allowlist of platform-owned read endpoints that the page renderer may fetch.
4. Report:
     wired            — endpoints that resolved correctly
     platform_endpoints — platform-owned read endpoints that do not map to modules
     orphaned_pages   — endpoints with no matching module action or platform endpoint (BLOCKING)
     orphaned_actions — module actions with no page referencing them (advisory warning)
5. Check page output fields and workflow targets, and require reachable page
   bindings for entitlement-gated, user-facing module actions and for the
   user-facing canonical create/update/delete of every collection a page
   table lists, gated or not.

Unresolved endpoints and missing input are blocking. A static/custom UI bundle
may legitimately have no declarative page API references.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import yaml
from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError

from mozaiksai.core.runtime.app.page_schema import (
    discover_page_schema_paths,
    validate_ask_context_references,
)
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.module_action_inventory import (
    collection_has_canonical_writes,
)
from mozaiksai.core.workflow.generator_support.page_action_bindings import (
    PAGE_ACTION_FIELDS,
    generated_workflow_names,
    page_workflow_binding_errors,
    reachable_page_action_keys,
)
from mozaiksai.core.workflow.generator_support.page_binding_construction import (
    canonical_write_ids,
    listed_collections,
)
from mozaiksai.core.workflow.generator_support.page_data_bindings import (
    iter_data_bound_sections,
    page_data_binding_errors,
    schema_field_paths,
)

_logger = logging.getLogger("tools.validate_wiring")

PLATFORM_READ_ENDPOINTS = {
    "/api/me/usage",
    "/api/me/tokens",
    "/api/me/tokens/ledger",
}


# ---------------------------------------------------------------------------
# Helpers — context access
# ---------------------------------------------------------------------------

def _context_get(context_variables: dict[str, Any] | None, key: str) -> Any | None:
    if context_variables is None:
        return None
    if hasattr(context_variables, "get"):
        try:
            v = context_variables.get(key)
            if v is not None:
                return detach(v)
        except Exception:
            pass
    data = getattr(context_variables, "data", None)
    if isinstance(data, dict):
        return detach(data.get(key))
    if isinstance(context_variables, dict):
        return detach(context_variables.get(key))
    return None


def _generated_files_from_context(context_variables: dict[str, Any] | None) -> dict[str, str]:
    raw = _context_get(context_variables, "generated_files")
    if not isinstance(raw, dict):
        return {}
    files: dict[str, str] = {}
    for path, content in raw.items():
        if not isinstance(path, str):
            continue
        normalized = path.replace("\\", "/").strip()
        if normalized and not normalized.startswith("/") and ".." not in normalized.split("/"):
            files[normalized] = str(content)
    return files


def _pages_from_generated_files(files: dict[str, str]) -> list[dict[str, Any]]:
    pages: list[dict[str, Any]] = []
    for path, content in sorted(files.items()):
        if not path.startswith("ui/pages/") or not path.endswith((".yaml", ".yml")):
            continue
        try:
            parsed = yaml.safe_load(content) or {}
        except Exception as exc:
            _logger.warning("validate_wiring: failed to parse generated page %s: %s", path, exc)
            continue
        if isinstance(parsed, dict):
            pages.append(parsed)
    return pages


# ---------------------------------------------------------------------------
# Helpers — filesystem
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    here = Path(__file__).resolve()
    for parent in [here] + list(here.parents):
        if (parent / "mozaiksai").is_dir():
            return parent
    return here.parents[-1]


def _resolve_generated_artifacts_root() -> Path:
    raw = os.getenv("MOZAIKS_GENERATED_ARTIFACTS_PATH", "generated").strip()
    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = _repo_root() / candidate
    return candidate.resolve()


# ---------------------------------------------------------------------------
# Endpoint extraction — pages
# ---------------------------------------------------------------------------

def _collect_endpoints_from_config(
    page_name: str,
    section_id: str,
    config: Any,
    out: list[tuple[str, str, str]],
) -> None:
    """Extract api_endpoint from config dict and recurse into children."""
    if not isinstance(config, dict):
        return
    ep = config.get("api_endpoint")
    if isinstance(ep, str) and ep.strip():
        out.append((page_name, section_id, ep.strip()))
    href = config.get("href")
    if isinstance(href, str) and href.strip().startswith("/api/"):
        out.append((page_name, section_id, href.strip()))
    for field in (*PAGE_ACTION_FIELDS, "empty"):
        action = config.get(field)
        if isinstance(action, dict):
            _collect_endpoints_from_config(page_name, f"{section_id}/{field}", action, out)
    for action in config.get("actions") or []:
        if isinstance(action, dict):
            action_id = str(action.get("id") or "action").strip()
            _collect_endpoints_from_config(page_name, f"{section_id}/{action_id}", action, out)
    for child in config.get("children") or []:
        if isinstance(child, dict):
            child_id = str(child.get("id") or f"{section_id}/child")
            _collect_endpoints_from_config(page_name, child_id, child.get("config"), out)


def _extract_endpoint_refs(pages: list[Any]) -> list[tuple[str, str, str]]:
    """
    Walk all pages and return (page_name, section_id, api_endpoint) triples
    for every api_endpoint found anywhere in the section tree.
    """
    results: list[tuple[str, str, str]] = []
    for page in pages or []:
        if not isinstance(page, dict):
            continue
        page_name = str(page.get("name") or "<unnamed>")
        for section in page.get("sections") or []:
            if not isinstance(section, dict):
                continue
            section_id = str(section.get("id") or "<no-id>")
            _collect_endpoints_from_config(page_name, section_id, section.get("config"), results)
    return results


def _endpoint_path(endpoint: str) -> str:
    return urlsplit(endpoint.strip()).path.strip()


def _is_platform_read_endpoint(endpoint: str) -> bool:
    return _endpoint_path(endpoint) in PLATFORM_READ_ENDPOINTS


def _endpoint_to_action_key(endpoint: str) -> tuple[str | None, str | None]:
    """Normalize a page api_endpoint to the module action registry key.

    Canonical app pages call module actions at /api/modules/{module}/{action}
    or read the explicit platform-owned account endpoints listed in
    PLATFORM_READ_ENDPOINTS.
    Query strings are intentionally rejected because durable page parameters
    belong in page_size, payload, form input, or module action input schemas.
    """
    parsed = urlsplit(endpoint.strip())
    if parsed.scheme or parsed.netloc:
        return None, "api_endpoint must be an app-relative path, not an absolute URL"
    if parsed.query or parsed.fragment:
        return None, "api_endpoint must not include query strings or fragments"

    path = parsed.path.strip()
    if path in PLATFORM_READ_ENDPOINTS:
        return None, None
    if path.startswith("/api/modules/"):
        parts = path.strip("/").split("/")
        if len(parts) != 4 or parts[0] != "api" or parts[1] != "modules" or not parts[2] or not parts[3]:
            return None, "api_endpoint must use /api/modules/{module_id}/{action_id}"
        return f"{parts[2]}/{parts[3]}", None

    return path.lstrip("/"), None


# ---------------------------------------------------------------------------
# Module action registry — two sources
# ---------------------------------------------------------------------------

def _actions_from_capability_packs(capability_packs: list[Any]) -> set[str]:
    """
    Build action registry from app_build_plan.capability_packs.

    Accepted pack shapes:
      { "id": "orders",    "actions": ["list_orders", ...] }
      { "module_id": "orders", "actions": [{"id": "list_orders"}, ...] }
    """
    valid: set[str] = set()
    for pack in capability_packs or []:
        if not isinstance(pack, dict):
            continue
        module_id = str(pack.get("module_id") or pack.get("id") or "").strip()
        if not module_id:
            continue
        action_list = (
            pack.get("actions")
            or pack.get("action_ids")
            or pack.get("action_names")
            or []
        )
        if not isinstance(action_list, list):
            continue
        for action in action_list:
            if isinstance(action, dict):
                action_id = str(action.get("id") or action.get("name") or "").strip()
            else:
                action_id = str(action).strip()
            if action_id:
                valid.add(f"{module_id}/{action_id}")
                valid.add(action_id)  # bare match (for pages that omit module prefix)
    return valid


def _actions_from_module_yamls(app_dir: Path) -> set[str]:
    """
    Scan app_dir/modules/*/module.yaml and build action registry.

    Returns a set containing both:
      "{module_id}/{action_id}"  (canonical form)
      "{action_id}"              (bare form, for pages that omit the module prefix)
    """
    valid: set[str] = set()
    modules_dir = app_dir / "modules"
    if not modules_dir.is_dir():
        return valid
    for module_dir in sorted(modules_dir.iterdir()):
        if not module_dir.is_dir():
            continue
        module_yaml_path = module_dir / "module.yaml"
        if not module_yaml_path.exists():
            continue
        try:
            with open(module_yaml_path, encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
            module_id = str(data.get("id") or module_dir.name).strip()
            for action in data.get("actions") or []:
                if isinstance(action, dict):
                    action_id = str(action.get("id") or "").strip()
                elif isinstance(action, str):
                    action_id = action.strip()
                else:
                    continue
                if action_id:
                    valid.add(f"{module_id}/{action_id}")
                    valid.add(action_id)
        except Exception as exc:
            _logger.warning("validate_wiring: failed to parse %s: %s", module_yaml_path, exc)
    return valid


def _generated_module_action_contracts(files: dict[str, str]) -> dict[str, dict[str, Any]]:
    contracts: dict[str, dict[str, Any]] = {}
    for path, content in sorted(files.items()):
        if not path.startswith("modules/") or not path.endswith("/module.yaml"):
            continue
        try:
            data = yaml.safe_load(content) or {}
        except Exception as exc:
            _logger.warning("validate_wiring: failed to parse generated module %s: %s", path, exc)
            continue
        if not isinstance(data, dict):
            continue
        module_block = data.get("module") if isinstance(data.get("module"), dict) else data
        module_id = str(module_block.get("id") if isinstance(module_block, dict) else "").strip()
        if not module_id:
            parts = path.split("/")
            module_id = parts[1] if len(parts) > 1 else ""
        if not module_id:
            continue
        for action in data.get("actions") or []:
            if isinstance(action, dict):
                action_id = str(action.get("id") or "").strip()
            elif isinstance(action, str):
                action_id = action.strip()
            else:
                continue
            if action_id:
                contracts[f"{module_id}/{action_id}"] = action if isinstance(action, dict) else {}
    return contracts


def _actions_from_generated_module_files(files: dict[str, str]) -> set[str]:
    contracts = _generated_module_action_contracts(files)
    return set(contracts) | {key.split("/", 1)[1] for key in contracts}


def _has_schema_reference(value: Any) -> bool:
    if isinstance(value, dict):
        return any(key in value for key in ("$ref", "$dynamicRef", "$recursiveRef")) or any(
            _has_schema_reference(item) for item in value.values()
        )
    return isinstance(value, list) and any(_has_schema_reference(item) for item in value)


def _required_output_type(schema: Any, key_path: Any, expected: str) -> bool:
    if not isinstance(key_path, str) or not key_path:
        return False
    for key in key_path.split("."):
        if not isinstance(schema, dict) or schema.get("type") != "object":
            return False
        properties = schema.get("properties")
        if not isinstance(properties, dict) or key not in (schema.get("required") or []):
            return False
        schema = properties.get(key)
    if not isinstance(schema, dict) or schema.get("type") != expected:
        return False
    if expected == "array":
        items = schema.get("items")
        return isinstance(items, dict) and items.get("type") == "object"
    return True


def _server_table_contract_error(config: dict[str, Any], action: dict[str, Any]) -> str | None:
    surface = action.get("api_surface")
    if surface is not None and not isinstance(surface, str):
        return "Server paging requires a valid module action surface."
    if surface in {"internal", "admin_internal"}:
        return "Server paging cannot bind an internal-only module action."
    inputs, outputs = action.get("input_schema"), action.get("output_schema")
    if not isinstance(inputs, dict) or not isinstance(outputs, dict):
        return "Server paging requires the generated action's input and output schemas."
    try:
        if _has_schema_reference(inputs) or _has_schema_reference(outputs):
            return "Server paging requires inline query and response schemas; schema references are unsupported."
        Draft202012Validator.check_schema(inputs)
        Draft202012Validator.check_schema(outputs)
        properties = inputs.get("properties", {})
        for field, expected in (("page", "integer"), ("page_size", "integer"), ("search", "string")):
            declaration = properties.get(field, {})
            if declaration.get("type") != expected:
                return f"Server paging requires an explicit {expected} input named {field}."
        validator = Draft202012Validator(inputs)
        queries = [(1, ""), (2, "")]
        if config.get("search"):
            queries.append((1, "a"))
        for page, search in queries:
            if not validator.is_valid({"page": page, "page_size": config.get("page_size"), "search": search}):
                return "The action schema rejects the table's initial, next-page or enabled text-search query."
        for field, expected in (("data_key", "array"), ("total_key", "integer")):
            if not _required_output_type(outputs, config.get(field), expected):
                suffix = " with explicitly typed object items" if expected == "array" else ""
                valid = ", ".join(schema_field_paths(outputs)) or "(none declared)"
                return f"Server paging {field} must resolve to a required {expected} response field{suffix}. Valid fields: {valid}."
    except (SchemaError, TypeError, ValueError, RecursionError, AttributeError):
        return "Server paging requires valid, inline action schemas."
    return None


def _server_table_binding_errors(pages: list[Any], contracts: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []

    def visit(page_name: str, sections: Any) -> None:
        for section in sections or []:
            if not isinstance(section, dict) or not isinstance(section.get("config"), dict):
                continue
            config = section["config"]
            if config.get("pagination_mode") == "server":
                endpoint = config.get("api_endpoint")
                key, _ = _endpoint_to_action_key(endpoint) if isinstance(endpoint, str) else (None, None)
                error = _server_table_contract_error(config, contracts.get(key or "", {}))
                if error:
                    failures.append({
                        "test": "wiring_server_table_contract", "page": page_name,
                        "section": str(section.get("id") or "<no-id>"), "error": error,
                        "fix_suggestion": "Align the table's page/page_size/search inputs and required data_key/total_key outputs with the generated module action contract.",
                    })
            visit(page_name, config.get("children"))

    for page in pages:
        if isinstance(page, dict):
            visit(str(page.get("name") or "<unnamed>"), page.get("sections"))
    return failures


def _ask_context_binding_errors(pages: list[Any], contracts: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    modules = {key.split("/", 1)[0] for key in contracts}
    action_index = {
        module: frozenset(key.split("/", 1)[1] for key in contracts if key.startswith(f"{module}/"))
        for module in modules
    }
    eligible_index = {
        module: frozenset(
            key.split("/", 1)[1] for key, action in contracts.items()
            if key.startswith(f"{module}/")
            and action.get("ask_context_safe") is True and action.get("permissions", []) == []
        ) for module in modules
    }
    failures: list[dict[str, Any]] = []
    for page in pages:
        meta = page.get("meta") if isinstance(page, dict) else None
        raw = meta.get("ask_context") if isinstance(meta, dict) else None
        if raw is None:
            continue
        errors = [(item.location, item.message) for item in validate_ask_context_references(
            raw, action_index=action_index, ask_context_index=eligible_index,
        )]
        for location, message in errors:
            failures.append({
                "test": "wiring_ask_context", "page": page.get("name") or page.get("path") or "<unnamed>",
                "section": location, "error": message,
                "fix_suggestion": "Reference an existing read-only action with ask_context_safe: true and permissions: [].",
            })
    return failures


_TABLE_PRIMITIVES = frozenset({"DataTable", "ResourceTable"})
_CANONICAL_WRITE_ENTRY_POINTS = {
    "create": "a toolbar action (requires_selection: false) opening a modal Form whose submit_action posts to {endpoint}",
    "update": (
        "an Edit row action (requires_selection: true, table selection single) opening a modal Form with "
        "initial_values_key: selected_row whose submit_action posts the row's identifier and fields to {endpoint}"
    ),
    "delete": (
        "a Delete row action (requires_selection: true, table selection single) that posts the selected row's "
        "identifier to {endpoint}, directly or from a confirmation modal"
    ),
}


def _unreachable_canonical_write_errors(
    pages: list[Any], contracts: dict[str, dict[str, Any]], data_contract: Any, reachable: set[str], reported: set[str],
) -> list[dict[str, Any]]:
    """Require an entry point for every user-facing canonical write of a collection a page table lists.

    Page construction adds these whether or not a plan gates the write, so one
    still unreachable is a construction the contracts did not determine; the
    page that lists the collection must supply it. Actions in ``reported``
    already failed the gated-action check and are not reported twice.
    """
    listed = listed_collections(data_contract)
    writes: dict[str, tuple[str, str, list[str]]] = {}
    for page in pages:
        page_name = str(page.get("name") or "<unnamed>") if isinstance(page, dict) else "<unnamed>"
        for section, key, _ in iter_data_bound_sections(page):
            module_id, _, list_action = (key or "").partition("/")
            collection = listed.get((module_id, list_action))
            if section.get("primitive") not in _TABLE_PRIMITIVES or collection is None:
                continue
            if not collection_has_canonical_writes(collection):
                continue
            for operation, write_id in canonical_write_ids(collection).items():
                write_key = f"{module_id}/{write_id}"
                action = contracts.get(write_key)
                if (
                    action is None or write_key in reachable or write_key in reported
                    or action.get("api_surface") in ("internal", "admin_internal")
                ):
                    continue
                listing = writes.setdefault(write_key, (operation, str(collection.get("name")), []))[2]
                if page_name not in listing:
                    listing.append(page_name)
    failures: list[dict[str, Any]] = []
    for write_key, (operation, collection_name, listing) in sorted(writes.items()):
        where = f"page '{listing[0]}'" if len(listing) == 1 else "pages " + ", ".join(f"'{name}'" for name in listing)
        entry_point = _CANONICAL_WRITE_ENTRY_POINTS[operation].format(endpoint=f"/api/modules/{write_key}")
        failures.append({
            "test": "wiring_unreachable_canonical_write", "action": write_key, "page": listing[0], "pages": listing,
            "error": (
                f"Canonical {operation} action '{write_key}' has no reachable page entry point, but {where} "
                f"lists its collection '{collection_name}'."
            ),
            "fix_suggestion": f"Give the '{collection_name}' table on page '{listing[0]}' {entry_point}.",
        })
    return failures


# ---------------------------------------------------------------------------
# Main tool function
# ---------------------------------------------------------------------------

async def validate_wiring(
    context_variables: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Cross-reference page api_endpoint references against known module actions.

    Returns a wiring report compatible with run_integration_tests output shape:
    {
      "contract_version": "1.0",
      "passed": bool,
      "wired": [{"page": str, "section": str, "endpoint": str}, ...],
      "orphaned_pages": [...],     # endpoints with no known module action — BLOCKING
      "orphaned_actions": [...],   # module actions never referenced by a page — warning
      "checks": [...],
      "failed_tests": [...],
      "warnings": [...],
    }
    """
    # ── Read context ──────────────────────────────────────────────────────
    generated_files = _generated_files_from_context(context_variables)
    has_file_snapshot = _context_get(context_variables, "generated_files") is not None
    app_pages: list[Any] = (
        _pages_from_generated_files(generated_files)
        if has_file_snapshot
        else _context_get(context_variables, "app_pages") or []
    )
    app_build_plan: dict[str, Any] = _context_get(context_variables, "app_build_plan") or {}
    generated_app_dir_str: str | None = _context_get(context_variables, "generated_app_dir")

    # Build the module action registry.
    known_actions: set[str] = set()

    # Source A: capability_packs
    capability_packs = app_build_plan.get("capability_packs") or []
    if not has_file_snapshot:
        known_actions.update(_actions_from_capability_packs(capability_packs))

    # Source B: modules/*/module.yaml on disk
    app_dir: Path | None = None
    if generated_app_dir_str:
        app_dir = Path(generated_app_dir_str)
    else:
        app_id = _context_get(context_variables, "app_id")
        build_id = (
            _context_get(context_variables, "build_id")
            or _context_get(context_variables, "chat_id")
        )
        if app_id and build_id:
            app_dir = (
                _resolve_generated_artifacts_root()
                / "apps"
                / str(app_id)
                / str(build_id)
                / "app"
            )

    if not has_file_snapshot and app_dir and app_dir.is_dir():
        known_actions.update(_actions_from_module_yamls(app_dir))
    if generated_files:
        known_actions.update(_actions_from_generated_module_files(generated_files))

    # Saved snapshots are authoritative; disk input is only for standalone checks.
    contract_files = generated_files
    if not has_file_snapshot and app_dir and app_dir.is_dir():
        contract_files = {}
        for path in sorted((app_dir / "modules").glob("*/module.yaml")):
            try:
                contract_files[path.relative_to(app_dir).as_posix()] = path.read_text(encoding="utf-8")
            except (OSError, UnicodeError):
                _logger.warning("validate_wiring: module contract could not be read: %s", path)
        for relative in ("ui/route_manifest.json", "data/contract.json"):
            if (app_dir / relative).is_file():
                contract_files[relative] = (app_dir / relative).read_text(encoding="utf-8")
        if not app_pages:
            app_pages = [
                yaml.safe_load(path.read_text(encoding="utf-8"))
                for path in discover_page_schema_paths(app_dir).values()
            ]
        # Standalone workspaces keep workflows beside app/, outside the app bundle.
        for path in sorted((app_dir.parent / "workflows").glob("*/orchestrator.yaml")):
            contract_files[f"workflows/{path.parent.name}/orchestrator.yaml"] = path.read_text(encoding="utf-8")
    ask_pages = list(app_pages)
    if "ui/route_manifest.json" in contract_files:
        manifest = json.loads(contract_files["ui/route_manifest.json"])
        if isinstance(manifest, dict) and isinstance(manifest.get("pages"), list):
            ask_pages.extend(manifest["pages"])
    action_contracts = _generated_module_action_contracts(contract_files)
    server_table_failures = _server_table_binding_errors(app_pages, action_contracts)
    ask_context_failures = _ask_context_binding_errors(
        ask_pages, action_contracts,
    )
    workflow_names = generated_workflow_names(contract_files, context_variables)
    page_binding_failures: list[dict[str, Any]] = []
    for page in app_pages:
        for test, errors, suggestion in (
            ("wiring_page_output", page_data_binding_errors(page, action_contracts),
             "Select KPI keys, table response keys and columns from the bound action's declared output_schema."),
            ("wiring_page_workflow", page_workflow_binding_errors(page, workflow_names),
             "Use a workflow present in the generated bundle or a typed submit/delete module action."),
        ):
            for binding_error in errors:
                page_binding_failures.append({
                    "test": test, "page": page.get("name") if isinstance(page, dict) else "<unnamed>",
                    "error": binding_error, "fix_suggestion": suggestion,
                })
    reachable_actions = reachable_page_action_keys(app_pages)
    unreachable_gated_actions = sorted(
        key for key, action in action_contracts.items()
        if action.get("entitlement_gate")
        and action.get("api_surface") not in ("internal", "admin_internal")
        and key not in reachable_actions
    )
    for key in unreachable_gated_actions:
        page_binding_failures.append({
            "test": "wiring_unreachable_gated_action", "action": key,
            "error": f"Gated user-facing action '{key}' ({action_contracts[key]['entitlement_gate']}) has no reachable page binding.",
            "fix_suggestion": "Bind the action to a page read or typed submit/delete action; modal forms need a reachable opener.",
        })
    try:
        data_contract = json.loads(contract_files.get("data/contract.json") or "null")
    except json.JSONDecodeError:
        data_contract = None  # The bundle scanner owns malformed contract diagnostics.
    canonical_write_failures = _unreachable_canonical_write_errors(
        app_pages, action_contracts, data_contract, reachable_actions, set(unreachable_gated_actions),
    )
    page_binding_failures.extend(canonical_write_failures)

    # Collect endpoint references after standalone disk pages have been resolved.
    endpoint_refs = _extract_endpoint_refs(app_pages)
    referenced_set: set[str] = set()
    endpoint_keys: dict[tuple[str, str, str], str | None] = {}
    invalid_refs: set[tuple[str, str, str]] = set()
    invalid_endpoints: list[dict[str, str]] = []
    platform_refs: set[tuple[str, str, str]] = set()
    for page_name, section_id, endpoint in endpoint_refs:
        action_key, error = _endpoint_to_action_key(endpoint)
        endpoint_keys[(page_name, section_id, endpoint)] = action_key
        if _is_platform_read_endpoint(endpoint):
            platform_refs.add((page_name, section_id, endpoint))
        if action_key:
            referenced_set.add(action_key)
            if "/" in action_key:
                referenced_set.add(action_key.split("/", 1)[1])
        if error:
            invalid_refs.add((page_name, section_id, endpoint))
            invalid_endpoints.append({
                "page": page_name,
                "section": section_id,
                "endpoint": endpoint,
                "error": error,
            })

    # ── 3. Cross-reference ────────────────────────────────────────────────
    wired: list[dict[str, str]] = []
    platform_endpoints: list[dict[str, str]] = []
    orphaned_pages: list[dict[str, str]] = []

    for page_name, section_id, endpoint in endpoint_refs:
        action_key = endpoint_keys.get((page_name, section_id, endpoint))
        if (page_name, section_id, endpoint) in invalid_refs:
            continue
        if (page_name, section_id, endpoint) in platform_refs:
            platform_endpoints.append({"page": page_name, "section": section_id, "endpoint": endpoint})
            continue
        if action_key in known_actions:
            wired.append({"page": page_name, "section": section_id, "endpoint": endpoint})
        else:
            orphaned_pages.append({"page": page_name, "section": section_id, "endpoint": endpoint})

    # Orphaned actions: defined but never referenced by any page
    # Only consider the canonical "module/action" form to avoid bare-id duplication noise.
    canonical_actions: set[str] = {a for a in known_actions if "/" in a}
    orphaned_actions: list[str] = sorted(
        a for a in canonical_actions
        if a not in referenced_set and a.split("/")[1] not in referenced_set
    )

    # ── 4. Determine pass/fail ─────────────────────────────────────────────
    no_endpoints = not endpoint_refs
    no_registry = not known_actions
    has_orphaned_pages = bool(orphaned_pages)
    has_invalid_endpoints = bool(invalid_endpoints)
    missing_input = not generated_files and not app_pages and not ask_pages

    blocking_pass: bool = not (
        missing_input or has_invalid_endpoints or has_orphaned_pages
        or server_table_failures or ask_context_failures or page_binding_failures
    )

    # ── 5. Build human-readable output ───────────────────────────────────
    warnings: list[str] = []
    failed_tests: list[dict[str, Any]] = [*server_table_failures, *ask_context_failures, *page_binding_failures]

    if missing_input:
        failed_tests.append({
            "test": "wiring_missing_input",
            "error": "No generated files or page schemas were available for wiring validation.",
            "fix_suggestion": "Pass the assembled generated_files snapshot to the acceptance gate.",
        })

    for item in invalid_endpoints:
        failed_tests.append({
            "test": "wiring_invalid_endpoint",
            "page": item["page"],
            "section": item["section"],
            "endpoint": item["endpoint"],
            "error": (
                f"Page '{item['page']}' section '{item['section']}' has invalid "
                f"api_endpoint '{item['endpoint']}': {item['error']}."
            ),
            "fix_suggestion": (
                "Use the canonical /api/modules/{module_id}/{action_id} path and put "
                "filters, limits, and selected row data in page_size, payload, form "
                "state, or the module action input schema."
            ),
        })

    if has_orphaned_pages:
        for item in orphaned_pages:
            failed_tests.append({
                "test": "wiring_orphaned_endpoint",
                "page": item["page"],
                "section": item["section"],
                "endpoint": item["endpoint"],
                "error": (
                    f"Page '{item['page']}' section '{item['section']}' references "
                    f"api_endpoint '{item['endpoint']}' which has no matching module action."
                ),
                "fix_suggestion": (
                    f"Either add action '{item['endpoint']}' to the appropriate module.yaml, "
                    "use one of the supported platform read endpoints, or correct the "
                    "api_endpoint value in the page schema."
                ),
            })

    if no_endpoints:
        warnings.append(
            "No api_endpoint fields found in any page section. "
            "If this app uses module actions, ensure AppSchemaAgent wires them."
        )

    if no_registry:
        warnings.append(
            "No module actions were found in the validation input. "
            "Only supported platform read endpoints can resolve without app modules."
        )

    if orphaned_actions:
        warnings.append(
            f"{len(orphaned_actions)} module action(s) not referenced by any page: "
            f"{orphaned_actions}. These may be subscription handlers or admin-only "
            "actions — review intent."
        )

    if missing_input:
        message = "Wiring validation requires generated files or page schemas."
    elif ask_context_failures:
        message = f"{len(ask_context_failures)} page ask-context declaration(s) do not resolve to eligible actions."
    elif has_invalid_endpoints:
        message = f"{len(invalid_endpoints)} page endpoint(s) have invalid api_endpoint syntax."
    elif server_table_failures:
        message = f"{len(server_table_failures)} server table binding(s) do not match their module action contracts."
    elif page_binding_failures:
        message = f"{len(page_binding_failures)} page data/action binding(s) do not resolve to reachable declared contracts."
    elif not blocking_pass:
        message = (
            f"{len(orphaned_pages)} page endpoint(s) reference unknown module actions."
        )
    elif not no_endpoints and not no_registry:
        platform_count = len(platform_endpoints)
        platform_suffix = (
            f" and {platform_count} platform-owned endpoint(s)"
            if platform_count
            else ""
        )
        message = (
            f"All {len(wired)} page api_endpoint reference(s) resolve to known "
            f"module actions{platform_suffix}."
        )
    else:
        message = "Wiring check passed; no unresolved page API references."

    check: dict[str, Any] = {
        "id": "module_action_wiring",
        "passed": blocking_pass,
        "message": message,
        "details": {
            "blocking": True,
            "ask_context_failures": ask_context_failures,
            "page_binding_failures": page_binding_failures,
            "unreachable_gated_actions": unreachable_gated_actions,
            "unreachable_canonical_writes": [failure["action"] for failure in canonical_write_failures],
            "total_endpoints_referenced": len(endpoint_refs),
            "wired_count": len(wired),
            "platform_endpoint_count": len(platform_endpoints),
            "invalid_endpoint_count": len(invalid_endpoints),
            "orphaned_page_count": len(orphaned_pages),
            "orphaned_action_count": len(orphaned_actions),
            "module_registry_available": not no_registry,
            "wired": wired,
            "platform_endpoints": platform_endpoints,
            "invalid_endpoints": invalid_endpoints,
            "orphaned_pages": orphaned_pages,
            "orphaned_actions": orphaned_actions,
            **(
                {"fix_suggestions": [f["fix_suggestion"] for f in failed_tests]}
                if failed_tests
                else {}
            ),
        },
    }

    result: dict[str, Any] = {
        "contract_version": "1.0",
        "passed": blocking_pass,
        "wired": wired,
        "platform_endpoints": platform_endpoints,
        "invalid_endpoints": invalid_endpoints,
        "orphaned_pages": orphaned_pages,
        "orphaned_actions": orphaned_actions,
        "checks": [check],
        "failed_tests": failed_tests,
        "warnings": warnings,
    }

    # ── Persist into context for routing ──────────────────────────────────
    try:
        if context_variables is not None and hasattr(context_variables, "set"):
            context_variables.set("wiring_validation_passed", blocking_pass)
            context_variables.set("wiring_validation_result", result)
    except Exception as exc:
        _logger.debug("validate_wiring: failed to persist results: %s", exc)

    return result


__all__ = ["validate_wiring"]

