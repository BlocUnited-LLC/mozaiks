"""AppGenerator integration readiness checkpoint tool."""

from __future__ import annotations

from typing import Any

from factory_app.workflows._shared.platform.build_target import require_build_binding
from mozaiksai.core.workflow.generator_support.connector_request import (
    collect_missing_connector_needs,
)
from mozaiksai.core.workflow.generator_support.connector_request import (
    record_integration_need as shared_record_integration_need,
)


async def record_integration_need(
    service: str,
    display_name: str | None = None,
    kind: str = "api_key",
    provider: str | None = None,
    purpose: str | None = None,
    required_at: str = "runtime",
    required_fields: list[dict[str, Any]] | None = None,
    required_by: dict[str, Any] | None = None,
    optional: bool = False,
    preferred_setup_lane: str | None = None,
    allowed_setup_lanes: list[str] | None = None,
    managed_default: dict[str, Any] | str | None = None,
    context_variables: Any = None,
) -> dict[str, Any]:
    """Record an integration need discovered by an AppGenerator task agent."""

    return await shared_record_integration_need(
        service=service,
        display_name=display_name,
        kind=kind,
        provider=provider,
        purpose=purpose,
        required_at=required_at,
        required_fields=required_fields,
        required_by=required_by,
        optional=optional,
        preferred_setup_lane=preferred_setup_lane,
        allowed_setup_lanes=allowed_setup_lanes,
        managed_default=managed_default,
        context_variables=context_variables,
    )


async def check_integration_readiness(
    prompt: bool = True,
    context_variables: Any = None,
) -> dict[str, Any]:
    """Collect build/validation setup, retaining runtime needs for deployment."""

    return await collect_missing_connector_needs(
        context_variables=context_variables,
        target_app_id=require_build_binding(context_variables).target_app_id,
        required_at=["build_time", "validation_time"],
        prompt=prompt,
    )


__all__ = ["check_integration_readiness", "record_integration_need"]

