"""Review model-authored plans before the existing task executor sees them."""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Iterator, Sequence
from pathlib import Path
from typing import Annotated, Any

import yaml
from pydantic import ValidationError

from factory_app.workflows._shared.surface_ownership import validate_surface_ownership
from factory_app.workflows.AppGenerator.tools.app_build_plan import (
    _CANONICAL_INITIAL_AGENTS,
    _MODULE_LOCAL_TASK_TYPES,
    _SHARED_OWNED_PATHS,
    SUBSCRIPTIONS_CONFIG_PATH,
    _apply_selected_pack_files,
    _construct_task_requirements,
    _context_available_pack_map,
    _dedupe_preserving_order,
    _ensure_context_selected_capability_packs,
    _facade_pack_descriptor,
    _normalized_owned_paths,
    _pack_facades,
    _pack_id_from_descriptor,
    _release_owned_paths,
    _rename_requirement_tasks,
    app_build_plan,
    release_pack_facade_paths,
    release_pack_owned_paths,
    release_subscriptions_config,
)
from factory_app.workflows.AppGenerator.tools.plan_page_data_sources import (
    drop_unapproved_page_data_sources,
)
from factory_app.workflows.AppGenerator.tools.requirement_delivery import (
    approved_inventory_from_context,
)
from mozaiksai.builder.requirements import validate_requirement_deliveries
from mozaiksai.builder.resources import resolve_packaged_build_context
from mozaiksai.core.runtime.app.paths import is_safe_app_path, normalize_app_path
from mozaiksai.core.runtime.persistence.intent_loader import iter_data_contract_collections
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.dependency_graph import deterministic_topological_order
from mozaiksai.core.workflow.generator_support.code_files import planned_page_path
from mozaiksai.core.workflow.generator_support.module_account_data import owns_per_user_collections
from mozaiksai.core.workflow.generator_support.module_action_inventory import (
    PackFacadeDirectory,
    pack_facade_directories,
    pack_owned_output_paths,
)
from mozaiksai.core.workflow.outputs.structured import load_workflow_structured_outputs

# Dispatch's own owned-path rules, not copies: review must accept exactly what
# task dispatch will run.
from mozaiksai.core.workflow.path_ownership import _GLOB_CHARS, normalize_owned_path
from mozaiksai.core.workflow.task_batches import (
    _normalize_task_items,
    _validate_batch_owned_paths,
    load_task_batches_config,
)

logger = logging.getLogger(__name__)

_WORKFLOWS_ROOT = Path(__file__).resolve().parents[2]


def _clear_plan(context: Any) -> None:
    context.set("app_plan_ready", False)
    context.set("app_build_plan", None)
    context.set("app_task_batch_items", [])
    context.set("app_task_batch_status", None)


def _task_scope(task: dict[str, Any]) -> str:
    return str(task.get("capability_pack_id") or task.get("surface_id") or "").strip()


def _tasks_by_scope_and_type(tasks: list[dict[str, Any]]) -> dict[tuple[str, str], list[dict[str, Any]]]:
    indexed: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for task in tasks:
        key = (_task_scope(task), str(task.get("task_type") or ""))
        indexed.setdefault(key, []).append(task)
    return indexed


def _available_task_id(preferred: str, reserved: set[str]) -> str:
    candidate = preferred
    suffix = 2
    while candidate in reserved:
        candidate = f"{preferred}.{suffix}"
        suffix += 1
    reserved.add(candidate)
    return candidate


def _requirement_realizations(plan: dict[str, Any]) -> Iterator[tuple[str, dict[str, Any]]]:
    for delivery in plan.get("requirement_deliveries") or []:
        for part in delivery.get("realizations") or []:
            yield delivery["requirement_id"], part


def _rename_requirement_modules(plan: dict[str, Any], renamed: dict[str, str]) -> None:
    """Follow approved module identity changes in typed links, never prose."""
    for _requirement_id, part in _requirement_realizations(plan):
        part["output_paths"] = [
            "/".join(["modules", renamed[path.split("/")[1]], *path.split("/")[2:]])
            if path.startswith("modules/") and path.split("/")[1] in renamed else path
            for path in part["output_paths"]
        ]
        for reference in part["action_refs"]:
            reference["module_id"] = renamed.get(reference["module_id"], reference["module_id"])


def _linked_requirements(plan: dict[str, Any], capabilities: list[str], tasks: list[dict[str, Any]],
                         surface_id: str) -> list[str]:
    task_ids = {task["task_id"] for task in tasks}
    paths = {path for task in tasks for path in _normalized_owned_paths(task)}
    modules = {*capabilities, surface_id} - {""}
    return sorted({requirement_id for requirement_id, part in _requirement_realizations(plan)
                   if set(part["task_ids"]) & task_ids
                   or part["owner_ref"] in {*("task:" + key for key in task_ids),
                                             *("pack:" + key for key in capabilities)}
                   or set(part["output_paths"]) & paths
                   or any(ref["module_id"] in modules for ref in part["action_refs"])
                   or any(path.startswith("modules/" + module + "/")
                          for path in part["output_paths"] for module in modules)})


def _missing_requirement_design(surface_id: str, requirement_ids: list[str]) -> str:
    return (
        f"Approved requirements {requirement_ids} still require delivery, but unapproved surface {surface_id!r} "
        "has no approved design authority. Preserve their exact scope and acceptance criteria; "
        "repair links to existing approved contracts. Where no faithful approved realization exists, "
        "revise DesignDocs to declare the bounded custom module/action, workflow or page contract, "
        "then map concrete outputs and tasks. Do not delete approved requirements or substitute "
        "an approximate reusable feature. No design approval is inferred from this candidate."
    )


def _repair_task_identities(plan: dict[str, Any], context: Any) -> list[str]:
    """Qualify colliding draft IDs before any repair writes dependency edges.

    Task type selects a worker contract; task ID identifies one build unit.
    Repeated type names are resolvable across modules, but two candidates in
    the same scope or an unscoped cross-module edge still require judgment.
    """
    tasks = plan.get("build_tasks") or []
    by_id: dict[str, list[int]] = {}
    for index, task in enumerate(tasks):
        by_id.setdefault(str(task.get("task_id") or "").strip(), []).append(index)
    collisions = {identifier for identifier, indexes in by_id.items() if not identifier or len(indexes) > 1}
    if not collisions:
        return []

    by_scope_and_type = _tasks_by_scope_and_type(tasks)
    reserved = set(by_id) - collisions
    identities = [str(task.get("task_id") or "") for task in tasks]
    repairs: list[str] = []
    for index, task in enumerate(tasks):
        old_id = identities[index].strip()
        if old_id not in collisions:
            continue
        scope, kind = _task_scope(task), str(task.get("task_type") or "")
        if not scope or not kind or len(by_scope_and_type[(scope, kind)]) != 1:
            raise ValueError(
                f"Cannot qualify duplicate task_id {old_id!r}: expected one task for "
                f"scope={scope!r}, task_type={kind!r}. Declare distinct build units and explicit dependencies."
            )
        identities[index] = _available_task_id(f"{scope}.{kind}", reserved)
        repairs.append(f"task_id {old_id!r} ({scope}) -> {identities[index]!r}")

    def resolve(reference: str, scope: str, *, page_bundle: bool = False) -> list[str]:
        indexes = by_id.get(str(reference).strip(), [])
        if len(indexes) <= 1:
            return [identities[indexes[0]]] if indexes else [reference]
        local = [index for index in indexes if _task_scope(tasks[index]) == scope]
        if len(local) == 1:
            return [identities[local[0]]]
        # Page work already requires visibility of every module contract. A
        # shared page dependency on a repeated module phase means all owners.
        if not local and page_bundle and all(
            tasks[index].get("task_type") in {"module_contract", "data_models", "business_services"}
            for index in indexes
        ):
            return [identities[index] for index in indexes]
        raise ValueError(
            f"Ambiguous task reference {reference!r} from scope {scope!r}; "
            f"choose an explicit task from {[identities[index] for index in indexes]}"
        )

    # Resolve every typed reference before changing the caller's draft. A
    # rejected ambiguity must not leave half-renamed task identities behind.
    repaired = detach(plan)
    for requirement_id, part in _requirement_realizations(repaired):
        rewritten: dict[str, str] = {}
        references = list(part["task_ids"])
        if part["owner_ref"].startswith("task:"):
            references.append(part["owner_ref"].removeprefix("task:"))
        for reference in references:
            if reference not in collisions:
                continue
            # Repeated IDs are resolved only by the realization's exact outputs,
            # not a category, a nearby task, or an inferred feature meaning.
            owners = [index for index in by_id[reference]
                      if set(part["output_paths"]) <= set(_normalized_owned_paths(tasks[index]))]
            if len(owners) != 1:
                raise ValueError(
                    f"Ambiguous requirement task reference {reference!r} for {requirement_id}: "
                    "exact outputs must identify one original task; preserve the requirement and repair its mapping."
                )
            rewritten[reference] = identities[owners[0]]
        _rename_requirement_tasks(part, rewritten)
    for index, task in enumerate(repaired["build_tasks"]):
        task["task_id"] = identities[index]
        task["depends_on"] = list(dict.fromkeys(
            resolved
            for dependency in task.get("depends_on") or []
            for resolved in resolve(dependency, _task_scope(task), page_bundle=task.get("task_type") == "page_bundle")
        ))
        for need in task.get("integration_needs") or []:
            required_by = need.get("required_by") or {}
            if required_by.get("kind") == "task" and required_by.get("id"):
                required_by["id"] = resolve(required_by["id"], _task_scope(task))[0]
    for decision in repaired.get("carry_forward_decisions") or []:
        if decision.get("affected_build_tasks"):
            decision["affected_build_tasks"] = list(dict.fromkeys(
                resolved
                for reference in decision["affected_build_tasks"]
                for resolved in resolve(reference, str(decision.get("module_id") or ""))
            ))
    if repaired.get("generation_order"):
        order: list[str] = []
        seen: set[str] = set()
        for reference in repaired["generation_order"]:
            indexes = by_id.get(str(reference).strip())
            if indexes is None:
                order.append(reference)  # Advisory phase labels are not task IDs.
                continue
            for index in indexes:
                if identities[index] not in seen:
                    order.append(identities[index])
                    seen.add(identities[index])
        repaired["generation_order"] = order
    plan.update(repaired)
    return repairs


def _repair_module_task_capabilities(plan: dict[str, Any], context: Any) -> list[str]:
    """Use approved surface/path agreement before label-based coverage repair."""
    design = detach(context.get("design_surface_map")) or {}
    approved = {
        surface["surface_id"]
        for surface in design.get("surfaces") or []
        if surface.get("owner") == "app" and surface.get("surface_kind") == "module"
    }
    repairs: list[str] = []
    for task in plan.get("build_tasks") or []:
        surface_id = task.get("surface_id")
        if task.get("task_type") not in _MODULE_LOCAL_TASK_TYPES or surface_id not in approved:
            continue
        paths = _normalized_owned_paths(task)
        if not all(is_safe_app_path(path) for path in task.get("owned_paths") or []):
            continue
        if not all(path.startswith(f"modules/{surface_id}/") for path in paths):
            continue  # Disagreement still belongs to origin validation.
        previous = task.get("capability_pack_id")
        if previous != surface_id:
            task["capability_pack_id"] = surface_id
            repairs.append(
                f"{task.get('task_id')}: capability_pack_id {previous!r} -> {surface_id!r} "
                "from approved surface_id and owned_paths"
            )
        if task.get("surface_kind") != "module":
            task["surface_kind"] = "module"
            repairs.append(f"{task.get('task_id')}: surface_kind -> approved module")
    return repairs


def _repair_plan(plan: dict[str, Any], context: Any) -> list[str]:
    """Fix plan fields whose correct value the validator already knows.

    A live build of a habit tracker failed three times and killed the run on
    four errors that were one mistake: the planner named its module after the
    product category it came from ("crud_pack") instead of the approved surface
    ("habits_module"), and the validator's own message said so - "must match its
    approved surface_id". Every downstream ownership check then keyed off the
    wrong name and failed too.

    Rejecting a plan over a name the system can derive, and asking the model to
    guess it again, costs three LLM rounds and then the whole run. Where the
    approved design already states the answer, apply it and say so. Anything not
    derivable is still rejected by the validators, unchanged.
    """
    repairs: list[str] = []
    design = detach(context.get("design_surface_map")) or {}
    validate_surface_ownership(
        design, context_variables=context, data_contract=detach(context.get("data_contract")),
    )
    packs = plan.get("capability_packs") or []

    approved = {
        surface["surface_id"]: surface
        for surface in design.get("surfaces") or []
        if surface.get("owner") == "app" and surface.get("surface_kind") == "module"
    }

    # 0. An approved module surface with no capability at all. The design
    #    states the identity and the entities; the source is generated_module
    #    by definition for app-owned code. A live build lost its whole run to
    #    two surfaces missing here, which then produced no build tasks and no
    #    bundle. Only absence is repaired: several packs claiming one surface
    #    is a genuine ambiguity and stays an error.
    #    Only when every pack already maps to an approved surface. A pack
    #    pointing somewhere unapproved is a mislabelled module, not a missing
    #    one, and synthesizing here would duplicate it under two identities.
    every_pack_is_approved = all(
        pack.get("surface_id") in approved
        for pack in packs
        if pack.get("surface_kind") == "module"
    )
    for surface_id, surface in (approved.items() if every_pack_is_approved else []):
        if any(pack.get("surface_id") == surface_id for pack in packs):
            continue
        packs.append({
            "surface_id": surface_id,
            "surface_kind": "module",
            "capability_source": "generated_module",
            "capability_pack_id": surface_id,
            "primary_entities": list(surface.get("primary_entities") or []),
            "operations": list(dict.fromkeys([
                *(surface.get("owned_mutations") or []), *(surface.get("custom_reads") or []),
            ])),
        })
        repairs.append(f"{surface_id}: approved module had no capability -> generated_module")
    plan["capability_packs"] = packs

    # 1. The approved surface_id is the module's identity. Adopt it.
    renames: dict[str, str] = {}
    available_now = _context_available_pack_map(context)
    # A surface claimed by more than one pack is the ambiguity step 0 refuses to
    # resolve, and adopting the surface_id on each would give them identical
    # capability_pack_ids - turning two distinguishable packs into twins and
    # making the ambiguity harder to read, or to merge later. Seen live:
    # "habit_registry: requires exactly one module capability (found 2)".
    claims: dict[str, int] = {}
    for pack in packs:
        if pack.get("surface_kind") == "module" and pack.get("surface_id") in approved:
            claims[str(pack["surface_id"])] = claims.get(str(pack["surface_id"]), 0) + 1
    for pack in packs:
        surface_id = pack.get("surface_id")
        surface = approved.get(surface_id)
        if surface is None or pack.get("surface_kind") != "module":
            continue
        if claims.get(str(surface_id), 0) > 1:
            continue
        source = pack.get("capability_source")
        if source not in {"generated_module", None, ""}:
            # After ownership validation, an unregistered provider source on
            # an approved app domain surface is app code mislabelled. The
            # validator says so outright: "For app-owned code use
            # generated_module with capability_pack_id=surface_id=...". Seen live
            # as operator_pack, and previously as managed_capability.
            if str(_pack_id_from_descriptor(pack)) in available_now:
                continue
            pack["capability_source"] = "generated_module"
            repairs.append(f"{surface_id}: {source} with no installed provider -> generated_module")
        pack.setdefault("capability_source", "generated_module")
        current = _pack_id_from_descriptor(pack)
        if current != surface_id:
            if str(current) in renames and renames[str(current)] != str(surface_id):
                raise ValueError(f"Ambiguous module identity {current!r}; preserve requirements and select explicit approved owners")
            renames[str(current)] = str(surface_id)
            pack["capability_pack_id"] = surface_id
            repairs.append(f"capability_pack_id {current!r} -> approved surface_id {surface_id!r}")
        approved_entities = list(surface.get("primary_entities") or [])
        if set(pack.get("primary_entities") or []) != set(approved_entities):
            pack["primary_entities"] = approved_entities
            repairs.append(f"{surface_id}: primary_entities -> approved {approved_entities}")
        operations = list(pack.get("operations") or [])
        missing_operations = [
            operation for operation in dict.fromkeys([
                *(surface.get("owned_mutations") or []), *(surface.get("custom_reads") or []),
            ]) if operation not in operations
        ]
        if missing_operations:
            pack["operations"] = [*operations, *missing_operations]
            repairs.append(f"{surface_id}: preserved approved operations {missing_operations}")

    # A capability sourced from a provider that does not exist, for a surface the
    # design never approved, is invented scope. The live run produced exactly
    # one: a "notifications_pack" declared managed_capability on a habit tracker
    # whose approved design has no notifications surface and whose concept never
    # mentioned them. Three attempts produced it every time, so feedback does not
    # remove it - and one unapproved capability fails the whole plan.
    available = _context_available_pack_map(context)
    surviving: list[dict[str, Any]] = []
    dropped: set[str] = set()
    for pack in packs:
        pack_id = str(_pack_id_from_descriptor(pack))
        source = pack.get("capability_source")
        unbacked = source in {"managed_capability", "framework_pack", "operator_pack"} and pack_id not in available
        if unbacked and pack.get("surface_id") not in approved:
            linked = _linked_requirements(plan, [pack_id], [task for task in plan.get("build_tasks") or []
                                          if task.get("capability_pack_id") == pack_id], str(pack.get("surface_id") or ""))
            if linked:
                raise ValueError(_missing_requirement_design(str(pack.get("surface_id") or ""), linked))
            dropped.add(pack_id)
            repairs.append(
                f"dropped {pack_id!r}: {source} with no registered provider and no approved surface"
            )
            continue
        surviving.append(pack)

    if dropped:
        plan["capability_packs"] = surviving
        kept_tasks = []
        for task in plan.get("build_tasks") or []:
            if str(task.get("capability_pack_id") or "") in dropped:
                repairs.append(f"dropped task {task.get('task_id')!r}: built a capability that was dropped")
                continue
            kept_tasks.append(task)
        dropped_ids = {
            str(t.get("task_id"))
            for t in (plan.get("build_tasks") or [])
            if str(t.get("capability_pack_id") or "") in dropped
        }
        for task in kept_tasks:
            depends = [d for d in (task.get("depends_on") or []) if str(d) not in dropped_ids]
            if len(depends) != len(task.get("depends_on") or []):
                task["depends_on"] = depends
                repairs.append(f"{task.get('task_id')}: dropped dependency on a removed task")
        plan["build_tasks"] = kept_tasks
        packs = surviving

    if not renames:
        return repairs

    # 2. Tasks must agree with the pack they build, including the directory
    #    their owned paths sit under - the rule is module_ids == {pack_id}.
    pack_surface = {_pack_id_from_descriptor(p): p.get("surface_id") for p in packs}
    for task in plan.get("build_tasks") or []:
        pack_id = str(task.get("capability_pack_id") or "")
        new_pack_id = renames.get(pack_id)
        module_dirs = {
            path.split("/")[1]
            for path in _normalized_owned_paths(task)
            if path.startswith("modules/") and len(path.split("/")) > 1
        }
        if new_pack_id is None and len(module_dirs) == 1:
            # The directory is the other way of naming the same module.
            new_pack_id = renames.get(next(iter(module_dirs)))
        if new_pack_id is None:
            continue

        if task.get("capability_pack_id") != new_pack_id:
            task["capability_pack_id"] = new_pack_id
            repairs.append(f"{task.get('task_id')}: capability_pack_id -> {new_pack_id!r}")
        surface_id = pack_surface.get(new_pack_id)
        if surface_id and task.get("surface_id") != surface_id:
            task["surface_id"] = surface_id
            repairs.append(f"{task.get('task_id')}: surface_id -> {surface_id!r}")

        stale = {d for d in module_dirs if d != new_pack_id}
        if stale:
            paths = list(task.get("owned_paths") or [])
            for index, path in enumerate(paths):
                parts = str(path).split("/")
                if len(parts) > 1 and parts[0] == "modules" and parts[1] in stale:
                    parts[1] = new_pack_id
                    paths[index] = "/".join(parts)
            task["owned_paths"] = paths
            repairs.append(
                f"{task.get('task_id')}: owned paths moved from modules/{sorted(stale)[0]}/ to modules/{new_pack_id}/"
            )

    _rename_requirement_modules(plan, renames)
    return repairs

def _required_page_paths(plan: dict[str, Any]) -> list[str]:
    """Use the materializer's identity for both construction and coverage."""
    pages = plan.get("pages") or []
    paths = ["app.json", *[planned_page_path(page) for page in pages]]
    if any(page.get("ui_surface") == "custom_react_page" for page in pages):
        paths.extend(["ui/route_manifest.json", "ui/index.js"])
    return paths


def _authored_page_paths(plan: dict[str, Any], pack_paths: frozenset[str]) -> list[str]:
    """The page artifacts page_bundle authors: every required one a selected pack does not ship."""
    authored = [path for path in _required_page_paths(plan) if path not in pack_paths]
    if any(path.startswith("ui/pages/custom/") for path in authored):
        conflicts = {"ui/route_manifest.json", "ui/index.js"} & pack_paths
        if conflicts:
            raise ValueError(
                "Custom page generation conflicts with selected-pack registry ownership: "
                f"{sorted(conflicts)}. Use the selected pack's declared pages or revise the pack selection; "
                "a page_bundle cannot overwrite its registry."
            )
    return authored


def _note_pack_pages(plan: dict[str, Any], context: Any) -> list[str]:
    """Tell each page_bundle worker which approved pages the selected packs ship."""
    pack_paths = pack_owned_output_paths(context)
    pack_pages = [path for path in _required_page_paths(plan) if path in pack_paths]
    if not pack_pages:
        return []
    note = (
        f"Selected pack templates provide {', '.join(pack_pages)}; do not author those pages. "
        "Their routes, names and bound actions are fixed by the pack."
    )
    repairs: list[str] = []
    for task in plan.get("build_tasks") or []:
        if task.get("task_type") != "page_bundle":
            continue
        message = str(task.get("initial_message") or "").rstrip()
        if note in message:
            continue
        task["initial_message"] = "\n\n".join(part for part in (message, note) if part)
        repairs.append(f"{task.get('task_id')}: named the pack-provided pages {pack_pages}")
    return repairs


def _approved_page_inventory(context: Any) -> list[dict[str, Any]]:
    return list((detach(context.get("experience_spec")) or {}).get("pages") or [])


def _validate_page_realizations(plan: dict[str, Any], context: Any) -> None:
    """A plan implements the approved rendering contract; it cannot re-decide it."""
    planned = {page.get("route"): page for page in plan.get("pages") or []}
    for approved in _approved_page_inventory(context):
        surface = approved.get("ui_surface")
        if surface not in {"declarative_page", "custom_react_page"}:
            raise ValueError(
                f"Approved page {approved.get('route')!r} needs an explicit ui_surface "
                "in ExperienceSpec; revise DesignDocs before app planning."
            )
        candidate = planned.get(approved.get("route"))
        if candidate is not None and candidate.get("ui_surface") != surface:
            raise ValueError(
                f"Page {approved['route']!r} must preserve approved ui_surface {surface!r}; "
                f"received {candidate.get('ui_surface')!r}. Update the plan and page_bundle "
                f"ownership to implement {planned_page_path(approved)!r}; changing the "
                "rendering decision requires revising the approved ExperienceSpec."
            )


def _required_module_paths(pack: dict[str, Any], context: Any) -> dict[str, set[str]]:
    module_id = _pack_id_from_descriptor(pack)
    required = {
        "module_contract": {f"modules/{module_id}/module.yaml"},
        "data_models": {f"modules/{module_id}/backend/schemas.py"},
        "business_services": {f"modules/{module_id}/backend/{name}.py" for name in ("handler", "service")},
    }
    contract = detach(context.get("data_contract")) or {}
    if any(owner == module_id and kind == "module"
           for owner, kind, _collection in iter_data_contract_collections(contract)):
        required["business_services"].update(
            f"modules/{module_id}/backend/{name}.py" for name in ("repo", "policy")
        )
    if pack.get("user_data_scope") is True:
        required["business_services"].add(f"modules/{module_id}/backend/account_data_handler.py")
    return required


def _repair_user_data_scope(plan: dict[str, Any], context: Any) -> list[str]:
    """A module owning per_user collections takes part in account export and deletion.

    The data contract decides it, so the plan records user_data_scope and code
    renders the module's account-data handler (owned by its business_services task).
    """
    repairs = []
    for pack in plan.get("capability_packs") or []:
        module_id = _pack_id_from_descriptor(pack)
        if pack.get("capability_source") != "generated_module" or not owns_per_user_collections(module_id, context.get("data_contract")):
            continue
        if pack.get("user_data_scope") is not True:
            repairs.append(f"{module_id}: user_data_scope {pack.get('user_data_scope')!r} -> true (owns per_user collections)")
            pack["user_data_scope"] = True
    return repairs


def _authored_module_paths(
    pack: dict[str, Any], context: Any, pack_paths: frozenset[str], facades: Sequence[PackFacadeDirectory],
) -> dict[str, set[str]]:
    """The required module files a task authors: those no selected pack ships or holds in its facade module."""
    return {
        kind: {path for path in paths if not _pack_owns(path, pack_paths, facades)}
        for kind, paths in _required_module_paths(pack, context).items()
    }


def _pack_owns(path: str, pack_paths: frozenset[str], facades: Sequence[PackFacadeDirectory]) -> bool:
    return path in pack_paths or any(facade.owns(path) for facade in facades)


def _is_glob_pattern(path: str) -> bool:
    return bool(_GLOB_CHARS.intersection(path))


_WORKSPACE_APP_ROOT = "app/"


def _strip_workspace_app_root(plan: dict[str, Any]) -> list[str]:
    """Owned paths are app-bundle-relative; a leading workspace ``app/`` names the bundle root itself.

    Chat 5cd39d67 at deeef42d planned its page task owning ``app/app.json``,
    the manifest's physical workspace path. The bundle has no ``app/``
    directory (generated_bundle_scanner strips the same prefix from pack
    contract paths), so the path named a stray file, not the manifest, and the
    page task failed the approved-page check. The prefix is removed from the
    leading segment only; ``app/`` deeper in a path, and an ``app.json`` or
    ``application/`` segment, are untouched. A path the planner wrote in both
    spellings is kept once.
    """
    repairs: list[str] = []
    for task in plan.get("build_tasks") or []:
        owned = task.get("owned_paths")
        if not isinstance(owned, list):
            continue
        stripped = [
            text for path in owned
            if isinstance(path, str)
            and (text := path.replace("\\", "/").strip()).startswith(_WORKSPACE_APP_ROOT)
            and text != _WORKSPACE_APP_ROOT
        ]
        if not stripped:
            continue
        targets = {text.removeprefix(_WORKSPACE_APP_ROOT) for text in stripped}
        rewritten: list[Any] = []
        for path in owned:
            spelled = path.replace("\\", "/").strip() if isinstance(path, str) else None
            if spelled is not None and spelled in stripped:
                path = spelled.removeprefix(_WORKSPACE_APP_ROOT)
            if path in targets and path in rewritten:
                continue
            rewritten.append(path)
        task["owned_paths"] = rewritten
        repairs.append(
            f"{task.get('task_id')}: owned paths {stripped} are workspace paths; "
            "owned paths are relative to the app bundle root"
        )
    for _requirement_id, part in _requirement_realizations(plan):
        part["output_paths"] = [path.removeprefix(_WORKSPACE_APP_ROOT) for path in part["output_paths"]]
    return repairs


def _apply_dispatch_path_rules(plan: dict[str, Any]) -> list[str]:
    """Hold every owned path to task dispatch's rules before anything else reads it.

    Review checked owned paths with is_safe_app_path, which accepts a pattern;
    dispatch normalizes each with normalize_owned_path, which refuses one.
    Chat e67150d7 at 49c69860 passed review owning
    modules/billing_portal/contracts/*.yaml and
    modules/task_registry/contracts/*.yaml, and dispatch ended the run in
    AppPlanAgent's turn: "glob characters not allowed in owned path".

    A pattern names no file. The companion manifests it reaches for are
    already optional outputs of the module's module_contract task
    (optional_task_output_paths), so it is released; a task left with nothing
    to build is dropped with its dependency edges. Any other path dispatch
    refuses (absolute, traversal, a secret term) needs the planner, so the
    plan is rejected with dispatch's own message for each.
    """
    refused: list[str] = []
    for task in plan.get("build_tasks") or []:
        for path in task.get("owned_paths") or []:
            try:
                normalize_owned_path(path)
            except ValueError as error:
                if not _is_glob_pattern(str(path)):
                    refused.append(f"{task.get('task_id')}: {error}")
    if refused:
        raise ValueError(
            "Task dispatch refuses these owned paths; every owned path is one exact "
            "app-bundle-relative file:\n- " + "\n- ".join(refused)
        )
    return _release_owned_paths(
        plan, _is_glob_pattern, owner="a pattern, not a file",
        provider="task dispatch refuses patterns, and a module's contracts/ companions "
        "are optional outputs of its module_contract task",
    )


def _repair_selected_pack_sources(plan: dict[str, Any], context: Any) -> list[str]:
    """The registered source is fixed once a known pack identity is supplied."""
    selected = _context_available_pack_map(context)
    repairs = []
    for pack in plan.get("capability_packs") or []:
        registered = selected.get(_pack_id_from_descriptor(pack)) or {}
        source = registered.get("capability_source")
        if source and pack.get("capability_source") != source:
            pack["capability_source"] = source
            repairs.append(f"{_pack_id_from_descriptor(pack)}: capability_source -> selected {source}")
    return repairs


def _repair_selected_pack_inventory(plan: dict[str, Any], context: Any) -> list[str]:
    """Close selected registry inventory before constructing its worker tasks."""
    packs, pages, tasks = _apply_selected_pack_files(
        capability_packs=plan.get("capability_packs") or [],
        pages=plan.get("pages") or [],
        build_tasks=plan.get("build_tasks") or [],
        context_variables=context,
    )
    plan.update(capability_packs=packs, pages=pages, build_tasks=tasks)
    return []


def _repair_coverage(plan: dict[str, Any], context: Any) -> list[str]:
    """Supply the coverage facts the validator already computes.

    With ownership repaired, a live run failed on two errors that both name
    their own answer:

      - pages must preserve the approved name/route inventory:
        [('Dashboard', '/dashboard'), ('Habits', '/habits')]
      - habit_registry/business_services is incomplete; missing
        ['modules/habit_registry/backend/account_data_handler.py',
         'modules/habit_registry/backend/policy.py']

    The approved inventory comes from experience_spec and the required file set
    is derived from the pack itself, so neither needs a model. Anything the
    validator cannot derive is still left for it to reject.
    """
    repairs: list[str] = []
    tasks = plan.get("build_tasks") or []
    if context.get("build_mode") == "revision" or context.get("brownfield_build_path"):
        return repairs

    # 1. The approved page inventory is authority.
    approved_pages = _approved_page_inventory(context)
    expected = [
        (page["name"], page["route"])
        for page in approved_pages
    ]
    if expected:
        planned = plan.get("pages") or []
        approved_by_route = {page["route"]: page for page in approved_pages}
        for page in planned:
            # Selected pack descriptors can add pages after the model's plan is
            # checked. Their rendering contract comes from the approved design.
            approved_page = approved_by_route.get(page.get("route"))
            if approved_page is not None and not page.get("ui_surface"):
                page["ui_surface"] = approved_page["ui_surface"]
                repairs.append(f"{page['route']}: copied approved ui_surface for constructed page")
        by_route = {page.get("route"): page for page in planned}
        by_name = {page.get("name"): page for page in planned}
        if {(p.get("name"), p.get("route")) for p in planned} != set(expected):
            rebuilt = []
            for approved_page in approved_pages:
                name, route = approved_page["name"], approved_page["route"]
                existing = by_route.get(route) or by_name.get(name) or {}
                page = {
                    key: value for key, value in approved_page.items()
                    if key in {"name", "route", "purpose", "design_intent", "primary_entities", "primary_actions", "ui_surface"}
                }
                page.update(existing)
                page["name"], page["route"] = name, route
                page["ui_surface"] = approved_page["ui_surface"]
                rebuilt.append(page)
            plan["pages"] = rebuilt
            repairs.append(f"pages -> approved inventory {sorted(expected)}")

    # 2. page_bundle must own app.json and every materialized page file a
    #    selected pack does not ship from its templates.
    pack_paths = pack_owned_output_paths(context)
    required_paths = _authored_page_paths(plan, pack_paths)
    bundle_tasks = [task for task in tasks if task.get("task_type") == "page_bundle"]
    if not bundle_tasks and plan.get("pages"):
        task = {
            "task_id": _available_task_id("page_bundle", {str(task.get("task_id")) for task in tasks}),
            "task_type": "page_bundle",
            "capability_pack_id": None,
            "surface_id": "page_bundle",
            "surface_kind": "ui_only",
            "initial_agent": _CANONICAL_INITIAL_AGENTS["page_bundle"],
            "execution_target": "AppGenerator",
            "description": "Materialize the approved app manifest and page inventory.",
            "initial_message": (
                "Generate app.json and every approved page in app_build_plan.pages at its "
                "route-derived owned path. Preserve each page's approved purpose and design "
                "intent. Bind actions using the dependency module contracts."
            ),
            "owned_paths": list(required_paths),
            "depends_on": [],
        }
        tasks.append(task)
        bundle_tasks.append(task)
        repairs.append(f"constructed page_bundle owning {required_paths}")
    if bundle_tasks and plan.get("pages"):
        wanted_stems = {path.lower() for path in required_paths}

        # A plan may split page work across several page_bundle tasks. The
        # coverage rule takes the union of what they own, but a separate rule
        # forbids two tasks owning the same artifact - "task batches cannot
        # race". So assign each required path to exactly one task: leave it
        # where it already lives, and give the rest to the first task.
        assigned: dict[str, dict[str, Any]] = {}
        for task in bundle_tasks:
            for path in _normalized_owned_paths(task):
                if path.lower() in wanted_stems:
                    assigned.setdefault(path, task)

        for path in required_paths:
            assigned.setdefault(path, bundle_tasks[0])

        # One typed custom bundle owns its route registry and all its components.
        # Splitting these across workers cannot produce a complete registry.
        custom_paths = [path for path in required_paths if path.startswith("ui/pages/custom/")]
        if custom_paths:
            custom_owner = assigned["ui/route_manifest.json"]
            for path in [*custom_paths, "ui/route_manifest.json", "ui/index.js"]:
                assigned[path] = custom_owner

        for task in bundle_tasks:
            mine = [path for path in required_paths if assigned.get(path) is task]
            others: list[str] = []
            for path in task.get("owned_paths") or []:
                text = str(path)
                if text.lower() in wanted_stems:
                    continue
                if normalize_app_path(text) in pack_paths:
                    # An approved page a selected pack ships: releasing it is
                    # release_pack_owned_paths' decision, not an unapproved page.
                    others.append(text)
                    continue
                # Rewriting pages to the approved inventory can orphan a page
                # file the planner invented. Keeping it fails materialization
                # with "page has no approved plan identity", because no approved
                # page claims that stem. Non-page assets are untouched.
                if text.startswith("ui/pages/") and text.endswith((".yaml", ".yml", ".jsx")):
                    repairs.append(f"{task.get('task_id')}: dropped {text!r}, not an approved page")
                    continue
                others.append(text)
            merged = others + mine
            if merged != list(task.get("owned_paths") or []):
                task["owned_paths"] = merged
                repairs.append(
                    f"{task.get('task_id')}: page_bundle owns {len(mine)} of "
                    f"{len(required_paths)} page artifact(s), no shared ownership"
                )

        empty = [
            task
            for task in bundle_tasks
            if task.get("task_type") == "page_bundle" and not (task.get("owned_paths") or [])
        ]
        if empty:
            empty_ids = {str(task.get("task_id")) for task in empty}
            tasks = [task for task in tasks if task not in empty]
            for task in tasks:
                depends = [d for d in (task.get("depends_on") or []) if str(d) not in empty_ids]
                if len(depends) != len(task.get("depends_on") or []):
                    task["depends_on"] = depends
            for task_id in sorted(empty_ids):
                repairs.append(f"dropped task {task_id!r}: no approved page left to build")
            plan["build_tasks"] = tasks

    # 3. Every generated module needs its required files owned by a task of the
    #    right type. The required set is derived exactly as the validator does;
    #    files a selected pack owns (its templates, its facade module) need no task.
    facades = pack_facade_directories(context)
    path_owners: dict[str, list[str]] = {}
    for task in tasks:
        for path in _normalized_owned_paths(task):
            path_owners.setdefault(path, []).append(str(task.get("task_id")))
    for pack in plan.get("capability_packs") or []:
        if pack.get("surface_kind") != "module" or pack.get("capability_source") != "generated_module":
            continue
        module_id = _pack_id_from_descriptor(pack)
        module_tasks = [task for task in tasks if task.get("capability_pack_id") == module_id]
        required = _authored_module_paths(pack, context, pack_paths, facades)

        for kind, paths in required.items():
            typed = [t for t in module_tasks if t.get("task_type") == kind]
            owned = {path for t in typed for path in _normalized_owned_paths(t)}
            missing = sorted(paths - owned)
            if not missing:
                continue
            conflicts = {path: path_owners[path] for path in missing if path in path_owners}
            if conflicts:
                raise ValueError(
                    f"{module_id}/{kind}: cannot repair coverage; required paths already owned "
                    f"by other tasks: {conflicts}. Correct the existing task's module/type ownership."
                )
            if typed:
                target = typed[0]
                target["owned_paths"] = list(target.get("owned_paths") or []) + missing
                repairs.append(f"{target.get('task_id')}: {kind} gained {missing}")
            else:
                synthesized = {
                    "task_id": _available_task_id(
                        f"task_{module_id}_{kind}", {str(task.get("task_id")) for task in tasks},
                    ),
                    "task_type": kind,
                    "capability_pack_id": module_id,
                    "surface_id": pack.get("surface_id"),
                    "surface_kind": "module",
                    "initial_agent": _CANONICAL_INITIAL_AGENTS[kind],
                    "execution_target": _CANONICAL_INITIAL_AGENTS[kind],
                    "description": _synthesized_task_brief(kind, module_id, pack),
                    "initial_message": _synthesized_task_brief(kind, module_id, pack),
                    "owned_paths": missing,
                    "depends_on": [],
                }
                tasks.append(synthesized)
                module_tasks.append(synthesized)
                repairs.append(f"synthesized {synthesized['task_id']!r} owning {missing}")
                target = synthesized
            for path in missing:
                path_owners[path] = [str(target["task_id"])]

    contract = detach(context.get("data_contract"))
    if contract and not any("data/contract.json" in _normalized_owned_paths(task) for task in tasks):
        persistence_tasks = [task for task in tasks if task.get("task_type") == "persistence_contract"]
        if persistence_tasks:
            persistence_tasks[0]["owned_paths"] = [
                *(persistence_tasks[0].get("owned_paths") or []), "data/contract.json",
            ]
            repairs.append(f"{persistence_tasks[0]['task_id']}: added approved data/contract.json")
        else:
            tasks.append({
                "task_id": _available_task_id("data_contract", {str(task.get("task_id")) for task in tasks}),
                "task_type": "persistence_contract", "capability_pack_id": None,
                "surface_id": "data_contract", "surface_kind": "module",
                "initial_agent": "DatabaseAgent", "execution_target": "AppGenerator",
                "description": "Serialize the approved DesignDocs data contract.",
                "initial_message": "The approved data_contract is final. Code serializes data/contract.json; emit empty database_files and code_files.",
                "owned_paths": ["data/contract.json"], "depends_on": [],
            })
            repairs.append("constructed persistence_contract owner for approved data/contract.json")
    plan["build_tasks"] = tasks
    repairs.extend(_repair_module_task_dependencies(plan, context))
    return repairs


def _repair_module_task_dependencies(plan: dict[str, Any], context: Any) -> list[str]:
    """Supply direct contract inputs after every module task has been synthesized.

    The approved data/contract.json serializer is an input of every persistent
    module's data_models and business_services tasks, never their consumer.
    Chat 5cd39d67 at deeef42d drafted the reverse edge (the persistence task
    waiting on both data_models tasks); adding the canonical edge beside it made
    a cycle, and review rejected the plan with "dependency cycle detected". A
    reverse edge from a persistence task to a task that now depends on it is
    dropped; every other edge the planner declared is kept.
    """
    repairs: list[str] = []
    tasks = plan.get("build_tasks") or []
    by_scope_and_type = _tasks_by_scope_and_type(tasks)
    persistence_tasks = [
        str(task["task_id"])
        for task in tasks
        if task.get("task_type") == "persistence_contract"
        and "data/contract.json" in _normalized_owned_paths(task)
    ]
    pack_paths = pack_owned_output_paths(context)
    facades = pack_facade_directories(context)
    persistence_consumers: set[str] = set()
    for pack in plan.get("capability_packs") or []:
        if pack.get("surface_kind") != "module" or pack.get("capability_source") != "generated_module":
            continue
        module_id = _pack_id_from_descriptor(pack)
        module_tasks = [task for task in tasks if task.get("capability_pack_id") == module_id]
        prerequisites: dict[str, str] = {}
        required_paths = _authored_module_paths(pack, context, pack_paths, facades)
        for kind in ("module_contract", "data_models"):
            if not required_paths[kind]:
                continue  # the selected pack's template is the contract input
            path = next(iter(required_paths[kind]))
            owners = [
                task for task in by_scope_and_type.get((module_id, kind), [])
                if path in _normalized_owned_paths(task)
            ]
            if len(owners) != 1:
                raise ValueError(
                    f"{path}: expected exactly one {kind} task owner; "
                    f"found {[task.get('task_id') for task in owners]}"
                )
            prerequisites[kind] = str(owners[0]["task_id"])

        for task in module_tasks:
            kind = task.get("task_type")
            if kind not in {"data_models", "business_services"}:
                continue
            required = (
                [prerequisites["module_contract"]] if kind == "data_models" and "module_contract" in prerequisites
                else [] if kind == "data_models" else list(prerequisites.values())
            )
            if f"modules/{module_id}/backend/repo.py" in required_paths["business_services"]:
                required.extend(persistence_tasks)
                persistence_consumers.add(str(task["task_id"]))
            declared = list(task.get("depends_on") or [])
            missing = [task_id for task_id in required if task_id not in declared]
            if missing:
                task["depends_on"] = [*declared, *missing]
                repairs.append(
                    f"{task.get('task_id')}: added prerequisite contract inputs {missing}"
                )
    for task in tasks:
        if str(task.get("task_id")) not in persistence_tasks:
            continue
        declared = list(task.get("depends_on") or [])
        reverse = [task_id for task_id in declared if str(task_id) in persistence_consumers]
        if reverse:
            task["depends_on"] = [task_id for task_id in declared if task_id not in reverse]
            repairs.append(
                f"{task.get('task_id')}: dropped reverse edges {reverse}; those tasks consume "
                "the data contract it serializes"
            )
    return repairs

# What each synthesized task tells its worker to do. A task the coverage
# repair invents still has to run: task_batches rejects any task whose
# prompt field is empty, so a task created without one does not merely lack
# polish - it kills the build. Six such tasks ended a live run 55 seconds in.
#
# Phrasing follows the planner's own, so a synthesized task reads like the
# ones beside it rather than announcing itself as machine-filled.
_SYNTHESIZED_TASK_BRIEFS = {
    "business_services": (
        "Implement the services required for managing {subject} operations, "
        "including the business logic and events the module contract declares."
    ),
    "data_models": (
        "Create the data models required for the {subject} entity based on the "
        "contract and persistence rules."
    ),
    "module_contract": (
        "Define the module contract that outlines the actions and relationships "
        "for managing {subject}."
    ),
    "persistence_contract": (
        "Establish data ownership over the {subject} collection with its schema "
        "and lifecycle policies in place."
    ),
    "data_migrations": (
        "Define the additive migrations required for the {subject} entity."
    ),
    "service_foundation": (
        "Establish the shared service foundation {subject} depends on."
    ),
}


def _synthesized_task_brief(kind: str, module_id: str, pack: dict[str, Any]) -> str:
    """Describe the work a synthesized task covers, from what the plan states.

    The entity the pack owns is the subject where one exists, matching how the
    planner writes these ("managing Tool operations"). A pack owning no entity
    falls back to the module id, which is still specific enough to act on.
    """
    entities = [str(e).strip() for e in (pack.get("primary_entities") or []) if str(e).strip()]
    subject = entities[0] if entities else str(module_id).replace("_", " ")
    template = _SYNTHESIZED_TASK_BRIEFS.get(kind)
    if template:
        return template.format(subject=subject)
    readable = str(kind).replace("_", " ")
    return f"Complete the {readable} work for {subject} as the approved plan describes."

WORD = chr(92) + "b"  # regex word boundary

def _repair_page_contract_dependencies(plan: dict[str, Any], context: Any) -> list[str]:
    """Let a page_bundle task see the module contracts it is told to copy from.

    The page agent is instructed to "Copy every module action id exactly from
    dependency module.yaml outputs". A task only receives the outputs of its
    direct depends_on entries, and a live plan wired both page bundles to
    data_models and business_services and not to module_contract - the task that
    owns modules/*/module.yaml. So the agent was told to copy from a set that was
    always empty, and it did the only other thing available: it guessed.

    It guessed /api/modules/habits/create_habit for a module whose id is
    habits_registry. The canonical form was right because the rule is stated
    four times; the identity was invented because the contract never arrived.

    Ordering already held - business_services depends on module_contract, so the
    pages ran after it. Only visibility was missing.
    """
    repairs: list[str] = []
    tasks = plan.get("build_tasks") or []
    by_scope_and_type = _tasks_by_scope_and_type(tasks)
    contracts = [
        str(task.get("task_id"))
        for (_, kind), owners in by_scope_and_type.items() if kind == "module_contract"
        for task in owners if str(task.get("task_id") or "").strip()
    ]
    if not contracts:
        return repairs

    for task in tasks:
        if task.get("task_type") != "page_bundle":
            continue
        declared = [str(dep) for dep in (task.get("depends_on") or []) if str(dep).strip()]
        # Every module contract, not a guessed subset: which modules a page binds
        # to is the page agent's call, and a page denied one contract is exactly
        # the failure this repairs. They are already ordered ahead of pages, so
        # naming them adds visibility and not serialization.
        missing = [contract for contract in contracts if contract not in declared]
        if not missing:
            continue
        task["depends_on"] = [*declared, *missing]
        repairs.append(
            f"{task.get('task_id')}: page_bundle could not see {missing}; "
            "added so its endpoints can name the real module"
        )
    return repairs


def validate_plan_dependencies(plan: dict[str, Any], context: Any) -> None:
    """Every depends_on must name a task the plan actually declares.

    Nothing checked this. The repairs above only strip dependencies on tasks
    they themselves removed, so a task the planner never declared in the first
    place survived review and killed the run at batch-build time instead:

        AG2 turn failed for AppPlanAgent: task batch 'app_build_tasks' has
        unresolved or cyclic dependencies: {'task_completion_4': [...]}

    That is a fatal ValueError with no feedback path, so the plan is discarded
    and the build is over. Raising here routes the same problem into the normal
    revision loop, where the agent is told which ids are missing.

    Rejecting rather than dropping the edge is deliberate. A task waiting on
    an id that was never declared usually means the planner intended that work
    and omitted it; silently deleting the dependency would hand back a plan
    that looks valid and builds an app missing whatever those tasks owned.
    """
    tasks = plan.get("build_tasks") or []
    declared = {
        str(task.get("task_id"))
        for task in tasks
        if str(task.get("task_id") or "").strip()
    }
    dangling = {}
    for task in tasks:
        missing = [
            str(dep)
            for dep in (task.get("depends_on") or [])
            if str(dep).strip() and str(dep) not in declared
        ]
        if missing:
            dangling[str(task.get("task_id"))] = missing
    if dangling:
        detail = "; ".join(
            f"{task_id} waits on {missing}" for task_id, missing in sorted(dangling.items())
        )
        raise ValueError(
            "Every depends_on must name a task_id this plan declares. "
            f"{detail}. Either declare the missing tasks, or drop the dependency "
            "if the work is already covered by a task that is present."
        )
    deterministic_topological_order(
        tasks,
        item_id=lambda task: str(task.get("task_id") or ""),
        dependencies=lambda task: task.get("depends_on") or [],
    )



def _repair_managed_facade_capabilities(plan: dict[str, Any], context: Any) -> list[str]:
    """Separate the approved MozaiksPay facade from its managed provider.

    The pack contract fixes the facade's identity, pages and actions. The
    approved design fixes its data ownership. Repair these before the generic
    module repair interprets a provider claiming the facade as its owner.
    """
    design = detach(context.get("design_surface_map")) or {}
    surfaces = {surface["surface_id"]: surface for surface in design.get("surfaces") or []}
    approved = {
        surface_id: surface for surface_id, surface in surfaces.items()
        if surface.get("owner") == "app" and surface.get("surface_kind") == "module"
        and "mozaikspay" in (surface.get("source_capability_packs") or [])
    }
    if not approved or context.get("monetization_enabled") is False:
        return []
    available = _context_available_pack_map(context)
    if (available.get("mozaikspay") or {}).get("capability_source") != "managed_capability":
        return []  # Origin validation still requires a registered provider.
    root = resolve_packaged_build_context("mozaikspay")
    if root is None:
        raise FileNotFoundError("Installed mozaikspay contract is missing")
    contract = yaml.safe_load((root / "contract.yaml").read_text(encoding="utf-8"))
    repairs: list[str] = []
    packs = plan.get("capability_packs") or []
    for facade in contract["facades"]:
        facade_id = facade["module_id"]
        surface = approved.get(facade_id)
        if surface is None:
            continue
        descriptor = _facade_pack_descriptor(facade, approved_surface=surface)
        if descriptor is None:
            continue
        providers = [pack for pack in packs if _pack_id_from_descriptor(pack) == "mozaikspay"]
        if len(providers) != 1:
            continue  # Provider selection and competing declarations keep their existing validation path.
        provider = providers[0]
        if provider.get("surface_id") in approved or provider.get("surface_kind") == "module":
            provider.update(
                surface_id="mozaikspay_managed", surface_kind="external_integration",
                implementation_mode="external_integration", capability_source="managed_capability",
            )
            repairs.append("mozaikspay: separated managed provider from the app-owned facade surface")

        # A second name is a duplicate only when its scope proves it is this
        # facade. Never consume an independently approved module or app data.
        page_names = set(descriptor["primary_pages"])
        actions = set(descriptor["operations"])
        duplicates = []
        for pack in packs:
            pack_id = _pack_id_from_descriptor(pack)
            if pack_id in {"mozaikspay", facade_id} or pack_id in available or pack_id in surfaces:
                continue
            if pack.get("capability_source") != "generated_module" or pack.get("surface_kind") != "module":
                continue
            if pack.get("primary_entities") or pack.get("user_data_scope"):
                continue
            owned_pages = {str(page).lower().replace(" ", "_") for page in pack.get("primary_pages") or []}
            if not owned_pages <= page_names or not set(pack.get("operations") or []) <= actions:
                continue
            same_surface = pack.get("surface_id") == facade_id
            facade_only = pack.get("surface_id") not in surfaces and bool(owned_pages)
            if same_surface or facade_only:
                duplicates.append(pack)
        renamed = {_pack_id_from_descriptor(pack) for pack in duplicates}
        if renamed:
            packs = [pack for pack in packs if pack not in duplicates]
            repairs.append(f"{facade_id}: consolidated duplicate facade capabilities {sorted(renamed)}")

        existing = [pack for pack in packs if _pack_id_from_descriptor(pack) == facade_id]
        if not existing:
            packs.append(descriptor)
            repairs.append(f"{facade_id}: added generated_module capability from the pack contract")
        elif len(existing) == 1:
            target = existing[0]
            fixed = {key: descriptor[key] for key in ("surface_id", "surface_kind", "capability_source", "primary_entities")}
            fixed["operations"] = list(dict.fromkeys([*(target.get("operations") or []), *descriptor["operations"]]))
            existing_pages = list(target.get("primary_pages") or [])
            named_pages = {str(page).lower().replace(" ", "_") for page in existing_pages}
            fixed["primary_pages"] = existing_pages + [page for page in descriptor["primary_pages"] if page not in named_pages]
            if any(target.get(key) != value for key, value in fixed.items()):
                target.update(fixed)
                repairs.append(f"{facade_id}: restored contract scope and approved entity ownership")

        for task in plan.get("build_tasks") or []:
            pack_id = task.get("capability_pack_id")
            if pack_id == "mozaikspay" and task.get("task_type") == "api_surface":
                fixed = {"surface_id": provider["surface_id"], "surface_kind": "external_integration"}
                if any(task.get(key) != value for key, value in fixed.items()):
                    task.update(fixed)
                    repairs.append(f"{task.get('task_id')}: adapter uses the managed provider surface")
            elif pack_id in renamed:
                task.update(capability_pack_id=facade_id, surface_id=facade_id, surface_kind="module")
                task["owned_paths"] = [
                    "/".join(["modules", facade_id, *path.split("/")[2:]])
                    if path.startswith("modules/") and path.split("/")[1] in renamed else path
                    for path in _normalized_owned_paths(task)
                ]
                repairs.append(f"{task.get('task_id')}: duplicate facade task now owns {facade_id}")
        _rename_requirement_modules(plan, dict.fromkeys(renamed, facade_id))
    if repairs:
        plan["capability_packs"] = packs
    return repairs


def _repair_contract_task_operations(plan: dict[str, Any], context: Any) -> list[str]:
    """Name the planner's operations in the task the contract agent reads.

    ConfigMiddlewareAgent is told to "Treat the action list in
    current_build_task.initial_message as a closed contract. Emit every named
    action exactly once." Nothing guarantees that message names any actions.

    A live plan declared operations ['create_habit', 'list_habits',
    'record_checkin'] on the pack and gave the contract task this entire
    initial_message:

        Module to manage habits including creation, check-in recording,
        and retrieval.

    The closed contract was prose. The agent inferred create_habit and
    record_checkin from "creation, check-in recording", missed "retrieval", and
    shipped a module with no read at all. Its pages then bound to list_habits,
    which no module declared, and acceptance rejected the bundle.

    #634 covered the case where the planner omits a read entirely. This covers
    the larger one: the planner declared the operation and it never reached the
    agent. Operations already named in the message are left alone, so the two
    repairs compose rather than duplicate.
    """
    repairs: list[str] = []
    tasks = plan.get("build_tasks") or []

    for pack in plan.get("capability_packs") or []:
        if pack.get("surface_kind") != "module" or pack.get("capability_source") != "generated_module":
            continue
        operations = [str(op).strip() for op in (pack.get("operations") or []) if str(op).strip()]
        if not operations:
            continue
        module_id = str(_pack_id_from_descriptor(pack))
        contract = next(
            (
                task
                for task in tasks
                if task.get("task_type") == "module_contract"
                and str(_pack_id_from_descriptor(task)) == module_id
            ),
            None,
        )
        if contract is None:
            continue
        message = str(contract.get("initial_message") or "").rstrip()
        # Word-boundary, so record_checkin does not mask checkin.
        missing = [op for op in operations if not re.search(WORD + re.escape(op) + WORD, message)]
        if not missing:
            continue
        named = ", ".join(f"`{op}`" for op in operations)
        note = (
            f"Actions for this module (authoritative, from the approved plan): {named}. "
            "Every action must appear in the final actions[] exactly once with these ids. "
            "Declare approved writes and custom reads; code constructs canonical list/get reads. "
            "For app_wide collections with protected writes, explicitly declare the canonical "
            "reads and their permissions, API exposure, and handler policy. "
            "The prose above describes the module; this list defines it."
        )
        contract["initial_message"] = "\n\n".join(part for part in (message, note) if part)
        repairs.append(
            f"{module_id}: contract task {str(contract.get('task_id'))!r} did not name "
            f"{missing}; added the approved operation list"
        )
    return repairs


_HANDLER_ENTRYPOINT = re.compile(r"backend\.handler:([A-Za-z_][A-Za-z0-9_]*)")
_HANDLER_SPLIT_NOTE = "Handler split (from the approved plan):"


def _manifest_handler_class(module_id: str, context: Any) -> str | None:
    """The module.handler class an existing module.yaml declares (a revision baseline or an earlier write)."""
    files = detach(context.get("generated_files")) or {}
    source = files.get(f"modules/{module_id}/module.yaml") if isinstance(files, dict) else None
    if isinstance(source, dict):
        source = source.get("content")
    if not isinstance(source, str):
        return None
    try:
        manifest = yaml.safe_load(source)
    except yaml.YAMLError:
        return None
    entrypoint = str(((manifest or {}).get("module") or {}).get("handler") or "") if isinstance(manifest, dict) else ""
    match = _HANDLER_ENTRYPOINT.fullmatch(entrypoint)
    return match.group(1) if match else None


def _module_handler_class(module_id: str, context: Any, *messages: str) -> tuple[str, str]:
    """The module.handler class and where it came from.

    In order: a class a plan message names, the class the existing module.yaml
    declares, and only then the module-contract naming rule.
    """
    for message in messages:
        match = _HANDLER_ENTRYPOINT.search(message)
        if match:
            return match.group(1), "plan"
    declared = _manifest_handler_class(module_id, context)
    if declared:
        return declared, "module_yaml"
    return "".join(part[:1].upper() + part[1:] for part in module_id.split("_") if part) + "Module", "convention"


def _base_handler_class(handler_class: str) -> str:
    for suffix in ("Module", "Handler"):
        stem = handler_class[: -len(suffix)]
        if handler_class.endswith(suffix) and stem:
            return f"{stem}Base{suffix}"
    return f"{handler_class}Base"


def _restate_handler_split(plan: dict[str, Any], context: Any) -> list[str]:
    """Restate the two-file handler contract in every business_services task that owns base_handler.py.

    The planner prompt requires each business_services initial_message to name
    the module.handler class and the base/workspace split. A live CRM build's
    message instead read "Implement backend/handler.py, backend/service.py,
    backend/repo.py, backend/policy.py": no base_handler.py, and an instruction
    to author a code-rendered policy. ServiceAgent followed the message, wrote a
    flat handler class and a policy copy, and lost its one correction round
    before ever emitting base_handler.py, which ended the run.

    Everything stated here is projected from declared inputs: the owned paths,
    the module's data_contract collections, and the handler entrypoint a task
    message names or the existing module.yaml declares. Only when neither does
    the module-contract naming rule supply a name; the note says so, and the
    module_contract task (if planned) is told the same name, so both tasks name
    one class.
    """
    repairs: list[str] = []
    tasks = plan.get("build_tasks") or []
    data_contract = detach(context.get("data_contract")) or {}
    persistent = {
        owner for owner, kind, _collection in iter_data_contract_collections(data_contract)
        if kind == "module"
    }
    for task in tasks:
        if task.get("task_type") != "business_services":
            continue
        owned = _normalized_owned_paths(task)
        for base_path in [path for path in owned if path.endswith("/backend/base_handler.py")]:
            parts = base_path.split("/")
            if len(parts) != 4 or parts[0] != "modules":
                continue
            module_id = parts[1]
            backend = f"modules/{module_id}/backend"
            message = str(task.get("initial_message") or "").rstrip()
            if _HANDLER_SPLIT_NOTE in message:
                continue
            contract = next(
                (
                    candidate for candidate in tasks
                    if candidate.get("task_type") == "module_contract"
                    and f"modules/{module_id}/module.yaml" in _normalized_owned_paths(candidate)
                ),
                None,
            )
            contract_message = str((contract or {}).get("initial_message") or "").rstrip()
            handler_class, source = _module_handler_class(module_id, context, contract_message, message)
            base_class = _base_handler_class(handler_class)
            collections = module_id in persistent
            schemas_path = f"{backend}/schemas.py"
            rendered = [
                path for path in owned
                if path.startswith(f"{backend}/") and (
                    (path in {f"{backend}/policy.py", schemas_path} and collections)
                    or (path == f"{backend}/account_data_handler.py"
                        and owns_per_user_collections(module_id, data_contract))
                )
            ]
            authored = [path for path in owned if path.startswith(f"{backend}/") and path not in rendered]
            not_authored = [*rendered, *([] if schemas_path in owned else [schemas_path])]
            entrypoint = f"`backend.handler:{handler_class}`"
            identity = {
                "plan": f"The plan names module.yaml module.handler {entrypoint}.",
                "module_yaml": f"The existing module.yaml declares module.handler {entrypoint}.",
                "convention": (
                    f"No declared module.handler exists yet; by the module-contract naming rule it is "
                    f"{entrypoint}. If the accepted module.yaml declares another class, use that class "
                    "and name its base accordingly."
                ),
            }[source]
            canonical = (
                f" Code adds the canonical create/update/delete and list/get methods to {handler_class} "
                "and their service.py and repo.py functions; author them in neither class."
                if collections else ""
            )
            note = (
                f"{_HANDLER_SPLIT_NOTE} {identity} "
                f"`{backend}/base_handler.py` defines `class {base_class}` holding the module's custom action "
                "methods, each delegating to service.py. "
                f"`{backend}/handler.py` imports it (`from .base_handler import {base_class}`) and defines "
                f"`class {handler_class}({base_class})`, the exact module.handler class, with a workspace "
                "docstring; an import or re-export alone is invalid."
                f"{canonical} "
                f"Author and emit: {', '.join(authored)}. "
                + (f"Code renders or another task owns these, so do not author them: {', '.join(not_authored)}. "
                   if not_authored else "")
                + "Where the text above differs on these files, this note governs."
            )
            task["initial_message"] = "\n\n".join(part for part in (message, note) if part)
            repairs.append(
                f"{task.get('task_id')}: restated the {handler_class}/{base_class} handler split ({source}) "
                f"and authored files {authored}"
            )
            if contract is not None and f"backend.handler:{handler_class}" not in contract_message:
                contract["initial_message"] = "\n\n".join(part for part in (
                    contract_message,
                    f"module.yaml module.handler: `backend.handler:{handler_class}`, the class the "
                    f"business_services task {task.get('task_id')!r} defines in handler.py.",
                ) if part)
                repairs.append(f"{contract.get('task_id')}: named module.handler backend.handler:{handler_class}")
    return repairs


def _approved_surface_ids(context: Any) -> set[str]:
    """Surfaces the approved design and the selected packs' registry declarations name."""
    design = detach(context.get("design_surface_map")) or {}
    approved = {
        surface["surface_id"] for surface in design.get("surfaces") or []
        if surface.get("surface_id")
    }
    # This protected projection contains selected registry declarations. Neither
    # the proposed plan nor an available-capability catalog grants approval.
    for pack in detach(context.get("capability_packs")) or []:
        pack_id = _pack_id_from_descriptor(pack)
        if pack_id:
            approved.add(pack_id)
            if pack.get("capability_source") == "managed_capability":
                approved.add(f"{pack_id}_managed")
        if pack.get("surface_id"):
            approved.add(pack["surface_id"])
        for facade in _pack_facades(pack):
            for key in ("module_id", "provider_module"):
                if facade.get(key):
                    approved.add(facade[key])
    return approved


def _pack_page_paths(context: Any) -> frozenset[str]:
    """The UI artifacts selected packs ship from their templates (for example MozaiksPay's billing pages)."""
    return frozenset(path for path in pack_owned_output_paths(context) if path.startswith("ui/"))


def _approved_page_paths(context: Any) -> set[str]:
    """Lowercased page artifacts a page_bundle task may name: approved pages plus the pages selected packs ship.

    Chat 5cd39d67 at deeef42d planned its page task with the structural
    page_bundle label and owned app.json, the three approved pages, and the
    billing, usage and pricing pages the selected MozaiksPay pack ships. Only
    the approved experience_spec pages counted, so the task was rejected as an
    unapproved surface before release_pack_owned_paths could release the pack
    pages and _repair_coverage could build the approved page task, three times
    in a row. validate_plan_coverage already accepts pack pages (#967); a pack
    page here is released later, never built by the task.
    """
    pages = _approved_page_inventory(context)
    # This optional typed support output has no ordinary ExperienceSpec route.
    # Recognizing its structural owner does not create a task or approve scope:
    # the requirement compiler still binds every task to the retained inventory.
    return {
        "admin/admin_registry.yaml",
        *(path.lower() for path in (*_required_page_paths({"pages": pages}), *_pack_page_paths(context))),
    }


def _owns_only_approved_pages(task: dict[str, Any], context: Any) -> bool:
    """Recognize approved page work or an explicit typed registry support task."""
    return bool(
        task.get("task_type") == "page_bundle"
        and task.get("capability_pack_id") is None
        and (
            _approved_page_inventory(context)
            or _normalized_owned_paths(task) == ["admin/admin_registry.yaml"]
        )
        and all(is_safe_app_path(path) for path in task.get("owned_paths") or [])
        and {path.lower() for path in _normalized_owned_paths(task)} <= _approved_page_paths(context)
    )


def _owns_only_approved_data_contract(task: dict[str, Any], context: Any) -> bool:
    """A DatabaseAgent serializer owns the approved contract, not a new module."""
    return bool(
        context.get("data_contract")
        and task.get("task_type") == "persistence_contract"
        and task.get("initial_agent") == _CANONICAL_INITIAL_AGENTS["persistence_contract"]
        and task.get("capability_pack_id") is None
        and task.get("owned_paths") == ["data/contract.json"]
    )


def _label_persistence_tasks(plan: dict[str, Any], context: Any) -> list[str]:
    approved = _approved_surface_ids(context)
    capability_ids = approved | set(_context_available_pack_map(context)) | {
        _pack_id_from_descriptor(pack) for pack in plan.get("capability_packs") or []
    }
    repairs: list[str] = []
    for task in plan.get("build_tasks") or []:
        surface_id = str(task.get("surface_id") or "")
        capability_id = task.get("capability_pack_id")
        if (
            surface_id in approved
            or capability_id in capability_ids
            or not _owns_only_approved_data_contract({**task, "capability_pack_id": None}, context)
            or (surface_id == "data_contract" and task.get("surface_kind") == "module" and capability_id is None)
        ):
            continue
        # Its exact approved artifact determines serializer ownership. An
        # unbound label cannot create a module, and a real association is never
        # removed to make a task pass the surface inventory check.
        task.update(surface_id="data_contract", surface_kind="module", capability_pack_id=None)
        repairs.append(
            f"{task.get('task_id')}: surface {surface_id!r} -> 'data_contract', "
            f"capability_pack_id {capability_id!r} -> None; "
            "the persistence task serializes only the approved data/contract.json"
        )
    return repairs


def _label_page_tasks(plan: dict[str, Any], context: Any) -> list[str]:
    """A page task is labelled by what it builds, not by the page it is named after.

    Chat 64dbe4b9 at 95ad6325 planned one page_bundle task per approved page and
    gave each the page's name as its surface_id (dashboard, pricing, billing,
    usage). Review accepts a page_bundle task owning only approved page
    artifacts under the structural ``page_bundle`` label (kind ``ui_only``), but
    it rejected the four page-name labels as unapproved surfaces, and the model
    resubmitted the same plan until its three attempts ran out. The label is
    determined by what the task owns, so code sets it: for a task under no
    approved surface, or under ``page_bundle`` with another kind. A task owning
    nothing has nothing to label it by and keeps its check.

    A task under an approved ``ui_only`` surface's ID that builds only
    approved page artifacts keeps that surface and takes its kind: the
    surface approves page work, so the kind follows from the approval.
    """
    approved = _approved_surface_ids(context)
    ui_only = _approved_ui_only_surfaces(context)
    repairs: list[str] = []
    for task in plan.get("build_tasks") or []:
        surface_id, surface_kind = str(task.get("surface_id") or ""), task.get("surface_kind")
        if (
            surface_id in ui_only
            and surface_kind != "ui_only"
            and _normalized_owned_paths(task)
            and _owns_only_approved_pages(task, context)
        ):
            task["surface_kind"] = "ui_only"
            repairs.append(
                f"{task.get('task_id')}: surface_kind {surface_kind!r} -> 'ui_only'; approved ui_only "
                f"surface {surface_id!r} owns page work only"
            )
            continue
        if (
            (surface_id == "page_bundle" and surface_kind == "ui_only")
            or surface_id in approved
            or not _normalized_owned_paths(task)
            or not _owns_only_approved_pages(task, context)
        ):
            continue
        task["surface_id"], task["surface_kind"] = "page_bundle", "ui_only"
        repairs.append(
            f"{task.get('task_id')}: surface {surface_id!r} ({surface_kind}) -> 'page_bundle' (ui_only); a "
            f"page_bundle task owning only approved page artifacts {sorted(_normalized_owned_paths(task))} "
            "is not a surface of its own"
        )
    return repairs


def _merge_split_tasks(plan: dict[str, Any], context: Any) -> list[str]:
    """One unit of work split across tasks that claim the same files is merged back into one task.

    Chat 0d442d1f at c8b9ea2e planned the tasks module's business_services as
    four tasks, one per action (create_task, update_task, delete_task,
    list_tasks), each owning modules/tasks/backend/service.py. A file has one
    owner, so review rejected the plan as overlapping ownership and the model
    resubmitted the split until its attempts ran out. Tasks of the same type for
    the same capability and surface that share an owned file are one task by
    construction: the first in plan order keeps its id and absorbs the others'
    owned paths, criteria and instructions, and the plan's task references
    (depends_on, generation_order, carry_forward_decisions, integration_needs)
    that named an absorbed id name it.

    Ownership another step already settles is not a reason to merge: shared
    app.json, config/subscriptions.yaml, a selected pack's outputs and facade
    module (released later), and page_bundle work (coverage assigns pages
    across page tasks). Tasks of different types sharing a file are a real
    conflict, and a group is left to the later checks when it repeats a task_id
    or uses one found elsewhere in the plan, has a blank id, or would close a
    dependency cycle.
    """
    pack_paths = pack_owned_output_paths(context)
    facades = pack_facade_directories(context)
    tasks = [task for task in plan.get("build_tasks") or [] if isinstance(task, dict)]
    parent = list(range(len(tasks)))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    first_owner: dict[tuple[Any, ...], int] = {}
    for index, task in enumerate(tasks):
        if task.get("task_type") == "page_bundle":
            continue
        unit = (task.get("task_type"), task.get("capability_pack_id"), task.get("surface_id"), task.get("surface_kind"))
        for path in _normalized_owned_paths(task):
            if path in _SHARED_OWNED_PATHS or path == SUBSCRIPTIONS_CONFIG_PATH or _pack_owns(path, pack_paths, facades):
                continue
            owner = first_owner.setdefault((*unit, path), index)
            if owner != index:
                left, right = root(owner), root(index)
                parent[max(left, right)] = min(left, right)

    groups: dict[int, list[int]] = {}
    for index in range(len(tasks)):
        groups.setdefault(root(index), []).append(index)
    all_ids = [str(task.get("task_id") or "").strip() for task in tasks]
    absorbed: set[int] = set()
    renamed: dict[str, str] = {}
    repairs: list[str] = []
    for members in groups.values():
        if len(members) < 2:
            continue
        ids = [all_ids[index] for index in members]
        # A blank or repeated id is an identity question for identity repair and its rejection.
        if not all(ids) or len(set(ids)) < len(ids) or any(all_ids.count(task_id) > 1 for task_id in ids):
            continue
        keeper_id, absorbed_ids = ids[0], set(ids[1:])
        if _merge_closes_cycle(tasks, keeper_id, absorbed_ids, renamed):
            continue
        keeper = tasks[members[0]]
        for other in (tasks[index] for index in members[1:]):
            _absorb_task(keeper, other)
        renamed.update(dict.fromkeys(absorbed_ids, keeper_id))
        absorbed.update(members[1:])
        repairs.append(
            f"merged {ids} into {keeper_id!r}: one {keeper.get('task_type')} task for "
            f"{keeper.get('capability_pack_id')!r} split across tasks that claim the same files"
        )
    if not renamed:
        return []

    def rename(refs: Any) -> list[str]:
        return _dedupe_preserving_order(renamed.get(str(ref).strip(), str(ref)) for ref in refs or [])

    kept = [task for index, task in enumerate(tasks) if index not in absorbed]
    for task in kept:
        if "depends_on" in task:
            task["depends_on"] = [ref for ref in rename(task.get("depends_on")) if ref != task.get("task_id")]
        for need in task.get("integration_needs") or []:
            required_by = need.get("required_by") if isinstance(need, dict) else None
            if isinstance(required_by, dict) and required_by.get("kind") == "task" and str(required_by.get("id") or "").strip() in renamed:
                required_by["id"] = renamed[str(required_by["id"]).strip()]
    if plan.get("generation_order"):
        plan["generation_order"] = rename(plan["generation_order"])
    for decision in plan.get("carry_forward_decisions") or []:
        if isinstance(decision, dict) and decision.get("affected_build_tasks"):
            decision["affected_build_tasks"] = rename(decision["affected_build_tasks"])
    plan["build_tasks"] = kept
    for _requirement_id, part in _requirement_realizations(plan):
        _rename_requirement_tasks(part, renamed)
    return repairs


def _absorb_task(keeper: dict[str, Any], other: dict[str, Any]) -> None:
    """Fold one task of a split unit into the task that keeps its id; the keeper wins every conflict."""
    for key, value in other.items():
        if key == "task_id":
            continue
        current = keeper.get(key)
        if key == "initial_message":
            parts = [str(part).strip() for part in (current, value) if str(part or "").strip()]
            keeper[key] = "\n\n".join(dict.fromkeys(parts))
        elif key == "context_variables" and isinstance(value, list):
            present = {str(item.get("key")) for item in current or [] if isinstance(item, dict)}
            keeper[key] = [*(current or []), *(
                item for item in value if isinstance(item, dict) and str(item.get("key")) not in present
            )]
        elif isinstance(value, list):
            merged = list(current or [])
            seen = {json.dumps(item, sort_keys=True, default=str) for item in merged}
            for item in value:
                marker = json.dumps(item, sort_keys=True, default=str)
                if marker not in seen:
                    seen.add(marker)
                    merged.append(item)
            keeper[key] = merged
        elif isinstance(value, dict):
            keeper[key] = {**value, **(current or {})}
        elif current is None:
            keeper[key] = value


def _merge_closes_cycle(
    tasks: list[dict[str, Any]], keeper_id: str, absorbed_ids: set[str], renamed: dict[str, str],
) -> bool:
    """Whether folding `absorbed_ids` into `keeper_id` would make the merged task depend on itself."""
    mapping = {**renamed, **dict.fromkeys(absorbed_ids, keeper_id)}
    graph: dict[str, set[str]] = {}
    for task in tasks:
        task_id = mapping.get(str(task.get("task_id") or ""), str(task.get("task_id") or ""))
        edges = {mapping.get(str(ref), str(ref)) for ref in task.get("depends_on") or []}
        edges.discard(task_id)
        graph.setdefault(task_id, set()).update(edges)
    visiting: set[str] = set()
    done: set[str] = set()

    def cyclic(node: str) -> bool:
        if node in done:
            return False
        if node in visiting:
            return True
        visiting.add(node)
        found = any(cyclic(edge) for edge in graph.get(node, ()) if edge in graph)
        visiting.discard(node)
        done.add(node)
        return found

    return cyclic(keeper_id)


_UI_ONLY_HINT_GUIDANCE = (
    "source_capability_packs are descriptive hints, not selected provider registrations. "
    "Use capability_packs=[] when no backend/provider capability is approved, "
    "and preserve the approved pages and their behavior in page_bundle tasks."
)


def _approved_ui_only_surfaces(context: Any) -> dict[str, dict[str, Any]]:
    design = detach(context.get("design_surface_map")) or {}
    return {
        surface["surface_id"]: surface for surface in design.get("surfaces") or []
        if surface.get("surface_id") and surface.get("surface_kind") == "ui_only"
    }


def _selected_ui_provider_ids(context: Any) -> set[str]:
    """Selected build-context packs that may bind an approved UI-only surface.

    A selected pack descriptor (``normalize_pack_descriptor``) carries its
    identity and registered capability_source, never a surface binding:
    selection is the registration. The registered source decides, not the
    plan's label, which ``_repair_selected_pack_sources`` normalizes later.
    Generated module code and DesignDocs category hints are not providers.
    """
    return {
        pack_id
        for pack in detach(context.get("capability_packs")) or []
        if isinstance(pack, dict)
        and pack.get("capability_source") != "generated_module"
        and (pack_id := _pack_id_from_descriptor(pack))
    }


def _validate_ui_only_surface_claims(plan: dict[str, Any], context: Any) -> None:
    """Check raw UI-only claims before a repair can remove or relabel them."""
    ui_surfaces = _approved_ui_only_surfaces(context)
    if not ui_surfaces:
        return
    selected = _selected_ui_provider_ids(context)
    approved_pages = _approved_page_inventory(context)
    page_paths = {
        path.lower() for path in _required_page_paths({"pages": approved_pages})
    } | {
        "brand/theme_config.json", "config/shell.json", "config/asset_manifest.json",
        "admin/admin_registry.yaml",
    }
    errors: list[str] = []
    for pack in plan.get("capability_packs") or []:
        surface_id = str(pack.get("surface_id") or "")
        pack_id = _pack_id_from_descriptor(pack)
        if surface_id not in ui_surfaces or pack_id in selected:
            continue
        source = pack.get("capability_source") or "unspecified"
        errors.append(
            f"{pack_id}: surface {surface_id!r} is approved ui_only and {pack_id!r} is not a "
            f"selected provider; its {source} capability grants no ownership of that surface "
            "or of backend modules. " + _UI_ONLY_HINT_GUIDANCE
        )
    for task in plan.get("build_tasks") or []:
        surface_id = str(task.get("surface_id") or "")
        if surface_id not in ui_surfaces:
            continue
        task_id = task.get("task_id")
        # A page task that builds only approved pages under the UI-only
        # surface's ID with another kind is a label slip _label_page_tasks
        # repairs; it claims nothing beyond the approved pages.
        label_slip = bool(_normalized_owned_paths(task)) and _owns_only_approved_pages(task, context)
        if task.get("task_type") != "page_bundle" or (
            task.get("surface_kind") != "ui_only" and not label_slip
        ):
            errors.append(
                f"{task_id}: surface {surface_id!r} is approved ui_only; preserve its kind "
                "and page_bundle behavior. It grants no module ownership (including modules/ paths). "
                + _UI_ONLY_HINT_GUIDANCE
            )
        claimed_pack = task.get("capability_pack_id")
        if claimed_pack is not None and str(claimed_pack) not in selected:
            errors.append(
                f"{task_id}: approved ui_only surface {surface_id!r} does not select "
                f"task capability {claimed_pack!r}. " + _UI_ONLY_HINT_GUIDANCE
            )
        invalid_paths = [
            path for path in task.get("owned_paths") or []
            if not isinstance(path, str) or path.lower() not in page_paths
        ]
        registry_only = _normalized_owned_paths(task) == ["admin/admin_registry.yaml"]
        if (not approved_pages and not registry_only) or invalid_paths:
            errors.append(
                f"{task_id}: approved ui_only surface {surface_id!r} owns only approved "
                f"page_bundle artifacts {sorted(page_paths)}; remove backend or unapproved paths "
                f"{invalid_paths!r} (including modules/ and services/). " + _UI_ONLY_HINT_GUIDANCE
            )
    if errors:
        raise ValueError("Plan surface inventory errors:\n- " + "\n- ".join(errors))


def _page_bundle_label_message(
    capabilities: list[str], tasks: list[dict[str, Any]], context: Any,
) -> str:
    """Say which page_bundle entries left the structural page scope, and how to return to it.

    page_bundle is the label review itself gives aggregate page work
    (_label_page_tasks, _repair_coverage), so "remove its capability and tasks"
    is a dead end for it: in chat 5cd39d67 the planner obeyed and deleted the
    valid approved-page task, and in chat 601d2f56 it deleted every page task.
    What is wrong is one task's fields or files, so the message names them.
    """
    approved_inventory = _approved_page_inventory(context)
    approved_pages = _required_page_paths({"pages": approved_inventory})
    allowed = _approved_page_paths(context)
    pack_pages = sorted(_pack_page_paths(context))
    pack_note = (
        f" Pages a selected pack ships ({pack_pages}) need no task; the pack's templates provide them."
        if pack_pages else ""
    )
    details: list[str] = [
        f"capability_packs entry {pack_id!r} uses surface_id='page_bundle', a task label rather than "
        "a capability surface; remove that entry"
        for pack_id in capabilities
    ]
    if not approved_inventory:
        # _owns_only_approved_pages approves page_bundle work only within an
        # approved page inventory, so with none every page_bundle task fails;
        # advising one would send the planner straight back here.
        ids = [str(task.get("task_id")) for task in tasks]
        if ids:
            details.append(f"build_tasks {ids} use it")
        return (
            f"unapproved surface 'page_bundle': {'; '.join(details)}. The approved experience_spec "
            "declares no pages, so page_bundle approves no task here: remove those page_bundle tasks."
            f"{pack_note} A page the app needs must first be approved in ExperienceSpec."
        )
    for task in tasks:
        faults = [
            f"{field}={task.get(field)!r} (page work needs {expected!r})"
            for field, expected in (("task_type", "page_bundle"), ("surface_kind", "ui_only"), ("capability_pack_id", None))
            if task.get(field) != expected
        ]
        outside = [
            str(path) for path in task.get("owned_paths") or []
            if not is_safe_app_path(path) or normalize_app_path(path).lower() not in allowed
        ]
        # The same page shape _repair_coverage drops when no approved page claims it.
        invented = [path for path in outside if path.startswith("ui/pages/") and path.endswith((".yaml", ".yml", ".jsx"))]
        misplaced = [path for path in outside if path not in invented]
        if invented:
            faults.append(f"drop {invented}: no approved page or selected pack declares those pages")
        if misplaced:
            faults.append(f"move {misplaced} to the task of the approved surface that owns them")
        details.append(f"task {task.get('task_id')!r}: {'; '.join(faults) or 'owns no approved page artifact'}")
    return (
        f"unapproved surface 'page_bundle': {'. '.join(details)}. Keep the page_bundle label for page "
        "work: task_type=page_bundle, surface_kind=ui_only, capability_pack_id=null, owning only "
        f"the approved experience_spec page artifacts {approved_pages}.{pack_note} Do not delete "
        "the approved page work."
    )


def _validate_plan_surface_inventory(plan: dict[str, Any], context: Any) -> None:
    """Reject invented scope before repairs or identity advice can obscure it."""
    _validate_ui_only_surface_claims(plan, context)
    _validate_page_realizations(plan, context)
    validate_surface_ownership(
        detach(context.get("design_surface_map")) or {},
        context_variables=context, data_contract=detach(context.get("data_contract")),
    )
    approved = _approved_surface_ids(context)
    ui_hints = {
        hint for surface in _approved_ui_only_surfaces(context).values()
        for hint in surface.get("source_capability_packs") or []
    }
    errors: list[str] = []
    unapproved: dict[str, tuple[list[str], list[dict[str, Any]]]] = {}
    for entries, is_task in (
        (plan.get("capability_packs") or [], False),
        (plan.get("build_tasks") or [], True),
    ):
        for entry in entries:
            surface_id = str(entry.get("surface_id") or "")
            if surface_id in approved:
                continue
            if (
                is_task and surface_id == "page_bundle"
                and entry.get("surface_kind") == "ui_only"
                and _owns_only_approved_pages(entry, context)
            ):
                continue
            if (
                is_task and surface_id == "data_contract"
                and entry.get("surface_kind") == "module"
                and _owns_only_approved_data_contract(entry, context)
            ):
                continue
            capabilities, tasks = unapproved.setdefault(surface_id, ([], []))
            if is_task:
                tasks.append(entry)
            else:
                capabilities.append(str(_pack_id_from_descriptor(entry)))
    if unapproved:
        for surface_id, (capabilities, tasks) in sorted(unapproved.items()):
            linked = _linked_requirements(plan, capabilities, tasks, surface_id)
            if linked:
                errors.append(_missing_requirement_design(surface_id, linked))
                continue
            if surface_id == "page_bundle":
                errors.append(_page_bundle_label_message(capabilities, tasks, context))
                continue
            offenders = [
                *(f"capability {pack_id!r}" for pack_id in capabilities),
                *(f"task {task.get('task_id')!r} owning {list(task.get('owned_paths') or [])}" for task in tasks),
            ]
            message = (
                f"unapproved surface {surface_id!r} (declared by {'; '.join(offenders)}): "
                "remove its capability and tasks rather than relabel them. Use only surfaces "
                "from design_surface_map or selected pack provider/facade contracts. "
                f"Valid approved surface_ids: {sorted(approved)}."
            )
            if re.search(r"(?:^|[_-])(?:auth|authentication|login|signin)(?:$|[_-])", surface_id.lower()):
                message += " Authentication is platform-provided and needs no generated module."
            if surface_id in ui_hints:
                message += " " + _UI_ONLY_HINT_GUIDANCE
            errors.append(message)
    if errors:
        raise ValueError("Plan surface inventory errors:\n- " + "\n- ".join(errors))


def validate_plan_origins(plan: dict[str, Any], context: Any) -> None:
    _validate_plan_surface_inventory(plan, context)
    available = _context_available_pack_map(context)
    packs = plan.get("capability_packs") or []
    errors: list[str] = []
    for pack in packs:
        pack_id = _pack_id_from_descriptor(pack)
        source = pack.get("capability_source")
        registered = available.get(pack_id)
        if source == "managed_capability" and not registered:
            errors.append(f"{pack_id}: managed_capability requires a registered provider pack; a product category is not a managed service")
        if source in {"framework_pack", "operator_pack"} and not registered:
            errors.append(f"{pack_id}: {source} requires an installed pack in capability_packs context. For app-owned code use generated_module with capability_pack_id=surface_id={pack.get('surface_id')!r}; product categories belong only in pack_type")
        if registered and source != registered.get("capability_source"):
            errors.append(f"{pack_id}: capability_source must match the registered pack ({registered.get('capability_source')})")

    design = detach(context.get("design_surface_map")) or {}
    for surface in design.get("surfaces") or []:
        if surface.get("owner") != "app" or surface.get("surface_kind") != "module":
            continue
        surface_id = surface["surface_id"]
        matching = [pack for pack in packs if pack.get("surface_id") == surface_id]
        if len(matching) != 1 or matching[0].get("surface_kind") != "module" or matching[0].get("capability_source") not in {"generated_module", "framework_pack", "operator_pack"}:
            # "found 0" alone does not say what to emit. The usual cause is a
            # product category used as an identity: upstream hints and
            # source_capability_packs are full of names like crud_pack, so a plan
            # declares those as capabilities and no pack carries the surface_id.
            detail = (
                f"{surface_id}: the approved app-owned module requires exactly one module "
                f"capability, normally generated_module; preserve its surface_id "
                f"(found {len(matching)})"
            )
            if not matching:
                declared = sorted({str(_pack_id_from_descriptor(pack)) for pack in packs})
                detail += (
                    f". Emit a generated_module capability with surface_id={surface_id!r} and "
                    f"capability_pack_id={surface_id!r}. Declared capabilities are {declared}; "
                    "a product category such as crud_pack or billing_pack belongs in pack_type, "
                    "never in capability_pack_id or surface_id"
                )
            errors.append(detail)
            continue
        pack = matching[0]
        if pack.get("capability_source") == "generated_module":
            if _pack_id_from_descriptor(pack) != surface_id:
                errors.append(
                    f"{surface_id}: generated module capability_pack_id must match its approved "
                    f"surface_id, not the source product category. Set it to {surface_id!r} "
                    f"(currently {_pack_id_from_descriptor(pack)!r}); the category belongs in pack_type"
                )
            if set(pack.get("primary_entities") or []) != set(surface.get("primary_entities") or []):
                errors.append(f"{surface_id}: preserve the approved primary_entities: {surface.get('primary_entities') or []}")

    for task in plan.get("build_tasks") or []:
        module_ids = {path.split("/")[1] for path in _normalized_owned_paths(task) if path.startswith("modules/")}
        if not module_ids:
            continue
        pack_id = task.get("capability_pack_id")
        matching = [pack for pack in packs if _pack_id_from_descriptor(pack) == pack_id]
        task_id = task.get("task_id")
        # One message for three different faults told the agent a disagreement
        # existed but not which signal was wrong or what to set it to. A live
        # build spent all three revision attempts re-emitting the same mismatch.
        if len(matching) != 1:
            declared = sorted({str(_pack_id_from_descriptor(pack)) for pack in packs})
            errors.append(
                f"{task_id}: capability_pack_id={pack_id!r} matches "
                f"{len(matching)} declared capabilities; it must name exactly one of {declared}"
            )
        elif len(module_ids) > 1:
            # Two faults shared one message. With several module directories,
            # "set it to sorted(module_ids)[0]" names whichever sorts first --
            # frequently the value already declared, so the instruction is a
            # no-op and the revision attempts re-emit the same plan. A live
            # build spent all three that way on
            # owned_paths spanning modules/crud_pack/ and modules/tasks/.
            errors.append(
                f"{task_id}: this task owns paths in {len(module_ids)} module directories "
                f"{sorted(module_ids)} under modules/. A module task writes exactly one module. "
                f"Split it into one task per module, each with capability_pack_id equal to the "
                f"module directory it writes. If {sorted(module_ids)} are meant to be the same "
                "module, a product category is being used as a directory name: the module "
                "directory is the surface_id, and the category belongs in pack_type."
            )
        elif module_ids != {pack_id}:
            owned = sorted(module_ids)[0]
            errors.append(
                f"{task_id}: this task owns modules/{owned}/ and declares "
                f"surface_id={task.get('surface_id')!r}, but claims capability_pack_id={pack_id!r}. "
                "A module task's capability_pack_id is the module directory it writes. Set it to "
                f"{owned!r}, or move the files to the module that capability owns."
            )
        elif task.get("surface_id") != matching[0].get("surface_id"):
            errors.append(
                f"{task_id}: surface_id={task.get('surface_id')!r} disagrees with capability "
                f"{pack_id!r}, which declares surface_id={matching[0].get('surface_id')!r}. "
                "Use the capability's surface_id."
            )

    if errors:
        raise ValueError("Plan ownership errors:\n- " + "\n- ".join(errors))


def validate_plan_coverage(plan: dict[str, Any], context: Any) -> None:
    _validate_page_realizations(plan, context)
    tasks = plan.get("build_tasks") or []
    if not tasks:
        raise ValueError("A build plan must declare materializing build_tasks, not just a page or capability inventory")
    pack_paths = pack_owned_output_paths(context)
    facades = pack_facade_directories(context)
    pack_owned = {
        str(task.get("task_id")): claimed
        for task in tasks
        if (claimed := sorted(path for path in _normalized_owned_paths(task) if _pack_owns(path, pack_paths, facades)))
    }
    if pack_owned:
        raise ValueError(
            "Selected packs own these paths (template outputs and facade modules), so no task may own them: "
            + "; ".join(f"{task_id} owns {paths}" for task_id, paths in sorted(pack_owned.items()))
        )
    if context.get("build_mode") == "revision" or context.get("brownfield_build_path"):
        return

    errors: list[str] = []
    pages = plan.get("pages") or []
    planned_routes = [page.get("route") for page in pages]
    if len(set(planned_routes)) != len(planned_routes):
        errors.append("page routes must be unique")
    expected_pages = {(page["name"], page["route"]) for page in _approved_page_inventory(context)}
    # A selected pack ships its declared pages from its own templates, so the
    # cached plan carries them even when the approved design left them out.
    # Only a page nobody approved and no selected pack ships is invented scope.
    pack_pages = {(page["name"], page["route"]) for page in pages if planned_page_path(page) in pack_paths}
    planned_pages = {(page["name"], page["route"]) for page in pages}
    if expected_pages and (expected_pages - planned_pages or planned_pages - expected_pages - pack_pages):
        errors.append(f"pages must preserve the approved name/route inventory: {sorted(expected_pages)}")
    all_page_paths = _required_page_paths(plan)[1:]
    if len(set(all_page_paths)) != len(all_page_paths):
        errors.append("page routes resolve to colliding materialized filenames")
    required_page_paths = _authored_page_paths(plan, pack_paths)
    page_paths = [path for path in required_page_paths if path != "app.json"]
    page_owned = {
        path for task in tasks if task.get("task_type") == "page_bundle"
        for path in _normalized_owned_paths(task)
    }
    missing = set(required_page_paths) - page_owned
    if missing:
        errors.append(f"page_bundle/AppSchemaAgent must own all page files and app.json; missing {sorted(missing)}")
        errors.append(
            "Page paths are case-sensitive and use the materializer's lowercase route-derived stem, "
            f"not the display name. Required page paths: {page_paths}; received page_bundle paths: {sorted(page_owned)}. "
            "Replace differently cased filenames; do not add both spellings."
        )
    custom_paths = {path for path in required_page_paths if path.startswith("ui/pages/custom/")}
    if custom_paths:
        custom_bundle_paths = custom_paths | {"ui/route_manifest.json", "ui/index.js"}
        if not any(custom_bundle_paths <= set(_normalized_owned_paths(task)) for task in tasks
                   if task.get("task_type") == "page_bundle"):
            errors.append("One page_bundle task must own the complete custom route manifest, registry, and page files")

    for pack in plan.get("capability_packs") or []:
        if pack.get("surface_kind") != "module" or pack.get("capability_source") != "generated_module":
            continue
        module_id = _pack_id_from_descriptor(pack)
        module_tasks = [task for task in tasks if task.get("capability_pack_id") == module_id]
        required = _authored_module_paths(pack, context, pack_paths, facades)
        for kind, paths in required.items():
            owned = {path for task in module_tasks if task.get("task_type") == kind for path in _normalized_owned_paths(task)}
            if paths - owned:
                errors.append(f"{module_id}/{kind} is incomplete; missing {sorted(paths - owned)}")
    if errors:
        raise ValueError("Incomplete build plan:\n- " + "\n- ".join(errors))


def validate_plan_dispatch(context: Any) -> None:
    """Run task dispatch's owned-path preflight on the items review hands to it.

    Dispatch reads the batch items app_build_plan cached and refuses the whole
    batch on one unusable owned path or collision. It raises inside
    AppPlanAgent's turn, where no revision path exists, so the run dies. The
    same refusal here is a review rejection the planner can correct. The check
    is dispatch's own (_validate_batch_owned_paths over _normalize_task_items)
    for every batch AppPlanAgent triggers, so review and dispatch cannot
    disagree. Each task is checked alone and then together for collisions, so
    one message names every refusal.
    """
    config = load_task_batches_config("AppGenerator", _WORKFLOWS_ROOT)
    if config is None:
        raise RuntimeError("AppGenerator task batch contract not found; plan dispatch cannot be preflighted")
    errors: list[str] = []
    for batch in config.batches:
        if batch.trigger_agent != "AppPlanAgent" or batch.source.kind != "context_variable":
            continue
        dispatchable: list[dict[str, Any]] = []
        for item in _normalize_task_items(detach(context.get(batch.source.path))):
            try:
                _validate_batch_owned_paths(batch, [item])
            except ValueError as error:
                errors.append(f"{item['task_id']}: {error}")
            else:
                dispatchable.append(item)
        try:
            _validate_batch_owned_paths(batch, dispatchable)
        except ValueError as error:
            errors.append(str(error))
    if errors:
        raise ValueError("Task dispatch would refuse this plan:\n- " + "\n- ".join(errors))


def _plan_validation_feedback(error: ValueError, payload: dict[str, Any] | None) -> str:
    locations: list[str] = []
    if isinstance(error, ValidationError) and isinstance(payload, dict):
        pages = payload.get("pages")
        for detail in error.errors():
            path = detail["loc"]
            if ("data_source" not in path or len(path) < 2 or path[0] != "pages"
                    or not isinstance(pages, list) or not isinstance(path[1], int)
                    or path[1] >= len(pages) or not isinstance(pages[path[1]], dict)):
                continue
            page = pages[path[1]]
            page_name = page.get("name") or page.get("page_id") or f"pages[{path[1]}]"
            section_name = "<page>"
            sections = page.get("sections_hint")
            if (len(path) >= 4 and path[2] == "sections_hint" and isinstance(path[3], int)
                    and isinstance(sections, list) and path[3] < len(sections)):
                section = sections[path[3]]
                section_name = (
                    section.get("section_id_hint") if isinstance(section, dict) else None
                ) or f"sections_hint[{path[3]}]"
            location = f"Page '{page_name}', section '{section_name}': invalid data_source"
            if location not in locations:
                locations.append(location)
    return "\n".join([*locations, str(error)])[:6000]


def review_app_build_plan(
    *,
    AppBuildPlan: Annotated[dict[str, Any] | None, "Complete AppBuildPlan output"] = None,
    context_variables: Annotated[Any | None, "Runtime-owned workflow context"] = None,
) -> dict[str, Any]:
    if context_variables is None:
        raise ValueError("Plan review requires runtime context")
    _clear_plan(context_variables)
    context_variables.set("app_plan_outcome", "blocked")
    context_variables.set("app_build_failure_message", None)
    attempts = context_variables.get("app_plan_attempts") or 0
    if type(attempts) is not int or attempts < 0:
        raise ValueError("Invalid runtime plan attempt counter")
    if attempts >= 3:
        feedback = context_variables.get("app_plan_feedback") or "Plan review attempt budget exhausted"
        context_variables.set(
            "app_build_failure_message",
            "The app build cannot continue: the implementation plan has unresolved contract errors.\n" + feedback,
        )
        return {"outcome": "blocked", "error": "Plan review attempt budget exhausted"}
    attempts += 1
    context_variables.set("app_plan_attempts", attempts)
    try:
        from mozaiksai.builder.messaging import reconcile_messaging_configurations
        from mozaiksai.builder.storefront import normalize_storefront_recipe

        candidate = detach(AppBuildPlan)
        if isinstance(candidate, dict):
            for pack in candidate.get("capability_packs") or []:
                if isinstance(pack, dict) and pack.get("storefront_recipe") is not None:
                    pack["storefront_recipe"] = normalize_storefront_recipe(
                        pack["storefront_recipe"], pack_id=_pack_id_from_descriptor(pack),
                    )
                if isinstance(pack, dict) and pack.get("messaging_configuration") is not None:
                    pack["messaging_configuration"] = reconcile_messaging_configurations(
                        _pack_id_from_descriptor(pack), pack["messaging_configuration"],
                    )
            validate_requirement_deliveries(
                candidate.get("requirement_deliveries"), approved_inventory_from_context(context_variables),
            )
        models, _ = load_workflow_structured_outputs("AppGenerator")
        plan = models["AppBuildPlan"].model_validate(candidate).model_dump(mode="json")
        for repair in _strip_workspace_app_root(plan):
            logger.info("[AppGenerator] plan repaired: %s", repair)
        _validate_ui_only_surface_claims(plan, context_variables)
        for repair in (
            *_apply_dispatch_path_rules(plan),
            *_label_persistence_tasks(plan, context_variables),
            *_label_page_tasks(plan, context_variables),
            *_merge_split_tasks(plan, context_variables),
        ):
            logger.info("[AppGenerator] plan repaired: %s", repair)
        _validate_plan_surface_inventory(plan, context_variables)
        plan["capability_packs"] = _ensure_context_selected_capability_packs(
            plan.get("capability_packs") or [], context_variables=context_variables,
        )
        for repair in (
            *_repair_task_identities(plan, context_variables),
            *_repair_module_task_capabilities(plan, context_variables),
            *_repair_selected_pack_sources(plan, context_variables),
            *_repair_managed_facade_capabilities(plan, context_variables),
            *_repair_plan(plan, context_variables),
            *_repair_selected_pack_inventory(plan, context_variables),
            *release_pack_owned_paths(plan, context_variables),
            *release_pack_facade_paths(plan, context_variables),
            *release_subscriptions_config(plan),
            *_repair_user_data_scope(plan, context_variables),
            *_repair_coverage(plan, context_variables),
            *_construct_task_requirements(plan, context_variables),
            *_repair_contract_task_operations(plan, context_variables),
            *_restate_handler_split(plan, context_variables),
            *_repair_page_contract_dependencies(plan, context_variables),
            *_note_pack_pages(plan, context_variables),
            *drop_unapproved_page_data_sources(plan, context_variables),
        ):
            logger.info("[AppGenerator] plan repaired: %s", repair)
        validate_plan_dependencies(plan, context_variables)
        validate_plan_origins(plan, context_variables)
        validate_plan_coverage(plan, context_variables)
        app_build_plan(AppBuildPlan=plan, context_variables=context_variables)
        cached = detach(context_variables.get("app_build_plan"))
        if not context_variables.get("app_plan_ready") or not isinstance(cached, dict):
            raise RuntimeError("Validated plan was not cached")
        _validate_plan_surface_inventory(cached, context_variables)
        validate_plan_origins(cached, context_variables)
        validate_plan_dependencies(cached, context_variables)
        validate_plan_coverage(cached, context_variables)
        validate_plan_dispatch(context_variables)
    except ValueError as error:
        _clear_plan(context_variables)
        feedback = _plan_validation_feedback(error, AppBuildPlan)
        context_variables.set("app_plan_feedback", feedback)
        outcome = "needs_revision" if attempts < 3 else "blocked"
        context_variables.set("app_plan_outcome", outcome)
        if outcome == "blocked":
            context_variables.set(
                "app_build_failure_message",
                "The app build cannot continue: the implementation plan has unresolved contract errors.\n" + feedback,
            )
        # Without ok=False the runtime's failure detector reads a rejection as
        # success, so three rejected plans logged as three clean completions and
        # the real validator errors never reached the log at all.
        return {"ok": False, "outcome": outcome, "error": feedback}
    except BaseException:
        _clear_plan(context_variables)
        raise
    context_variables.set("app_plan_feedback", "")
    context_variables.set("app_plan_outcome", "ready")
    return {"outcome": "ready", "task_count": len(cached["build_tasks"])}
