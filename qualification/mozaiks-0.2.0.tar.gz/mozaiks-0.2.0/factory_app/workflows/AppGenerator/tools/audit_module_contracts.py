"""Deterministic module contract auditor.

Validates generated module declarations with the runtime's canonical models,
then checks Factory layout and cross-file event references.

Used by the module contract quality gate tool. Pure function — no side effects.
"""

from __future__ import annotations

from pathlib import PurePosixPath
from typing import Any

import yaml
from pydantic import BaseModel, ValidationError

from mozaiksai.core.runtime.app.module_loader import (
    ModuleAdminPanel,
    ModuleDefinition,
    ModuleEventsManifest,
    ModuleLoader,
)
from mozaiksai.core.workflow.generator_support.code_files import validate_generated_admin_registry

# This auditor intentionally covers its existing manifest families only. The
# runtime owns their models and taxonomies; no loader instance or app imports
# are needed to validate declarations.
_MANIFEST_MODELS: dict[str, type[BaseModel]] = {
    "module.yaml": ModuleDefinition,
    **{
        filename: model
        for key, (filename, model) in ModuleLoader.OPTIONAL_MANIFESTS.items()
        if key in {"events", "reactions", "notifications", "settings", "admin"}
    },
}


def _parse_yaml_content(content: str) -> dict[str, Any] | None:
    try:
        parsed = yaml.safe_load(content)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        return None


def _manifest_model_for_path(filename: str) -> tuple[type[BaseModel] | None, str | None]:
    path = PurePosixPath(filename)
    model = _MANIFEST_MODELS.get(path.name)
    if model is None or not path.parts or path.parts[0] != "modules":
        return None, None
    module_id = path.parts[1] if len(path.parts) > 2 else "<module_id>"
    expected = (
        f"modules/{module_id}/module.yaml" if path.name == "module.yaml"
        else f"modules/{module_id}/contracts/{path.name}"
    )
    if module_id in {".", ".."} or filename != expected:
        return model, f"{filename}: noncanonical module contract path; expected {expected!r}"
    return model, None


def _validate_contract_yaml(
    filename: str, data: dict[str, Any],
) -> tuple[BaseModel | None, list[str]]:
    model, layout_error = _manifest_model_for_path(filename)
    if model is None:
        return None, []
    if layout_error:
        return None, [layout_error]
    warnings: list[str] = []
    # Runtime companion defaults are convenient for authored apps. Generated
    # artifacts retain the existing explicit-version requirement.
    if "schema_version" not in data:
        warnings.append(f"{filename}: missing required 'schema_version' marker")
    try:
        parsed = model.model_validate(data)
    except ValidationError as exc:
        warnings.append(f"{filename}: invalid canonical {model.__name__} contract: {exc}")
        return None, warnings
    if isinstance(parsed, ModuleDefinition):
        # The runtime accepts safe module-local entrypoints more generally; the
        # generated Factory layout specifically owns backend/handler.py.
        if not parsed.module.handler.startswith("backend.handler:"):
            warnings.append(
                f"{filename}: handler {parsed.module.handler!r} must start with "
                "'backend.handler:' for generated modules"
            )
        if "modules" in PurePosixPath(filename).parts:
            folder_name = PurePosixPath(_module_dir_of(filename)).name
            if parsed.name != folder_name:
                warnings.append(
                    f"{filename}: module.id {parsed.name!r} must match folder name {folder_name!r}"
                )
    return parsed, warnings


def _audit_module_yaml(filename: str, data: dict[str, Any]) -> list[str]:
    return _validate_contract_yaml(filename, data)[1]


def _audit_contract_yaml(filename: str, data: dict[str, Any]) -> list[str]:
    """Validate an existing audited companion family with its runtime model."""
    return _validate_contract_yaml(filename, data)[1]


def _module_dir_of(filename: str) -> str:
    """Return the modules/{module_id} prefix for a given contract file path."""
    parts = PurePosixPath(filename).parts
    # Expected shapes:
    #   modules/{id}/module.yaml  → modules/{id}
    #   modules/{id}/contracts/events.yaml  → modules/{id}
    for i, part in enumerate(parts):
        if part == "modules" and i + 1 < len(parts):
            return "/".join(parts[: i + 2])
    return str(PurePosixPath(filename).parent)


def audit_admin_panel_page_refs(
    code_files: list[dict[str, Any]],
    valid_page_ids: set,
) -> list[str]:
    """Check that every admin.yaml panel ``page`` field references a declared registry id.

    Args:
        code_files: List of {filename, content} dicts.
        valid_page_ids: Enabled ids from the actual admin/admin_registry.yaml snapshot.

    Returns:
        List of warning strings. Empty list means no issues.
    """
    if not code_files:
        return []

    warnings: list[str] = []
    for file_entry in code_files:
        if not isinstance(file_entry, dict):
            continue
        filename = str(file_entry.get("filename") or "").strip()
        if not filename.startswith("modules/") or not filename.endswith("/contracts/admin.yaml"):
            continue
        content = file_entry.get("content")
        if not isinstance(content, str) or not content.strip():
            continue
        data = _parse_yaml_content(content)
        if data is None:
            continue
        panels = data.get("panels") or []
        if not isinstance(panels, list):
            continue
        for panel in panels:
            if not isinstance(panel, dict):
                continue
            page_ref = panel.get("page")
            panel_id = str(panel.get("id") or "<unknown>")
            if not page_ref:
                warnings.append(
                    f"{filename}: panel {panel_id!r} missing required 'page' field"
                )
            elif ModuleAdminPanel._page(page_ref) not in valid_page_ids:
                warnings.append(
                    f"{filename}: panel {panel_id!r} unresolved admin page ref "
                    f"{page_ref!r} (valid ids: {sorted(valid_page_ids)})"
                )
    return warnings


def audit_admin_registry_file_map(files: dict[str, str]) -> list[str]:
    """Close module panel references against this exact artifact snapshot.

    Missing, empty and disabled registries provide no valid page ids. Intermediate
    module generation may defer this whole check until its explicit registry task
    settles; completed candidates and registry saves may not defer it.
    """
    valid_ids: set[str] = set()
    warnings: list[str] = []
    content = files.get("admin/admin_registry.yaml")
    if content is not None:
        try:
            registry = validate_generated_admin_registry(yaml.safe_load(content))
            valid_ids = registry.page_ids()
        except (ValueError, TypeError, yaml.YAMLError) as exc:
            warnings.append(f"admin/admin_registry.yaml: invalid admin registry: {exc}")
    warnings.extend(audit_admin_panel_page_refs(
        [{"filename": path, "content": content} for path, content in files.items()], valid_ids,
    ))
    return warnings


def audit_module_contracts(code_files: list[dict[str, Any]]) -> list[str]:
    """Audit module contract YAML files in code_files.

    Args:
        code_files: List of {filename, content} dicts from agent code output.

    Returns:
        List of warning strings. Empty list means no issues found.
    """
    warnings: list[str] = []

    if not code_files:
        return warnings

    module_yamls: dict[str, ModuleDefinition] = {}
    events_by_module: dict[str, tuple[str, ModuleEventsManifest]] = {}

    for file_entry in code_files:
        if not isinstance(file_entry, dict):
            continue
        filename = str(file_entry.get("filename") or "").strip()
        content = file_entry.get("content")
        if not filename:
            continue

        model, layout_error = _manifest_model_for_path(filename)
        if model is None:
            continue
        if layout_error:
            warnings.append(layout_error)
            continue

        data = _parse_yaml_content(content) if isinstance(content, str) else None
        if data is None:
            warnings.append(f"{filename}: could not parse as YAML")
            continue

        mod_dir = _module_dir_of(filename)

        parsed, diagnostics = _validate_contract_yaml(filename, data)
        warnings.extend(diagnostics)
        if isinstance(parsed, ModuleDefinition):
            module_yamls[filename] = parsed
        elif isinstance(parsed, ModuleEventsManifest):
            events_by_module[mod_dir] = (filename, parsed)

    # Match the runtime's event closure: every producer is checked even when no
    # action emits that event, and every declared action emission must resolve.
    for mod_path, definition in module_yamls.items():
        mod_dir = _module_dir_of(mod_path)
        event_contract = events_by_module.get(mod_dir)
        if event_contract is None:
            emitted = [event for action in definition.actions for event in action.emits]
            if emitted:
                warnings.append(
                    f"{mod_path}: actions declare emits {emitted} "
                    f"but no events.yaml found under {mod_dir}/"
                )
            continue

        event_path, events = event_contract
        for event in events.events:
            if event.producer != definition.name:
                warnings.append(
                    f"{event_path}: event {event.type!r} producer {event.producer!r} "
                    f"does not match module id {definition.name!r}"
                )
        for action in definition.actions:
            for event_type in action.emits:
                if event_type not in events.event_types:
                    warnings.append(
                        f"{mod_path}: action {action.id!r} emits {event_type!r} "
                        f"but that type is not declared in {event_path}"
                    )

    return warnings


__all__ = ["audit_module_contracts", "audit_admin_panel_page_refs", "audit_admin_registry_file_map"]

