"""Runtime smoke gates: boot an app bundle and use it as two people.

Production generated-app acceptance uses a contained Docker app with private
MongoDB and a separate source-free observer. The direct host child path remains
for trusted repository fixtures. Both paths load through the platform's
``AppLoader``, apply declared indexes and migrations, and exercise module
actions as synthetic signed-in principals.

Generic smoke checks are derived from the bundle's contracts: ``data/contract.json``
collections and their canonical action ids, ``module.yaml`` schemas, gates and
surfaces, ``config/subscriptions.yaml`` plans and assignment store, and the
requested token scopes in ``config/auth.yaml`` as synthetic smoke inputs, not
issuer-grant evidence. Optional reviewed reference cases are
selected independently from installed Factory code and passed to the observer
in a separate, read-only descriptor, never as candidate executable code.

The trusted-fixture child path starts this module with a restricted environment,
uses a disposable host database and enforces a hard time limit. Production
acceptance never invokes that path. Both paths dispatch in enforce mode with
in-memory audit and no usage metering. The contained reviewed reference path
installs a fixed image-owned test-host role policy; its unauthenticated and
ungranted probes remain denied. Startup services are not started because they
run outside module dispatch with their own clients. Optional contained Vite
build/preview is only a loopback availability diagnostic, not browser proof.

The direct trusted-fixture smoke records an event rejected by the runtime as
its own failed check. The contained external observer cannot see that internal
rejection. Generated-app acceptance records this limit in its versioned scope
without claiming the candidate made no invalid emission attempt.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

from anyio import CancelScope
from fastapi import FastAPI, Request
from httpx import TimeoutException

from mozaiksai.core.adapters.local_docker_cli import _docker_cli_env, _docker_prefix

logger = logging.getLogger(__name__)

SMOKE_CONTRACT_VERSION = "1.0"
GENERATED_ACCEPTANCE_SCOPE_VERSION = "2.0"
SMOKE_TIMEOUT_SECONDS = 60.0
_CHILD_MODULE = "factory_app.workflows.AppGenerator.tools.app_runtime_smoke"
_EVENT_PREFIX = "@@mozaiks-runtime-smoke@@ "
_SMOKE_DATABASE_PREFIX = "mozaiks_runtime_smoke_"
_CONTAINED_APP_ROOT = PurePosixPath("/workspace/app")
_CONTAINED_PLAN_ROOT = PurePosixPath("/workspace/plan")
_CONTAINED_WEB_SHELL_ROOT = PurePosixPath("/opt/mozaiks/web_shell")
_CONTAINED_FRONTEND_DIST = PurePosixPath("/tmp/mozaiks-frontend-dist")
_CONTAINED_IMAGE = "mozaiks-sandbox:local"
_GENERATED_IMAGE_ENV = "MOZAIKS_APP_RUNTIME_IMAGE_ID"
_GENERATED_LOAD_TIMEOUT_SECONDS = 90
_GENERATED_LOAD_RESULT_LIMIT = 128 * 1024
_MAX_IMPORTED_SOURCE_BYTES = 64_000_000
_MAX_IMPORTED_SOURCE_FILES = 4096
_CONTAINER_STARTUP_SECONDS = 20.0
# The pinned disposable issuer rebuilds its configuration and initializes a fresh
# realm/database under one CPU. Measured startup reaches 116s without app load;
# keep this prerequisite bounded separately from app/browser execution budgets.
_BROWSER_ISSUER_STARTUP_SECONDS = 180.0
_CONTAINER_STDOUT_LIMIT_BYTES = 4_000_000
# Complete paired desktop/mobile reports include inline PNG evidence: the first
# 25 images alone exceed 3.7 MB. Retain it in the existing trusted observer
# channel, with a separate finite cap; imported app output stays at 4 MB.
_BROWSER_REPORT_LIMIT_BYTES = 16_000_000
_CONTAINER_STDERR_LIMIT_BYTES = 256_000
_LOCAL_BROWSER_POLICY_SHA256 = "8f3b2fa3fdf50c6e6f8f25a51d32d3d4148fac534b35130dcb013ca2e87d57b7"
_BROWSER_MANIFEST_KEYS = ("source_sha", "spec_sha256", "helper_sha256", "config_sha256")
_PING_TIMEOUT_SECONDS = 5.0
_STEP_TIMEOUT_SECONDS = 20.0
_REQUEST_TIMEOUT_SECONDS = 10.0
_UNREACHABLE_SURFACES = frozenset({"internal", "admin_internal"})
_RUNTIME_LOGGER = "mozaiks.workflow"
# The child's environment: what a Python process needs to start on this OS. No
# other host variable (secrets, provider keys, MONGO_URI, MOZAIKS_*) is passed.
_CHILD_ENVIRONMENT = ("PATH", "PATHEXT", "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "COMSPEC", "TEMP", "TMP", "TMPDIR",
                      "APPDATA",  # Windows Python needs this to locate its installed user-site packages.
                      "LANG", "LC_ALL", "LC_CTYPE")

_FIX_SUGGESTION = (
    "Fix the named generated file so the app boots and its declared module actions behave as the "
    "data contract, module.yaml and config/subscriptions.yaml declare when two signed-in users use it."
)


# --------------------------------------------------------------------------- parent: database and child process


def resolve_smoke_mongo_uri() -> str | None:
    """The host's configured Mongo URI, or None when no database is configured."""
    from mozaiksai.core.secrets import inspect_secret_config, resolve_secret

    try:
        if not inspect_secret_config("MONGO_URI").configured:
            return None
        return str(resolve_secret("MONGO_URI") or "").strip() or None
    except Exception as exc:  # secret policy failure; never log the value
        logger.warning("APP_RUNTIME_SMOKE_DATABASE_UNAVAILABLE: %s", type(exc).__name__)
        return None


def child_environment() -> dict[str, str]:
    """The child's whole environment: OS essentials plus the import roots of this very code."""
    environment = {name: os.environ[name] for name in _CHILD_ENVIRONMENT if os.environ.get(name)}
    roots: list[str] = []
    for package_name in ("mozaiksai", "factory_app", "logs"):
        package = sys.modules.get(package_name) or __import__(package_name)
        root = str(Path(str(package.__file__)).resolve().parents[1])
        if root not in roots:
            roots.append(root)
    environment.update({
        "PYTHONPATH": os.pathsep.join(roots),
        "PYTHON_DOTENV_DISABLED": "1",
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
        "PYTHONDONTWRITEBYTECODE": "1",
    })
    return environment


@dataclass
class _ChildRun:
    stdout: str
    stderr: str
    returncode: int | None
    timed_out: bool
    cleanup_failed: bool = False
    output_truncated: bool = False
    contained: bool = False
    app_exited: bool = False


class _ChildProcess:
    """One child run; ``kill`` is safe to call from another thread."""

    def __init__(self) -> None:
        self.process: subprocess.Popen[str] | None = None
        self.cancelled = False

    def run(self, app_root: Path, request: dict[str, Any], timeout_seconds: float) -> _ChildRun:
        environment = child_environment()
        environment["USERPROFILE" if os.name == "nt" else "HOME"] = str(app_root.parent)
        self.process = subprocess.Popen(
            [sys.executable, "-m", _CHILD_MODULE],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            env=environment, cwd=str(app_root.parent),
        )
        if self.cancelled:  # the gate was cancelled while the process was being created
            self.process.kill()
        try:
            stdout, stderr = self.process.communicate(input=json.dumps(request), timeout=timeout_seconds)
            return _ChildRun(stdout, stderr, self.process.returncode, False)
        except subprocess.TimeoutExpired:
            self.process.kill()
            stdout, stderr = self.process.communicate()
            return _ChildRun(stdout, stderr, None, True)

    def kill(self) -> None:
        self.cancelled = True
        if self.process is not None and self.process.poll() is None:
            self.process.kill()
            self.process.wait()


async def run_app_runtime_smoke(
    app_root: Path, *, mongo_uri: str | None, timeout_seconds: float = SMOKE_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    """Boot the bundle at ``app_root`` in a child process on a disposable database and use it as two users."""
    started = time.monotonic()
    if not mongo_uri:
        return _skipped("no database configured", started=started)
    if not (app_root / "app.json").is_file():
        return _skipped("the bundle has no app.json to boot", started=started)
    from motor.motor_asyncio import AsyncIOMotorClient

    client: Any = AsyncIOMotorClient(mongo_uri, serverSelectionTimeoutMS=int(_PING_TIMEOUT_SECONDS * 1000))
    try:
        try:
            await asyncio.wait_for(client.admin.command("ping"), timeout=_PING_TIMEOUT_SECONDS)
        except Exception as exc:
            reason = _redact(f"database unreachable ({type(exc).__name__}: {exc})", mongo_uri)
            return _skipped(reason, started=started)
        database_name = f"{_SMOKE_DATABASE_PREFIX}{uuid4().hex[:20]}"
        request = {"app_root": str(app_root), "mongo_uri": mongo_uri, "database_name": database_name}
        child = _ChildProcess()
        try:
            run = await asyncio.to_thread(child.run, app_root, request, timeout_seconds)
        except BaseException:
            # ASGI cancellation must not leave generated code running.
            with CancelScope(shield=True):
                await asyncio.to_thread(child.kill)
            raise
        finally:
            with CancelScope(shield=True):
                try:
                    await client.drop_database(database_name)
                except Exception as exc:
                    logger.warning("APP_RUNTIME_SMOKE_DROP_FAILED: database=%s error=%s", database_name, type(exc).__name__)
        return _child_result(run, mongo_uri=mongo_uri, timeout_seconds=timeout_seconds, started=started)
    finally:
        client.close()


def _is_link_or_reparse(metadata: os.stat_result) -> bool:
    return stat.S_ISLNK(metadata.st_mode) or bool(
        getattr(metadata, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def _copy_imported_app(
    app_root: Path, destination: Path, *, expected_sha256: Mapping[str, str] | None = None,
) -> None:
    """Copy only regular staged app files into the sole host path mounted by Docker."""
    root_stat = app_root.lstat()
    if _is_link_or_reparse(root_stat) or not stat.S_ISDIR(root_stat.st_mode):
        raise ValueError("imported app root must be a directory, not a symlink")
    destination.mkdir()
    total_bytes = 0
    file_count = 0
    copied_paths: set[str] = set()
    def fail_walk(error: OSError) -> None:
        raise error

    for root, directories, files in os.walk(app_root, followlinks=False, onerror=fail_walk):
        source_dir = Path(root)
        relative_dir = source_dir.relative_to(app_root)
        for name in directories:
            source = source_dir / name
            source_stat = source.lstat()
            if _is_link_or_reparse(source_stat) or not stat.S_ISDIR(source_stat.st_mode):
                raise ValueError("imported app contains a directory link")
            (destination / relative_dir / name).mkdir()
        for name in files:
            source = source_dir / name
            relative_path = (relative_dir / name).as_posix()
            if expected_sha256 is not None and relative_path not in expected_sha256:
                raise ValueError("imported app contains a file outside the verified source")
            source_stat = source.lstat()
            if (_is_link_or_reparse(source_stat) or not stat.S_ISREG(source_stat.st_mode)
                    or source_stat.st_nlink != 1):
                raise ValueError("imported app contains a link or special file")
            file_count += 1
            total_bytes += source_stat.st_size
            if file_count > _MAX_IMPORTED_SOURCE_FILES or total_bytes > _MAX_IMPORTED_SOURCE_BYTES:
                raise ValueError("imported app exceeds the source smoke limit")
            target = destination / relative_dir / name
            digest = hashlib.sha256()
            with source.open("rb") as reader, target.open("xb") as writer:
                copied = 0
                while chunk := reader.read(1024 * 1024):
                    copied += len(chunk)
                    if copied > source_stat.st_size:
                        raise ValueError("imported app changed while staging")
                    digest.update(chunk)
                    writer.write(chunk)
                if copied != source_stat.st_size:
                    raise ValueError("imported app changed while staging")
            if expected_sha256 is not None and digest.hexdigest() != expected_sha256[relative_path]:
                raise ValueError("imported app bytes differ from the verified source")
            copied_paths.add(relative_path)
    if expected_sha256 is not None and copied_paths != set(expected_sha256):
        raise ValueError("imported app is missing a verified source file")
    if not (destination / "app.json").is_file():
        raise ValueError("imported app has no app.json")


_REFERENCE_REQUEST_FILENAME = "requirement_behavior.json"
_MAX_REFERENCE_REQUEST_BYTES = 2 * 1024 * 1024


def _copy_probe_plan(staged_root: Path, plan_root: Path, *, requirement_behavior: dict[str, Any] | None = None) -> None:
    """Give the observer declarative contracts only; app Python stays in the other container."""
    paths = [Path("app.json"), Path("data/contract.json"), Path("config/auth.yaml"),
             Path("config/subscriptions.yaml")]
    modules_root = staged_root / "modules"
    if modules_root.is_dir():
        paths.extend(Path("modules") / module.name / "module.yaml"
                     for module in modules_root.iterdir() if module.is_dir())
    plan_root.mkdir()
    for relative in paths:
        source = staged_root / relative
        if source.is_file():
            target = plan_root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    if requirement_behavior is not None:
        from .requirement_delivery import validate_reference_request

        request = validate_reference_request(requirement_behavior).model_dump(mode="json")
        data = json.dumps(request, sort_keys=True, separators=(",", ":")).encode("utf-8")
        if len(data) > _MAX_REFERENCE_REQUEST_BYTES:
            raise ValueError("Reference behavior descriptor exceeds its bounded limit")
        (plan_root / _REFERENCE_REQUEST_FILENAME).write_bytes(data)


def _container_removed(name: str, *, config_dir: str) -> bool:
    """Force removal and verify that Docker no longer knows the container."""
    command = _docker_prefix(config_dir)
    environment = _docker_cli_env()
    try:
        subprocess.run([*command, "rm", "-f", name], capture_output=True, timeout=10,
                       check=False, env=environment)
        remaining = subprocess.run(
            [*command, "ps", "-a", "--filter", f"name=^/{name}$", "--format", "{{.Names}}"],
            capture_output=True, text=True, timeout=5, check=False, env=environment,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return remaining.returncode == 0 and name not in remaining.stdout.splitlines()


def _prepare_browser_plan(app_root: Path, plan_root: Path, identity_root: Path,
                          request: dict[str, Any], image_id: str, *,
                          owner_navigation_diagnostic: bool = False,
                          paired_login_diagnostic: bool = False,
                          login_clock_capture: bool = False) -> tuple[Path, dict[str, str]]:
    """Admit the existing finite browser suite and disposable local issuer inputs."""
    from mozaiksai.builder.ui_acceptance import PAIRED_UI_SUITE, validate_profile_coverage
    from mozaiksai.core.runtime.app.auth_contract import (
        APP_AUTH_COMPONENTS,
        load_app_auth_contract,
        validate_app_auth_route_bindings,
    )
    from mozaiksai.core.runtime.app.page_schema import load_app_page_schemas
    from mozaiksai.core.semantics.canonical import canonical_digest
    from mozaiksai.hosts.shell_config import PROFILE_SHELL_ROUTE, PUBLIC_PROFILE_SHELL_ROUTE

    from .requirement_delivery import reference_browser_contract, reference_browser_refinement

    suite, _spec, cases = reference_browser_contract(request)
    paired = suite == PAIRED_UI_SUITE
    if paired and owner_navigation_diagnostic:
        raise ValueError("Owner-navigation diagnostics do not implement paired requirement behavior")
    if (paired_login_diagnostic or login_clock_capture) and not paired:
        raise ValueError("Paired login diagnostics require the admitted paired candidate")
    manifest = json.loads((app_root / "app.json").read_text(encoding="utf-8"))
    if manifest.get("authRequired") is not True:
        raise ValueError("Browser acceptance requires the candidate's declared authentication intent")
    auth = load_app_auth_contract(app_root, auth_required=True)
    if auth is None or auth.frontend.adapter != "oidc_pkce":
        raise ValueError("Browser acceptance requires the canonical OIDC app contract")
    route_manifest = json.loads((app_root / "ui/route_manifest.json").read_text(encoding="utf-8"))["pages"]
    validate_app_auth_route_bindings(auth, route_manifest)

    policy = Path(os.environ.get("MOZAIKS_BROWSER_OBSERVER_SECCOMP", "")).resolve(strict=True)
    if not policy.is_file() or hashlib.sha256(policy.read_bytes()).hexdigest() != _LOCAL_BROWSER_POLICY_SHA256:
        raise ValueError("Local browser observer requires the exact reviewed seccomp policy")
    identity_image = os.environ.get("MOZAIKS_TEST_IDENTITY_IMAGE", "")
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", identity_image):
        raise ValueError("Local identity requires an explicitly pinned disposable fixture image")
    with tempfile.TemporaryDirectory(prefix="mozaiks-browser-preflight-") as config:
        def inspect(image):
            checked = subprocess.run([*_docker_prefix(config), "image", "inspect", image],
                                     env=_docker_cli_env(), capture_output=True, text=True, timeout=10, check=True)
            return json.loads(checked.stdout)[0]
        labels = inspect(image_id)["Config"].get("Labels") or {}
        if inspect(identity_image)["Id"] != identity_image:
            raise ValueError("Disposable identity image changed")
    execution = {key: labels.get("io.mozaiks.browser." + key, "") for key in _BROWSER_MANIFEST_KEYS}
    if paired:
        execution["spec_sha256"] = labels.get("io.mozaiks.browser.paired_spec_sha256", "")
    if (not re.fullmatch(r"[a-f0-9]{40}", execution["source_sha"])
            or any(not re.fullmatch(r"[a-f0-9]{64}", execution[key]) for key in _BROWSER_MANIFEST_KEYS[1:])):
        raise ValueError("Browser image lacks exact source/spec/helper/config build identities")
    execution.update(policy_sha256=_LOCAL_BROWSER_POLICY_SHA256, identity_image_id=identity_image)
    if owner_navigation_diagnostic:
        execution["diagnostic"] = "owner_navigation"
    if paired_login_diagnostic:
        execution["diagnostic"] = "paired_login"
    if paired_login_diagnostic or login_clock_capture:
        execution["clock_diagnostic"] = "evaluated_auth_operands"
    app_id = request["inventory"]["app_id"]
    realm_path = Path(__file__).resolve().parents[1] / "smoke_identity_realm.json"
    realm = json.loads(realm_path.read_text(encoding="utf-8"))
    actor_roles = (("customer", ["participant"]), ("owner", ["participant"]), ("ungranted", [])) if paired else (
        ("customer", ["customer"]), ("owner", ["admin"]), ("ungranted", []))
    realm["roles"] = {"realm": [{"name": role} for role in sorted({role for _, roles in actor_roles for role in roles})]}
    realm["clientScopes"] = [row for row in realm["clientScopes"] if row["name"] in {"basic", "profile", "email"}]
    client = realm["clients"][0]
    client["redirectUris"] = ["http://127.0.0.1:4174/auth/callback"]
    client["webOrigins"] = ["http://127.0.0.1:4174"]
    client["attributes"]["post.logout.redirect.uris"] = "http://127.0.0.1:4174/*"
    client["defaultClientScopes"] = ["basic", "profile", "email"]
    for mapper in client["protocolMappers"]:
        if mapper["config"].get("claim.name") == "app_id":
            mapper["config"]["claim.value"] = app_id
        if mapper["protocolMapper"] == "oidc-usermodel-realm-role-mapper":
            # The canonical UI adapter reads ID-token roles; the API verifies
            # access-token roles. Both project the same trusted fixture grants.
            mapper["config"]["id.token.claim"] = "true"
    login: dict[str, Any] = {"issuer": "http://127.0.0.1:8080/realms/common-ground", "actors": {}}
    realm["users"] = []
    for kind, roles in actor_roles:
        username, user_id, password = "browser-" + kind, str(uuid4()), uuid4().hex + "-Aa1!"
        login["actors"][kind] = {"username": username, "password": password, "expected_user_id": user_id}
        realm["users"].append({"id": user_id, "username": username, "email": username + "@example.test",
                               "firstName": kind.title(), "lastName": "Fixture", "emailVerified": True,
                               "enabled": True, "realmRoles": roles,
                               "credentials": [{"type": "password", "value": password, "temporary": False}]})
    identity_root.mkdir()
    (identity_root / "realm.json").write_text(json.dumps(realm), encoding="utf-8")
    (plan_root / "browser-login.json").write_text(json.dumps(login), encoding="utf-8")
    routes, declared = [], {}
    for name, page in load_app_page_schemas(app_root).items():
        data = page.model_dump(mode="json")
        heading = next((section["config"]["title"] for section in data["sections"]
                        if section["primitive"] == "PageHeader"), page.title)
        declared[page.route] = ("SchemaPage", name, "declarative")
        routes.append({"path": page.route, "component": "SchemaPage", "schema": name,
                       "kind": "declarative", "heading": heading})
    headings = {"CommerceCart": "Cart", "CommerceProductDetail": "alpine-canister",
                "CommerceOrderDetail": "Order details", "BuildKit": "Build a compatible camping kit"}
    if paired:
        headings = {"PlanningBoard": "The work, in motion.", "Messages": "Messages"}
    for route in route_manifest:
        component, path = route["component"], route["path"]
        if component in APP_AUTH_COMPONENTS:
            declared[path] = (component, None, "auth")
            routes.append({"path": path, "component": component, "kind": "auth",
                           "excluded_reason": "Authentication transitions are exercised by normal retained-context login in the required journeys."})
            continue
        if component not in headings:
            raise ValueError("Local reference browser case does not cover this custom component")
        declared[path] = (component, None, "custom")
        visit = path.replace(":productId", "browser-alpine-canister").replace(":orderId", "browser-initial-order")
        routes.append({"path": path, "component": component, "kind": "custom", "heading": headings[component],
                       "visit_path": visit})
    # The canonical shell injects these account routes for authenticated apps.
    # Retain them in exact inventory without crediting unrelated account UI.
    for framework_route in (PROFILE_SHELL_ROUTE, PUBLIC_PROFILE_SHELL_ROUTE):
        routes.append({"path": framework_route["path"], "component": framework_route["component"],
                       "kind": "auth", "excluded_reason": (
                           "Profile persistence is exercised inside the required projects interaction; public-profile navigation is outside this scope."
                           if paired else "Framework account UI is outside the approved storefront and kit requirements.")})
    for route in routes:
        if route.get("excluded_reason"):
            continue
        if any(case["route"] == route["path"] for case in cases):
            continue
        cases.extend({"id": "route:" + route["path"], "route": route["path"], "project": project}
                     for project in ("generated-desktop", "generated-mobile"))
    profile = {"candidate": {"app_id": app_id, "revision": request["inventory"]["review_id"],
                             "source_sha": execution["source_sha"], "bundle_sha256": request["source_content_sha256"]},
               "routes": routes, "cases": cases, "behavior_suite": suite,
               **({"presentation": request["presentation"]} if paired else {}),
               **({"messaging_configuration": request["pack"]["messaging_configuration"]}
                  if paired and request["pack"].get("messaging_configuration") is not None else {}),
               "requirement_inventory_digest": request["accounting"]["inventory_digest"],
               "requirement_accounting_digest": canonical_digest(request["accounting"])}
    refinement = reference_browser_refinement(request)
    if refinement is not None:
        profile["refinement"] = refinement
    validate_profile_coverage(profile, declared_routes=declared, requirement_accounting=request["accounting"])
    execution["profile_sha256"] = canonical_digest(profile)
    (plan_root / "browser-profile.json").write_text(json.dumps(profile, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    (plan_root / "browser-execution.json").write_text(json.dumps(execution), encoding="utf-8")
    return policy, execution


class _ContainedDockerProcess:
    """Run untrusted app and image-owned observer in separate container processes."""

    def __init__(self) -> None:
        self.name = f"mozaiks-imported-smoke-{uuid4().hex[:20]}"
        self.probe_name = f"{self.name}-observer"
        self._config = tempfile.TemporaryDirectory(prefix="mozaiks-smoke-docker-cli-")
        self._docker_command = _docker_prefix(self._config.name)
        self._docker_environment = _docker_cli_env()
        self.app_process: subprocess.Popen[bytes] | None = None
        self.probe_process: subprocess.Popen[bytes] | None = None
        self.reference_host_authority = None
        self.frontend_probe = False
        self.browser_execution: dict[str, str] | None = None
        self.browser_policy: Path | None = None
        self.identity_root: Path | None = None
        self.identity_name = f"{self.name}-identity"
        self.browser_launch: dict[str, Any] | None = None
        self.cancelled = False
        self.run_started = threading.Event()
        self.registration_done = threading.Event()

    def close(self) -> None:
        self._config.cleanup()

    def run(self, app_root: Path, plan_root: Path, image: str, timeout_seconds: float,
            observer_nonce: str) -> _ChildRun:
        database_name = f"{_SMOKE_DATABASE_PREFIX}{observer_nonce[:20]}"
        app_command = [
            *self._docker_command, "create", "--log-driver=none", "--name", self.name,
            "--network=none", "--read-only", "--init", "--cap-drop=ALL",
            "--security-opt=no-new-privileges", "--pids-limit=256",
            "--memory=3g", "--memory-swap=3g", "--cpus=1",
            "--user=10001:10001",
            "--tmpfs=/tmp:rw,nosuid,nodev,size=512m",
            "--tmpfs=/workspace/logs:rw,nosuid,nodev,size=16m,uid=10001,gid=10001,mode=0700",
            f"--mount=type=bind,source={app_root},target={_CONTAINED_APP_ROOT},readonly",
            "--env=PYTHON_DOTENV_DISABLED=1", "--env=PYTHONDONTWRITEBYTECODE=1",
            "--env=PYTHONUNBUFFERED=1", "--env=MONGO_URI=",
            f"--env=PLATFORM_PATH={_CONTAINED_APP_ROOT}",
            image, "python", "-m", _CHILD_MODULE, "--contained-serve", database_name, observer_nonce,
            *(["--reference-host-authority=" + self.reference_host_authority] if self.reference_host_authority else []),
            *(["--frontend-probe"] if self.frontend_probe else []),
            *(["--browser-probe"] if self.browser_execution else []),
        ]
        probe_command = [
            *self._docker_command, "create", "--log-driver=none", "--name", self.probe_name,
            f"--network=container:{self.name}", "--read-only", "--init", "--cap-drop=ALL",
            "--security-opt=no-new-privileges", "--pids-limit=128",
            "--memory=1g", "--memory-swap=1g", "--cpus=1",
            "--user=10001:10001",
            "--tmpfs=/tmp:rw,nosuid,nodev,size=64m",
            "--tmpfs=/workspace/logs:rw,nosuid,nodev,size=16m",
            f"--mount=type=bind,source={plan_root},target={_CONTAINED_PLAN_ROOT},readonly",
            "--env=PYTHON_DOTENV_DISABLED=1", "--env=PYTHONDONTWRITEBYTECODE=1",
            "--env=PYTHONUNBUFFERED=1", "--env=MONGO_URI=",
            image, "python", "-m", _CHILD_MODULE, "--trusted-probe", database_name, observer_nonce,
            *(["--frontend-probe"] if self.frontend_probe else []),
        ]
        identity_command = None
        if self.browser_execution is not None:
            if self.browser_policy is None or self.identity_root is None:
                raise ValueError("Browser launch lacks its reviewed observer policy or private identity fixture")
            issuer = "http://127.0.0.1:8080/realms/common-ground"
            public_auth = {
                "AUTH_ENABLED": "true", "AUTH_PROVIDER": "jwt", "AUTH_AUDIENCE": "common-ground-api",
                "AUTH_ISSUER": issuer, "AUTH_JWKS_URL": issuer + "/protocol/openid-connect/certs",
                "AUTH_SCOPES_CLAIM": "scope", "AUTH_ROLES_CLAIM": "roles",
                "AUTH_ACCESS_TOKEN_TYPE_CLAIM": "typ", "AUTH_ACCESS_TOKEN_TYPE_VALUE": "Bearer",
                "MOZAIKS_OIDC_AUTHORITY": issuer,
                "MOZAIKS_OIDC_DISCOVERY_URL": issuer + "/.well-known/openid-configuration",
                "VITE_OIDC_AUTHORITY": issuer,
                "VITE_OIDC_DISCOVERY_URL": issuer + "/.well-known/openid-configuration",
                "VITE_OIDC_CLIENT_ID": "common-ground",
                "VITE_OIDC_REDIRECT_URI": "http://127.0.0.1:4174/auth/callback",
                "VITE_OIDC_SCOPE": "openid profile email",
            }
            app_command[app_command.index(image):app_command.index(image)] = [
                f"--env={key}={value}" for key, value in public_auth.items()
            ]
            # Only B receives the reviewed browser policy and extra temporary
            # browser space. A's containment arguments remain unchanged.
            probe_command[probe_command.index(image):probe_command.index(image)] = [
                f"--security-opt=seccomp={self.browser_policy}", "--shm-size=128m",
                f"--env=MOZAIKS_OBSERVER_IMAGE_ID={image}",
            ]
            # Pinned Playwright uses /tmp for Chromium shared memory. Two retained
            # authenticated contexts exhaust 256 MiB; keep a bounded 512 MiB tmpfs
            # inside B's unchanged 1 GiB memory limit. No change to A or seccomp.
            probe_command[probe_command.index("--tmpfs=/tmp:rw,nosuid,nodev,size=64m")] = "--tmpfs=/tmp:rw,nosuid,nodev,size=512m"
            # Chromium's renderer/thread creation hit the 128-task cgroup ceiling
            # in the contained paired journey. Only the browser observer gets
            # 256 tasks; CPU, memory, app and non-browser observer limits stay put.
            probe_command[probe_command.index("--pids-limit=128")] = "--pids-limit=256"
            probe_command.append("--browser-probe")
            identity_command = [
                *self._docker_command, "create", "--log-driver=none", "--name", self.identity_name,
                f"--network=container:{self.name}", "--cap-drop=ALL", "--security-opt=no-new-privileges",
                "--pids-limit=256", "--memory=1g", "--memory-swap=1g", "--cpus=1", "--user=1000:0",
                f"--mount=type=bind,source={self.identity_root},target=/opt/keycloak/data/import,readonly",
                self.browser_execution["identity_image_id"], "start-dev", "--import-realm",
                "--http-host=127.0.0.1", "--http-port=8080", "--hostname=http://127.0.0.1:8080",
            ]
        timed_out = False
        output = [bytearray() for _ in range(4)]
        truncated = [False] * 4
        returncode: int | None = None
        creation_error = ""
        readers: list[threading.Thread] = []

        def drain(process: subprocess.Popen[bytes], index: int, limit: int) -> None:
            stream = process.stdout if index % 2 == 0 else process.stderr
            assert stream is not None
            try:
                while chunk := os.read(stream.fileno(), 8192):
                    remaining = max(0, limit - len(output[index]))
                    output[index].extend(chunk[:remaining])
                    if len(chunk) > remaining:
                        truncated[index] = True
            except OSError:
                truncated[index] = True

        def attach(process: subprocess.Popen[bytes], stdout_index: int) -> None:
            stdout_limit = (_BROWSER_REPORT_LIMIT_BYTES
                            if stdout_index == 2 and self.browser_execution is not None
                            else _CONTAINER_STDOUT_LIMIT_BYTES)
            for index, limit in ((stdout_index, stdout_limit),
                                 (stdout_index + 1, _CONTAINER_STDERR_LIMIT_BYTES)):
                reader = threading.Thread(target=drain, args=(process, index, limit), daemon=True)
                reader.start()
                readers.append(reader)

        def register(command: list[str]) -> bool:
            nonlocal creation_error
            try:
                created = subprocess.run(
                    command, stdin=subprocess.DEVNULL, capture_output=True,
                    timeout=_CONTAINER_STARTUP_SECONDS, check=False,
                    env=self._docker_environment,
                )
                if created.returncode == 0:
                    return True
                creation_error = "Docker could not register the contained smoke"
            except (OSError, subprocess.TimeoutExpired):
                creation_error = "Docker container registration did not complete"
            return False

        self.run_started.set()
        if self.cancelled:
            self.registration_done.set()
            return _ChildRun("", "contained smoke was cancelled before registration", None, False, contained=True)
        try:
            if register(app_command) and not self.cancelled:
                self.app_process = subprocess.Popen(
                    [*self._docker_command, "start", "--attach", self.name],
                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    env=self._docker_environment,
                )
                attach(self.app_process, 0)
                # Docker needs the app container running before a second container
                # can join its isolated loopback namespace.
                deadline = time.monotonic() + _CONTAINER_STARTUP_SECONDS
                while time.monotonic() < deadline and not self.cancelled:
                    inspected = subprocess.run(
                        [*self._docker_command, "inspect", "--format", "{{.State.Running}}", self.name],
                        capture_output=True, text=True, timeout=5, check=False,
                        env=self._docker_environment,
                    )
                    if inspected.returncode == 0 and inspected.stdout.strip() == "true":
                        break
                    if self.app_process.poll() is not None:
                        break
                    time.sleep(0.1)
                else:
                    creation_error = "Contained app did not start"
                if not creation_error and not self.cancelled and identity_command is not None:
                    if register(identity_command):
                        identity_started = subprocess.run(
                            [*self._docker_command, "start", self.identity_name], capture_output=True,
                            timeout=_CONTAINER_STARTUP_SECONDS, env=self._docker_environment, check=False,
                        )
                        if identity_started.returncode:
                            creation_error = "Disposable local identity fixture did not start"
                if not creation_error and not self.cancelled and register(probe_command):
                    if self.browser_execution is not None:
                        snapshots = {}
                        for name, network, destination in (
                            (self.name, "none", str(_CONTAINED_APP_ROOT)),
                            (self.probe_name, None, str(_CONTAINED_PLAN_ROOT)),
                        ):
                            check = subprocess.run([*self._docker_command, "inspect", name],
                                                   capture_output=True, text=True, timeout=10, check=True,
                                                   env=self._docker_environment)
                            item = json.loads(check.stdout)[0]
                            host, mounts = item["HostConfig"], item["Mounts"]
                            if (item["Config"]["User"] != "10001:10001" or item["Image"] != image
                                    or host["Privileged"] or host["CapAdd"] or host["CapDrop"] != ["ALL"]
                                    or not host["ReadonlyRootfs"] or host["IpcMode"] != "private" or host["PidMode"]
                                    or "no-new-privileges" not in host["SecurityOpt"]
                                    or host["PidsLimit"] not in {128, 256} or not 0 < host["Memory"] <= 3 * 1024**3
                                    or host["MemorySwap"] != host["Memory"] or host["NanoCpus"] != 10**9
                                    or host["PortBindings"] or len(mounts) != 1
                                    or mounts[0]["Destination"] != destination or mounts[0]["RW"]
                                    or network is not None and host["NetworkMode"] != network
                                    or network is None and not host["NetworkMode"].startswith("container:")):
                                raise ValueError("Actual browser/app Docker launch differs from contained policy")
                            custom = [option for option in host["SecurityOpt"] if option.startswith("seccomp=")]
                            if name == self.name and custom:
                                raise ValueError("Generated app must retain default Docker seccomp")
                            if name == self.probe_name and (
                                len(custom) != 1 or json.loads(custom[0].split("=", 1)[1])
                                != json.loads(self.browser_policy.read_bytes())
                            ):
                                raise ValueError("Observer did not receive the reviewed seccomp policy")
                            snapshots[name] = {key: host[key] for key in (
                                "NetworkMode", "IpcMode", "PidMode", "ReadonlyRootfs", "CapDrop", "CapAdd",
                                "PidsLimit", "Memory", "MemorySwap", "NanoCpus", "PortBindings",
                            )}
                        self.browser_launch = snapshots
                    self.probe_process = subprocess.Popen(
                        [*self._docker_command, "start", "--attach", self.probe_name],
                        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        env=self._docker_environment,
                    )
                    attach(self.probe_process, 2)
            self.registration_done.set()
            if self.probe_process is not None:
                try:
                    self.probe_process.wait(timeout=timeout_seconds)
                    returncode = self.probe_process.returncode
                except subprocess.TimeoutExpired:
                    timed_out = True
                    self.probe_process.kill()
                    self.probe_process.wait(timeout=5)
        finally:
            self.registration_done.set()
            app_exited = self.app_process is not None and self.app_process.poll() is not None
            cleanup_failed = not _container_removed(self.probe_name, config_dir=self._config.name)
            if identity_command is not None:
                cleanup_failed = not _container_removed(self.identity_name, config_dir=self._config.name) or cleanup_failed
            cleanup_failed = not _container_removed(self.name, config_dir=self._config.name) or cleanup_failed
            for reader in readers:
                reader.join(timeout=5)
            if any(reader.is_alive() for reader in readers):
                truncated[2] = True
        return _ChildRun(
            output[2].decode("utf-8", errors="replace"),
            creation_error or output[3].decode("utf-8", errors="replace")
            or output[1].decode("utf-8", errors="replace"),
            returncode, timed_out, cleanup_failed=cleanup_failed,
            output_truncated=any(truncated), contained=True, app_exited=app_exited,
        )

    def kill(self) -> None:
        self.cancelled = True
        if not self.run_started.is_set():
            return
        if not self.registration_done.wait(timeout=2 * _CONTAINER_STARTUP_SECONDS + 5):
            raise RuntimeError("Docker container registration could not be confirmed during cancellation")
        try:
            for process in (self.probe_process, self.app_process):
                if process is not None and process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)
        finally:
            _container_removed(self.probe_name, config_dir=self._config.name)
            if self.browser_execution is not None:
                _container_removed(self.identity_name, config_dir=self._config.name)
            _container_removed(self.name, config_dir=self._config.name)


def preflight_contained_imported_smoke(
    *, image: str | None = None, expected_image_id: str | None = None,
) -> str:
    """Require Docker and the exact trusted image ID before imported-source staging."""
    from mozaiksai.core.adapters.docker_sandbox import docker_available

    if not docker_available():
        raise RuntimeError("contained Docker validation is unavailable")
    pinned_image_id = expected_image_id or os.environ.get("MOZAIKS_IMPORTED_SMOKE_IMAGE_ID")
    if not pinned_image_id:
        raise RuntimeError("contained validator image identity is unconfigured")
    selected_image = image or os.environ.get("DOCKER_SANDBOX_IMAGE") or _CONTAINED_IMAGE
    try:
        with tempfile.TemporaryDirectory(prefix="mozaiks-smoke-docker-cli-") as config_dir:
            inspected = subprocess.run(
                [*_docker_prefix(config_dir), "image", "inspect", "--format", "{{.Id}}", selected_image],
                capture_output=True, text=True, timeout=5, check=False, env=_docker_cli_env(),
            )
    except (OSError, subprocess.TimeoutExpired):
        raise RuntimeError("contained Docker image is unavailable") from None
    image_id = inspected.stdout.strip() if inspected.returncode == 0 else ""
    if image_id != pinned_image_id or not image_id.startswith("sha256:") or len(image_id) != 71:
        raise RuntimeError("contained Docker image is unavailable")
    return image_id


async def run_contained_imported_app_runtime_smoke(
    app_root: Path, *, timeout_seconds: float = SMOKE_TIMEOUT_SECONDS, image: str | None = None,
    expected_source_sha256: Mapping[str, str] | None = None,
    expected_image_id: str | None = None,
    requirement_behavior: dict[str, Any] | None = None,
    frontend_probe: bool = False,
    browser_probe: bool = False,
    owner_navigation_diagnostic: bool = False,
    paired_login_diagnostic: bool = False,
) -> dict[str, Any]:
    """Smoke verified imported bytes with a private MongoDB and no container egress."""
    started = time.monotonic()
    if not expected_source_sha256:
        return _imported_observer_scope(_contained_unavailable(
            "verified imported-source digests are unavailable", started=started,
        ))
    try:
        if requirement_behavior is not None:
            from .requirement_delivery import validate_reference_request

            requirement_behavior = validate_reference_request(requirement_behavior).model_dump(mode="json")
            if requirement_behavior["source_content_sha256"] != _source_content_sha256(expected_source_sha256):
                raise ValueError("Reference behavior source differs from the verified candidate")
            if "presentation" in requirement_behavior and not browser_probe:
                raise RuntimeError("Paired requirement behavior requires the complete contained browser path")
        image_id = await asyncio.to_thread(
            preflight_contained_imported_smoke, image=image, expected_image_id=expected_image_id,
        )
    except (KeyError, RuntimeError, TypeError, ValueError) as exc:
        return _imported_observer_scope(_contained_unavailable(str(exc), started=started))
    with tempfile.TemporaryDirectory(prefix="mozaiks-imported-smoke-") as temporary:
        staged_root = Path(temporary) / "app"
        plan_root = Path(temporary) / "plan"
        try:
            _copy_imported_app(app_root, staged_root, expected_sha256=expected_source_sha256)
            if requirement_behavior is None:
                _copy_probe_plan(staged_root, plan_root)
            else:
                _copy_probe_plan(staged_root, plan_root, requirement_behavior=requirement_behavior)
        except (OSError, ValueError) as exc:
            return _imported_observer_scope(_summary([{
                "check": "smoke.source", "status": "failed", "path": None,
                "message": f"Imported app cannot be staged safely: {type(exc).__name__}: {exc}",
            }], {}, started=started))
        child = _ContainedDockerProcess()
        child.reference_host_authority = requirement_behavior["spec"]["id"] if requirement_behavior is not None else None
        child.frontend_probe = frontend_probe or browser_probe
        if browser_probe:
            try:
                if requirement_behavior is None:
                    raise ValueError("Browser reference execution requires approved requirement accounting")
                child.identity_root = Path(temporary) / "identity"
                child.browser_policy, child.browser_execution = _prepare_browser_plan(
                    staged_root, plan_root, child.identity_root, requirement_behavior, image_id,
                    owner_navigation_diagnostic=owner_navigation_diagnostic,
                    paired_login_diagnostic=paired_login_diagnostic,
                )
            except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
                child.close()
                return _imported_observer_scope(_contained_unavailable(str(exc), started=started))
        observer_nonce = uuid4().hex
        try:
            run = await asyncio.to_thread(child.run, staged_root, plan_root, image_id, timeout_seconds,
                                          observer_nonce)
        except Exception as exc:
            with CancelScope(shield=True):
                await asyncio.to_thread(child.kill)
            return _imported_observer_scope(_summary([{
                "check": "smoke.container", "status": "failed", "path": None,
                "message": f"Contained runtime smoke could not complete: {type(exc).__name__}.",
            }], {}, started=started))
        except BaseException:
            with CancelScope(shield=True):
                await asyncio.to_thread(child.kill)
            raise
        finally:
            child.close()
        result = _child_result(run, mongo_uri="", timeout_seconds=timeout_seconds, started=started)
        events = _events(run.stdout)
        boot = [index for index, event in enumerate(events) if event.get("event") == "outcome"
                and event.get("check") == "boot.http_ready" and event.get("status") == "passed"]
        done = [index for index, event in enumerate(events) if event.get("event") == "done"]
        valid_receipt = (bool(events) and len(boot) == 1 and len(done) == 1
                         and boot[0] < done[0] == len(events) - 1
                         and all(event.get("observer_nonce") == observer_nonce for event in events))
        if result["status"] == "passed" and not valid_receipt:
            result = _summary([*result["results"], {
                "check": "smoke.observer", "status": "failed", "path": None,
                "message": "The external observer did not return one matching boot and completion receipt.",
            }], result, started=started)
        if requirement_behavior is not None and result["status"] == "passed" and not browser_probe:
            from .requirement_delivery import reference_behavior_owner

            try:
                issue = reference_behavior_owner(requirement_behavior).reference_evidence_issue(requirement_behavior, result["results"])
            except (KeyError, OSError, TypeError, ValueError) as exc:
                issue = f"admitted reference identity could not be revalidated: {exc}"
            if issue:
                result = _summary([*result["results"], {
                    "check": "smoke.requirement_observer", "status": "failed", "path": None,
                    "message": "The external observer's reference coverage is invalid: " + issue,
                }], result, started=started)
        result["validator_image_id"] = image_id
        if child.browser_execution is not None:
            result["browser_execution"] = child.browser_execution
            result["browser_launch"] = child.browser_launch
        result["source_content_sha256"] = hashlib.sha256(json.dumps(
            expected_source_sha256, sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        if result["status"] == "passed" and valid_receipt:
            result["observer_origin"] = "trusted_external_probe_v1"
            result["observer_run_id"] = observer_nonce
            result["observed_boot"] = {"check": "boot.http_ready", "status": "passed"}
            result["observer_completion_verified"] = True
            result["observer_cleanup_verified"] = not run.cleanup_failed
            if requirement_behavior is not None:
                from mozaiksai.core.semantics.canonical import canonical_digest

                result["requirement_behavior_request_digest"] = canonical_digest(requirement_behavior)
        return _imported_observer_scope(result)


def _preflight_generated_image() -> str:
    """Resolve a locally inspected image ID before generated bytes are staged."""
    image_id = os.environ.get(_GENERATED_IMAGE_ENV, "").strip()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", image_id):
        raise RuntimeError(f"{_GENERATED_IMAGE_ENV} must name an immutable local image ID")

    # The local-only CLI owner is being integrated separately. Its absence must
    # keep this draft's generated acceptance path closed.
    from mozaiksai.core.adapters.docker_sandbox import docker_available

    if not docker_available():
        raise RuntimeError("contained Docker validation is unavailable")
    with tempfile.TemporaryDirectory(prefix="mozaiks-docker-cli-") as config_dir:
        try:
            inspected = subprocess.run(
                [*_docker_prefix(config_dir), "image", "inspect", "--format", "{{.Id}}", image_id],
                capture_output=True, text=True, timeout=5, check=False, env=_docker_cli_env(),
            )
        except (OSError, subprocess.TimeoutExpired):
            raise RuntimeError("contained Docker image is unavailable") from None
    if inspected.returncode != 0 or inspected.stdout.strip() != image_id:
        raise RuntimeError("contained Docker image is unavailable")
    return image_id


def _generated_source_digests(files: Mapping[str, str]) -> dict[str, str]:
    if not files or len(files) > _MAX_IMPORTED_SOURCE_FILES:
        raise ValueError("generated app exceeds the contained source limit")
    digests: dict[str, str] = {}
    total = 0
    for raw_path, content in files.items():
        if not isinstance(raw_path, str) or not isinstance(content, str):
            raise ValueError("generated app contains invalid source content")
        path = PurePosixPath(raw_path.replace("\\", "/"))
        if (not raw_path or path.is_absolute() or ":" in raw_path or "\x00" in raw_path
                or any(part == ".." for part in path.parts) or str(path) == "."
                or str(path) in digests):
            raise ValueError("generated app contains an unsafe source path")
        data = content.encode("utf-8")
        total += len(data)
        if total > _MAX_IMPORTED_SOURCE_BYTES:
            raise ValueError("generated app exceeds the contained source limit")
        digests[str(path)] = hashlib.sha256(data).hexdigest()
    if "app.json" not in digests:
        raise ValueError("generated app has no app.json")
    return digests


def _source_content_sha256(digests: Mapping[str, str]) -> str:
    return hashlib.sha256(json.dumps(
        digests, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")).hexdigest()


def generated_acceptance_scope() -> dict[str, Any]:
    """The narrower claim made only by contained generated-app acceptance."""
    return {
        "version": GENERATED_ACCEPTANCE_SCOPE_VERSION,
        "excluded_observer_checks": ["event_rejection"],
    }


def generated_smoke_evidence_issue(
    result: Mapping[str, Any], files: Mapping[str, str], expected_image_id: str,
) -> str | None:
    """Check the host-owned observer evidence before applying the generated scope."""
    try:
        expected_source_digest = _source_content_sha256(_generated_source_digests(files))
    except (UnicodeError, ValueError):
        return "generated source identity could not be verified"
    if result.get("status") != "passed" or result.get("passed") is not True:
        return "the external observer did not pass"
    if result.get("observer_unverified_checks") != ["event_rejection"]:
        return "the external observer's unverified checks differ from the generated scope"
    if (not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_image_id)
            or result.get("validator_image_id") != expected_image_id):
        return "the external observer image identity does not match the pinned image"
    if result.get("source_content_sha256") != expected_source_digest:
        return "the external observer source identity does not match the generated snapshot"
    if (result.get("observer_origin") != "trusted_external_probe_v1"
            or not re.fullmatch(r"[0-9a-f]{32}", str(result.get("observer_run_id") or ""))
            or result.get("observed_boot") != {"check": "boot.http_ready", "status": "passed"}
            or result.get("observer_completion_verified") is not True):
        return "the external observer boot and completion receipts were not verified"
    if result.get("observer_cleanup_verified") is not True:
        return "the external observer container cleanup was not verified"
    outcomes = result.get("results")
    checks = result.get("checks")
    if (not isinstance(outcomes, list) or not outcomes
            or not all(isinstance(row, dict) and row.get("status") in {"passed", "not_run"}
                       for row in outcomes)
            or sum(row.get("check") == "boot.http_ready" and row.get("status") == "passed"
                   for row in outcomes) != 1
            or not isinstance(checks, list) or len(checks) != 1
            or not isinstance(checks[0], dict) or checks[0].get("id") != "app_runtime_smoke"
            or checks[0].get("status") != "passed" or checks[0].get("passed") is not True
            or result.get("failed_tests") != []):
        return "the external observer runtime checks did not all complete successfully"
    details = checks[0].get("details")
    if (not isinstance(details, dict) or details.get("status") != "passed"
            or details.get("check_count") != sum(row["status"] == "passed" for row in outcomes)
            or details.get("failed_check_count") != 0
            or details.get("not_run_check_count") != sum(row["status"] == "not_run" for row in outcomes)):
        return "the external observer runtime check summary does not match its outcomes"
    return None


def _generated_scope_pending(result: dict[str, Any], reason: str) -> dict[str, Any]:
    """Retain observer evidence while refusing an incomplete generated claim."""
    result.pop("acceptance_scope", None)
    result["status"] = "pending"
    result["passed"] = None
    result["skipped_reason"] = reason
    result["checks"] = [{
        "id": "app_runtime_smoke", "status": "pending", "passed": None,
        "message": f"Contained runtime acceptance awaits {reason}.",
        "details": {"status": "pending", "blocking": True},
    }]
    return result


def apply_generated_acceptance_scope(
    result: dict[str, Any], files: Mapping[str, str], expected_image_id: str,
) -> dict[str, Any]:
    """Admit only the exact generated scope on a fully verified observer run."""
    if result.get("status") != "passed":
        result.pop("acceptance_scope", None)
        return result
    issue = generated_smoke_evidence_issue(result, files, expected_image_id)
    if not issue and ("acceptance_scope" in result
                      and result["acceptance_scope"] != generated_acceptance_scope()):
        issue = "the generated acceptance scope differs from the approved contract"
    if issue:
        return _generated_scope_pending(result, issue)
    result["acceptance_scope"] = generated_acceptance_scope()
    return result


def _stage_generated_source(root: Path, files: Mapping[str, str]) -> None:
    for path, content in files.items():
        target = root / PurePosixPath(path.replace("\\", "/"))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8", newline="")


def _generated_load_unavailable(reason: str) -> dict[str, Any]:
    return {
        "contract_version": "1.0", "status": "skipped", "passed": None,
        "skipped_reason": reason,
        "checks": [{
            "id": "app_runtime_load", "status": "skipped", "passed": None,
            "message": f"Contained AppLoader check unavailable: {reason}.",
            "details": {"blocking": True},
        }],
        "failed_tests": [], "warnings": [], "details": {},
    }


async def run_contained_generated_app_runtime_load(files: dict[str, str]) -> dict[str, Any]:
    """Collect AppLoader repair diagnostics in Docker; the smoke remains the authority."""
    files = dict(files)
    try:
        digests = _generated_source_digests(files)
        image_id = await asyncio.to_thread(_preflight_generated_image)
    except (ImportError, RuntimeError, UnicodeError, ValueError) as exc:
        return _generated_load_unavailable(str(exc) if not isinstance(exc, ImportError)
                                           else "fixed-local Docker validation is unavailable")

    from mozaiksai.core.adapters.docker_sandbox import DockerSandboxAdapter

    adapter = DockerSandboxAdapter(image=image_id, default_timeout_seconds=_GENERATED_LOAD_TIMEOUT_SECONDS + 30)
    session_id: str | None = None
    result: dict[str, Any] | None = None
    failure: str | None = None
    try:
        creation = asyncio.create_task(adapter.create_session(
            timeout_seconds=_GENERATED_LOAD_TIMEOUT_SECONDS + 30,
            metadata={"purpose": "app_runtime_diagnostic"},
            envs={"PYTHON_DOTENV_DISABLED": "1"},
        ))
        try:
            session = await asyncio.shield(creation)
        except BaseException:
            with CancelScope(shield=True):
                try:
                    created = await creation
                except Exception:
                    pass
                else:
                    await adapter.terminate_session(session_id=created.session_id)
            raise
        session_id = session.session_id
        staged_files: dict[str, str | bytes] = dict(files)
        await adapter.write_files(session_id=session_id, files=staged_files, cwd="/workspace/app")
        execution = await adapter.run_command(
            session_id=session_id,
            command=(
                "python -m factory_app.workflows.AppGenerator.tools.app_runtime_load_probe "
                "--app-root /workspace/app --output /workspace/app-runtime-load.json "
                "> /workspace/app-runtime-load.log 2>&1"
            ),
            cwd="/workspace", timeout_seconds=_GENERATED_LOAD_TIMEOUT_SECONDS,
        )
        if not execution.success:
            failure = "contained AppLoader worker did not complete"
        else:
            output = await adapter.run_command(
                session_id=session_id,
                command=f"head -c {_GENERATED_LOAD_RESULT_LIMIT + 1} /workspace/app-runtime-load.json",
                cwd="/workspace", timeout_seconds=10,
            )
            if not output.success or len(output.stdout.encode("utf-8")) > _GENERATED_LOAD_RESULT_LIMIT:
                failure = "contained AppLoader worker returned no bounded result"
            else:
                decoded = json.loads(output.stdout)
                if (not isinstance(decoded, dict) or decoded.get("contract_version") != "1.0"
                        or not isinstance(decoded.get("passed"), bool)
                        or not isinstance(decoded.get("checks"), list)
                        or not isinstance(decoded.get("failed_tests"), list)
                        or not isinstance(decoded.get("details"), dict)):
                    failure = "contained AppLoader worker returned an invalid result"
                else:
                    result = decoded
    except Exception as exc:
        logger.warning("APP_RUNTIME_LOAD_CONTAINMENT_FAILED: %s", type(exc).__name__)
        failure = "contained AppLoader worker could not complete"
    finally:
        if session_id is not None:
            with CancelScope(shield=True):
                try:
                    removed = await adapter.terminate_session(session_id=session_id)
                except Exception:
                    removed = False
            if not removed:
                failure = "contained AppLoader worker removal could not be confirmed"
    if failure or result is None:
        return _generated_load_unavailable(failure or "contained AppLoader worker returned no result")
    # This flag is host-owned: candidate Python can forge the diagnostic JSON,
    # but it cannot attest that the host removed its worker afterward.
    result["worker_containment_verified"] = True
    result["validator_image_id"] = image_id
    result["source_content_sha256"] = _source_content_sha256(digests)
    return result


async def run_contained_generated_app_runtime_smoke(
    files: dict[str, str], *, requirement_behavior: dict[str, Any] | None = None,
    frontend_probe: bool = False,
    browser_probe: bool = False,
    owner_navigation_diagnostic: bool = False,
    paired_login_diagnostic: bool = False,
) -> dict[str, Any]:
    """Stage generated bytes only after image preflight, then use the external probe."""
    started = time.monotonic()
    files = dict(files)
    try:
        digests = _generated_source_digests(files)
        if requirement_behavior is not None:
            from .requirement_delivery import validate_reference_request

            requirement_behavior = validate_reference_request(requirement_behavior).model_dump(mode="json")
            if requirement_behavior["source_content_sha256"] != _source_content_sha256(digests):
                raise ValueError("Reference behavior source differs from the generated snapshot")
        image_id = await asyncio.to_thread(_preflight_generated_image)
    except (ImportError, KeyError, RuntimeError, TypeError, UnicodeError, ValueError) as exc:
        reason = str(exc) if not isinstance(exc, ImportError) else "fixed-local Docker validation is unavailable"
        return _contained_unavailable(reason, started=started)
    try:
        with tempfile.TemporaryDirectory(prefix="mozaiks-generated-smoke-") as temporary:
            app_root = Path(temporary) / "app"
            _stage_generated_source(app_root, files)
            result = await run_contained_imported_app_runtime_smoke(
                app_root, expected_source_sha256=digests,
                image=image_id, expected_image_id=image_id,
                frontend_probe=frontend_probe,
                **({"browser_probe": True, "timeout_seconds": 900.0} if browser_probe else {}),
                **({"owner_navigation_diagnostic": True} if owner_navigation_diagnostic else {}),
                **({"paired_login_diagnostic": True} if paired_login_diagnostic else {}),
                **({"requirement_behavior": requirement_behavior} if requirement_behavior is not None else {}),
            )
    except OSError:
        return _contained_unavailable("generated app source staging failed", started=started)
    return apply_generated_acceptance_scope(result, files, image_id)


def _redact(text: str, mongo_uri: str) -> str:
    return text.replace(mongo_uri, "<database uri>") if mongo_uri else text


def _events(stdout: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for line in stdout.splitlines():
        if not line.startswith(_EVENT_PREFIX):
            continue
        try:
            event = json.loads(line[len(_EVENT_PREFIX):])
        except ValueError:
            continue
        if isinstance(event, dict):
            events.append(event)
    return events


def _child_result(run: _ChildRun, *, mongo_uri: str, timeout_seconds: float, started: float) -> dict[str, Any]:
    events = _events(run.stdout)
    outcomes = [{key: value for key, value in event.items() if key not in {"event", "observer_nonce"}} for event in events
                if event.get("event") == "outcome"]
    done = next((event for event in reversed(events) if event.get("event") == "done"), None)
    activity = next((event for event in reversed(events) if event.get("event") in {"calling", "step"}), None)
    where, path = "", None
    if activity is not None and activity.get("event") == "calling":
        where = f" while {activity['module']}.{activity['action']} was running as user {activity['principal']}"
        path = f"modules/{activity['module']}/backend/service.py"
    elif activity is not None:
        where = f" during {activity['name']}"
    if run.timed_out:
        outcomes.append({
            "check": "smoke.timeout", "status": "failed", "path": path,
            "message": f"The runtime smoke was stopped at its {timeout_seconds:.0f}s limit{where}. Generated code "
                       "must not block or wait on unreachable services when its actions are called.",
        })
    elif done is None or (run.contained and run.returncode != 0):
        tail = " ".join(run.stderr.strip().splitlines()[-3:])[-600:]
        phase = "before finishing" if done is None else "after reporting completion"
        outcomes.append({
            "check": "smoke.process", "status": "failed", "path": path,
            "message": f"The runtime smoke process exited with code {run.returncode}{where} {phase}: "
                       f"{tail or 'no output'}",
        })
    if run.app_exited:
        outcomes.append({
            "check": "smoke.process", "status": "failed", "path": None,
            "message": "The imported app container exited before the external observer finished.",
        })
    if run.cleanup_failed:
        outcomes.append({
            "check": "smoke.cleanup", "status": "failed", "path": None,
            "message": "The contained runtime smoke could not confirm Docker container removal.",
        })
    if run.output_truncated:
        outcomes.append({
            "check": "smoke.output", "status": "failed", "path": None,
            "message": "The contained runtime smoke exceeded its bounded output limit.",
        })
    for outcome in outcomes:
        outcome["message"] = _redact(str(outcome.get("message") or ""), mongo_uri)
    return _summary(outcomes, done or {}, started=started)


# --------------------------------------------------------------------------- result records


@dataclass
class _Outcome:
    check: str
    passed: bool | None  # None: the check had nothing to act on and did not run
    message: str
    path: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "check": self.check,
            "status": "not_run" if self.passed is None else "passed" if self.passed else "failed",
            "message": self.message,
            "path": self.path,
            **({"details": self.details} if self.details else {}),
        }


@dataclass(frozen=True)
class _Principal:
    label: str
    user_id: str
    token: str
    workspace_id: str | None
    extra_scopes: tuple[str, ...] = ()
    roles: tuple[str, ...] = ()


@dataclass
class _Entity:
    module: str
    collection: dict[str, Any]
    entity: str
    id_field: str
    owner_field: str | None
    tenancy: str
    actions: dict[str, str]

    @property
    def label(self) -> str:
        return f"{self.module}.{self.collection.get('name')}"

    @property
    def lookup_field(self) -> str:
        from mozaiksai.core.workflow.generator_support.data_contract_fields import read_lookup_field

        return read_lookup_field(self.collection)


class _RunLogCapture(logging.Handler):
    """Keep the runtime's warning and error records (the child runs one smoke)."""

    def __init__(self) -> None:
        super().__init__(logging.WARNING)
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)


def _skipped(reason: str, *, started: float) -> dict[str, Any]:
    message = f"Runtime smoke skipped: {reason}. Boot, two-user CRUD and entitlement checks did not run."
    return {
        "contract_version": SMOKE_CONTRACT_VERSION,
        "status": "skipped",
        "passed": None,
        "skipped_reason": reason,
        "duration_ms": int((time.monotonic() - started) * 1000),
        "results": [],
        "checks": [{
            "id": "app_runtime_smoke",
            "passed": None,
            "status": "skipped",
            "message": message,
            "details": {"status": "skipped", "skipped_reason": reason, "blocking": False},
        }],
        "failed_tests": [],
        "warnings": [message],
    }


def _contained_unavailable(reason: str, *, started: float) -> dict[str, Any]:
    result = _skipped(reason, started=started)
    result["checks"][0]["details"]["blocking"] = True
    return result


def _imported_observer_scope(result: dict[str, Any]) -> dict[str, Any]:
    # A rejected ctx.emit leaves no HTTP or Mongo trace. A's in-process
    # rejection list cannot be evidence for the separate trusted observer.
    result["observer_unverified_checks"] = ["event_rejection"]
    return result


# --------------------------------------------------------------------------- the run


class _SmokeRun:
    def __init__(self, app_root: Path, client: Any, database_name: str, emit: Callable[..., None],
                 *, browser_probe: bool = False) -> None:
        self.app_root = app_root
        self.client = client
        self.database_name = database_name
        self.emit = emit
        self.outcomes: list[_Outcome] = []
        self.capture = _RunLogCapture()
        self.app: Any = None
        self.load: Any = None
        self.app_id = "mozaiks-runtime-smoke"
        self.scopes: list[str] = []
        self.default_roles: tuple[str, ...] = ()
        self.reference_host_authority = None
        self.browser_probe = browser_probe
        self.profile_persistence_binding: tuple[Any, Any] | None = None
        self.paired_host_binding: tuple[Any, Any, Any] | None = None
        self.principals: dict[str, _Principal] = {}
        self.events: list[str] = []
        self.http: Any = None
        self.workspace_claims = False
        self.last_exception_path: str | None = None
        self.permission_denials: set[tuple[str, str]] = set()
        # (module, action, rejection) for every emitted event the runtime rejected.
        self.rejected_events: list[tuple[str, str, Any]] = []
        self.reported_rejections: set[tuple[str, str, str, str, str]] = set()
        self.external_server = False
        self.external_probe = False
        self.probe_nonce = ""

    @property
    def database(self) -> Any:
        return self.client[self.database_name]

    def record(self, check: str, passed: bool, message: str, *, path: str | None = None, **details: Any) -> bool:
        outcome = _Outcome(check, passed, message, path, details)
        self.outcomes.append(outcome)
        self.emit("outcome", **outcome.to_dict())
        return passed

    def not_run(self, check: str, reason: str) -> None:
        outcome = _Outcome(check, None, f"Not run: {reason}")
        self.outcomes.append(outcome)
        self.emit("outcome", **outcome.to_dict())

    def step(self, name: str) -> None:
        self.emit("step", name=name)

    async def record_event(self, event_type: str, envelope: dict[str, Any]) -> None:
        self.events.append(str(event_type))

    def principal(self, label: str) -> _Principal:
        if label not in self.principals:
            slug = "".join(char if char.isalnum() else "-" for char in label.lower()).strip("-")
            self.principals[label] = _Principal(
                label=label,
                user_id=f"smoke-{slug}",
                token=f"smoke-{slug}-{uuid4().hex}",
                workspace_id=f"smoke-workspace-{slug}" if self.workspace_claims else None,
                roles=self.default_roles,
            )
        return self.principals[label]

    # ---------------------------------------------------------------- failure detail

    def _exception_detail(self, since: int) -> tuple[str | None, str | None]:
        """The last captured action exception after ``since``: text and bundle-relative file."""
        for record in reversed(self.capture.records[since:]):
            if not record.exc_info or not record.exc_info[1]:
                continue
            exc = record.exc_info[1]
            text = f"{type(exc).__name__}: {exc}"
            path = None
            root = str(self.app_root.resolve())
            for frame in reversed(traceback.extract_tb(record.exc_info[2])):
                filename = str(Path(frame.filename).resolve())
                if filename.startswith(root):
                    path = PurePosixPath(Path(filename).relative_to(root)).as_posix()
                    text += f" (at {path}:{frame.lineno})"
                    break
            return text, path
        return None, None

    def _with_scopes(self, principal: _Principal, scopes: list[str]) -> _Principal:
        label = f"{principal.label} +{','.join(scopes)}"
        if label not in self.principals:
            self.principals[label] = _Principal(
                label=label, user_id=principal.user_id, token=f"{principal.token}-{uuid4().hex[:8]}",
                workspace_id=principal.workspace_id, extra_scopes=tuple(scopes), roles=principal.roles,
            )
        return self.principals[label]

    def _with_roles(self, principal: _Principal, roles: list[str]) -> _Principal:
        label = f"{principal.label} roles:{','.join(roles) or 'none'}"
        if label not in self.principals:
            self.principals[label] = _Principal(
                label=label, user_id=principal.user_id, token=f"{principal.token}-{uuid4().hex[:8]}",
                workspace_id=principal.workspace_id, extra_scopes=principal.extra_scopes,
                roles=tuple(roles),
            )
        return self.principals[label]

    async def call(
        self, method: str, module: str, action: str, principal: _Principal, params: dict[str, Any],
    ) -> tuple[int, Any, str]:
        """Call one module action as ``principal``; return status, JSON body and a one-line summary.

        Never turn an action declaration or requested OIDC scope into a grant.
        """
        loaded = next((item for item in self.load.modules if item.name == module), None)
        required = list((loaded.action_permissions_map.get(action) or []) if loaded is not None else [])
        status, body, summary = await self._request(method, module, action, principal, params)
        if required and status == 403 and (module, action) not in self.permission_denials:
            self.permission_denials.add((module, action))
            self.record(
                f"permission.{module}.{action}", False,
                f"{module}.{action} requires {required} but the test host granted no matching permission "
                f"to {principal.label} ({summary}). Requested config/auth.yaml scopes {self.scopes} "
                "are not grants. No retry or permission escalation was performed.",
                path=f"modules/{module}/module.yaml",
            )
        return status, body, summary

    def _record_rejected_event(self, module: str, action: str, principal: _Principal, rejection: Any) -> None:
        """An emitted event the runtime rejected fails its own check, once per action, event and reason.

        The action's response cannot show it: the runtime reports an action
        whose handler completed as succeeded and only names the rejected event
        on the dispatch result. No reaction or notification runs for it.
        """
        key = (module, action, rejection.event_type, rejection.category, rejection.reason)
        if key in self.reported_rejections:
            return
        self.reported_rejections.add(key)
        if rejection.category == "undeclared":
            problem = f"which {module}.{action} does not declare in its module.yaml emits"
            path = f"modules/{module}/module.yaml"
        elif rejection.category == "schema_invalid":
            problem = f"whose payload_schema in contracts/events.yaml cannot be evaluated ({rejection.reason})"
            path = f"modules/{module}/contracts/events.yaml"
        else:
            problem = (f"whose payload does not satisfy the payload_schema contracts/events.yaml declares for it "
                       f"(at {rejection.schema_path}: {rejection.reason})")
            path = f"modules/{module}/backend/service.py"
        self.record(
            f"event.{module}.{action}.{rejection.event_type}", False,
            f"{module}.{action} as user {principal.label} emitted {rejection.event_type} (event {rejection.event_id}) "
            f"{problem}. The runtime did not dispatch it, so no reaction or notification ran for it, although the "
            "action itself succeeded.",
            path=path,
        )

    async def _request(
        self, method: str, module: str, action: str, principal: _Principal, params: dict[str, Any],
    ) -> tuple[int, Any, str]:
        since = len(self.capture.records)
        rejected_since = len(self.rejected_events)
        self.emit("calling", module=module, action=action, principal=principal.label)
        url = f"/api/modules/{module}/{action}"
        headers = {"Authorization": f"Bearer {principal.token}"}
        if self.external_probe:
            assertion = {
                "nonce": self.probe_nonce, "user_id": principal.user_id,
                "workspace_id": principal.workspace_id, "label": principal.label,
                "extra_scopes": list(principal.extra_scopes),
                "roles": list(principal.roles),
            }
            headers["X-Mozaiks-Smoke-Principal"] = base64.urlsafe_b64encode(
                json.dumps(assertion, separators=(",", ":")).encode("utf-8")
            ).decode("ascii")
        try:
            if method == "GET":
                request = self.http.get(url, params={key: str(value) for key, value in params.items()}, headers=headers)
            else:
                request = self.http.post(url, json=params, headers=headers)
            response = await asyncio.wait_for(request, timeout=_REQUEST_TIMEOUT_SECONDS)
        except (TimeoutError, TimeoutException):
            return 0, None, f"no response within {_REQUEST_TIMEOUT_SECONDS:.0f}s"
        finally:
            for rejected_module, rejected_action, rejection in self.rejected_events[rejected_since:]:
                self._record_rejected_event(rejected_module, rejected_action, principal, rejection)
        try:
            body = response.json()
        except ValueError:
            body = response.text[:300]
        summary = f"{response.status_code}"
        detail = body.get("detail") if isinstance(body, dict) else None
        if isinstance(detail, dict):
            summary += f" {detail.get('error_code') or ''}: {detail.get('error') or ''}".rstrip(": ")
        elif isinstance(detail, str):
            summary += f": {detail}"
        elif isinstance(detail, list) and detail and isinstance(detail[0], Mapping):
            summary += f": {detail[0].get('msg')} at {detail[0].get('loc')}"
        self.last_exception_path = None
        if response.status_code >= 500:
            exception, self.last_exception_path = self._exception_detail(since)
            if exception:
                summary += f"; {exception}"
        return response.status_code, body, summary


# --------------------------------------------------------------------------- composition


def _app_id(load: Any) -> str:
    contract = load.data_contract or {}
    config = getattr(load.definition, "config", None) or {}
    return str(contract.get("app_id") or config.get("appId") or config.get("app_id") or "mozaiks-runtime-smoke")


def _declared_extensions(modules: list[Any], kind: str) -> list[tuple[str, str]]:
    declared: list[tuple[str, str]] = []
    for module in modules:
        manifests = getattr(module, "manifests", None)
        extensions = getattr(manifests, "runtime_extensions", None) if manifests is not None else None
        for extension in getattr(extensions, "extensions", None) or []:
            if extension.kind == kind:
                declared.append((module.name, extension.entrypoint))
    return declared


def _alias_collection_name(alias: str, contract: Mapping[str, Any] | None) -> str:
    from mozaiksai.core.runtime.persistence.app_data import collection_name_for_alias

    return collection_name_for_alias(alias, contract=contract or {})


async def _mount_paired_browser_interfaces(run: _SmokeRun, app: FastAPI, registry: Any, hooks: Any) -> None:
    """Compose existing authenticated profile/session owners in isolated A only."""
    from mozaiksai.core.runtime.composition.platform_hooks import PlatformHookRegistry
    from mozaiksai.core.transport.simple_transport import SimpleTransport
    from mozaiksai.hosts import platform, runtime
    from mozaiksai.hosts.routers.sessions import router as sessions_router
    from mozaiksai.hosts.routers.transitions import get_session_state

    run.paired_host_binding = platform.executor_registry, PlatformHookRegistry._instance, runtime.simple_transport
    # Native profile contributions dispatch through these existing platform
    # owners. Bind the same executor/host authority as the module-action route,
    # not an empty registry or a scope inferred from generated auth config.
    platform.executor_registry = registry
    PlatformHookRegistry._instance = hooks
    runtime.simple_transport = await SimpleTransport.get_instance()
    app.add_api_route("/api/me", platform.update_current_user_profile, methods=["PUT"])
    app.add_api_route("/api/me/profile-config", platform.get_profile_config, methods=["GET"])
    app.add_api_route("/api/me/profile-pages", platform.get_profile_pages, methods=["GET"])
    app.include_router(sessions_router)
    app.add_api_route("/api/session/state", get_session_state, methods=["GET"])
    app.add_api_websocket_route("/ws/{workflow_name}/{app_id}/{chat_id}/{user_id}", platform.websocket_endpoint)


async def _boot(run: _SmokeRun, initial_environment: set[str]) -> bool:
    """Compose the generated app the way the platform host does. False when nothing can be called."""
    from httpx import ASGITransport, AsyncClient

    from mozaiksai.core.audit.audit_logger import AuditLogger, AuditRecord
    from mozaiksai.core.auth import optional_user
    from mozaiksai.core.auth.dependencies import UserPrincipal
    from mozaiksai.core.runtime.app.entitlements import ConfiguredEntitlementAdapter
    from mozaiksai.core.runtime.app.loader import AppLoader
    from mozaiksai.core.runtime.composition.executor_registry import ExecutorRegistry
    from mozaiksai.core.runtime.composition.extensions import mount_module_routers
    from mozaiksai.core.runtime.composition.module_executor import ModuleExecutor
    from mozaiksai.core.runtime.composition.platform_hooks import PlatformHookRegistry
    from mozaiksai.core.runtime.persistence import (
        MongoPersistenceContext,
        PersistencePrincipal,
        apply_data_migrations,
        apply_database_indexes,
        load_data_migrations,
    )
    from mozaiksai.core.workflow.generator_support.module_write_actions import auth_contract_scopes
    from mozaiksai.hosts.routers import modules as module_router
    if run.external_server:
        from mozaiksai.hosts.routers.shell import router as shell_router
    if run.browser_probe:
        from mozaiksai.core.auth.adapters.registry import validate_auth_provider_configuration

        provider = validate_auth_provider_configuration()
        if not run.external_server or provider != "jwt":
            raise ValueError("Contained browser acceptance requires an external server with enabled JWT authentication")
        from mozaiksai.hosts import platform as profile_host

    gained = sorted(set(os.environ) - initial_environment)
    if gained:
        run.record(
            "smoke.environment", False,
            f"Loading the Mozaiks runtime added environment variables {gained} to the smoke process (a .env "
            "file was read), so generated code was not run: it must never see host configuration.",
        )
        return False
    run.step("boot.app_load")
    try:
        load = await asyncio.wait_for(AppLoader.load(str(run.app_root)), timeout=_STEP_TIMEOUT_SECONDS)
    except Exception as exc:
        message = str(exc).replace(str(run.app_root), "app")
        run.record("boot.app_load", False, f"AppLoader.load() failed, so the app cannot start: {message}")
        return False
    run.load = load
    run.app_id = _app_id(load)
    if load.failed_module_names:
        for name in sorted(load.failed_module_names):
            error = (load.module_load_errors.get(name) or "module failed to load").replace(str(run.app_root), "app")
            run.record(
                "boot.app_load", False,
                f"Module {name!r} failed to load at startup; every call to it returns 503: {error}",
                path=f"modules/{name}/module.yaml",
            )
    else:
        run.record("boot.app_load", True, f"AppLoader loaded {len(load.modules)} module(s).")

    contract = load.data_contract
    from mozaiksai.core.runtime.persistence.intent_loader import iter_data_contract_collections

    run.workspace_claims = any(
        collection.get("tenancy") == "per_workspace"
        for _owner, _kind, collection in iter_data_contract_collections(contract, require_complete_ownership=False)
    )

    def persistence() -> Any:
        return MongoPersistenceContext(app_id=run.app_id, database_name=run.database_name, client=run.client)

    if contract:
        run.step("boot.indexes")
        try:
            result = await asyncio.wait_for(
                apply_database_indexes(contract, app_id=run.app_id, persistence=persistence()),
                timeout=_STEP_TIMEOUT_SECONDS,
            )
            run.record("boot.indexes", True, f"{result.verified} declared index(es) created and verified.")
        except Exception as exc:
            run.record(
                "boot.indexes", False,
                f"Declared database indexes could not be applied, so the platform host refuses to start "
                f"with persistence enabled: {exc}",
                path="data/contract.json",
            )
    run.step("boot.migrations")
    try:
        migrations = load_data_migrations(run.app_root)
        if migrations:
            count = await asyncio.wait_for(
                apply_data_migrations(
                    app_id=run.app_id, migrations=migrations, persistence=persistence(),
                    history_client=run.client, history_database=run.database_name,
                ),
                timeout=_STEP_TIMEOUT_SECONDS,
            )
            run.record("boot.migrations", True, f"{count} data migration(s) applied.")
    except Exception as exc:
        run.record(
            "boot.migrations", False,
            f"Data migrations could not be applied at startup: {exc}",
            path="data/migrations/*.json",
        )

    class _RecordingAuditLogger(AuditLogger):
        def __init__(self) -> None:
            super().__init__()
            self.records: list[AuditRecord] = []

        async def log(self, record: AuditRecord) -> None:
            self.records.append(record)

    def alias_collection(alias: str) -> Any:
        return run.database[_alias_collection_name(alias, contract)]

    class _ObservedModuleExecutor(ModuleExecutor):
        """Keeps the events each dispatch rejected; the HTTP response carries only the action's data."""

        async def execute(self, request: Any, context: Any = None) -> Any:
            result = await super().execute(request, context)
            run.rejected_events.extend((request.module, request.action, item) for item in result.rejected_events)
            return result

    hooks = PlatformHookRegistry()
    if run.reference_host_authority:
        from mozaiksai.core.runtime.composition.module_role_scope import app_role_scope_resolver

        from .requirement_delivery import reference_behavior_owner

        hooks.register_bundle({"module_scope_resolver": app_role_scope_resolver(
            app_id=run.app_id, role_permissions=reference_behavior_owner(
                {"spec": {"id": run.reference_host_authority}}).reference_role_permissions(),
        )}, source="installed-reference-test-host")
    executor = _ObservedModuleExecutor(
        event_emitter=run.record_event,
        entitlement_checker=(
            ConfiguredEntitlementAdapter(config=load.subscriptions_config, collection_resolver=alias_collection)
            if load.subscriptions_config is not None else None
        ),
        data_contract=contract,
        platform_hooks=hooks,
        audit_logger=_RecordingAuditLogger(),
        persistence_database=run.database_name,
        persistence_client=run.client,
    )
    for loaded_module in load.modules:
        executor.register_loaded_module(loaded_module)
    registry = ExecutorRegistry()
    registry.register(executor)

    app = FastAPI()
    if run.browser_probe:
        from starlette.middleware.cors import CORSMiddleware

        app.add_middleware(CORSMiddleware, allow_origins=["http://127.0.0.1:4174"],
                           allow_methods=["GET", "POST", "OPTIONS"],
                           allow_headers=["Authorization", "Content-Type"])
    app.state.loaded_app_id = run.app_id
    app.state.executor_registry = registry
    app.state.module_action_surfaces = {module.name: module.action_api_surface_map for module in load.modules}
    app.state.failed_module_names = sorted(load.failed_module_names)
    app.state.data_contract = contract
    app.include_router(module_router.router)
    auth_yaml = run.app_root / "config" / "auth.yaml"
    run.scopes = sorted(auth_contract_scopes(
        {"config/auth.yaml": auth_yaml.read_text(encoding="utf-8")} if auth_yaml.is_file() else {}
    ))

    async def resolve_principal(request: Request) -> UserPrincipal | None:
        principal: _Principal | None
        if run.external_server:
            encoded = request.headers.get("x-mozaiks-smoke-principal") or ""
            if not encoded or len(encoded) > 4096:
                return None
            try:
                data = json.loads(base64.urlsafe_b64decode(encoded).decode("utf-8"))
                if (not isinstance(data, dict) or data.get("nonce") != run.probe_nonce
                        or not isinstance(data.get("user_id"), str)
                        or not isinstance(data.get("label"), str)
                        or not isinstance(data.get("extra_scopes"), list)
                        or not all(isinstance(scope, str) for scope in data["extra_scopes"])
                        or not isinstance(data.get("roles"), list)
                        or not all(isinstance(role, str) for role in data["roles"])
                        or data.get("workspace_id") is not None
                        and not isinstance(data["workspace_id"], str)):
                    return None
                principal = _Principal(data["label"], data["user_id"], "",
                                       data.get("workspace_id"), tuple(data["extra_scopes"]), tuple(data["roles"]))
            except (ValueError, UnicodeError):
                return None
        else:
            header = request.headers.get("authorization") or ""
            token = header[7:].strip() if header.lower().startswith("bearer ") else ""
            principal = next((item for item in run.principals.values() if item.token == token), None)
        if principal is None:
            return None
        return UserPrincipal(
            user_id=principal.user_id, email=None, name=principal.label, roles=list(principal.roles),
            scopes=list(principal.extra_scopes),
            raw_claims={"sub": principal.user_id, "app_id": run.app_id}, provider="runtime_smoke",
            app_id=run.app_id, workspace_id=principal.workspace_id, auth_provenance="token_validated",
        )

    def authenticated_persistence_principal(principal: UserPrincipal | None) -> PersistencePrincipal | None:
        if principal is None:
            return None
        return PersistencePrincipal(user_id=principal.user_id, workspace_id=principal.workspace_id)

    environment = module_router.ModuleDispatchEnvironment(
        authentication_enabled=True,
        platform_hooks=hooks,
        record_invocation=lambda **_: None,
        persistence_principal=authenticated_persistence_principal,
    )
    if not run.browser_probe:
        app.dependency_overrides[optional_user] = resolve_principal
    app.dependency_overrides[module_router.module_dispatch_environment] = lambda: environment
    if run.browser_probe:
        # Reuse the real profile endpoint and its require_any_auth dependency,
        # without serving the platform app or entering its unrelated lifespan.
        # PersistenceManager explicitly preserves a caller-supplied client.
        manager = profile_host.persistence_manager.persistence
        run.profile_persistence_binding = manager, manager.client
        manager.client = run.client
        app.add_api_route("/api/me", profile_host.get_current_user_profile, methods=["GET"])
        from mozaiksai.hosts.routers.notifications import router as notifications_router

        app.include_router(notifications_router)
        if run.reference_host_authority == "paired-projects-tasks-reference":
            await _mount_paired_browser_interfaces(run, app, registry, hooks)
    if run.external_server:
        # Match the platform's canonical shell/page composition without its
        # process lifespan. This exposes declaratives, not a browser or identity.
        app.state.page_schemas = {
            name: schema.model_dump(mode="json", exclude_none=True)
            for name, schema in sorted(load.page_schemas.items())
        }
        app.state.module_ask_context_actions = {
            module.name: module.action_ask_context_map for module in load.modules
        }
        app.include_router(shell_router)

        @app.get("/__mozaiks_smoke_ready")
        async def smoke_ready() -> dict[str, Any]:
            return {
                "app_id": run.app_id,
                "modules": sorted(module.name for module in load.modules),
                "failed_modules": sorted(load.failed_module_names),
            }

    declared_routers = _declared_extensions(load.modules, "api_router")
    if declared_routers:
        since = len(run.capture.records)
        mounted = mount_module_routers(app, load.modules)
        if mounted < len(declared_routers):
            failures = [record.getMessage() for record in run.capture.records[since:]
                        if "MODULE_EXTENSIONS" in record.getMessage()]
            run.record(
                "boot.runtime_extensions", False,
                f"{len(declared_routers) - mounted} of {len(declared_routers)} declared api_router "
                f"extension(s) did not mount: {'; '.join(failures) or 'no router returned'}",
                path=f"modules/{declared_routers[0][0]}/runtime_extensions.yaml",
            )
        else:
            run.record("boot.runtime_extensions", True, f"{mounted} api_router extension(s) mounted.")
    declared_services = _declared_extensions(load.modules, "startup_service")
    if declared_services:
        modules = sorted({name for name, _ in declared_services})
        run.not_run(
            "boot.startup_services",
            f"{len(declared_services)} startup_service extension(s) declared by {modules} are not started. They "
            "run outside module dispatch with their own clients, so the smoke cannot keep them inside its "
            "disposable database; only the deployed app starts them.",
        )

    run.app = app
    run.http = AsyncClient(transport=ASGITransport(app=app), base_url="http://runtime-smoke")
    return bool(load.modules)


# --------------------------------------------------------------------------- synthetic inputs


def _schema_type(schema: Mapping[str, Any]) -> str | None:
    kind = schema.get("type")
    if isinstance(kind, list):
        kind = next((item for item in kind if item != "null"), None)
    return kind if isinstance(kind, str) else None


def _input_schema(module: Any, action: str) -> dict[str, Any]:
    schemas = module.action_schemas_map.get(action) or {}
    schema = schemas.get("input") if isinstance(schemas, Mapping) else None
    return dict(schema) if isinstance(schema, Mapping) else {}


def _output_schema(module: Any, action: str) -> dict[str, Any]:
    schemas = module.action_schemas_map.get(action) or {}
    schema = schemas.get("output") if isinstance(schemas, Mapping) else None
    return dict(schema) if isinstance(schema, Mapping) else {}


def _properties(schema: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    properties = schema.get("properties")
    if not isinstance(properties, Mapping):
        return {}
    return {str(name): prop if isinstance(prop, Mapping) else {} for name, prop in properties.items()}


def _fields(entity: _Entity) -> dict[str, Mapping[str, Any]]:
    return {str(item.get("name")): item for item in entity.collection.get("fields") or [] if isinstance(item, Mapping)}


def _enum(prop: Mapping[str, Any], contract_field: Mapping[str, Any] | None) -> list[Any]:
    values = (contract_field or {}).get("enum") or prop.get("enum") or []
    return [item for item in values if item is not None]


def _kind(prop: Mapping[str, Any], contract_field: Mapping[str, Any] | None) -> str | None:
    kind = (contract_field or {}).get("type")
    return kind if isinstance(kind, str) else _schema_type(prop)


def _synthetic_value(name: str, prop: Mapping[str, Any], contract_field: Mapping[str, Any] | None) -> Any:
    """A valid value for one declared input: the first enum value, else one fixed value per type."""
    enum = _enum(prop, contract_field)
    if enum:
        return enum[0]
    kind = _kind(prop, contract_field)
    if kind == "datetime" or prop.get("format") == "date-time":
        return "2026-01-15T12:00:00+00:00"
    fixed: dict[str | None, Any] = {"date": "2026-01-15", "integer": 1, "number": 1, "boolean": True, "array": [], "object": {}}
    return fixed[kind] if kind in fixed else f"smoke {name}"


def _required_params(schema: Mapping[str, Any], fields: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    properties = _properties(schema)
    return {
        str(name): _synthetic_value(str(name), properties.get(str(name), {}), fields.get(str(name)))
        for name in schema.get("required") or []
    }


def _create_params_for_list_probe(
    schema: Mapping[str, Any], fields: Mapping[str, Mapping[str, Any]], *, has_list: bool,
) -> dict[str, Any]:
    """Choose a declared visible state when generic CRUD will verify default listing."""
    params = _required_params(schema, fields)
    status = _properties(schema).get("status")
    if has_list and status is not None and "active" in _enum(status, fields.get("status")):
        params["status"] = "active"
    return params


def _changed_value(current: Any, prop: Mapping[str, Any], contract_field: Mapping[str, Any] | None, label: str) -> Any:
    enum = _enum(prop, contract_field)
    if enum:
        return next((item for item in enum if item != current), None)
    kind = _kind(prop, contract_field)
    if kind == "string":
        return f"updated by {label}"
    if kind == "boolean":
        return not bool(current)
    if kind in {"integer", "number"}:
        return (current if isinstance(current, (int, float)) else 0) + 1
    return None


def _update_field(update_schema: Mapping[str, Any], entity: _Entity) -> str | None:
    """The first writable field whose change is observable: free text, then enum, boolean, number."""
    fields = _fields(entity)
    ranked: list[tuple[int, int, str]] = []
    for index, (name, prop) in enumerate(_properties(update_schema).items()):
        if name in {entity.id_field, entity.owner_field}:
            continue
        enum, kind = _enum(prop, fields.get(name)), _kind(prop, fields.get(name))
        rank = (
            0 if kind == "string" and not enum else
            1 if len(enum) > 1 else
            2 if kind == "boolean" else
            3 if kind in {"integer", "number"} else None
        )
        if rank is not None:
            ranked.append((rank, index, name))
    return min(ranked)[2] if ranked else None


# --------------------------------------------------------------------------- contract derivations


def _contract_entities(run: _SmokeRun) -> list[_Entity]:
    from mozaiksai.core.runtime.persistence.intent_loader import iter_data_contract_collections
    from mozaiksai.core.workflow.generator_support.data_contract_fields import record_id_field
    from mozaiksai.core.workflow.generator_support.module_action_inventory import (
        canonical_read_action_id,
        canonical_write_action_id,
    )

    modules = {module.name: module for module in run.load.modules}
    entities: list[_Entity] = []
    for owner, kind, collection in iter_data_contract_collections(run.load.data_contract, require_complete_ownership=False):
        module = modules.get(owner)
        if kind != "module" or module is None:
            continue
        entity_name = str(collection.get("entity") or "")
        try:
            candidates = {op: canonical_write_action_id(entity_name, op) for op in ("create", "update", "delete")}
            candidates.update({op: canonical_read_action_id(str(collection.get("name") or ""), op) for op in ("list", "get")})
        except ValueError:
            continue
        actions = {op: action for op, action in candidates.items() if action in module.action_method_map}
        if "create" not in actions:
            continue
        names = [str(item.get("name")) for item in collection.get("fields") or [] if isinstance(item, Mapping)]
        entities.append(_Entity(
            module=owner, collection=dict(collection), entity=entity_name,
            id_field=record_id_field(collection, names), owner_field=collection.get("owner_field"),
            tenancy=str(collection.get("tenancy") or ""), actions=actions,
        ))
    return entities


@dataclass(frozen=True)
class _PlanStore:
    store: Any
    plans: list[Any]
    default_plan_id: str | None


def _plan_stores(config: Any) -> list[_PlanStore]:
    if config is None:
        return []
    if config.products:
        return [_PlanStore(product.assignment_store, list(product.plans), product.default_plan_id) for product in config.products]
    return [_PlanStore(config.assignment_store, list(config.plans), config.default_plan_id)]


def _default_capabilities(config: Any) -> frozenset[str]:
    granted: set[str] = set()
    for item in _plan_stores(config):
        for plan in item.plans:
            if plan.plan_id == item.default_plan_id:
                granted.update(plan.capabilities or [])
    return frozenset(granted)


def _granting_plan(config: Any, capabilities: set[str]) -> tuple[_PlanStore, Any] | None:
    """The first declared plan granting every capability, else the one granting the most."""
    best: tuple[int, _PlanStore, Any] | None = None
    for item in _plan_stores(config):
        for plan in item.plans:
            covered = len(capabilities & set(plan.capabilities or []))
            if covered and (best is None or covered > best[0]):
                best = (covered, item, plan)
    return (best[1], best[2]) if best else None


def _assignment_store_defect(run: _SmokeRun, item: _PlanStore, plan: Any) -> tuple[str, str] | None:
    """Why no user can be granted ``plan`` through the declared assignment store, if anything."""
    store = item.store
    if store is None:
        return (
            f"Plan {plan.plan_id!r} grants capabilities but config/subscriptions.yaml declares no assignment_store, "
            "so no user can ever hold it.",
            "config/subscriptions.yaml",
        )
    if not store.user_id_field:
        return (
            f"assignment_store keys subscriptions by {store.app_id_field!r}/{store.tenant_id_field!r} without a "
            "user_id_field, so one assignment entitles every user of the app; per-user plans cannot be granted.",
            "config/subscriptions.yaml",
        )
    if not [status for status in store.active_statuses or [] if status]:
        return (
            "assignment_store.active_statuses is empty, so no assignment can ever grant a capability.",
            "config/subscriptions.yaml",
        )
    try:
        _alias_collection_name(store.data_alias, run.load.data_contract)
    except KeyError as exc:
        return (
            f"config/subscriptions.yaml assignment_store.data_alias {store.data_alias!r} is not declared in "
            f"data/contract.json aliases, so the entitlement adapter cannot read any assignment and every paid "
            f"capability is denied ({exc.args[0] if exc.args else exc}).",
            "data/contract.json",
        )
    return None


def _assignment_collection(contract: dict[str, Any] | None, alias: str) -> Mapping[str, Any] | None:
    """Find the declared collection behind an assignment alias, including alias-only mappings."""
    from mozaiksai.core.runtime.persistence.intent_loader import iter_data_contract_collections

    name = _alias_collection_name(alias, contract)
    collections = [
        collection
        for _owner, _kind, collection in iter_data_contract_collections(contract, require_complete_ownership=False)
        if str(collection.get("mongo_collection") or collection.get("collection") or collection.get("name") or "") == name
    ]
    if not collections:
        return None
    return next((collection for collection in collections if collection.get("data_alias") == alias), collections[0])


def _unique_assignment_value(name: str, field: Mapping[str, Any]) -> Any:
    """Use a fresh value for an otherwise absent key in a declared unique index."""
    kind = _kind({}, field)
    if kind in {None, "string"}:
        if _enum({}, field):
            raise ValueError(f"Cannot seed a distinct value for enumerated unique assignment field {name!r}")
        return f"smoke-{name}-{uuid4().hex}"
    if kind in {"integer", "number"}:
        return uuid4().int % (1 << 53)
    if kind == "datetime":
        return datetime.now(UTC).isoformat()
    raise ValueError(f"Cannot seed a distinct value for unique assignment field {name!r} of type {kind!r}")


def _required_assignment_value(name: str, field: Mapping[str, Any], store: Any, plan: Any) -> Any:
    from mozaiksai.core.workflow.generator_support.data_contract_fields import parse_default

    if name == store.capabilities_field:
        return list(plan.capabilities or [])
    if name == store.plan_snapshot_field:
        return {"granted_capabilities": list(plan.capabilities or [])}
    if name == "plan_name" and field.get("type") == "string":
        return plan.label
    if name in {"created_at", "updated_at"} and field.get("type") in {"string", "datetime"}:
        return datetime.now(UTC).isoformat()
    has_default, value = parse_default(field, f"assignment_store field {name!r}")
    if has_default:
        return value
    raise ValueError(f"required assignment_store field {name!r} has no declared default or known fixture value")


async def _seed_assignment(run: _SmokeRun, principal: _Principal, item: _PlanStore, plan: Any) -> bool:
    """Write one active assignment through the declared assignment_store data alias.

    A store that cannot hold the assignment is recorded once per defect as
    ``subscriptions.assignment_store``; the calls that follow still run and
    show what a subscriber of that plan actually gets.
    """
    defect = _assignment_store_defect(run, item, plan)
    if defect is not None:
        message, path = defect
        if not any(outcome.message == message for outcome in run.outcomes):
            run.record("subscriptions.assignment_store", False, message, path=path)
        return False
    store = item.store
    record = {
        store.app_id_field: run.app_id,
        store.user_id_field: principal.user_id,
        store.plan_id_field: plan.plan_id,
        store.status_field: next(status for status in store.active_statuses if status),
    }
    if store.tenant_id_field:
        record[store.tenant_id_field] = None
    if store.workspace_id_field:
        record[store.workspace_id_field] = None
    try:
        collection = _assignment_collection(run.load.data_contract, store.data_alias)
        if collection is not None:
            fields = {
                str(entry.get("name")): entry
                for entry in collection.get("fields") or []
                if isinstance(entry, Mapping) and entry.get("name")
            }
            for index in collection.get("indexes") or []:
                if not isinstance(index, Mapping) or index.get("unique") is not True:
                    continue
                for key in index.get("keys") or []:
                    if not isinstance(key, Mapping):
                        continue
                    name = str(key.get("field") or "")
                    if name and name not in record:
                        if name not in fields:
                            raise ValueError(f"Unique assignment index field {name!r} is not declared")
                        record[name] = _unique_assignment_value(name, fields[name])
            for name, field in fields.items():
                if field.get("required") and name not in record:
                    record[name] = _required_assignment_value(name, field, store, plan)
    except ValueError as exc:
        message = f"Cannot seed assignment_store from data/contract.json: {exc}."
        if not any(outcome.message == message for outcome in run.outcomes):
            run.record("subscriptions.assignment_store", False, message, path="data/contract.json")
        return False
    await run.database[_alias_collection_name(store.data_alias, run.load.data_contract)].insert_one(record)
    return True


# --------------------------------------------------------------------------- two-user CRUD


def _owner_value(entity: _Entity, principal: _Principal) -> str | None:
    return principal.workspace_id if entity.tenancy == "per_workspace" else principal.user_id


def _declared_member(schema: Mapping[str, Any], *, kind: str, canonical: str) -> str | None:
    """The response member an output schema declares: the canonical name, else its only member of that kind."""
    if _schema_type(schema) != "object":
        return None
    candidates = [name for name, prop in _properties(schema).items() if _schema_type(prop) == kind]
    return canonical if canonical in candidates else candidates[0] if len(candidates) == 1 else None


def _response_member(body: Any, schema: Mapping[str, Any], *, kind: str, canonical: str) -> Any:
    """Read the declared response member; ambiguous custom envelopes fail closed."""
    name = _declared_member(schema, kind=kind, canonical=canonical)
    return body.get(name) if name is not None and isinstance(body, Mapping) else None


def _items(body: Any, output_schema: Mapping[str, Any]) -> list[Any] | None:
    items = _response_member(body, output_schema, kind="array", canonical="items")
    return list(items) if isinstance(items, list) else None


def _record_id(entity: _Entity, body: Any, output_schema: Mapping[str, Any]) -> Any:
    if not isinstance(body, Mapping) or _schema_type(output_schema) != "object":
        return None
    if entity.id_field in _properties(output_schema):
        return body.get(entity.id_field)
    item = _response_member(body, output_schema, kind="object", canonical="item")
    return item.get(entity.id_field) if isinstance(item, Mapping) else None


def _get_record(entity: _Entity, body: Any, output_schema: Mapping[str, Any]) -> tuple[bool, Any]:
    """Read a get response's record through the get action's declared output schema.

    Returns ``(declared, record)``. As for create, the response is the record
    when the entity's id field is a declared property (a response without that
    id holds no record); otherwise the record is the declared object member,
    ``item`` or the only object property. ``declared`` is False when the
    schema declares neither, so no response can be read as a record or as its
    absence.
    """
    if _schema_type(output_schema) == "object" and entity.id_field in _properties(output_schema):
        return True, body if isinstance(body, Mapping) and body.get(entity.id_field) is not None else None
    name = _declared_member(output_schema, kind="object", canonical="item")
    if name is None:
        return False, None
    return True, body.get(name) if isinstance(body, Mapping) else None


def _lookup_value(entity: _Entity, stored: Mapping[str, Any] | None) -> str | None:
    """Use the stored canonical get key; it need not be the generated write id."""
    value = stored.get(entity.lookup_field) if stored is not None else None
    return str(value) if value is not None else None


async def _stored(run: _SmokeRun, entity: _Entity, record_id: Any) -> dict[str, Any] | None:
    from mozaiksai.core.runtime.persistence import MongoPersistenceContext

    names = MongoPersistenceContext(
        app_id=run.app_id, database_name=run.database_name, client=run.client, data_contract=run.load.data_contract,
    )
    try:
        collection_name = names.collection_name(entity.module, str(entity.collection.get("name")))
    except Exception:
        return None
    values: list[Any] = [record_id]
    if entity.id_field == "_id":
        from bson import ObjectId

        if ObjectId.is_valid(str(record_id)):
            values.append(ObjectId(str(record_id)))
    document = await run.database[collection_name].find_one({entity.id_field: {"$in": values}})
    return dict(document) if document else None


async def _stored_fields(run: _SmokeRun, entity: _Entity) -> list[str]:
    from mozaiksai.core.runtime.persistence import MongoPersistenceContext

    names = MongoPersistenceContext(
        app_id=run.app_id, database_name=run.database_name, client=run.client, data_contract=run.load.data_contract,
    )
    try:
        collection_name = names.collection_name(entity.module, str(entity.collection.get("name")))
    except Exception:
        return []
    document = await run.database[collection_name].find_one({})
    return sorted(str(key) for key in (document or {}) if key != "_id")


async def _crud(run: _SmokeRun, entity: _Entity) -> None:
    module = next(item for item in run.load.modules if item.name == entity.module)
    actions = entity.actions
    tag = f"crud.{entity.label}"
    path_repo = f"modules/{entity.module}/backend/repo.py"
    surface = module.action_api_surface_map.get(actions["create"])
    if surface in _UNREACHABLE_SURFACES:
        run.not_run(tag, f"{actions['create']} is on the {surface} surface; signed-in users cannot call it over HTTP.")
        return
    owned = entity.tenancy in {"per_user", "per_workspace"}
    a, b = run.principal("A"), run.principal("B")
    # A and B hold the same plan, so any refusal of B is ownership, never entitlement.
    # Without config/subscriptions.yaml the host wires no entitlement adapter and
    # every gate allows, exactly as in production.
    gates = {module.action_entitlement_map.get(action) for action in actions.values()} - {None, ""}
    if gates and run.load.subscriptions_config is not None:
        choice = _granting_plan(run.load.subscriptions_config, set(gates))
        if choice is None:
            run.record(f"{tag}.plan", False, f"{entity.label} actions gate on {sorted(gates)} but no plan grants them.",
                       path="config/subscriptions.yaml")
        elif await _seed_assignment(run, a, choice[0], choice[1]) and owned:
            await _seed_assignment(run, b, choice[0], choice[1])

    def failure_path() -> str:
        return run.last_exception_path or f"modules/{entity.module}/backend/service.py"

    def describe(action: str, who: str, sent: Any = None) -> str:
        return f"{entity.module}.{action} as user {who}" + (f" with {sent}" if sent is not None else "")

    fields = _fields(entity)
    create = actions["create"]
    payload = _create_params_for_list_probe(_input_schema(module, create), fields, has_list="list" in actions)
    status, body, summary = await run.call("POST", entity.module, create, a, payload)
    record_id = _record_id(entity, body, _output_schema(module, create)) if 200 <= status < 300 else None
    stored = await _stored(run, entity, record_id) if record_id is not None else None
    no_record = f"user A's {create} produced no stored record to act on"
    if not 200 <= status < 300:
        run.record(f"{tag}.a_create", False,
                   f"{describe(create, 'A', payload)}: expected 2xx with the created record, got {summary}.",
                   path=failure_path())
    elif record_id is None:
        keys = sorted(body) if isinstance(body, Mapping) else type(body).__name__
        run.record(f"{tag}.a_create", False,
                   f"{describe(create, 'A')} returned {status} without the record id {entity.id_field!r} the data "
                   f"contract declares (response keys: {keys}).",
                   path=path_repo)
    elif stored is None:
        no_record = f"user A's {create} returned {entity.id_field}={record_id!r}, which no stored record has"
        run.record(f"{tag}.a_create", False,
                   f"{describe(create, 'A')} returned {entity.id_field}={record_id!r} but no stored {entity.label} "
                   f"record has that {entity.id_field}; the stored record fields are {await _stored_fields(run, entity)} "
                   f"where the data contract declares id field {entity.id_field!r} and owner field "
                   f"{entity.owner_field!r}. Reads, updates and deletes by the returned id can never find it.",
                   path=path_repo)
    elif owned and entity.owner_field and stored.get(entity.owner_field) != _owner_value(entity, a):
        run.record(f"{tag}.a_create", False,
                   f"The {entity.label} record user A created stores owner field {entity.owner_field!r} = "
                   f"{stored.get(entity.owner_field)!r}, expected {_owner_value(entity, a)!r} "
                   f"(stored fields: {sorted(key for key in stored if key != '_id')}).",
                   path=path_repo)
    else:
        run.record(f"{tag}.a_create", True, f"A created {entity.entity} {entity.id_field}={record_id!r}.")
    has_record = stored is not None
    lookup_value = _lookup_value(entity, stored)
    no_lookup = f"the stored record has no value for canonical get lookup {entity.lookup_field!r}"

    def listed_ids(body: Any) -> list[Any] | None:
        items = _items(body, _output_schema(module, actions["list"]))
        return None if items is None else [item.get(entity.id_field) for item in items if isinstance(item, Mapping)]

    if "list" in actions:
        status, body, summary = await run.call("GET", entity.module, actions["list"], a, {})
        listed = listed_ids(body)
        if not 200 <= status < 300 or listed is None:
            run.record(f"{tag}.a_list", False,
                       f"{describe(actions['list'], 'A')}: expected 2xx with the declared record array, got {summary}.",
                       path=failure_path())
        elif has_record and record_id not in listed:
            run.record(f"{tag}.a_list", False,
                       f"{describe(actions['list'], 'A')} did not list A's own record {record_id!r} "
                       f"(listed {entity.id_field} values: {listed[:5]}).", path=path_repo)
        else:
            run.record(f"{tag}.a_list", True,
                       f"A lists {len(listed)} record(s)" + (", including its own." if has_record else "."))
    get_schema = _output_schema(module, actions["get"]) if "get" in actions else {}
    path_manifest = f"modules/{entity.module}/module.yaml"
    undeclared_get = (
        f"{entity.module}.{actions.get('get')} declares no response record: its output schema names neither the "
        f"id field {entity.id_field!r} nor one object member such as 'item'"
    )
    if "get" in actions:
        missing_id = f"smoke-missing-{uuid4().hex[:8]}"
        status, body, summary = await run.call("GET", entity.module, actions["get"], a, {"id": missing_id})
        declared, record = _get_record(entity, body, get_schema)
        if 200 <= status < 300 and not declared:
            run.record(f"{tag}.get_missing", False,
                       f"{describe(actions['get'], 'A')} for an id that does not exist returned {status}, but "
                       f"{undeclared_get}, so the response cannot be read as not found.", path=path_manifest)
        else:
            found_nothing = status == 404 or (200 <= status < 300 and not record)
            run.record(f"{tag}.get_missing", found_nothing,
                       f"{describe(actions['get'], 'A')} for an id that does not exist: "
                       + ("not found." if found_nothing else f"expected 404, got {summary}."),
                       path=None if found_nothing else failure_path())
        if not has_record:
            run.not_run(f"{tag}.a_get", no_record)
        elif lookup_value is None:
            run.record(f"{tag}.a_get", False, no_lookup, path=path_repo)
        else:
            status, body, summary = await run.call("GET", entity.module, actions["get"], a, {"id": lookup_value})
            declared, record = _get_record(entity, body, get_schema)
            if 200 <= status < 300 and not declared:
                run.record(f"{tag}.a_get", False,
                           f"{describe(actions['get'], 'A')}(id={lookup_value!r}) returned {status}, but "
                           f"{undeclared_get}, so A's record cannot be read from it.", path=path_manifest)
            elif not 200 <= status < 300 or not isinstance(record, Mapping) or record.get(entity.id_field) != record_id:
                run.record(f"{tag}.a_get", False,
                           f"{describe(actions['get'], 'A')}(id={lookup_value!r}): expected 2xx with A's record, got {summary}.",
                           path=failure_path())
            else:
                run.record(f"{tag}.a_get", True, "A reads its own record by id.")
    if owned and "list" in actions:
        if not has_record:
            run.not_run(f"{tag}.b_list_isolated", no_record)
        else:
            status, body, summary = await run.call("GET", entity.module, actions["list"], b, {})
            listed = listed_ids(body)
            if not 200 <= status < 300 or listed is None:
                run.record(f"{tag}.b_list_isolated", False,
                           f"{describe(actions['list'], 'B')}: expected 2xx with B's declared record array, got {summary}.",
                           path=failure_path())
            elif record_id in listed:
                run.record(f"{tag}.b_list_isolated", False,
                           f"{describe(actions['list'], 'B')} returned user A's record {record_id!r}; "
                           f"{entity.tenancy} records must be visible only to their owner.", path=path_repo)
            else:
                run.record(f"{tag}.b_list_isolated", True, "B's list does not include A's record.")
    if owned and "get" in actions:
        if not has_record:
            run.not_run(f"{tag}.b_get_isolated", no_record)
        elif lookup_value is None:
            run.not_run(f"{tag}.b_get_isolated", no_lookup)
        else:
            status, body, summary = await run.call("GET", entity.module, actions["get"], b, {"id": lookup_value})
            declared, record = _get_record(entity, body, get_schema)
            if 200 <= status < 300 and not declared:
                run.record(f"{tag}.b_get_isolated", False,
                           f"{describe(actions['get'], 'B')}(id={lookup_value!r}) returned {status}, but "
                           f"{undeclared_get}, so B's isolation from A's record cannot be checked.",
                           path=path_manifest)
            elif 200 <= status < 300 and isinstance(record, Mapping) and record:
                run.record(f"{tag}.b_get_isolated", False,
                           f"{describe(actions['get'], 'B')}(id={lookup_value!r}) returned user A's record.", path=path_repo)
            elif status >= 500 or status == 0:
                run.record(f"{tag}.b_get_isolated", False,
                           f"{describe(actions['get'], 'B')}(id={lookup_value!r}): expected 404, got {summary}.",
                           path=failure_path())
            else:
                run.record(f"{tag}.b_get_isolated", True, f"B cannot read A's record ({status}).")

    update_schema = _input_schema(module, actions["update"]) if "update" in actions else {}
    update_field = _update_field(update_schema, entity) if "update" in actions else None
    update_props = _properties(update_schema)

    def update_params(current: Mapping[str, Any], who: str) -> dict[str, Any]:
        params: dict[str, Any] = {entity.id_field: record_id}
        if update_field:
            params[update_field] = _changed_value(
                current.get(update_field), update_props.get(update_field, {}), fields.get(update_field), f"user {who}",
            )
        return params

    for operation in ("update", "delete"):
        if not owned or operation not in actions:
            continue
        check = f"{tag}.b_{operation}_denied"
        if not has_record:
            run.not_run(check, no_record)
            continue
        action = actions[operation]
        before = await _stored(run, entity, record_id) or {}
        params = update_params(before, "B") if operation == "update" else {entity.id_field: record_id}
        status, _body, summary = await run.call("POST", entity.module, action, b, params)
        after = await _stored(run, entity, record_id)
        if status == 402:
            run.record(check, False,
                       f"{describe(action, 'B')} on user A's record was refused by the entitlement gate ({summary}), "
                       "although B holds the same plan as A; ownership was never exercised.", path=failure_path())
        elif status >= 500 or status == 0:
            run.record(check, False, f"{describe(action, 'B')} on user A's record: expected 403/404, got {summary}.",
                       path=failure_path())
        elif after is None if operation == "delete" else after != before:
            verb = "deleted" if operation == "delete" else "changed"
            run.record(check, False,
                       f"{describe(action, 'B')} {verb} user A's record {record_id!r} ({status}); "
                       f"{entity.tenancy} records must be writable only by their owner.",
                       path=path_repo)
        else:
            run.record(check, True, f"B's {operation} of A's record is refused ({status}); the record is unchanged.")

    if "update" in actions:
        if not has_record:
            run.not_run(f"{tag}.a_update", no_record)
        else:
            before = await _stored(run, entity, record_id) or {}
            params = update_params(before, "A")
            status, _body, summary = await run.call("POST", entity.module, actions["update"], a, params)
            after = await _stored(run, entity, record_id) or {}
            if not 200 <= status < 300:
                run.record(f"{tag}.a_update", False,
                           f"{describe(actions['update'], 'A', params)} on its own record: expected 2xx, got {summary}.",
                           path=failure_path())
            elif update_field and after.get(update_field) != params[update_field]:
                run.record(f"{tag}.a_update", False,
                           f"{describe(actions['update'], 'A', params)} returned {status} but the stored "
                           f"{update_field!r} is {after.get(update_field)!r}.", path=path_repo)
            else:
                changed = f" ({update_field})" if update_field else ""
                run.record(f"{tag}.a_update", True, f"A updated its own record{changed}.")
    if "delete" in actions:
        if not has_record:
            run.not_run(f"{tag}.a_delete", no_record)
        else:
            status, _body, summary = await run.call(
                "POST", entity.module, actions["delete"], a, {entity.id_field: record_id},
            )
            if not 200 <= status < 300:
                run.record(f"{tag}.a_delete", False,
                           f"{describe(actions['delete'], 'A')} on its own record: expected 2xx, got {summary}.",
                           path=failure_path())
            elif await _stored(run, entity, record_id) is not None:
                run.record(f"{tag}.a_delete", False,
                           f"{describe(actions['delete'], 'A')} returned {status} but record {record_id!r} is still stored.",
                           path=path_repo)
            else:
                run.record(f"{tag}.a_delete", True, "A deleted its own record.")


# --------------------------------------------------------------------------- entitlements


async def _gated_params(
    run: _SmokeRun, module: Any, action: str, principal: _Principal, entities: list[_Entity],
) -> tuple[str, dict[str, Any]]:
    """HTTP method and params for one gated call, creating the caller's own record when the action needs one."""
    for entity in entities:
        if entity.module != module.name or action not in entity.actions.values():
            continue
        operation = next(op for op, name in entity.actions.items() if name == action)
        fields = _fields(entity)
        if operation == "list":
            return "GET", {}
        if operation == "create":
            return "POST", _required_params(_input_schema(module, action), fields)
        create = entity.actions["create"]
        status, body, _summary = await run.call(
            "POST", module.name, create, principal, _required_params(_input_schema(module, create), fields),
        )
        record_id = _record_id(entity, body, _output_schema(module, create)) if 200 <= status < 300 else None
        record_id = record_id if record_id is not None else "smoke-missing-record"
        if operation == "get":
            stored = await _stored(run, entity, record_id)
            return "GET", {"id": _lookup_value(entity, stored) or "smoke-missing-record"}
        return "POST", {entity.id_field: record_id}
    return "POST", _required_params(_input_schema(module, action), {})


async def _entitlements(run: _SmokeRun, entities: list[_Entity]) -> None:
    config = run.load.subscriptions_config
    if config is None:
        return
    default_caps = _default_capabilities(config)
    seeded: dict[str, _Principal] = {}
    for module in run.load.modules:
        for action, capability in sorted(module.action_entitlement_map.items()):
            if not capability:
                continue
            tag = f"entitlement.{module.name}.{action}"
            surface = module.action_api_surface_map.get(action)
            if surface in _UNREACHABLE_SURFACES:
                run.not_run(tag, f"{action} is on the {surface} surface; signed-in users cannot call it over HTTP.")
                continue
            choice = _granting_plan(config, {capability})
            if choice is None:
                run.record(f"{tag}.granted_by_plan", False,
                           f"{module.name}.{action} gates on {capability!r} but no plan in config/subscriptions.yaml "
                           "grants it, so no subscriber can ever use this action.",
                           path="config/subscriptions.yaml")
                continue
            item, plan = choice
            if capability in default_caps:
                run.not_run(f"{tag}.default_plan_denied",
                            f"{capability!r} is granted by the default plan, so there is no unentitled user to deny.")
            else:
                principal = run.principal("default plan")
                method, params = await _gated_params(run, module, action, principal, entities)
                status, _body, summary = await run.call(method, module.name, action, principal, params)
                run.record(
                    f"{tag}.default_plan_denied", status == 402,
                    f"{module.name}.{action} as a default-plan user without {capability!r}: "
                    + ("denied with 402." if status == 402 else f"expected 402 ENTITLEMENT_REQUIRED, got {summary}."),
                    path=None if status == 402 else (
                        f"modules/{module.name}/module.yaml" if 200 <= status < 300 or status == 403
                        else run.last_exception_path or f"modules/{module.name}/backend/service.py"
                    ),
                )
            label = f"plan {plan.plan_id}"
            if label not in seeded:
                # A failed seed is recorded; the call below still runs and shows
                # what a paying user of this plan actually gets.
                seeded[label] = run.principal(label)
                await _seed_assignment(run, seeded[label], item, plan)
            principal = seeded[label]
            method, params = await _gated_params(run, module, action, principal, entities)
            status, _body, summary = await run.call(method, module.name, action, principal, params)
            allowed = status not in {0, 401, 402, 403} and status < 500
            run.record(
                f"{tag}.entitled_allowed", allowed,
                f"{module.name}.{action} as a user with an active {plan.plan_id!r} assignment granting {capability!r}: "
                + (f"allowed ({status})." if allowed else f"expected the gate to allow it, got {summary}."),
                path=None if allowed else (
                    f"modules/{module.name}/module.yaml" if status == 403
                    else "config/subscriptions.yaml" if status == 402
                    else run.last_exception_path or f"modules/{module.name}/backend/service.py"
                ),
            )


# --------------------------------------------------------------------------- entry point


def _summary(outcomes: list[dict[str, Any]], meta: Mapping[str, Any], *, started: float) -> dict[str, Any]:
    failures = [outcome for outcome in outcomes if outcome.get("status") == "failed"]
    not_run = sum(outcome.get("status") == "not_run" for outcome in outcomes)
    passed = not failures
    ran = len(outcomes) - not_run
    message = (
        f"Generated app booted and passed {ran} runtime check(s) as two signed-in users."
        if passed else
        f"{len(failures)} of {ran} runtime check(s) failed when the generated app was booted and used"
        + (f"; {not_run} more could not run." if not_run else ".")
    )
    return {
        "contract_version": SMOKE_CONTRACT_VERSION,
        "status": "passed" if passed else "failed",
        "passed": passed,
        "skipped_reason": None,
        "duration_ms": int((time.monotonic() - started) * 1000),
        "app_id": meta.get("app_id"),
        "principals": meta.get("principals") or {},
        "results": outcomes,
        "events_emitted": meta.get("events_emitted") or [],
        "checks": [{
            "id": "app_runtime_smoke",
            "passed": passed,
            "status": "passed" if passed else "failed",
            "message": message,
            "details": {
                "status": "passed" if passed else "failed",
                "check_count": ran,
                "failed_check_count": len(failures),
                "not_run_check_count": not_run,
            },
        }],
        "failed_tests": [
            {
                "test": "app_runtime_smoke",
                "check": outcome.get("check"),
                **({"path": outcome["path"]} if outcome.get("path") else {}),
                "error": outcome.get("message"),
                "fix_suggestion": _FIX_SUGGESTION,
            }
            for outcome in failures
        ],
        "warnings": [],
    }


__all__ = [
    "SMOKE_TIMEOUT_SECONDS",
    "child_environment",
    "preflight_contained_imported_smoke",
    "resolve_smoke_mongo_uri",
    "run_app_runtime_smoke",
    "run_contained_imported_app_runtime_smoke",
]


# --------------------------------------------------------------------------- child process


async def _child_run(request: Mapping[str, Any], emit: Callable[..., None], initial_environment: set[str]) -> None:
    from motor.motor_asyncio import AsyncIOMotorClient

    client: Any = AsyncIOMotorClient(str(request["mongo_uri"]), serverSelectionTimeoutMS=int(_PING_TIMEOUT_SECONDS * 1000))
    run = _SmokeRun(Path(str(request["app_root"])), client, str(request["database_name"]), emit)
    runtime_logger = logging.getLogger(_RUNTIME_LOGGER)
    runtime_logger.addHandler(run.capture)
    try:
        if await _boot(run, initial_environment):
            entities = _contract_entities(run)
            for entity in entities:
                await _crud(run, entity)
            await _entitlements(run, entities)
    except Exception as exc:  # report the gate's own failure as a check, never a silent pass
        run.record("smoke.error", False, f"The runtime smoke could not complete: {type(exc).__name__}: {exc}")
    finally:
        if run.http is not None:
            await run.http.aclose()
        runtime_logger.removeHandler(run.capture)
        client.close()
    emit(
        "done",
        app_id=run.app_id,
        principals={
            label: {"user_id": principal.user_id, "workspace_id": principal.workspace_id,
                    "scopes": list(principal.extra_scopes), "roles": list(principal.roles)}
            for label, principal in run.principals.items()
        },
        events_emitted=sorted(set(run.events)),
    )


def _child_main(request: Mapping[str, Any] | None = None) -> int:
    """Entry point of ``python -m`` this module: one smoke run, results as JSON lines on stdout."""
    initial_environment = set(os.environ)
    if request is None:
        request = json.loads(sys.stdin.read() or "{}")
    channel = os.fdopen(os.dup(sys.stdout.fileno()), "w", encoding="utf-8")
    sys.stdout = sys.stderr  # generated code's prints never reach the result channel

    def emit(kind: str, **data: Any) -> None:
        channel.write(_EVENT_PREFIX + json.dumps({"event": kind, **data}, default=str) + "\n")
        channel.flush()

    asyncio.run(_child_run(request, emit, initial_environment))
    channel.close()
    return 0


def _start_contained_frontend(*, browser_probe: bool = False) -> subprocess.Popen[bytes]:
    """Build and preview with image-owned Vite under the disposable A sandbox."""
    shell = Path(_CONTAINED_WEB_SHELL_ROOT)
    dist = Path(_CONTAINED_FRONTEND_DIST)
    for directory in (shell, shell.parent):
        if any((directory / name).exists() for name in (
            ".env", ".env.local", ".env.production", ".env.production.local",
        )):
            raise RuntimeError("Contained frontend refuses image dotenv files")
    environment = {
        "PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": "/tmp", "TMPDIR": "/tmp",
        "PLATFORM_PATH": str(_CONTAINED_APP_ROOT),
        "MOZAIKS_APP_WORKSPACE_PATH": str(_CONTAINED_APP_ROOT),
        "VITE_API_URL": "http://127.0.0.1:8000",
        "MOZAIKS_BACKEND_URL": "http://127.0.0.1:8000",
        "VITE_MOZAIKS_HOST": "platform",
        "PYTHON_DOTENV_DISABLED": "1",
    }
    if browser_probe:
        # Use the existing same-origin Vite backend proxy. An explicit empty
        # API base also keeps the optional client-console bridge off during
        # private OIDC callback handling.
        environment["VITE_API_URL"] = ""
        # Only public browser handles enter Vite. Never inherit arbitrary
        # AUTH_/OIDC variables: the issuer's signing material is not app input.
        for name in ("VITE_OIDC_AUTHORITY", "VITE_OIDC_DISCOVERY_URL", "VITE_OIDC_CLIENT_ID",
                     "VITE_OIDC_REDIRECT_URI", "VITE_OIDC_SCOPE"):
            value = os.environ.get(name, "").strip()
            if not value:
                raise ValueError(f"Contained browser acceptance requires public OIDC setting {name}")
            environment[name] = value
    vite = ["/usr/local/bin/node", "node_modules/vite/bin/vite.js"]
    built = subprocess.run(
        [*vite, "build", "--configLoader", "native", "--outDir", str(dist), "--emptyOutDir"],
        cwd=shell, env=environment, stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=45, check=False,
    )
    if built.returncode != 0 or not (dist / "index.html").is_file():
        raise RuntimeError(f"Contained fixed frontend build failed (exit {built.returncode})")
    return subprocess.Popen(
        [*vite, "preview", "--configLoader", "native", "--host", "127.0.0.1",
         "--port", "4174", "--strictPort", "--outDir", str(dist)],
        cwd=shell, env=environment, stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


async def _serve_imported_app(database_name: str, observer_nonce: str, mongo_uri: str,
                              reference_host_authority: str | None = None,
                              frontend_probe: bool = False,
                              browser_probe: bool = False) -> int:
    """A serves untrusted app behavior; its stdout is never a result channel."""
    import uvicorn
    from motor.motor_asyncio import AsyncIOMotorClient

    client: Any = AsyncIOMotorClient(mongo_uri, serverSelectionTimeoutMS=2000)
    run = _SmokeRun(Path(_CONTAINED_APP_ROOT), client, database_name, lambda *_args, **_kwargs: None,
                    browser_probe=browser_probe)
    run.external_server = True
    run.reference_host_authority = reference_host_authority
    run.probe_nonce = observer_nonce
    preview: subprocess.Popen[bytes] | None = None
    original_mongo_uri = os.environ.get("MONGO_URI")
    mongo_environment_bound = False
    try:
        if browser_probe:
            # The separate trusted issuer must own its listener before any
            # candidate module is imported. A cannot preempt that port while
            # the host-owned identity fixture is still starting.
            from httpx import AsyncClient, HTTPError

            issuer = "http://127.0.0.1:8080/realms/common-ground"
            async with AsyncClient(trust_env=False) as issuer_client:
                deadline = time.monotonic() + _BROWSER_ISSUER_STARTUP_SECONDS
                while time.monotonic() < deadline:
                    try:
                        discovery = await issuer_client.get(issuer + "/.well-known/openid-configuration", timeout=2)
                        if discovery.status_code == 200 and discovery.json().get("issuer") == issuer:
                            break
                    except (HTTPError, ValueError):
                        pass
                    await asyncio.sleep(0.5)
                else:
                    raise RuntimeError("Trusted disposable issuer must be ready before candidate import")
            # Canonical host routes use the process Mongo resolver. This is the
            # same disposable loopback server already owned by A, never host DB
            # configuration or issuer signing material.
            os.environ["MONGO_URI"] = mongo_uri
            mongo_environment_bound = True
        booted = await _boot(run, set(os.environ))
        if not booted or any(outcome.passed is False for outcome in run.outcomes):
            return 1
        await run.http.aclose()
        run.http = None
        if frontend_probe or browser_probe:
            preview = await asyncio.to_thread(_start_contained_frontend, browser_probe=browser_probe)
        server = uvicorn.Server(uvicorn.Config(run.app, host="127.0.0.1", port=8000,
                                               access_log=False, log_level="warning"))
        await server.serve()
        return 0
    finally:
        if mongo_environment_bound:
            from mozaiksai.core.core_config import close_mongo_client

            close_mongo_client()
            if original_mongo_uri is None:
                os.environ.pop("MONGO_URI", None)
            else:
                os.environ["MONGO_URI"] = original_mongo_uri
        if run.profile_persistence_binding is not None:
            manager, original_client = run.profile_persistence_binding
            manager.client = original_client
        if run.paired_host_binding is not None:
            from mozaiksai.core.runtime.composition.platform_hooks import PlatformHookRegistry
            from mozaiksai.hosts import platform, runtime

            platform.executor_registry, PlatformHookRegistry._instance, runtime.simple_transport = run.paired_host_binding
        if run.http is not None:
            await run.http.aclose()
        if preview is not None and preview.poll() is None:
            preview.terminate()
            try:
                preview.wait(timeout=5)
            except subprocess.TimeoutExpired:
                preview.kill()
                preview.wait(timeout=5)
        client.close()


def _probe_contracts(run: _SmokeRun) -> None:
    """Load only copied declarative files; B has no imported Python mount."""
    import yaml

    from mozaiksai.core.runtime.app.module_loader import ModuleDefinition
    from mozaiksai.core.runtime.app.subscriptions_loader import load_subscriptions_config
    from mozaiksai.core.runtime.persistence.intent_loader import (
        iter_data_contract_collections,
        load_data_contract,
    )
    from mozaiksai.core.workflow.generator_support.module_write_actions import auth_contract_scopes

    root = run.app_root
    modules_root = root / "modules"
    modules = []
    if modules_root.is_dir():
        for directory in sorted(modules_root.iterdir()):
            manifest = directory / "module.yaml"
            if directory.is_dir() and manifest.is_file():
                modules.append(ModuleDefinition.model_validate(yaml.safe_load(
                    manifest.read_text(encoding="utf-8"))))
    app_config = json.loads((root / "app.json").read_text(encoding="utf-8"))
    contract = load_data_contract(root)
    run.load = SimpleNamespace(
        modules=modules, data_contract=contract,
        subscriptions_config=load_subscriptions_config(root),
        definition=SimpleNamespace(config=app_config),
    )
    run.app_id = _app_id(run.load)
    auth_yaml = root / "config" / "auth.yaml"
    run.scopes = sorted(auth_contract_scopes(
        {"config/auth.yaml": auth_yaml.read_text(encoding="utf-8")} if auth_yaml.is_file() else {}
    ))
    run.workspace_claims = any(
        collection.get("tenancy") == "per_workspace"
        for _owner, _kind, collection in iter_data_contract_collections(contract, require_complete_ownership=False)
    )
    if (root / _REFERENCE_REQUEST_FILENAME).is_file():
        from .requirement_delivery import validate_reference_request

        validate_reference_request(json.loads((root / _REFERENCE_REQUEST_FILENAME).read_text(encoding="utf-8")))
        run.default_roles = ("admin",)


def _observer_prohibited_path_exists(path: Path) -> bool:
    try:
        return path.exists()
    except PermissionError:
        # Denied traversal is inaccessible, not evidence of a host mount.
        # Other filesystem failures must still stop qualification.
        return False


def _observer_browser_failure_signals(stderr: str) -> dict[str, bool]:
    """Classify fixed Chromium failures without exporting private raw logs."""
    return {name: any(marker in stderr for marker in markers) for name, markers in {
        "bus_error": ("Received signal 7", "SIGBUS", "Bus error"),
        "no_space": ("No space left on device",),
        "resource_unavailable": ("Resource temporarily unavailable",),
        "heap_exhausted": ("JavaScript heap out of memory", "Fatal process out of memory"),
        "seccomp_signal": ("SIGSYS", "Received signal 31"),
    }.items()}


def _observer_resource_diagnostics() -> dict[str, Any]:
    """Numeric observer cgroup diagnostics, never acceptance or host inventory."""
    result = {}
    for name, keys in {
        "memory.events": {"low", "high", "max", "oom", "oom_kill", "oom_group_kill"},
        "pids.events": {"max"},
        "memory.peak": None, "memory.max": None, "pids.peak": None, "pids.max": None,
    }.items():
        try:
            raw = (Path("/sys/fs/cgroup") / name).read_text(encoding="ascii")
            entries = [line.split() for line in raw.splitlines()] if keys else [["value", raw.strip()]]
            counters = {}
            for key, value in entries:
                if key not in (keys or {"value"}) or key in counters or not value.isascii() or not value.isdigit():
                    raise ValueError("Unsupported resource counter")
                counters[key] = int(value)
            if not counters:
                raise ValueError("Missing resource counter")
            result[name] = counters
        except (OSError, UnicodeError, ValueError):
            result[name] = {"available": False}
    return result


def _sample_observer_storage(peaks: dict[str, dict[str, int]]) -> None:
    # Chromium's temporary shared-memory files can be unlinked before exit.
    # Post-process disk usage misses that pressure; inspect only numeric totals.
    for path in ("/tmp", "/dev/shm"):
        total, used, free = shutil.disk_usage(path)
        prior = peaks.get(path, {"peak_used": 0, "min_free": total})
        peaks[path] = {"total": total, "peak_used": max(prior["peak_used"], used),
                       "min_free": min(prior["min_free"], free)}


def _browser_command(shell: Path, execution: dict[str, str], *, spec_filename: str) -> list[str]:
    if spec_filename not in {"generated-app.real-host.acceptance.spec.js", "paired-app.real-host.acceptance.spec.js"}:
        raise ValueError("Browser specification must be an installed finite acceptance owner")
    diagnostic = execution.get("diagnostic") == "owner_navigation"
    paired_login = execution.get("diagnostic") == "paired_login"
    if paired_login and spec_filename != "paired-app.real-host.acceptance.spec.js":
        raise ValueError("Paired login diagnostics require the existing paired specification")
    return [
        "node", str(shell / "node_modules/@playwright/test/cli.js"), "test", "-c", "playwright.generated-ui.config.js",
        "playwright/generated-ui/" + spec_filename, "--reporter=json", "--retries=0",
        "--max-failures=0" if diagnostic else "--max-failures=1", "--output=/tmp/browser-artifacts",
        *(["--project=generated-desktop", "--grep", "owner navigation diagnostic (owner-only|customer-first)$"] if diagnostic else []),
        *(["--project=generated-desktop"] if paired_login else []),
    ]


async def _seed_storefront_browser(run: _SmokeRun, validated: Any, login: dict[str, Any]) -> None:
    from .storefront_reference_cases import seed_reference_products

    collections, _products = await seed_reference_products(run, validated, prefix="browser-")
    # Only the existing unlinked dynamic-route diagnostic uses this snapshot.
    # The interaction case must still submit its own real unpaid order.
    await collections["orders"].insert_one({
        "app_id": run.app_id, "actor_id": login["actors"]["customer"]["expected_user_id"],
        "order_id": "browser-initial-order", "cart_id": "browser-fixture", "status": "submitted", "items": [],
        "subtotal_amount": 0, "total_amount": 0, "currency": validated.pack["storefront_recipe"]["currency"],
        "payment": {"status": "unpaid"}, "fulfillment": {"status": "unfulfilled"}, "inventory_reserved": False,
        "created_at": "2026-10-22T00:00:00Z", "updated_at": "2026-10-22T00:00:00Z",
    })


async def _observe_browser_cases(run: _SmokeRun, request: dict[str, Any], observer_nonce: str) -> None:
    """Run the existing pinned Playwright spec from source-free observer B."""
    import errno
    import socket

    from mozaiksai.builder.ui_acceptance import (
        _extract_json_report,
        _Profile,
        _real_host_coverage,
        _report_coverage,
        _report_tests,
        parse_playwright_json_report,
    )
    from mozaiksai.core.semantics.canonical import canonical_digest
    from mozaiksai.core.validation import AcceptanceController, ValidationGate, ValidationRegistry

    from .requirement_delivery import reference_browser_contract, validate_reference_request

    plan = Path(_CONTAINED_PLAN_ROOT)
    execution = json.loads((plan / "browser-execution.json").read_text())
    profile_path = plan / "browser-profile.json"
    profile_bytes = profile_path.read_bytes()
    profile = _Profile.model_validate_json(profile_bytes)
    shell = Path(_CONTAINED_WEB_SHELL_ROOT)
    _suite, spec_filename, _cases = reference_browser_contract(request)
    inputs = {"spec_sha256": shell / "playwright/generated-ui" / spec_filename,
              "helper_sha256": shell / "playwright/fixtures/generatedUiRealHost.js",
              "config_sha256": shell / "playwright.generated-ui.config.js"}
    if (canonical_digest(profile.model_dump(mode="json", by_alias=True, exclude_none=True)) != execution["profile_sha256"]
            and canonical_digest(json.loads(profile_bytes)) != execution["profile_sha256"]):
        raise ValueError("Browser profile differs from its admitted digest")
    if any(hashlib.sha256(path.read_bytes()).hexdigest() != execution[key] for key, path in inputs.items()):
        raise ValueError("Installed browser spec/helper/config differs from the immutable image manifest")
    if any(_observer_prohibited_path_exists(Path(path)) for path in (
        "/var/run/docker.sock", "/host", "/root/.ssh/id_rsa", "/root/.aws/credentials",
    )):
        raise ValueError("Observer has prohibited host access")
    if any(Path(_CONTAINED_APP_ROOT).iterdir()):
        raise ValueError("Observer has access to candidate executable source")
    if any(os.environ.get(key) for key in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "AWS_SECRET_ACCESS_KEY", "GH_TOKEN", "GITHUB_TOKEN")):
        raise ValueError("Observer inherited a prohibited credential")
    try:
        with socket.create_connection(("1.1.1.1", 443), timeout=1):
            raise ValueError("Observer unexpectedly has external egress")
    except OSError as exc:
        if exc.errno != errno.ENETUNREACH:
            raise ValueError("Observer external route absence was not established") from None
    try:
        with (plan / "candidate-evidence-forgery.json").open("x"):
            pass
    except OSError as exc:
        if exc.errno not in {errno.EROFS, errno.EACCES}:
            raise
    else:
        raise ValueError("Observer plan/evidence binding is unexpectedly writable")
    run.record("browser.containment", True, "Source/credential/egress checks and read-only observer plan passed.")
    login = json.loads((plan / "browser-login.json").read_text())
    validated = validate_reference_request(request)
    if "presentation" not in request:
        await _seed_storefront_browser(run, validated, login)
    run_id = str(UUID(observer_nonce))
    environment = {"PATH": os.environ["PATH"], "HOME": "/tmp", "CI": "1", "DEBUG": "pw:browser",
                   "PLAYWRIGHT_BROWSERS_PATH": "/opt/mozaiks/playwright-browsers",
                   "MOZAIKS_GENERATED_UI_MODE": "real_host", "MOZAIKS_GENERATED_UI_BASE_URL": "http://127.0.0.1:4174",
                   "MOZAIKS_GENERATED_UI_SPEC": "playwright/generated-ui/" + spec_filename,
                   "MOZAIKS_GENERATED_UI_PROFILE": str(profile_path),
                   "MOZAIKS_GENERATED_UI_PROFILE_SHA256": hashlib.sha256(profile_bytes).hexdigest(),
                   "MOZAIKS_GENERATED_UI_RUN_ID": run_id,
                   "MOZAIKS_GENERATED_UI_LOGIN_FIXTURE": str(plan / "browser-login.json")}
    if execution.get("diagnostic") == "owner_navigation":
        environment["MOZAIKS_GENERATED_UI_OWNER_NAVIGATION_DIAGNOSTIC"] = "1"
    if execution.get("clock_diagnostic") == "evaluated_auth_operands":
        environment["MOZAIKS_GENERATED_UI_LOGIN_CLOCK_DIAGNOSTIC"] = "1"
    pending = asyncio.create_task(asyncio.to_thread(
        subprocess.run, _browser_command(shell, execution, spec_filename=spec_filename), cwd=str(shell), env=environment,
        text=True, capture_output=True, timeout=660, check=False))
    storage_peaks: dict[str, dict[str, int]] = {}
    while not pending.done():
        _sample_observer_storage(storage_peaks)
        await asyncio.wait({pending}, timeout=0.05)
    completed = await pending
    report = _extract_json_report(completed.stdout)
    coverage, findings = _report_coverage(report)
    if not any(issue.code == "report_integrity" for issue in findings):
        findings.extend(parse_playwright_json_report(report))
        _, linked_findings = _real_host_coverage(report, profile, run_id)
        findings.extend(linked_findings)
        if any(len(test["results"]) != 1 or test["results"][0].get("retry", 0) != 0
               for _, test in _report_tests(report)):
            raise ValueError("Retried browser observations cannot be accepted")
    registry = ValidationRegistry()
    registry.register(ValidationGate(gate_id="generated_ui_browser", description="Contained reference interactions",
                                     handler=lambda _context: findings))
    accepted = AcceptanceController(registry).run(context={}, max_attempts=0)
    # No login state or token is serialized. This is the existing observer event
    # channel; A cannot write B's report, spec, plan, stdout or launch attestation.
    run.record("requirement.browser", not execution.get("diagnostic") and completed.returncode == 0 and accepted.accepted,
               "Reviewed desktop/mobile interactions completed." if accepted.accepted else "Browser interactions did not satisfy the reviewed contract.",
               request_digest=canonical_digest(request), source_content_sha256=request["source_content_sha256"],
               image_id=os.environ["MOZAIKS_OBSERVER_IMAGE_ID"], observer_run_id=observer_nonce, run_id=run_id,
               browser_execution=execution, profile=json.loads(profile_bytes), report=report,
               playwright_version=json.loads((shell / "node_modules/playwright-core/package.json").read_text())["version"],
               exit_code=completed.returncode, coverage=coverage,
               observer_resources=_observer_resource_diagnostics(),
               observer_storage_peaks=storage_peaks,
               observer_tmp=dict(zip(("total", "used", "free"), shutil.disk_usage("/tmp"), strict=True)),
               browser_failure_signals=_observer_browser_failure_signals(completed.stderr),
               actors={kind: {"username": actor["username"], "user_id": actor["expected_user_id"]}
                       for kind, actor in login["actors"].items()})


async def _probe_imported_app(database_name: str, observer_nonce: str,
                              emit: Callable[..., None], frontend_probe: bool = False,
                              browser_probe: bool = False) -> None:
    """B checks loopback HTTP and Mongo from a process without imported source."""
    from httpx import AsyncClient, HTTPError
    from motor.motor_asyncio import AsyncIOMotorClient

    mongo_uri = "mongodb://127.0.0.1:27017/?directConnection=true"
    client: Any = AsyncIOMotorClient(mongo_uri, serverSelectionTimeoutMS=2000)
    run = _SmokeRun(Path(_CONTAINED_PLAN_ROOT), client, database_name, emit)
    run.external_probe = True
    run.probe_nonce = observer_nonce
    run.http = AsyncClient(base_url="http://127.0.0.1:8000", timeout=_REQUEST_TIMEOUT_SECONDS,
                           trust_env=False)
    try:
        _probe_contracts(run)
        expected_modules = sorted(module.name for module in run.load.modules)
        if browser_probe:
            # A must wait for this trusted issuer before importing the app.
            # Start B's app budget only after the same prerequisite, not while
            # the independent issuer stage is still consuming its own budget.
            login = json.loads((run.app_root / "browser-login.json").read_text())
            identity_deadline = time.monotonic() + _BROWSER_ISSUER_STARTUP_SECONDS
            while time.monotonic() < identity_deadline:
                try:
                    response = await run.http.get(login["issuer"] + "/.well-known/openid-configuration", timeout=2)
                    if response.status_code == 200 and response.json().get("issuer") == login["issuer"]:
                        break
                except (HTTPError, OSError, TimeoutError, ValueError):
                    pass
                await asyncio.sleep(0.5)
            else:
                raise ValueError("Disposable local issuer did not become ready at its finalized address")
        deadline = time.monotonic() + (120 if browser_probe else _CONTAINER_STARTUP_SECONDS)
        response: Any = None
        while time.monotonic() < deadline:
            try:
                response = await run.http.get("/__mozaiks_smoke_ready", timeout=1.0)
                if response.status_code == 200:
                    break
            except (HTTPError, OSError, TimeoutError):
                pass
            await asyncio.sleep(0.2)
        try:
            observed = response.json() if response is not None and response.status_code == 200 else {}
        except ValueError:
            observed = {}
        ready = (isinstance(observed, dict) and bool(expected_modules)
                 and observed.get("app_id") == run.app_id
                 and observed.get("modules") == expected_modules
                 and observed.get("failed_modules") == [])
        run.record("boot.http_ready", ready,
                   f"Loopback app endpoint {'reported the expected app and modules' if ready else 'did not report the expected app and modules'}.")
        if ready:
            if frontend_probe:
                try:
                    shell_response = await run.http.get("/api/shell-config", timeout=5.0)
                    shell_config = shell_response.json() if shell_response.status_code == 200 else {}
                    shell_ready = (isinstance(shell_config, dict) and shell_config.get("appId") == run.app_id
                                   and shell_config.get("appName") ==
                                   str(run.load.definition.config.get("appName") or "Mozaiks")
                                   and shell_config.get("auth", {}).get("runtime", {}).get("user") is None)
                except (HTTPError, OSError, TimeoutError, ValueError):
                    shell_ready = False
                run.record("boot.shell_ready", shell_ready,
                           "Canonical shell served the declared app without issuing an identity."
                           if shell_ready else "Canonical shell was unavailable or differed from app identity.")
                frontend_ready = False
                frontend_status: int | None = None
                expected_name = str(run.load.definition.config.get("appName") or "Mozaiks")
                frontend_deadline = time.monotonic() + 5.0
                while time.monotonic() < frontend_deadline:
                    try:
                        frontend = await run.http.get("http://127.0.0.1:4174/", timeout=1.0)
                        frontend_status = frontend.status_code
                        frontend_ready = (frontend.status_code == 200 and '<div id="root"' in frontend.text
                                          and expected_name in frontend.text)
                        if frontend_ready or frontend.status_code == 200:
                            break
                    except (HTTPError, OSError, TimeoutError):
                        pass
                    await asyncio.sleep(0.2)
                run.record("boot.frontend_ready", frontend_ready,
                           "Built frontend served the declared app over isolated loopback."
                           if frontend_ready else f"Fixed contained frontend was not ready (HTTP {frontend_status}).")
            await client.admin.command("ping")
            if browser_probe:
                request = json.loads((run.app_root / _REFERENCE_REQUEST_FILENAME).read_text())
                await _observe_browser_cases(run, request, observer_nonce)
            else:
                entities = _contract_entities(run)
                for entity in entities:
                    await _crud(run, entity)
                await _entitlements(run, entities)
                reference_path = run.app_root / _REFERENCE_REQUEST_FILENAME
                if reference_path.is_file():
                    from .requirement_delivery import reference_behavior_owner

                    with reference_path.open("rb") as stream:
                        data = stream.read(_MAX_REFERENCE_REQUEST_BYTES + 1)
                    if len(data) > _MAX_REFERENCE_REQUEST_BYTES:
                        raise ValueError("Reference behavior descriptor exceeds its bounded limit")
                    request = json.loads(data)
                    owner = reference_behavior_owner(request)
                    if "presentation" in request:
                        owner.validate_reference_request(request)
                        run.record("requirement.browser", False, "Paired requirements need the complete contained browser journey.")
                    else:
                        await owner.execute_reference_cases(run, request)
    except Exception as exc:
        run.record("smoke.error", False,
                   f"The external observer could not complete: {type(exc).__name__}: {exc}")
    finally:
        await run.http.aclose()
        client.close()
    emit(
        "done", app_id=run.app_id,
        principals={
            label: {"user_id": principal.user_id, "workspace_id": principal.workspace_id,
                    "scopes": list(principal.extra_scopes), "roles": list(principal.roles)}
            for label, principal in run.principals.items()
        },
        events_emitted=[],
    )


def _trusted_probe_main(database_name: str, observer_nonce: str, frontend_probe: bool = False,
                        browser_probe: bool = False) -> int:
    def emit(kind: str, **data: Any) -> None:
        print(_EVENT_PREFIX + json.dumps(
            {"event": kind, "observer_nonce": observer_nonce, **data}, default=str,
        ), flush=True)

    asyncio.run(_probe_imported_app(database_name, observer_nonce, emit, frontend_probe, browser_probe))
    return 0


def _contained_main(database_name: str, observer_nonce: str,
                    reference_host_authority: str | None = None,
                    frontend_probe: bool = False,
                    browser_probe: bool = False) -> int:
    """Start disposable MongoDB and the imported app server on isolated loopback."""
    from pymongo import MongoClient

    database_dir = Path(tempfile.mkdtemp(prefix="mozaiks-smoke-mongo-", dir="/tmp"))
    mongod = subprocess.Popen(
        ["mongod", "--dbpath", str(database_dir), "--bind_ip", "127.0.0.1", "--port", "27017",
         "--nounixsocket", "--quiet"],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    mongo_uri = "mongodb://127.0.0.1:27017/?directConnection=true"
    client: MongoClient[dict[str, Any]] = MongoClient(
        mongo_uri, serverSelectionTimeoutMS=500, connectTimeoutMS=500,
    )
    try:
        deadline = time.monotonic() + _CONTAINER_STARTUP_SECONDS
        while time.monotonic() < deadline and mongod.poll() is None:
            try:
                client.admin.command("ping")
                break
            except Exception:
                time.sleep(0.2)
        else:
            print("Contained smoke MongoDB did not start", file=sys.stderr)
            return 1
        return asyncio.run(_serve_imported_app(database_name, observer_nonce, mongo_uri,
                                              reference_host_authority, frontend_probe, browser_probe))
    finally:
        client.close()
        if mongod.poll() is None:
            mongod.terminate()
            try:
                mongod.wait(timeout=5)
            except subprocess.TimeoutExpired:
                mongod.kill()
                mongod.wait(timeout=5)


if __name__ == "__main__":
    if len(sys.argv) in {4, 5, 6, 7} and sys.argv[1] == "--contained-serve":
        flags = sys.argv[4:]
        authority_flags = {"--reference-host-authority=storefront-reference-backend",
                           "--reference-host-authority=paired-projects-tasks-reference"}
        selected = set(flags) & authority_flags
        if (len(flags) != len(set(flags)) or len(selected) > 1
                or set(flags) - (authority_flags | {"--frontend-probe", "--browser-probe"})):
            raise SystemExit(2)
        raise SystemExit(_contained_main(sys.argv[2], sys.argv[3],
                                         next(iter(selected)).split("=", 1)[1] if selected else None,
                                         "--frontend-probe" in flags,
                                         "--browser-probe" in flags))
    if len(sys.argv) in {4, 5, 6} and sys.argv[1] == "--trusted-probe":
        flags = sys.argv[4:]
        if len(flags) != len(set(flags)) or set(flags) - {"--frontend-probe", "--browser-probe"}:
            raise SystemExit(2)
        raise SystemExit(_trusted_probe_main(sys.argv[2], sys.argv[3], "--frontend-probe" in flags,
                                            "--browser-probe" in flags))
    raise SystemExit(_child_main())
