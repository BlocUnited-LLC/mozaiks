"""Image-owned backend acceptance cases for the reviewed storefront reference.

This is Factory validation code, not reusable app implementation or a test DSL.
The observer imports this installed module only; never candidate Python or case
paths. Statements without installed verification cases and all UI behavior
remain explicitly unverified; every approved statement stays in product scope.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from mozaiksai.builder.requirements import RequirementInventory
from mozaiksai.builder.storefront import StorefrontRecipe
from mozaiksai.core.semantics.canonical import canonical_digest

STATEMENTS = {
    "storefront": "Browse the reusable storefront catalog, cart and unpaid orders.",
    "compatibility": "Configure a camping kit with a compatible stove and fuel, optionally adding a supported pot; reject incompatible SKUs.",
    "quote": "Get an itemized server-priced kit quote from current active catalog products without reserving stock, collecting payment or adding a bundle to cart.",
}
CASE_IDS = {name: f"storefront-reference.{name}.backend.v1" for name in STATEMENTS}
IDENTITY_SCOPES = frozenset({"openid", "profile", "email"})
CUSTOMER_PERSONA = {
    "id": "synthetic_authorized_customer",
    "roles": ["customer"],
    "claim": "test_host_role_only_not_production_issuer_login_or_browser_acceptance",
}
_PREFIX = "modules/bundle_selection/"
_PAGE = "ui/pages/custom/build_kit.jsx"
_PACK_KEYS = ("pack_id", "version", "digest", "authority", "storefront_recipe", "recipe_digest")


def reference_role_permissions() -> dict[str, set[str]]:
    """Installed pack permission intent, with identity roles assigned by the test host."""
    import yaml

    from mozaiksai.builder.resources import resolve_packaged_build_context

    root = resolve_packaged_build_context("commerce")
    if root is None:
        raise ValueError("The installed commerce contract is unavailable")
    contract = yaml.safe_load((root / "contract.yaml").read_text(encoding="utf-8"))
    module = yaml.safe_load((root / "templates/modules/commerce/module.yaml").read_text(encoding="utf-8"))
    declared = {entry["id"] for entry in module["permissions"]}
    result = {entry["role"]: set(entry["permissions"]) for entry in contract["role_permission_intent"]}
    if (set(result) != {"customer", "admin"} or len(result) != len(contract["role_permission_intent"])
            or not all(values <= declared for values in result.values())
            or not result["customer"] < result["admin"]):
        raise ValueError("The installed commerce role intent does not match its declared permissions")
    return result


def spec_identity() -> dict[str, str]:
    return {"id": "storefront-reference-backend", "version": "1",
            "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


class ReferenceBehaviorRequest(BaseModel):
    """Unsupported IDs lack installed verification coverage, never product scope."""

    model_config = ConfigDict(extra="forbid", strict=True)

    schema_version: Literal["mozaiks.reference_behavior_request.v1"]
    inventory: RequirementInventory
    accounting: dict[str, Any]
    tasks: list[dict[str, Any]]
    pack: dict[str, Any]
    spec: dict[str, str]
    persona: dict[str, Any]
    source_content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    cases: dict[str, str]
    unsupported_requirement_ids: list[str]


def _reference_pack_entry(recipe: dict[str, Any]) -> dict[str, Any]:
    from .resolve_managed_capability_templates import verified_pack_template_inventory

    normalized = StorefrontRecipe.model_validate(recipe).model_dump(mode="json")
    selected = {"id": "commerce", "capability_source": "generated_module", "storefront_recipe": normalized}
    entries = verified_pack_template_inventory(context_variables={"capability_packs": [selected]})
    if len(entries) != 1 or entries[0]["authority"] != "packaged_build_context":
        raise ValueError("Reference cases require the canonical installed commerce pack")
    return entries[0]


def fresh_reference_pack(recipe: dict[str, Any]) -> dict[str, Any]:
    entry = _reference_pack_entry(recipe)
    return {key: entry[key] for key in _PACK_KEYS}


def _semantic_cases(inventory: RequirementInventory, accounting: dict[str, Any],
                    tasks: list[dict[str, Any]], pack: dict[str, Any],
                    rendered: dict[str, str] | None = None) -> tuple[dict[str, str], list[str]]:
    if (accounting.get("schema_version") != "mozaiks.requirement_delivery.v1"
            or accounting.get("inventory_digest") != inventory.digest()
            or accounting.get("review_id") != inventory.review_id):
        raise ValueError("Reference cases require the complete current reviewed accounting")
    rows = accounting.get("requirements") or []
    by_id = {row["requirement_id"]: row for row in rows}
    if len(rows) != len(by_id) or set(by_id) != {row.requirement_id for row in inventory.requirements}:
        raise ValueError("Reference accounting must retain every approved requirement exactly once")
    task_map = {task["task_id"]: task for task in tasks}
    if len(task_map) != len(tasks):
        raise ValueError("Reference tasks repeat an identity")
    slots = {}
    for role, kind in (("contract", "module_contract"), ("models", "data_models"),
                       ("services", "business_services"), ("page", "page_bundle")):
        matches = [task for task in tasks if task.get("task_type") == kind
                   and task.get("capability_pack_id") == "bundle_selection" and task.get("surface_id") == "bundle_selection"]
        if len(matches) == 1:
            slots[role] = matches[0]["task_id"]
    cases, unsupported = {}, []
    for requirement in inventory.requirements:
        name = next((name for name, text in STATEMENTS.items()
                     if requirement.source == "core_features" and requirement.value == text), None)
        if name is None:
            unsupported.append(requirement.requirement_id)
            continue
        if name != "storefront" and (set(slots) != {"contract", "models", "services", "page"}
                                     or pack["storefront_recipe"]["extension"] != "bundle_selection"):
            raise ValueError("Reviewed custom cases require the declared task-owned bundle-selection extension")
        expected = {("pack", "pack:commerce"): {
            "ui/pages/products.yaml", "ui/pages/orders.yaml", "ui/route_manifest.json",
            "ui/pages/custom/Cart.jsx", "modules/commerce/module.yaml", "ui/pages/catalog_management.yaml",
        }} if name == "storefront" else {
            ("schema", "task:" + slots["contract"]): {_PREFIX + "module.yaml"},
            ("custom_generation", "task:" + slots["page"]): {_PAGE},
            ("custom_generation", "task:" + slots["services"]): (
                {_PREFIX + "backend/bundle_rules.py"} if name == "compatibility" else
                {_PREFIX + "backend/" + filename for filename in ("handler.py", "service.py", "repo.py")}),
        }
        if name == "quote":
            expected.update({("framework", "framework:module_api"): {"ui/lib/moduleApi.js"},
                             ("custom_generation", "task:" + slots["models"]): {_PREFIX + "backend/schemas.py"}})
        parts = by_id[requirement.requirement_id]["realizations"]
        if name == "storefront" and any(part["strategy"] == "schema" for part in parts):
            if "page" not in slots:
                raise ValueError("Authenticated reference storefront requires its declared app-schema task")
            # The app declares sign-in intent; the existing auth scaffold owns
            # deterministic routes/adapter output. Neither grants an identity.
            expected[("schema", "task:" + slots["page"])] = {"app.json"}
        actual = {(part["strategy"], part["owner_ref"]): set(part["output_paths"]) for part in parts}
        actions = {(ref["module_id"], ref["action_id"]) for part in parts for ref in part["action_refs"]}
        routes = {route for part in parts for route in part["page_routes"]}
        if (len(parts) != len(expected) or actual != expected
                or actions != ({("commerce", "list_products")} if name == "storefront" else {("bundle_selection", "quote_kit")})
                or routes != ({"/products", "/cart", "/orders", "/manage/catalog"} if name == "storefront" else {"/build-kit"})):
            raise ValueError("Reviewed statement does not match its independently owned reference case semantics")
        for part in parts:
            if not part["acceptance_criteria"]:
                raise ValueError("Reference realization has no acceptance criteria")
            if part["owner_ref"].startswith("task:"):
                task_id = part["owner_ref"].split(":", 1)[1]
                task = task_map[task_id]
                if (part["task_ids"] != [task_id] or not set(part["output_paths"]) <= set(task["owned_paths"])
                        or part["evidence_contract"] != {"task_contract_digest": canonical_digest(task)}
                        or part["depends_on"] != {task_id: sorted(task.get("depends_on") or [])}):
                    raise ValueError("Reference task evidence differs from actual task ownership")
            elif part["task_ids"]:
                raise ValueError("Reference reusable output cannot be owned by a custom task")
            elif part["depends_on"]:
                raise ValueError("Reference reusable output cannot invent task dependencies")
            if part["owner_ref"] == "pack:commerce":
                evidence = part["evidence_contract"]
                if (evidence["pack_identity"] != {key: pack[key] for key in _PACK_KEYS[:4]}
                        or evidence.get("recipe_digest") != pack["recipe_digest"]):
                    raise ValueError("Reference accounting names stale pack or recipe evidence")
                if rendered is not None:
                    from mozaiksai.core.workflow.generator_support.module_action_inventory import (
                        SHARED_PACK_OUTPUT_PATHS,
                    )

                    if (evidence.get("output_digests") != {
                            path: hashlib.sha256(rendered[path].encode()).hexdigest() for path in part["output_paths"]}
                            or evidence.get("composed_outputs") != sorted(set(part["output_paths"]) & SHARED_PACK_OUTPUT_PATHS)):
                        raise ValueError("Reference accounting differs from freshly rendered pack output evidence")
            elif part["owner_ref"] == "framework:module_api":
                from .module_api_template import get_module_api_template

                if part["evidence_contract"] != {"output_digests": {
                        "ui/lib/moduleApi.js": hashlib.sha256(get_module_api_template().encode()).hexdigest()}}:
                    raise ValueError("Reference framework evidence differs from its canonical owner")
        cases[CASE_IDS[name]] = requirement.requirement_id
    return cases, sorted(unsupported)


def validate_reference_request(value: Any) -> ReferenceBehaviorRequest:
    request = ReferenceBehaviorRequest.model_validate(value)
    if request.spec != spec_identity():
        raise ValueError("Reference spec is not the observer's installed code-owned version")
    if request.persona != CUSTOMER_PERSONA:
        raise ValueError("Reference persona is not the installed fixed synthetic customer")
    entry = _reference_pack_entry(request.pack.get("storefront_recipe"))
    if request.pack != {key: entry[key] for key in _PACK_KEYS}:
        raise ValueError("Reference pack or recipe changed since admission")
    cases, unsupported = _semantic_cases(request.inventory, request.accounting, request.tasks, request.pack,
                                        {item["filename"]: item["content"] for item in entry["files"]})
    if not cases or request.cases != cases or request.unsupported_requirement_ids != unsupported:
        raise ValueError("Reference cases are unknown, omitted, duplicated or misattributed")
    return request


def reference_request(inventory: RequirementInventory, accounting: dict[str, Any], tasks: list[dict[str, Any]],
                      pack: dict[str, Any], source_digest: str) -> dict[str, Any] | None:
    cases, unsupported = _semantic_cases(inventory, accounting, tasks, pack)
    if not cases:
        return None
    value = {"schema_version": "mozaiks.reference_behavior_request.v1", "inventory": inventory.model_dump(mode="json"),
             "accounting": accounting, "tasks": tasks, "pack": pack, "spec": spec_identity(),
             "persona": CUSTOMER_PERSONA,
             "source_content_sha256": source_digest, "cases": cases, "unsupported_requirement_ids": unsupported}
    return validate_reference_request(value).model_dump(mode="json")


async def seed_reference_products(run: Any, request: Any, *, prefix: str) -> tuple[dict, dict]:
    """Image-owned fixtures shared by the existing backend and browser observers."""
    from mozaiksai.core.runtime.persistence import MongoPersistenceContext

    names = MongoPersistenceContext(app_id=run.app_id, database_name=run.database_name,
                                   client=run.client, data_contract=run.load.data_contract)
    collections = {name: run.database[names.collection_name("commerce", name)]
                   for name in ("products", "carts", "orders", "checkout_requests")}
    currency = request.pack["storefront_recipe"]["currency"]
    seeded = {}
    for sku, price in (("alpine-canister", 5500), ("trail-alcohol", 4000),
                                         ("canister-230", 800), ("alcohol-500", 900),
                                         ("solo-900", 2200), ("group-1800", 3400)):
        row = {"app_id": run.app_id, "product_id": prefix + sku, "slug": prefix + sku,
               "sku": sku, "title": sku, "description": "Reference equipment", "category": prefix,
               "price_amount": price, "currency": currency, "status": "active", "track_inventory": True,
               "inventory_quantity": 10, "created_by": "reference", "created_at": "2026-10-21T00:00:00Z",
               "updated_at": "2026-10-21T00:00:00Z"}
        await collections["products"].insert_one(row)
        seeded[sku] = row
    return collections, seeded


async def execute_reference_cases(run: Any, value: Any) -> None:
    """Use only the observer's HTTP client and disposable private Mongo database."""
    request = validate_reference_request(value)
    if not run.external_probe or run.app_id != request.inventory.app_id:
        raise ValueError("Reference behavior requires the separate observer and matching app")
    if set(run.scopes) - IDENTITY_SCOPES:
        raise ValueError("Reference behavior requires identity-only base scopes; candidate grants are unsupported")
    prefix = "reference-" + uuid4().hex
    collections, seeded = await seed_reference_products(run, request, prefix=prefix)
    currency = request.pack["storefront_recipe"]["currency"]
    # Fixed image-owned test-host personas, not issuer or production membership proof.
    principal = run._with_roles(run.principal(prefix + "-customer-a"), CUSTOMER_PERSONA["roles"])
    other_customer = run._with_roles(run.principal(prefix + "-customer-b"), CUSTOMER_PERSONA["roles"])
    ungranted = run._with_roles(run.principal(prefix + "-ungranted"), [])
    owner = run._with_roles(run.principal(prefix + "-owner"), ["admin"])

    async def call(module, action, *, actor=principal, **params):
        # No permission escalation/retry: one actual external request per step.
        status, body, summary = await run._request("POST", module, action, actor, params)
        if status != 200 or not isinstance(body, dict):
            raise ValueError(f"{module}.{action} did not return a successful JSON response: {summary}")
        return body

    async def snapshot():
        result = {}
        for name, collection in collections.items():
            rows = await collection.find({}).sort([("_id", 1)]).to_list(length=10001)
            if len(rows) > 10000:
                raise ValueError("Reference persistence exceeds its bounded observation limit")
            result[name] = rows
        return result

    async def storefront():
        async def denied(action, params, actor=principal, expected_status=403):
            before = await snapshot()
            status, _body, summary = await run._request("POST", "commerce", action, actor, params)
            if status != expected_status:
                raise ValueError(f"Unauthorized {action} was not denied: {summary}")
            if await snapshot() != before:
                raise ValueError(f"Unauthorized {action} modified persistent commerce state")

        for action in ("list_products", "get_cart", "list_orders"):
            await denied(action, {}, ungranted)
        await denied("list_products", {}, run._with_scopes(ungranted, ["commerce.catalog.read"]))
        anonymous = await run.http.post("/api/modules/commerce/list_products", json={"params": {}})
        if anonymous.status_code != 403:
            raise ValueError("Unauthenticated catalog request was not denied")
        listing = await call("commerce", "list_products", category=prefix, page=1, page_size=20)
        if {row["product_id"] for row in listing.get("products", [])} != {row["product_id"] for row in seeded.values()}:
            raise ValueError("Catalog did not expose the seeded active products")
        before_order = await snapshot()
        product_id = seeded["alpine-canister"]["product_id"]
        added = await call("commerce", "add_cart_item", product_id=product_id, quantity=2)
        cart = added.get("cart", {})
        if added.get("success") is not True or cart.get("subtotal_amount") != 11000:
            raise ValueError("Cart did not use server catalog prices")
        result = await call("commerce", "submit_order", cart_id=cart["cart_id"], expected_revision=cart["revision"])
        order = result.get("order", {})
        if (result.get("success") is not True or order.get("total_amount") != 11000
                or order.get("payment") != {"status": "unpaid"} or order.get("inventory_reserved") is not False):
            raise ValueError("Order was not an accurate unpaid, non-reserving request")
        persisted = await collections["orders"].find_one({"app_id": run.app_id, "order_id": order["order_id"]})
        if not persisted or persisted.get("total_amount") != 11000:
            raise ValueError("The order response did not match independent persistence")
        after_order = await snapshot()
        if any(after_order[name] != before_order[name] for name in ("products", "checkout_requests")):
            raise ValueError("Unpaid order submission changed inventory or created a payment checkout")
        history = await call("commerce", "list_orders", page=1, page_size=20)
        if order["order_id"] not in {row["order_id"] for row in history.get("orders", [])}:
            raise ValueError("The submitted order disappeared from history")
        for action, params in (
            ("create_product", {"title": "Unauthorized product", "price_amount": 1}),
            ("update_product", {"product_id": product_id, "price_amount": 1}),
            ("archive_product", {"product_id": product_id}),
            ("adjust_inventory", {"product_id": product_id, "delta": 100}),
            ("update_order_status", {"order_id": order["order_id"], "status": "fulfilled"}),
        ):
            await denied(action, params)
        # Paid checkout is an internal integration boundary, not public HTTP.
        await denied("start_checkout", {"cart_id": cart["cart_id"], "expected_revision": cart["revision"]},
                     expected_status=404)
        for spoof in ({"app_id": "another-app"}, {"user_id": other_customer.user_id}):
            await denied("get_cart", spoof)
        other_cart = (await call("commerce", "get_cart", actor=other_customer)).get("cart") or {}
        if other_cart.get("cart_id") == cart["cart_id"] or other_cart.get("items") != []:
            raise ValueError("An equally authorized customer could read another customer's cart")
        before = await snapshot()
        other_order = await call("commerce", "get_order", actor=other_customer, order_id=order["order_id"])
        other_history = await call("commerce", "list_orders", actor=other_customer, page=1, page_size=20)
        stolen_cart = await call("commerce", "submit_order", actor=other_customer,
                                 cart_id=cart["cart_id"], expected_revision=cart["revision"])
        if (other_order.get("order") is not None or other_history.get("orders") != []
                or other_history.get("total") != 0 or stolen_cart.get("success") is not False):
            raise ValueError("An equally authorized customer crossed cart/order ownership")
        if await snapshot() != before:
            raise ValueError("Cross-customer reads or rejected submission modified commerce state")
        created = await call("commerce", "create_product", actor=owner,
                             title="Owner catalog product", price_amount=1250, status="active")
        managed_id = created.get("product", {}).get("product_id")
        if not managed_id:
            raise ValueError("Owner could not create a catalog product")
        changed = await call("commerce", "update_product", actor=owner,
                             product_id=managed_id, title="Owner managed product")
        if changed.get("success") is not True:
            raise ValueError("Owner could not update a catalog product")

    selection = {"stove_sku": "alpine-canister", "fuel_sku": "canister-230", "pot_sku": "solo-900", "quantity": 2}

    async def compatibility():
        before = await snapshot()
        if (await call("bundle_selection", "quote_kit", **selection)).get("success") is not True:
            raise ValueError("Compatible equipment was rejected")
        for changed in ({"fuel_sku": "alcohol-500"}, {"pot_sku": "group-1800"}, {"stove_sku": "unknown"}):
            if (await call("bundle_selection", "quote_kit", **{**selection, **changed})).get("success") is not False:
                raise ValueError("Incompatible or unsupported equipment was accepted")
        if (await call("bundle_selection", "quote_kit", stove_sku="trail-alcohol", fuel_sku="alcohol-500", quantity=1)).get("success") is not True:
            raise ValueError("Optional-pot selection did not work")
        if await snapshot() != before:
            raise ValueError("Compatibility checking modified persistent commerce state")

    async def quote():
        before = await snapshot()
        async def quoted(expected):
            response = await call("bundle_selection", "quote_kit", **selection)
            value = response.get("quote", {})
            amounts = [(row.get("sku"), row.get("quantity"), row.get("unit_amount"), row.get("line_amount"))
                       for row in value.get("items", [])]
            if (response.get("success") is not True or amounts != expected
                    or value.get("total_amount") != sum(row[3] for row in expected)
                    or value.get("currency") != currency or value.get("reservation") is not False
                    or value.get("payment_collected") is not False):
                raise ValueError("Quote did not preserve authoritative itemized prices and no-payment/no-reservation semantics")
        await quoted([("alpine-canister", 2, 5500, 11000), ("canister-230", 2, 800, 1600), ("solo-900", 2, 2200, 4400)])
        if await snapshot() != before:
            raise ValueError("Quoting modified persistent commerce state")
        await collections["products"].update_one({"product_id": seeded["alpine-canister"]["product_id"]}, {"$set": {"price_amount": 6000}})
        repriced = await snapshot()
        await quoted([("alpine-canister", 2, 6000, 12000), ("canister-230", 2, 800, 1600), ("solo-900", 2, 2200, 4400)])
        if await snapshot() != repriced:
            raise ValueError("Requoting modified persistent commerce state")
        await collections["products"].update_one(
            {"product_id": seeded["alpine-canister"]["product_id"]}, {"$set": {"status": "archived"}})
        inactive = await snapshot()
        if (await call("bundle_selection", "quote_kit", **selection)).get("success") is not False:
            raise ValueError("Quoting accepted a product that is no longer active")
        if await snapshot() != inactive:
            raise ValueError("Rejecting an inactive product modified persistent commerce state")

    implementations = {CASE_IDS["storefront"]: storefront, CASE_IDS["compatibility"]: compatibility, CASE_IDS["quote"]: quote}
    for case_id in implementations:
        if case_id not in request.cases:
            continue
        requirement_id = request.cases[case_id]
        try:
            await implementations[case_id]()
            passed, message = True, "Image-owned reference backend case completed. UI behavior is not verified."
        except Exception as exc:
            passed, message = False, f"Reference backend case failed: {type(exc).__name__}: {exc}"
        run.record("requirement.backend." + case_id, passed, message, case_id=case_id, requirement_id=requirement_id,
                   request_digest=canonical_digest(request.model_dump(mode="json")), spec=request.spec,
                   persona=request.persona, attempt=0)


def reference_evidence_issue(value: Any, outcomes: Any) -> str | None:
    """Match only directly observed, non-retried results to the closed admitted cases."""
    request = validate_reference_request(value)
    if not isinstance(outcomes, list):
        return "reference outcomes are unavailable"
    rows = [row for row in outcomes if isinstance(row, dict)
            and str(row.get("check", "")).startswith("requirement.backend.")]
    if len(rows) != len(request.cases):
        return "reference cases are missing or duplicated"
    seen = set()
    digest = canonical_digest(request.model_dump(mode="json"))
    for row in rows:
        details = row.get("details")
        if not isinstance(details, dict):
            return "reference case bindings are missing"
        case_id = details.get("case_id")
        if (not isinstance(case_id, str) or case_id not in request.cases or case_id in seen
                or row.get("check") != "requirement.backend." + case_id
                or row.get("status") != "passed" or type(details.get("attempt")) is not int or details["attempt"] != 0
                or details.get("requirement_id") != request.cases[case_id] or details.get("spec") != request.spec
                or details.get("persona") != request.persona
                or details.get("request_digest") != digest):
            return "reference case failed or differs from its admitted identity, bindings or first attempt"
        seen.add(case_id)
    return None
