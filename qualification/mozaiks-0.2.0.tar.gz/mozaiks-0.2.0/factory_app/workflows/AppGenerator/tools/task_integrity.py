"""Factory task ownership, repair admission, and final artifact completeness."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Collection, Iterable
from typing import Any, NoReturn

from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.code_files import planned_page_path, safe_relpath
from mozaiksai.core.workflow.task_batches import (
    optional_task_output_paths,
    task_evidence_digest,
    task_inventory_digest,
)


class RepairOwnershipError(ValueError):
    """The entire repair candidate was rejected before artifact mutation."""


#: AppGenerator cannot authorize a change to app-owned (``owner: workspace``)
#: pack code; only an authorized Studio backend refinement can.
WORKSPACE_PACK_CHANGE_DIAGNOSTIC = {
    "code": "WORKSPACE_PACK_OUTPUT_CHANGE_UNSUPPORTED",
    "missing_capability": "authorized_backend_refinement",
    # A bounded repair cannot authorize this change either.
    "block_reason": "authorized_backend_refinement_required",
}
WORKSPACE_PACK_CHANGE_REMEDY = (
    "It needs an authorized backend refinement: a Studio selected-file patch refinement of this exact path."
)


class WorkspacePackOutputChangeRejected(RepairOwnershipError):
    """A saved candidate changes app-owned pack code that AppGenerator cannot admit."""

    def __init__(self, *, paths: list[str], task_id: str) -> None:
        owner = f"task {task_id!r}" if task_id else "this output"
        super().__init__(
            f"{', '.join(paths)}: {owner} changes app-owned capability pack code, which AppGenerator "
            f"cannot admit. {WORKSPACE_PACK_CHANGE_REMEDY}"
        )
        self.diagnostic = {**WORKSPACE_PACK_CHANGE_DIAGNOSTIC, "paths": paths, "task_id": task_id}


def _get(context: Any, key: str, default: Any = None) -> Any:
    return detach(context.get(key, default)) if context is not None else default


def _set(context: Any, key: str, value: Any) -> None:
    if isinstance(context, dict):
        context[key] = value
    else:
        context.set(key, value)


def _task_contract(task: dict[str, Any]) -> dict[str, Any]:
    return {
        **{key: value for key, value in task.items() if key not in {
            "task_run_mode", "current_build_task_id", "current_build_task_type", "current_build_task",
        }},
        "task_id": task.get("task_id"),
        "task_type": task.get("task_type"),
        "initial_agent": task.get("initial_agent"),
        "owned_paths": sorted(safe_relpath(str(path)) for path in task.get("owned_paths", [])),
        "depends_on": sorted(task.get("depends_on") or []),
    }


def approved_task_inventory(context: Any) -> list[dict[str, Any]]:
    """Read the approved plan and verify its execution projection has not drifted."""
    plan = _get(context, "app_build_plan") or {}
    planned = plan.get("build_tasks") if isinstance(plan, dict) else None
    factory_bound = (
        _get(context, "workflow_name") == "AppGenerator"
        or bool(_get(context, "app_plan_ready"))
        or _get(context, "app_task_batch_status") is not None
        or bool(_get(context, "run_build_binding"))
    )
    if factory_bound and not isinstance(planned, list):
        raise ValueError("Factory generation requires approved app_build_plan.build_tasks")
    projected = _get(context, "app_task_batch_items")
    tasks = planned if isinstance(planned, list) else projected
    if tasks is None:
        return []
    if not isinstance(tasks, list) or any(not isinstance(task, dict) for task in tasks):
        raise ValueError("approved task inventory is invalid")
    if isinstance(planned, list) and isinstance(projected, list):
        if [_task_contract(task) for task in planned] != [_task_contract(task) for task in projected]:
            raise ValueError("approved plan differs from the task execution inventory")
        for task in projected:
            if "current_build_task" in task and _task_contract(task["current_build_task"]) != _task_contract(task):
                raise ValueError("task execution wrapper differs from the approved task")
            if "current_build_task_id" in task and task["current_build_task_id"] != task.get("task_id"):
                raise ValueError("task execution wrapper has a different task identity")
            if "current_build_task_type" in task and task["current_build_task_type"] != task.get("task_type"):
                raise ValueError("task execution wrapper has a different task type")
    results = _get(context, "app_task_batch_results") or {}
    meta = (results.get("_meta") or {}) if isinstance(results, dict) else {}
    expected_inventory = meta.get("task_inventory_digest")
    if expected_inventory and expected_inventory != task_inventory_digest(projected if isinstance(projected, list) else tasks):
        raise ValueError("approved task inventory differs from its original execution evidence")
    expected_plan = (meta.get("input_digests") or {}).get("app_build_plan")
    if expected_plan and expected_plan != task_evidence_digest(_get(context, "app_build_plan")):
        raise ValueError("approved build plan differs from its original execution evidence")
    ids: set[str] = set()
    owners: dict[str, str] = {}
    for task in tasks:
        task_id = str(task.get("task_id") or "")
        if not task_id or task_id in ids:
            raise ValueError("approved task inventory has missing or duplicate task identities")
        ids.add(task_id)
        for raw in task.get("owned_paths") or []:
            path = safe_relpath(str(raw))
            if not path or path in owners:
                raise ValueError(f"approved task ownership is invalid or ambiguous for {raw!r}")
            owners[path] = task_id
    return tasks


def task_allowed_paths(task: dict[str, Any], tasks: list[dict[str, Any]]) -> set[str]:
    """Use the batch's optionality rules without overriding another explicit owner."""
    own = {
        path for raw in task.get("owned_paths") or []
        if (path := safe_relpath(str(raw))) is not None
    }
    foreign = {
        path
        for other in tasks if other.get("task_id") != task.get("task_id")
        for raw in other.get("owned_paths") or []
        if (path := safe_relpath(str(raw))) is not None
    }
    return (own | optional_task_output_paths(task)) - foreign - {""}


def validate_admin_registry_task_output(context: Any, registry: Any) -> None:
    """Admit registry saves only for the exact approved page-bundle owner."""
    task = _get(context, "current_build_task") or {}
    path = "admin/admin_registry.yaml"
    if registry is None and path not in (task.get("owned_paths") or []):
        return
    from .requirement_delivery import validate_cached_requirement_delivery

    validate_cached_requirement_delivery(context)
    tasks = approved_task_inventory(context)
    canonical = next((item for item in tasks if item["task_id"] == task.get("task_id")), None)
    if canonical is None or _task_contract(canonical) != _task_contract(task):
        raise ValueError("admin_registry requires its exact approved page_bundle task")
    if canonical.get("task_type") != "page_bundle" or canonical.get("initial_agent") != "AppSchemaAgent":
        raise ValueError("admin_registry requires AppSchemaAgent/page_bundle ownership")
    if path not in canonical.get("owned_paths", []):
        raise ValueError("admin_registry is outside the current task's explicit owned_paths")
    if registry is None:
        active = (_get(context, "bundle_repair_result") or {}).get("active")
        if isinstance(active, dict):
            if active.get("task_id") != canonical["task_id"] or active.get("target_agent") != "AppSchemaAgent":
                raise ValueError("admin_registry repair must bind the current approved page task")
            # Reuse actual repair admission, not caller-authored allowed_paths
            # alone, before allowing the existing registry to remain untouched.
            validate_repair_candidate(context, {})
            if path not in active.get("allowed_paths", []):
                return
        raise ValueError("Declared admin/admin_registry.yaml requires nonnull AppSchemaOutput.admin_registry")


def planned_artifact_diagnostics(
    context: Any, files: dict[str, str], *, revision_baseline: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """Require accepted task evidence and all required artifacts in the final snapshot."""
    diagnostics: list[dict[str, Any]] = []

    def add(code: str, path: str = "", task: dict[str, Any] | None = None,
            reason: str = "", blocked_by: list[str] | None = None) -> None:
        task = task or {}
        diagnostics.append({
            "code": code, "path": path, "task_id": str(task.get("task_id") or ""),
            "owner_agent": str(task.get("initial_agent") or ""),
            "blocked_by": blocked_by or [], "block_reason": reason,
            "error": f"{path or task.get('task_id') or 'approved plan'}: {reason}",
        })

    try:
        tasks = approved_task_inventory(context)
    except (TypeError, ValueError) as exc:
        add("PLAN_INVENTORY_INVALID", reason=str(exc))
        return diagnostics
    results = _get(context, "app_task_batch_results") or {}
    if not isinstance(results, dict):
        add("TASK_EVIDENCE_UNAVAILABLE", reason="task execution results are invalid")
        results = {}
    if not tasks and results:
        add("PLAN_INVENTORY_UNAVAILABLE", reason="task results have no approved task inventory")
    failed = results.get("_failed") or {}
    meta = results.get("_meta") or {}
    in_flight = meta.get("in_flight") or {}
    failed_ids = set(failed) | set(meta.get("failed_tasks") or [])
    by_id = {str(task["task_id"]): task for task in tasks}
    owners = {
        path: task
        for task in tasks for raw in task.get("owned_paths") or []
        if (path := safe_relpath(str(raw))) is not None
    }
    for task in tasks:
        task_id = str(task["task_id"])
        blocked = [str(dep) for dep in task.get("depends_on") or [] if dep in failed_ids or dep in in_flight]
        if task_id in in_flight:
            add("TASK_EXECUTION_UNCERTAIN", task=task, reason="task attempt has no settled execution result")
        elif task_id in failed_ids:
            evidence = failed.get(task_id) or {}
            reason = str(evidence.get("error") or "original task failure diagnostic unavailable")
            blocked = list(evidence.get("blocked_by") or blocked)
            add("TASK_DEPENDENCY_BLOCKED" if blocked else "TASK_FAILED", task=task,
                reason=reason, blocked_by=blocked)
        elif not isinstance(results.get(task_id), dict) or not results[task_id]:
            history = (meta.get("failure_history") or {}).get(task_id) or []
            prior = history[-1] if history else {}
            if blocked:
                add("TASK_DEPENDENCY_BLOCKED", task=task, blocked_by=blocked,
                    reason=str(prior.get("error") or "prerequisite has no accepted execution result"))
            else:
                add("TASK_EVIDENCE_UNAVAILABLE", task=task, reason="accepted task output unavailable")
        elif meta.get("evidence_version") == 1 and (
            (meta.get("accepted_output_digests") or {}).get(task_id) != task_evidence_digest(results[task_id])
        ):
            add("TASK_EVIDENCE_INVALID", task=task, reason="accepted task output differs from its execution evidence")
        if "admin/admin_registry.yaml" in (task.get("owned_paths") or []) and isinstance(results.get(task_id), dict):
            if results[task_id].get("admin_registry") is None:
                add("TASK_EVIDENCE_INVALID", "admin/admin_registry.yaml", task,
                    "declared registry requires typed AppSchemaOutput.admin_registry, not a raw file mirror")
        for path in sorted(set(task.get("owned_paths") or []) - optional_task_output_paths(task)):
            normalized_path = safe_relpath(str(path))
            assert normalized_path is not None  # Approved inventory already validated every owned path.
            if normalized_path not in files:
                add("PLANNED_ARTIFACT_MISSING", normalized_path, task, "required planned artifact is missing", blocked)

    plan = _get(context, "app_build_plan") or {}
    from .audit_module_contracts import audit_admin_registry_file_map

    for warning in audit_admin_registry_file_map(files):
        add("ADMIN_REGISTRY_REFERENCE_INVALID", "admin/admin_registry.yaml", owners.get("admin/admin_registry.yaml"), warning)
    diagnostics.extend(_requirement_output_diagnostics(context, files, tasks, revision_baseline))
    if not isinstance(plan, dict) or not (tasks or plan.get("pages") or plan.get("modules")):
        return diagnostics
    if "app.json" not in files and not any(item["path"] == "app.json" for item in diagnostics):
        add("PLANNED_ARTIFACT_MISSING", "app.json", owners.get("app.json"), "required app manifest is missing")
    for page in plan.get("pages") or []:
        if not isinstance(page, dict):
            continue
        path = planned_page_path(page)
        if path not in files and not any(item["path"] == path for item in diagnostics):
            add("PLANNED_ARTIFACT_MISSING", path, owners.get(path), "required planned page is missing")
    for module in plan.get("modules") or []:
        if not isinstance(module, dict) or not module.get("module_id"):
            continue
        path = f"modules/{module['module_id']}/module.yaml"
        if path not in files and not any(item["path"] == path for item in diagnostics):
            add("PLANNED_ARTIFACT_MISSING", path, owners.get(path), "required planned module is missing")
    for task_id in failed_ids - by_id.keys():
        add("PLAN_INVENTORY_INVALID", reason=f"failed task {task_id!r} is absent from the approved inventory")
    return diagnostics


# Inputs consumed by canonical assembly outside the plan/task payloads. Selected
# template outputs are also bound below because their renderer can consume an
# installed pack's declared parameters beyond these core inputs.
_COMPOSITION_INPUT_KEYS = (
    "build_timestamp", "build_mode", "workflow_sequence", "brownfield_build_path",
    "data_contract", "design_surface_map", "concept_blueprint", "capability_packs",
    "operator_contracts", "subscription_contract", "subscription_contract_artifact",
    "captured_theme_config", "deployment_profile", "integration_needs", "current_build_task",
    "workflow_integration_metadata", "generated_workflow_name", "generated_workflow_capability_id",
    "generated_workflow_startup_mode", "generated_workflow_trigger_events",
)


def source_context_values(context: Any) -> dict[str, Any]:
    """Pure identities of persisted source tasks/assembly, not UI or gate receipts.

    Semantic data references and installed pack projections have their own
    authorities. The existing AG2 persistence policy decides which source fields
    actually survive; acceptance compares these fixed hashes on that document.
    """
    from mozaiksai.core.data.persistence.persistence_manager import (
        _context_authority_policy_for_workflow,
    )

    keys = {*_COMPOSITION_INPUT_KEYS, "app_build_plan", "app_task_batch_items", "app_task_batch_results",
            "bundle_repair_result", "code_files", "deleted_files", "revision_source_artifact_version_id"}
    policy = _context_authority_policy_for_workflow("AppGenerator")
    return policy.filter_for_persistence({key: _get(context, key) for key in sorted(keys)})


def source_context_digests(context: Any) -> dict[str, str]:
    return {key: task_evidence_digest(value) for key, value in source_context_values(context).items()}


def verified_repair_overlay(
    context: Any, tasks: list[dict[str, Any]],
) -> tuple[dict[str, str], list[str], list[dict[str, Any]]]:
    """Read admitted task successors through the existing repair writer's evidence.

    Closure and worker context use the same last-admitted successor semantics;
    arbitrary current files are never a substitute for the saved digest record.
    """
    from .code_file_utils import extract_code_file_map_from_payload

    repairs = _get(context, "bundle_repair_result") or {}
    overlay = extract_code_file_map_from_payload({"code_files": _get(context, "code_files")})
    admitted: dict[str, str | None] = {}
    records = []
    for record in [*(repairs.get("history") or []), repairs.get("active")]:
        if not isinstance(record, dict) or record.get("status") != "responded":
            continue
        saved = record.get("saved_paths") or []
        if not saved:
            continue
        task = next((task for task in tasks if task["task_id"] == record.get("task_id")), None)
        if task is None or record.get("target_agent") != task.get("initial_agent") or not record.get("request_id"):
            raise ValueError("Requirement repair has no matching approved task owner")
        allowed = task_allowed_paths(task, tasks)
        digests = record.get("saved_output_digests")
        removed = record.get("deleted_paths")
        if not isinstance(digests, dict) or not isinstance(removed, list):
            raise ValueError("Requirement repair lacks admitted output digest evidence; rerun the owned repair")
        if set(saved) != set(digests) | set(removed) or set(digests) & set(removed) or not set(saved) <= allowed:
            raise ValueError("Requirement repair output evidence differs from its approved ownership")
        admitted.update(digests)
        admitted.update({path: None for path in removed})
        records.append(record)
    repair_files = {}
    for path, digest in admitted.items():
        if digest is None:
            if path not in (_get(context, "deleted_files") or []):
                raise ValueError(f"Admitted repair deletion {path!r} is absent from the current overlay")
        elif path not in overlay or hashlib.sha256(overlay[path].encode()).hexdigest() != digest:
            raise ValueError(f"Admitted repair output {path!r} differs from its saved digest")
        else:
            repair_files[path] = overlay[path]
    return repair_files, [path for path, digest in admitted.items() if digest is None], records


def _requirement_output_diagnostics(
    context: Any, files: dict[str, str], tasks: list[dict[str, Any]],
    revision_baseline: dict[str, str] | None,
) -> list[dict[str, Any]]:
    """Recompose accounted artifacts from their admitted sources, never the candidate.

    This is output closure only. Identical bytes do not prove a requested behavior
    passed its reviewed acceptance case.
    """
    plan = _get(context, "app_build_plan") or {}
    factory_bound = (
        bool(_get(context, "run_build_binding")) or _get(context, "workflow_name") == "AppGenerator"
        or bool(_get(context, "app_plan_ready")) or _get(context, "app_task_batch_status") is not None
        or bool(_get(context, "approved_concept"))
        or isinstance(plan, dict) and bool(plan.get("requirement_inventory_digest"))
    )
    if not factory_bound:
        return []

    def diagnostic(code: str, reason: str, *, path: str = "", requirement_ids: list[str] | None = None):
        return {
            "code": code, "path": path, "task_id": "", "owner_agent": "", "blocked_by": [],
            "block_reason": reason, "error": f"{path or 'approved requirements'}: {reason}",
            "requirement_ids": requirement_ids or [],
        }

    from factory_app.workflows._shared.platform.build_target import require_build_binding

    from .assemble_app_tasks import compose_app_task_files
    from .code_file_utils import (
        ADMITTED_OVERLAY_OWNER,
        task_batch_outputs,
    )
    from .hydrate_app_revision_context import revision_baseline_required
    from .requirement_delivery import validate_cached_requirement_delivery
    from .resolve_managed_capability_templates import _context_to_dict

    try:
        validate_cached_requirement_delivery(context)
        accounting = plan["requirement_accounting"]
        source_context = _context_to_dict(context)
        source_context.update({key: _get(context, key) for key in _COMPOSITION_INPUT_KEYS})
        source_context.update(
            app_build_plan=plan, run_build_binding=_get(context, "run_build_binding"),
            app_task_batch_items=_get(context, "app_task_batch_items"),
            app_task_batch_results=_get(context, "app_task_batch_results"),
            # A final or previously assembled candidate is not an independent
            # baseline, even if it has been copied into multiple context slots.
            generated_files={}, code_files=[], deleted_files=[], bundle_repair_result={},
        )
        outputs: list[dict[str, Any]] = []
        owners: list[tuple[str, bool]] = []
        if _get(context, "build_mode") == "revision":
            if revision_baseline is None:
                raise ValueError("Requirement output verification requires the freshly verified bound revision source")
            if any(safe_relpath(path) != path or not isinstance(content, str)
                   for path, content in revision_baseline.items()):
                raise ValueError("The verified revision text source contains invalid paths or contents")
            if revision_baseline_required(context):
                source_context["generated_files"] = dict(revision_baseline)
                outputs.append({"code_files": [{"filename": path, "content": content}
                                                for path, content in sorted(revision_baseline.items())]})
                owners.append(("app:generated_files", True))
        else:
            revision_baseline = None
        accepted = task_batch_outputs(context)
        meta = (_get(context, "app_task_batch_results") or {}).get("_meta") or {}
        if tasks:
            if meta.get("evidence_version") != 1:
                raise ValueError("Requirement outputs require versioned accepted task execution evidence")
            projected = _get(context, "app_task_batch_items")
            if meta.get("task_inventory_digest") != task_inventory_digest(projected if isinstance(projected, list) else tasks):
                raise ValueError("Requirement task inventory differs from its original execution evidence")
            for key in ("app_build_plan", "build_timestamp"):
                if (meta.get("input_digests") or {}).get(key) != task_evidence_digest(_get(context, key)):
                    raise ValueError(f"Requirement composition input {key!r} differs from its original execution evidence")
            if set(key for key, _ in accepted) != {task["task_id"] for task in tasks}:
                raise ValueError("Requirement output verification requires every approved task's accepted output")
            for key, value in accepted:
                if (meta.get("accepted_output_digests") or {}).get(key) != task_evidence_digest(value):
                    raise ValueError(f"Requirement task {key!r} output differs from its original execution evidence")
        for key, value in accepted:
            outputs.append(value)
            owners.append((f"task:{key}", False))

        # A repair is an admitted successor to a task, not a new output authority.
        # Its existing tool-owned record binds the bytes saved by the same writer.
        repair_files, repair_deleted, records = verified_repair_overlay(context, tasks)
        if records:
            repair_entries = [{"filename": path, "content": content} for path, content in sorted(repair_files.items())]
            source_context.update(code_files=repair_entries, deleted_files=repair_deleted,
                                  bundle_repair_result={"history": records})
            outputs.append({"code_files": repair_entries})
            owners.append((ADMITTED_OVERLAY_OWNER, True))
        expected = {entry["filename"]: entry["content"] for entry in compose_app_task_files(
            app_id=require_build_binding(context).target_app_id, feature_outputs=outputs,
            ui_source_owners=owners, context_variables=source_context, verified_source=revision_baseline,
        )}
    except (TypeError, ValueError, KeyError, OSError) as exc:
        return [diagnostic("REQUIREMENT_OUTPUT_UNVERIFIED", str(exc))]
    required: dict[str, set[str]] = {}
    for row in accounting["requirements"]:
        for part in row["realizations"]:
            for path in part["output_paths"]:
                required.setdefault(path, set()).add(row["requirement_id"])
    diagnostics = []
    for path, requirement_ids in sorted(required.items()):
        if path not in expected:
            reason = "accounted output has no canonical materialization from its accepted sources"
        elif path not in files:
            reason = "accounted output is missing from the final candidate"
        elif files[path] != expected[path]:
            reason = "accounted output differs from canonical composition of its accepted sources"
        else:
            continue
        diagnostics.append(diagnostic("REQUIREMENT_OUTPUT_MISMATCH", reason, path=path,
                                      requirement_ids=sorted(requirement_ids)))
    return diagnostics


def admit_refinement_task_outputs(
    context: dict[str, Any], files: dict[str, str], *, baseline: dict[str, str],
    selected_paths: Collection[str], request_id: str,
) -> None:
    """Bind an inline patch to existing task owners through repair admission.

    This records admitted bytes in the temporary validation context, not a new
    execution or behavioral acceptance. New output ownership/requirements must
    return to workflow planning. Pack admission remains the finalizer's owner.
    """
    from .code_file_utils import extract_code_file_map_from_payload

    tasks = approved_task_inventory(context)
    changed = {path: content for path, content in files.items() if baseline.get(path) != content}
    if set(baseline) - files.keys() or not set(changed) <= set(selected_paths) or not request_id:
        raise RepairOwnershipError("refinement changes exceed the selected existing output scope")
    repairs = _get(context, "bundle_repair_result") or {}
    history = list(repairs.get("history") or [])
    if isinstance(repairs.get("active"), dict):
        history.append(repairs["active"])
    overlay = extract_code_file_map_from_payload({"code_files": _get(context, "code_files")})
    owners: dict[str, dict[str, Any]] = {}
    for path in changed:
        matches = [task for task in tasks if path in task_allowed_paths(task, tasks)]
        if len(matches) != 1:
            raise RepairOwnershipError(f"{path}: refinement requires one existing approved task owner; re-enter workflow planning")
        owners[path] = matches[0]
    for task in tasks:
        incoming = {path: content for path, content in changed.items() if owners[path] == task}
        if not incoming:
            continue
        context["bundle_repair_result"] = {"history": history, "active": {
            "request_id": request_id, "task_id": task["task_id"], "target_agent": task["initial_agent"],
            "status": "selected", "allowed_paths": sorted(incoming), "execution_owner": "control_plane_coding",
        }}
        admitted = validate_repair_candidate(context, incoming, existing=baseline)
        overlay.update(admitted)
        context["code_files"] = [{"filename": path, "content": value} for path, value in sorted(overlay.items())]
        mark_repair_responded(context, admitted)
        history.append(context["bundle_repair_result"]["active"])
    context["bundle_repair_result"] = {"history": history}


def artifact_snapshot_digest(context: Any, files: dict[str, str]) -> str:
    """Bind acceptance to its approved inputs and the exact exported contents."""
    from .resolve_managed_capability_templates import verified_pack_template_inventory

    revision = _get(context, "build_mode") == "revision"
    snapshot = {
        "plan": _get(context, "app_build_plan"),
        "tasks": _get(context, "app_task_batch_items"),
        "results": _get(context, "app_task_batch_results"),
        "binding": _get(context, "run_build_binding"),
        "files": files,
        "approval": _get(context, "approved_concept"),
        "composition_inputs": {key: _get(context, key) for key in _COMPOSITION_INPUT_KEYS},
        "repair_evidence": _get(context, "bundle_repair_result"),
        "rendered_packs": [
            {key: entry.get(key) for key in ("pack_id", "version", "digest", "authority", "recipe_digest",
                                           "messaging_configuration_digest", "files", "owner_map")}
            for entry in verified_pack_template_inventory(context_variables=context)
        ],
    }
    if revision:
        snapshot["revision_source_artifact_version_id"] = (
            _get(context, "revision_source_artifact_version_id") or _get(context, "artifact_version_id")
        )
        snapshot["revision_asset_evidence"] = _get(context, "revision_asset_evidence")
        snapshot["deleted_files"] = _get(context, "deleted_files")
    encoded = json.dumps(snapshot, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _settle_repair(context: Any, status: str, error: str = "") -> None:
    result = _get(context, "bundle_repair_result") or {}
    active = result.get("active")
    if not isinstance(active, dict):
        return
    result["active"] = {**active, "status": status, "error": error}
    _set(context, "bundle_repair_result", result)


def mark_repair_responded(context: Any, saved_paths: Iterable[str] = ()) -> None:
    """Settle a saved repair, recording what it saved: those paths are now newer than its task's output."""
    result = _get(context, "bundle_repair_result") or {}
    active = result.get("active")
    if not isinstance(active, dict):
        return
    from .code_file_utils import extract_code_file_map_from_payload

    paths = sorted(set(saved_paths))
    saved = extract_code_file_map_from_payload({"code_files": _get(context, "code_files")})
    deleted = set(_get(context, "deleted_files") or [])
    result["active"] = {
        **active, "status": "responded", "error": "", "saved_paths": paths,
        "saved_output_digests": {path: hashlib.sha256(saved[path].encode()).hexdigest()
                                 for path in paths if path in saved and path not in deleted},
        "deleted_paths": [path for path in paths if path in deleted],
    }
    _set(context, "bundle_repair_result", result)


def mark_repair_rejected(context: Any, error: str) -> bool:
    """Settle a pending repair's invalid candidate; infrastructure failures stay uncertain."""
    active = (_get(context, "bundle_repair_result") or {}).get("active")
    if not isinstance(active, dict) or active.get("status") != "selected":
        return False
    _settle_repair(context, "rejected", error)
    return True


def validate_repair_candidate(
    context: Any, incoming: dict[str, str], deleted: Iterable[str] = (),
    *, existing: dict[str, str] | None = None, protected: Collection[str] = (),
) -> dict[str, str]:
    """Admit one owned repair atomically; foreign identical readback is omitted.

    ``protected`` paths are app-owned pack code: a candidate that changes or
    deletes one is rejected whole, repair or not, because owning the path in
    the plan is not authority to change it. Identical bytes are not a change.
    """
    result = _get(context, "bundle_repair_result") or {}
    active = result.get("active")
    deleted = list(deleted)
    changed = sorted(
        {path for path, content in incoming.items() if path in protected and (existing or {}).get(path) != content}
        | {path for path in deleted if path in protected}
    )
    if changed:
        task = _get(context, "current_build_task") or {}
        rejection = WorkspacePackOutputChangeRejected(
            paths=changed,
            task_id=str((active or {}).get("task_id") or task.get("task_id") or ""),
        )
        if isinstance(active, dict) and active.get("status") == "selected":
            _settle_repair(context, "rejected", str(rejection))
        raise rejection
    if not isinstance(active, dict):
        if _get(context, "bundle_repair_target"):
            raise RepairOwnershipError("repair has no approved task ownership request")
        return incoming

    def reject(reason: str) -> NoReturn:
        _settle_repair(context, "rejected", reason)
        raise RepairOwnershipError(reason)

    if active.get("status") != "selected" or not active.get("request_id"):
        reject("repair request is not pending; replay or interrupted dispatch is blocked")
    try:
        tasks = approved_task_inventory(context)
    except (TypeError, ValueError) as exc:
        reject(str(exc))
    task = next((task for task in tasks if task.get("task_id") == active.get("task_id")), None)
    if task is None or task.get("initial_agent") != active.get("target_agent"):
        reject("repair task owner does not match the approved task inventory")
    allowed = {safe_relpath(str(path)) for path in active.get("allowed_paths") or []}
    if not allowed or not allowed.issubset(task_allowed_paths(task, tasks)):
        reject("repair allowed_paths extend beyond the approved task owner")
    existing = existing or {}
    unauthorized = sorted(
        path for path, content in incoming.items()
        if safe_relpath(path) != path or (path not in allowed and existing.get(path) != content)
    )
    unauthorized.extend(path for path in deleted if path not in allowed or safe_relpath(path) != path)
    if unauthorized:
        reject(f"repair emitted changes outside owned_paths: {sorted(set(unauthorized))}")
    return {path: content for path, content in incoming.items() if path in allowed}
