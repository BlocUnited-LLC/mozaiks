import json
import logging
import re
from collections.abc import Callable, Iterable
from pathlib import PurePosixPath
from typing import Annotated, Any

from pydantic import Field

from factory_app.workflows.AppGenerator.tools.requirement_delivery import (
    compile_requirement_delivery,
    invalidate_requirement_plan,
)
from mozaiksai.builder.requirements import RequirementDelivery
from mozaiksai.core.runtime.app.paths import (
    APP_AUTH_CONFIG_PATH,
    APP_PROVENANCE_PATH,
    APP_SECURITY_SECRETS_PATH,
    disallowed_legacy_app_paths,
    is_safe_app_path,
    noncanonical_app_config_paths,
    noncanonical_app_root_paths,
    normalize_app_path,
)
from mozaiksai.core.runtime.persistence.intent_loader import iter_data_contract_collections
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.code_files import (
    auth_required_from_strategy,
    planned_page_path,
)
from mozaiksai.core.workflow.generator_support.module_action_inventory import (
    pack_facade_directories,
    pack_owned_output_paths,
)
from mozaiksai.core.workflow.generator_support.module_entitlement_gates import (
    resolve_subscription_contract,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _page_stem_from_path,
)

try:
    from .managed_monetization_contract import (
        MOZAIKS_PAY_PROVIDER_ID,
        MOZAIKSPAY_PACK_ID,
        SELF_MANAGED_PROVIDER_ID,
        SUBSCRIPTION_WRITE_PATH_CAPABILITY,
        normalize_monetization_provider,
    )
    from .managed_monetization_contract import (
        pack_id_from_descriptor as _canonical_pack_id_from_descriptor,
    )
except ImportError:
    from factory_app.workflows.AppGenerator.tools.managed_monetization_contract import (
        MOZAIKS_PAY_PROVIDER_ID,
        MOZAIKSPAY_PACK_ID,
        SELF_MANAGED_PROVIDER_ID,
        SUBSCRIPTION_WRITE_PATH_CAPABILITY,
        normalize_monetization_provider,
    )
    from factory_app.workflows.AppGenerator.tools.managed_monetization_contract import (
        pack_id_from_descriptor as _canonical_pack_id_from_descriptor,
    )

_logger = logging.getLogger("tools.app_build_plan")

_CARRY_FORWARD_DECISION_VALUES: frozenset[str] = frozenset({"reuse", "adapt", "regenerate", "drop"})
_CARRY_FORWARD_SOURCE_VALUES: frozenset[str] = frozenset({"carry_forward_candidate", "human_override", "planner"})

_RAW_FRONTEND_SOURCE_EXTENSIONS = {".css", ".html", ".jsx", ".less", ".sass", ".scss", ".tsx"}
_FRONTEND_JS_TS_SEGMENTS = (
    "/frontend/",
    "/chat-ui/",
    "/chatui/",
    "/src/pages/",
    "/src/components/",
)
_OBSOLETE_HOST_ADMIN_CONFIG_PATH = "app/config/admin.json"
_APP_SERVICE_ADMIN_PATHS = {"services/admin_config.py", "services/routes/admin.py"}
_INTEGRATIONS_PREFIX = "services/integrations/"
_ADAPTERS_PREFIX = "services/adapters/"
_ROUTES_PREFIX = "services/routes/"
_CLIENT_SUFFIX = "_client.py"
_CANONICAL_SERVICE_FILES = frozenset({"services/config.py", "services/admin_config.py"})
_CANONICAL_SERVICE_PREFIXES = (_INTEGRATIONS_PREFIX, _ADAPTERS_PREFIX, _ROUTES_PREFIX)
_SERVICE_FOUNDATION_ALLOWED_FILES = frozenset({"services/config.py", APP_SECURITY_SECRETS_PATH})
_SERVICE_FOUNDATION_ALLOWED_PREFIXES = (_INTEGRATIONS_PREFIX, _ADAPTERS_PREFIX, _ROUTES_PREFIX)
_DEPLOYMENT_CONTRACT_ARTIFACT_FILES = frozenset(
    {
        "Dockerfile",
        "deployment.manifest.json",
        "docker-compose.yml",
        ".env.example",
        ".env.staging.example",
        ".env.production.example",
        ".github/workflows/readiness.yml",
        ".github/workflows/deploy.yml",
    }
)
_DEPLOYMENT_CONTRACT_ARTIFACT_PREFIXES = (".github/workflows/",)
_CANONICAL_INITIAL_AGENTS = {
    "service_foundation": "ConfigMiddlewareAgent",
    "module_contract": "ConfigMiddlewareAgent",
    "persistence_contract": "DatabaseAgent",
    "data_migrations": "DatabaseAgent",
    "data_models": "ModelAgent",
    "business_services": "ServiceAgent",
    "refinement_harness": "RefinementHarnessAgent",
    "api_surface": "ControllerAgent",
    "page_bundle": "AppSchemaAgent",
}
# AppGenerator materialization authority is narrower than generic assignment kinds.
_ALLOWED_TASK_TYPES = frozenset(_CANONICAL_INITIAL_AGENTS)
_SURFACE_KIND_ALLOWED_TASK_TYPES: dict[str, frozenset[str]] = {
    "external_integration": frozenset({"api_surface", "service_foundation"}),
    "refinement": frozenset({"refinement_harness"}),
    "ui_only": frozenset({"page_bundle"}),
}
_SHARED_OWNED_PATHS = frozenset({"app.json"})
_WORKFLOW_SURFACE_KIND = "workflow"
_MODULE_LOCAL_TASK_TYPES = frozenset({"module_contract", "data_models", "business_services"})
_DATA_MIGRATIONS_PREFIX = "data/migrations/"
_REFINEMENT_REQUIRED_PATHS = frozenset({
    "config/refinement_policy.yaml",
    "refinement_harness/config/harness.yaml",
})
_REFINEMENT_CONFIG_PATHS = _REFINEMENT_REQUIRED_PATHS | {
    "refinement_harness/config/tools.yaml",
    "refinement_harness/config/policies.yaml",
}
# Assembly writes this from the approved subscription contract
# (materialize_app_config_contracts); a task's copy would be overwritten.
SUBSCRIPTIONS_CONFIG_PATH = "config/subscriptions.yaml"


def _required_selected_task_paths(task: dict[str, Any]) -> frozenset[str]:
    """Required file closure once the planner has selected an optional task."""
    task_type = task.get("task_type")
    if task_type == "refinement_harness":
        return _REFINEMENT_REQUIRED_PATHS
    if task_type == "api_surface" and _APP_SERVICE_ADMIN_PATHS.intersection(_normalized_owned_paths(task)):
        return frozenset(_APP_SERVICE_ADMIN_PATHS)
    return frozenset()


def _construct_task_requirements(plan: dict[str, Any], context_variables: Any) -> list[str]:
    """Close fixed worker and file requirements without choosing optional work."""
    repairs: list[str] = []
    contract = detach(context_variables.get("data_contract")) or {}
    persistent_modules = {
        owner for owner, kind, _collection in iter_data_contract_collections(contract)
        if kind == "module"
    }
    registered = _context_available_pack_map(context_variables)
    managed_ids = {
        _pack_id_from_descriptor(pack)
        for pack in plan.get("capability_packs") or []
        if pack.get("capability_source") == "managed_capability"
        and (registered.get(_pack_id_from_descriptor(pack)) or {}).get("capability_source") == "managed_capability"
    }
    for task in plan.get("build_tasks") or []:
        task_type = task.get("task_type")
        task_id = task.get("task_id")
        worker = _CANONICAL_INITIAL_AGENTS.get(task_type)
        if worker and task.get("initial_agent") != worker:
            task["initial_agent"] = worker
            repairs.append(f"{task_id}: initial_agent -> {worker}")
        if not all(is_safe_app_path(path) for path in task.get("owned_paths") or []):
            continue  # Preserve unsafe proposals for origin/path validation.
        paths = _normalized_owned_paths(task)
        if task_type == "business_services":
            policy_paths = {
                path for path in paths
                if path.startswith("modules/") and path.endswith("/backend/policy.py")
                and path.split("/")[1] not in persistent_modules
            }
            if policy_paths:
                task["owned_paths"] = [path for path in paths if path not in policy_paths]
                paths = _normalized_owned_paths(task)
                repairs.append(f"{task_id}: removed policies for modules without collections {sorted(policy_paths)}")
        fixed: dict[str, Any] = {}
        if task_type == "refinement_harness" and all(
            path in _REFINEMENT_CONFIG_PATHS
            or (path.startswith("refinement_harness/prompts/") and PurePosixPath(path).suffix == ".yaml")
            for path in paths
        ):
            fixed = {"capability_pack_id": None, "surface_kind": "refinement"}
        elif task_type == "api_surface" and task.get("capability_pack_id") in managed_ids:
            fixed = {"surface_kind": "external_integration"}
        elif task_type == "api_surface" and _APP_SERVICE_ADMIN_PATHS.intersection(paths):
            fixed = {"capability_pack_id": None}
        for key, value in fixed.items():
            if task.get(key) != value:
                task[key] = value
                repairs.append(f"{task_id}: {key} -> {value!r}")
        missing = _required_selected_task_paths(task).difference(paths)
        if missing:
            task["owned_paths"] = [*(task.get("owned_paths") or []), *sorted(missing)]
            repairs.append(f"{task_id}: added required paths {sorted(missing)}")
    return repairs


def _release_owned_paths(
    plan: dict[str, Any], releases: Callable[[str], bool], *, owner: str, provider: str,
) -> list[str]:
    """Release every owned path `releases` selects; drop a task left with nothing to build."""
    for delivery in plan.get("requirement_deliveries") or []:
        for part in delivery.get("realizations") or []:
            if not part["owner_ref"].startswith("task:"):
                continue
            paths = part["output_paths"]
            if not any(releases(normalize_app_path(path)) for path in paths):
                continue
            raise ValueError(
                f"Requirement {delivery['requirement_id']} assigns {owner} outputs {paths} to {part['owner_ref']!r}. "
                "Preserve its scope and acceptance criteria; explicitly map faithful reusable behavior to its "
                "verified owner and keep unimplemented behavior in bounded app-owned custom extension outputs. "
                "File ownership cannot establish behavior equivalence or change the delivery strategy."
            )
    repairs: list[str] = []
    kept: list[dict[str, Any]] = []
    dropped: set[str] = set()
    for task in plan.get("build_tasks") or []:
        owned = list(task.get("owned_paths") or [])
        released = [path for path in owned if releases(normalize_app_path(str(path)))]
        if not released:
            kept.append(task)
            continue
        remaining = [path for path in owned if path not in released]
        if remaining:
            task["owned_paths"] = remaining
            kept.append(task)
            repairs.append(f"{task.get('task_id')}: released {owner} {released}; {provider}")
        else:
            dropped.add(str(task.get("task_id")))
            repairs.append(f"dropped task {task.get('task_id')!r}: every owned path {released} is {owner}")
    # A draft may repeat a task_id until identity repair qualifies it; an edge
    # to a surviving task of that id is not an edge to the dropped one.
    dropped -= {str(task.get("task_id")) for task in kept}
    for task in kept:
        depends = [dep for dep in task.get("depends_on") or [] if str(dep) not in dropped]
        if len(depends) != len(task.get("depends_on") or []):
            task["depends_on"] = depends
    if dropped and plan.get("generation_order"):
        plan["generation_order"] = [ref for ref in plan["generation_order"] if str(ref) not in dropped]
    plan["build_tasks"] = kept
    return repairs


def release_pack_owned_paths(plan: dict[str, Any], context: Any) -> list[str]:
    """Pack-owned outputs are never model work; no task keeps one.

    A selected pack writes every path it declares in required_outputs from its
    templates (owner: workspace only at genesis), and assembly takes those
    files only from the templates. A task that owns one - drafted by the
    planner or synthesized by an earlier repair - is building a file that is
    discarded. Its pack-owned paths are released; a task left with nothing to
    build is dropped with its dependency edges.
    """
    return _release_owned_paths(
        plan, pack_owned_output_paths(context).__contains__,
        owner="pack-owned", provider="selected pack templates provide them",
    )


def release_pack_facade_paths(plan: dict[str, Any], context: Any) -> list[str]:
    """A selected pack's facade module directory is never model work.

    release_pack_owned_paths releases the files a pack declares. A planner
    also adds files beside them: chat e67150d7 at 49c69860 kept tasks owning
    modules/billing_portal/backend/repo.py and contracts/events.yaml after the
    declared billing_portal files were released. The mozaikspay contract owns
    every declared file in that directory and asks a model for none, and
    assembly applies the pack's module, so those tasks built nothing that ships.
    Every path the pack does not leave to a model or the workspace is released
    (pack_facade_directories); a task left with nothing to build is dropped
    with its dependency edges.
    """
    repairs: list[str] = []
    for facade in pack_facade_directories(context):
        repairs.extend(_release_owned_paths(
            plan, facade.owns,
            owner="pack-owned", provider=f"the {facade.pack_id} pack owns its facade module {facade.path}/",
        ))
    return repairs


def release_subscriptions_config(plan: dict[str, Any]) -> list[str]:
    """config/subscriptions.yaml is never model work; no task keeps it.

    Assembly writes it from the approved subscription contract, or omits it
    when no contract is required, so a task's copy is always discarded. The
    planner's schema has no task type for it; this covers the path appearing
    in another task's owned_paths.
    """
    return _release_owned_paths(
        plan, lambda path: path == SUBSCRIPTIONS_CONFIG_PATH,
        owner="assembly-owned", provider="assembly writes it from the approved subscription contract",
    )


def _normalize_string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    items: list[str] = []
    for entry in value:
        text = str(entry).strip()
        if text:
            items.append(text)
    return items


def _normalize_object_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    items: list[dict[str, Any]] = []
    for entry in value:
        if isinstance(entry, dict):
            items.append(dict(entry))
    return items


def _normalize_context_variables(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return dict(value)
    if not isinstance(value, list):
        return None
    normalized: dict[str, Any] = {}
    for item in value:
        if not isinstance(item, dict):
            continue
        key = str(item.get("key") or "").strip()
        if not key:
            continue
        raw_value = item.get("value")
        value_type = str(item.get("value_type") or "string").strip()
        if value_type == "boolean":
            normalized[key] = str(raw_value).strip().lower() in {"1", "true", "yes", "on"}
        elif value_type == "integer":
            try:
                normalized[key] = int(str(raw_value).strip())
            except ValueError:
                normalized[key] = 0
        elif value_type == "number":
            try:
                normalized[key] = float(str(raw_value).strip())
            except ValueError:
                normalized[key] = 0.0
        elif value_type == "json":
            try:
                normalized[key] = json.loads(str(raw_value or "null"))
            except json.JSONDecodeError:
                normalized[key] = raw_value
        elif value_type == "null":
            normalized[key] = None
        else:
            normalized[key] = "" if raw_value is None else str(raw_value)
    return normalized


def _unwrap_app_build_plan_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if "app_kind" in payload:
        return payload
    for key in ("AppBuildPlan", "app_build_plan"):
        value = payload.get(key)
        if isinstance(value, dict):
            unwrapped = _unwrap_app_build_plan_payload(value)
            if "app_kind" in unwrapped:
                return unwrapped
    if len(payload) == 1:
        value = next(iter(payload.values()))
        if isinstance(value, dict):
            unwrapped = _unwrap_app_build_plan_payload(value)
            if "app_kind" in unwrapped:
                return unwrapped
    return payload


def _task_sort_key(task: dict[str, Any]) -> tuple[int, str]:
    task_id = str(task.get("task_id") or "")
    return (0 if task_id else 1, task_id)


def _infer_pack_id_from_integration_path(path: str) -> str | None:
    """
    Extract the managed capability id from an app-bundle-relative
    services/integrations/{pack_id}_client.py path.

    Returns the inferred pack_id string, or None if the path does not match
    the managed capability adapter pattern.
    """
    normalized = path.replace("\\", "/").strip()
    if not normalized.startswith(_INTEGRATIONS_PREFIX):
        return None
    filename = PurePosixPath(normalized).name
    if filename.endswith(_CLIENT_SUFFIX):
        return filename[: -len(_CLIENT_SUFFIX)]
    return None


def _raw_frontend_source_path(task: dict[str, Any]) -> str | None:
    owns_custom_bundle = (
        task.get("task_type") == "page_bundle"
        and task.get("initial_agent") == "AppSchemaAgent"
        and {"ui/route_manifest.json", "ui/index.js"} <= set(_normalized_owned_paths(task))
    )
    for owned_path in _normalize_string_list(task.get("owned_paths")):
        if owns_custom_bundle and re.fullmatch(r"ui/pages/custom/[a-z0-9_]+\.jsx", normalize_app_path(owned_path)):
            continue
        normalized = owned_path.replace("\\", "/").strip().lower()
        suffix = PurePosixPath(normalized).suffix

        if suffix in _RAW_FRONTEND_SOURCE_EXTENSIONS:
            return owned_path

        if suffix in {".js", ".ts"} and any(segment in normalized for segment in _FRONTEND_JS_TS_SEGMENTS):
            return owned_path

    return None


def _normalized_owned_paths(task: dict[str, Any]) -> list[str]:
    paths: list[str] = []
    for owned_path in _normalize_string_list(task.get("owned_paths")):
        normalized = normalize_app_path(owned_path)
        if normalized:
            paths.append(normalized)
    return paths


def _noncanonical_service_paths(paths: list[str]) -> list[str]:
    invalid: list[str] = []
    for path in paths:
        normalized = normalize_app_path(path)
        if not normalized.startswith("services/"):
            continue
        if normalized in _CANONICAL_SERVICE_FILES:
            continue
        if any(normalized.startswith(prefix) for prefix in _CANONICAL_SERVICE_PREFIXES):
            continue
        invalid.append(normalized)
    return sorted(set(invalid))


def _invalid_service_foundation_paths(paths: list[str]) -> list[str]:
    invalid: list[str] = []
    for path in paths:
        normalized = normalize_app_path(path)
        if normalized in _SERVICE_FOUNDATION_ALLOWED_FILES:
            continue
        if any(normalized.startswith(prefix) for prefix in _SERVICE_FOUNDATION_ALLOWED_PREFIXES):
            continue
        invalid.append(normalized)
    return sorted(set(invalid))


def _deployment_contract_artifact_paths(paths: list[str]) -> list[str]:
    invalid: list[str] = []
    for path in paths:
        normalized = normalize_app_path(path)
        if normalized in _DEPLOYMENT_CONTRACT_ARTIFACT_FILES:
            invalid.append(normalized)
            continue
        if any(normalized.startswith(prefix) for prefix in _DEPLOYMENT_CONTRACT_ARTIFACT_PREFIXES):
            invalid.append(normalized)
    return sorted(set(invalid))


def _infer_module_id_from_owned_paths(task: dict[str, Any]) -> str | None:
    module_ids: set[str] = set()
    for path in _normalized_owned_paths(task):
        parts = PurePosixPath(path).parts
        if len(parts) >= 2 and parts[0] == "modules" and parts[1]:
            module_ids.add(parts[1])
    if len(module_ids) == 1:
        return next(iter(module_ids))
    return None


def _normalize_build_task_identity(task: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(task)
    task_type = str(normalized.get("task_type") or "").strip()
    if task_type in _MODULE_LOCAL_TASK_TYPES:
        module_id = _infer_module_id_from_owned_paths(normalized)
        if module_id:
            declared_id = str(normalized.get("capability_pack_id") or "").strip()
            if declared_id != module_id:
                _logger.info(
                    "Normalized build task %s capability_pack_id from %r to %r based on owned_paths",
                    normalized.get("task_id") or "<unknown>",
                    declared_id or None,
                    module_id,
                )
                normalized["capability_pack_id"] = module_id
    return normalized


def _reserve_module_event_contract_paths(build_tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Reserve optional event declarations before execution freezes plan ownership."""
    owned = {path for task in build_tasks for path in _normalized_owned_paths(task)}
    normalized = []
    for task in build_tasks:
        item = dict(task)
        if item.get("task_type") == "module_contract":
            module_id = _infer_module_id_from_owned_paths(item)
            event_path = f"modules/{module_id}/contracts/events.yaml"
            if module_id and event_path not in owned:
                # Actions are authored later. Reserving this optional companion
                # grants one owner without inventing an event version or payload.
                item["owned_paths"] = [*_normalized_owned_paths(item), event_path]
                owned.add(event_path)
        normalized.append(item)
    return normalized


def _dedupe_preserving_order(values: Iterable[Any]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        result.append(text)
        seen.add(text)
    return result


def _join_unique_text(parts: Iterable[Any], *, separator: str = " ") -> str:
    return separator.join(_dedupe_preserving_order(parts)).strip()


def _rename_requirement_tasks(part: dict[str, Any], renamed: dict[str, str]) -> None:
    """Follow an established task identity repair, without changing delivery meaning."""
    owner = part["owner_ref"].removeprefix("task:")
    if part["owner_ref"].startswith("task:") and owner in renamed:
        part["owner_ref"] = "task:" + renamed[owner]
    part["task_ids"] = _dedupe_preserving_order(renamed.get(ref, ref) for ref in part["task_ids"])


_READINESS_PROFILE_VALUES = {
    "none",
    "basic_app",
    "saas_app",
    "host_operator_platform",
    "marketplace_platform",
}


def _normalize_readiness_profile(value: Any) -> str:
    profile = str(value or "").strip()
    return profile if profile in _READINESS_PROFILE_VALUES else "none"


def _infer_readiness_profile(
    plan: dict[str, Any],
    *,
    context_variables: Any | None,
) -> str:
    explicit = _normalize_readiness_profile(plan.get("readiness_profile"))
    if explicit != "none":
        return explicit

    parts: list[str] = [
        str(plan.get("agent_message") or ""),
        str(plan.get("app_kind") or ""),
        str(plan.get("profile_layout") or ""),
        " ".join(_normalize_string_list(plan.get("service_scope"))),
        " ".join(_normalize_string_list(plan.get("frontend_scope"))),
        " ".join(_normalize_string_list(plan.get("roles"))),
        " ".join(
            str(pack.get("capability_pack_id") or pack.get("id") or pack.get("pack_id") or "")
            for pack in _normalize_object_list(plan.get("capability_packs"))
            if isinstance(pack, dict)
        ),
    ]
    if context_variables is not None and hasattr(context_variables, "get"):
        for key in ("app_type", "concept_overview", "build_mode"):
            try:
                parts.append(str(context_variables.get(key) or ""))
            except Exception:
                continue

    haystack = " ".join(parts).lower()
    host_operator_terms = (
        "host operator",
        "host-operator",
        "hosted app",
        "hosted apps",
        "operator platform",
        "platform ops",
        "launch readiness",
        "readiness gate",
        "evidence ledger",
        "staging verification",
        "compliance",
        "launch gate",
        "hosting",
        "domains",
    )
    if any(term in haystack for term in host_operator_terms):
        return "host_operator_platform"

    if "marketplace" in haystack or "multi-tenant marketplace" in haystack:
        return "marketplace_platform"

    saas_terms = (
        "saas",
        "subscription",
        "subscriptions",
        "seat",
        "tier",
        "pricing",
        "billing portal",
    )
    if any(term in haystack for term in saas_terms):
        return "saas_app"

    if "simple app" in haystack or "single-purpose" in haystack or "basic app" in haystack:
        return "basic_app"

    return "none"


def _merge_persistence_contract_tasks(
    build_tasks: list[dict[str, Any]], *, requirement_deliveries: Any = None,
) -> list[dict[str, Any]]:
    persistence_tasks = [
        task
        for task in build_tasks
        if isinstance(task, dict) and str(task.get("task_type") or "").strip() == "persistence_contract"
    ]
    if len(persistence_tasks) <= 1:
        return build_tasks

    original_tasks = {task.get("task_id"): task for task in build_tasks}
    if len(original_tasks) != len(build_tasks) or any(
        not isinstance(identity, str) or not identity or identity != identity.strip()
        for identity in original_tasks
    ):
        raise ValueError("Persistence contract merge requires unique task identities with nonempty canonical values")
    primary = dict(sorted(persistence_tasks, key=_task_sort_key)[0])
    primary_id = primary["task_id"]
    removed_ids = {task["task_id"] for task in persistence_tasks if task["task_id"] != primary_id}
    if requirement_deliveries is not None:
        if not isinstance(requirement_deliveries, list):
            raise ValueError("AppBuildPlan.requirement_deliveries must be a list")
        for delivery in requirement_deliveries:
            validated = RequirementDelivery.model_validate(delivery)
            for part in validated.realizations:
                owner = part.owner_ref.removeprefix("task:")
                if part.owner_ref.startswith("task:") and owner in removed_ids | {primary_id}:
                    if part.task_ids != [owner] or not set(part.output_paths) <= set(_normalized_owned_paths(original_tasks[owner])):
                        raise ValueError(f"Requirement must reference exact outputs and task identity for {owner!r} before persistence merge")

    primary["task_id"] = primary_id
    primary["description"] = _join_unique_text(
        task.get("description") for task in persistence_tasks
    ) or str(primary.get("description") or "")
    primary["initial_message"] = _join_unique_text(
        task.get("initial_message") for task in persistence_tasks
    ) or str(primary.get("initial_message") or "")
    primary["owned_paths"] = _dedupe_preserving_order(
        path for task in persistence_tasks for path in _normalized_owned_paths(task)
    )
    primary["depends_on"] = _dedupe_preserving_order(
        dep
        for task in persistence_tasks
        for dep in _normalize_string_list(task.get("depends_on"))
        if str(dep or "").strip() != primary_id and str(dep or "").strip() not in removed_ids
    )
    primary["acceptance_criteria"] = _dedupe_preserving_order(
        criterion
        for task in persistence_tasks
        for criterion in _normalize_string_list(task.get("acceptance_criteria"))
    )

    result: list[dict[str, Any]] = []
    inserted_primary = False
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        task_type = str(task.get("task_type") or "").strip()
        str(task.get("task_id") or "").strip()
        if task_type == "persistence_contract":
            if not inserted_primary:
                result.append(primary)
                inserted_primary = True
            continue

        item = dict(task)
        deps = []
        for dep in _normalize_string_list(item.get("depends_on")):
            deps.append(primary_id if dep in removed_ids else dep)
        item["depends_on"] = _dedupe_preserving_order(deps)
        result.append(item)

    if not inserted_primary:
        result.insert(0, primary)
    for delivery in requirement_deliveries or []:
        for part in delivery["realizations"]:
            _rename_requirement_tasks(part, dict.fromkeys(removed_ids, primary_id))
    return sorted(result, key=_task_sort_key)


def _context_get(context_variables: Any | None, key: str, default: Any = None) -> Any:
    if context_variables is None or not hasattr(context_variables, "get"):
        return default
    try:
        return detach(context_variables.get(key, default))
    except Exception:
        return default


class _PlanPackSelection:
    """Read-only planning context whose pack selection is this plan's when the build context selects none.

    Assembly applies the build context's ``capability_packs``, else the stored
    plan's (an OSS SaaS plan's default id-only MozaiksPay row among them).
    While a plan is being built it is not stored yet, so the pack ownership
    planning releases and validates is read from the plan's own rows here,
    through the same resolver assembly uses.
    """

    def __init__(self, base: Any, capability_packs: list[dict[str, Any]]) -> None:
        self._base = base
        self._plan = {"capability_packs": [dict(pack) for pack in capability_packs if isinstance(pack, dict)]}

    def get(self, key: str, default: Any = None) -> Any:
        if key == "app_build_plan":
            return self._plan
        return self._base.get(key, default)


def _pack_selection_context(context_variables: Any | None, capability_packs: list[dict[str, Any]]) -> Any | None:
    """The context pack ownership is read from while planning (see :class:`_PlanPackSelection`)."""
    if context_variables is None or not hasattr(context_variables, "get") or _context_get(
        context_variables, "capability_packs",
    ):
        return context_variables
    return _PlanPackSelection(context_variables, capability_packs)


def _context_available_pack_map(context_variables: Any | None) -> dict[str, dict[str, Any]]:
    raw_groups = [
        _context_get(context_variables, "capability_packs", []),
        _context_get(context_variables, "available_managed_capabilities", []),
    ]
    result: dict[str, dict[str, Any]] = {}
    for raw_packs in raw_groups:
        if not isinstance(raw_packs, list):
            continue
        for pack in raw_packs:
            if not isinstance(pack, dict):
                continue
            pack_id = str(pack.get("id") or pack.get("pack_id") or pack.get("capability_pack_id") or "").strip()
            if pack_id:
                result[pack_id] = {**result.get(pack_id, {}), **dict(pack)}
    return result


def _context_managed_capability_ids(context_variables: Any | None) -> frozenset[str]:
    if context_variables is None or not hasattr(context_variables, "get"):
        return frozenset()
    pack_ids: set[str] = set()
    for key in ("capability_packs", "available_managed_capabilities"):
        raw_packs = _context_get(context_variables, key, [])
        if not isinstance(raw_packs, list):
            continue
        for pack in raw_packs:
            if not isinstance(pack, dict):
                continue
            pack_id = str(pack.get("id") or pack.get("pack_id") or pack.get("capability_pack_id") or "").strip()
            if pack_id and str(pack.get("capability_source") or "").strip() == "managed_capability":
                pack_ids.add(pack_id)
    return frozenset(pack_ids)


def _pack_required_integrations(descriptor: dict[str, Any] | None) -> list[Any]:
    if not isinstance(descriptor, dict):
        return []
    raw = descriptor.get("required_integrations")
    if isinstance(raw, list):
        return list(raw)
    pack = descriptor.get("pack")
    if isinstance(pack, dict):
        raw = pack.get("required_integrations")
        if isinstance(raw, list):
            return list(raw)
    return []


def _merge_available_pack_defaults(
    item: dict[str, Any],
    available: dict[str, Any] | None,
) -> dict[str, Any]:
    from mozaiksai.builder.messaging import reconcile_messaging_configurations
    from mozaiksai.builder.storefront import reconcile_storefront_recipes

    recipe = reconcile_storefront_recipes(
        _pack_id_from_descriptor(item), item.get("storefront_recipe"), (available or {}).get("storefront_recipe"),
    )
    if recipe is not None:
        item = {**item, "storefront_recipe": recipe}
    messaging = reconcile_messaging_configurations(
        _pack_id_from_descriptor(item), item.get("messaging_configuration"),
        (available or {}).get("messaging_configuration"),
    )
    if messaging is not None:
        item = {**item, "messaging_configuration": messaging}
    if not isinstance(available, dict) or not available:
        return item
    merged = dict(item)
    for key in ("capabilities", "facades", "operator_contracts"):
        if not merged.get(key) and isinstance(available.get(key), list):
            merged[key] = list(available[key])

    if not merged.get("required_integrations"):
        required_integrations = _pack_required_integrations(available)
        if required_integrations:
            merged["required_integrations"] = required_integrations

    if not merged.get("pack_source_path") and available.get("pack_source_path"):
        merged["pack_source_path"] = available["pack_source_path"]
        # The source's pins travel with its path: an external source resolves only with them.
        for key in ("version", "digest"):
            if not merged.get(key) and available.get(key):
                merged[key] = available[key]
    if not merged.get("context_id") and available.get("context_id"):
        merged["context_id"] = available["context_id"]
    return merged


def _normalize_capability_pack_sources(
    capability_packs: list[dict[str, Any]],
    *,
    context_variables: Any | None,
) -> list[dict[str, Any]]:
    available_packs = _context_available_pack_map(context_variables)
    context_managed_capability_ids = _context_managed_capability_ids(context_variables)
    normalized: list[dict[str, Any]] = []
    for pack in capability_packs:
        item = dict(pack)
        pack_id = str(item.get("capability_pack_id") or item.get("id") or item.get("pack_id") or "").strip()
        source = str(item.get("capability_source") or "").strip()
        pack_type = str(item.get("pack_type") or "").strip()
        available = available_packs.get(pack_id) if pack_id else None
        available_source = str((available or {}).get("capability_source") or "").strip()
        item = _merge_available_pack_defaults(item, available)
        if not source and (pack_type == "managed_capability" or available_source == "managed_capability" or pack_id in context_managed_capability_ids):
            item["capability_source"] = "managed_capability"
        if item.get("capability_source") == "managed_capability":
            item.setdefault("implementation_mode", "external_integration")
            item.setdefault("surface_kind", "external_integration")
        normalized.append(item)
    return normalized


def _infer_managed_capability_ids_from_adapter_tasks(
    build_tasks: list[dict[str, Any]],
    *,
    context_variables: Any | None,
) -> frozenset[str]:
    available_packs = _context_available_pack_map(context_variables)
    inferred: set[str] = set()
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        if str(task.get("task_type") or "").strip() != "api_surface":
            continue
        if str(task.get("surface_kind") or "").strip() != "external_integration":
            continue
        for owned_path in _normalized_owned_paths(task):
            pack_id = _infer_pack_id_from_integration_path(owned_path)
            if not pack_id:
                continue
            available = available_packs.get(pack_id) or {}
            if available.get("capability_source") == "managed_capability":
                inferred.add(pack_id)
    return frozenset(inferred)


def _ensure_managed_capability_entries(
    capability_packs: list[dict[str, Any]],
    *,
    managed_capability_ids: frozenset[str],
    context_variables: Any | None,
) -> list[dict[str, Any]]:
    if not managed_capability_ids:
        return capability_packs
    available_packs = _context_available_pack_map(context_variables)
    existing = {
        str(pack.get("capability_pack_id") or pack.get("id") or pack.get("pack_id") or "").strip()
        for pack in capability_packs
        if isinstance(pack, dict)
    }
    result = [dict(pack) for pack in capability_packs]
    for pack_id in sorted(managed_capability_ids - existing):
        available = available_packs.get(pack_id) or {}
        result.append(
            {
                "capability_pack_id": pack_id,
                "surface_id": f"{pack_id}_managed",
                "surface_kind": "external_integration",
                "pack_type": "custom_domain",
                "label": available.get("display_name") or available.get("label") or pack_id,
                "summary": available.get("description") or f"Managed {pack_id} capability.",
                "implementation_mode": "external_integration",
                "primary_entities": [],
                "primary_pages": [],
                "operations": [
                    str(capability.get("capability_id") or "").strip()
                    for capability in available.get("capabilities") or []
                    if isinstance(capability, dict) and str(capability.get("capability_id") or "").strip()
                ],
                "required_integrations": _pack_required_integrations(available),
                "agentic_extensions": [],
                "capability_source": "managed_capability",
            }
        )
    return result


def _pack_id_from_descriptor(pack: dict[str, Any]) -> str:
    return _canonical_pack_id_from_descriptor(pack)


def _ensure_context_selected_capability_packs(
    capability_packs: list[dict[str, Any]],
    *,
    context_variables: Any | None,
) -> list[dict[str, Any]]:
    """Include packs projected by selected build_context even if the LLM omitted them."""
    selected_packs = {
        _pack_id_from_descriptor(pack): pack
        for pack in _normalize_object_list(_context_get(context_variables, "capability_packs", []))
        if _pack_id_from_descriptor(pack)
    }
    if not selected_packs:
        return capability_packs

    existing = {
        _pack_id_from_descriptor(pack)
        for pack in capability_packs
        if isinstance(pack, dict)
    } - {""}
    result = [dict(pack) for pack in capability_packs]
    for pack_id, descriptor in sorted(selected_packs.items()):
        if pack_id in existing:
            continue
        source = str(descriptor.get("capability_source") or "").strip()
        if (source not in {"managed_capability", "framework_pack", "operator_pack"}
                and descriptor.get("storefront_recipe") is None and descriptor.get("messaging_configuration") is None):
            continue
        managed = source == "managed_capability"
        item = dict(descriptor)
        item.setdefault("capability_pack_id", pack_id)
        item.setdefault("surface_id", str(item.get("surface_id") or pack_id))
        item.setdefault("surface_kind", "external_integration" if managed else "module")
        item.setdefault("implementation_mode", "external_integration" if managed else "declarative_module")
        item.setdefault("pack_type", "custom_domain")
        item.setdefault("label", item.get("display_name") or pack_id)
        item.setdefault("summary", item.get("description") or f"Selected {pack_id} capability.")
        result.append(item)
        existing.add(pack_id)
    return result


def _default_mozaikspay_descriptor(context_variables: Any | None) -> dict[str, Any]:
    """Return the public MozaiksPay pack descriptor used for SaaS defaults."""
    available_packs = _context_available_pack_map(context_variables)
    configured = available_packs.get(MOZAIKSPAY_PACK_ID)
    if isinstance(configured, dict):
        descriptor = dict(configured)
    else:
        import yaml

        from mozaiksai.builder.resources import resolve_packaged_build_context

        root = resolve_packaged_build_context(MOZAIKSPAY_PACK_ID)
        if root is None:
            raise FileNotFoundError("Installed mozaikspay contract is missing")
        contract_path = root / "contract.yaml"
        contract = yaml.safe_load(contract_path.read_text(encoding="utf-8")) or {}
        descriptor = {
            "id": MOZAIKSPAY_PACK_ID,
            "display_name": "MozaiksPay",
            "description": "Managed subscription billing provider for generated SaaS apps.",
            "provides_capabilities": contract.get("provides_capabilities") or [],
            "required_integrations": contract.get("required_integrations") or [],
            "facades": contract.get("facades") or [],
        }

    descriptor.setdefault("capability_pack_id", MOZAIKSPAY_PACK_ID)
    descriptor.setdefault("capability_source", "managed_capability")
    descriptor.setdefault("surface_id", "mozaikspay_managed")
    descriptor.setdefault("surface_kind", "external_integration")
    descriptor.setdefault("implementation_mode", "external_integration")
    descriptor.setdefault("pack_type", "mozaikspay")
    descriptor.setdefault("label", descriptor.get("display_name") or "MozaiksPay")
    descriptor.setdefault(
        "summary",
        descriptor.get("description") or "Managed subscription billing capability.",
    )
    return descriptor


def _subscription_contract_required(context_variables: Any | None) -> bool:
    """Whether the approved subscription contract makes this a subscription build."""
    if context_variables is None:
        return False
    contract = resolve_subscription_contract(context_variables)
    return contract is not None and contract.get("contract_required") is True


def _resolve_monetization_provider(
    capability_packs: list[dict[str, Any]],
    *,
    contract_required: bool,
    monetization_provider: str | None,
    context_variables: Any | None,
) -> tuple[list[dict[str, Any]], str | None]:
    """Resolve the provider from an explicit choice or selected provider pack."""
    if not contract_required:
        return capability_packs, monetization_provider

    selected_ids = {
        _pack_id_from_descriptor(pack)
        for pack in capability_packs
        if isinstance(pack, dict)
    } - {""}
    if monetization_provider == MOZAIKS_PAY_PROVIDER_ID and MOZAIKSPAY_PACK_ID not in selected_ids:
        return [*capability_packs, _default_mozaikspay_descriptor(context_variables)], monetization_provider
    if monetization_provider:
        return capability_packs, monetization_provider
    if SELF_MANAGED_PROVIDER_ID in selected_ids:
        return capability_packs, SELF_MANAGED_PROVIDER_ID
    if MOZAIKSPAY_PACK_ID in selected_ids:
        return capability_packs, MOZAIKS_PAY_PROVIDER_ID

    # Needing a subscription contract does not choose its assignment provider.
    # The validator returns bounded feedback when this judgment is still absent.
    return capability_packs, None


def _validate_monetization_provider_selection(
    capability_packs: list[dict[str, Any]],
    *,
    contract_required: bool,
    monetization_provider: str | None,
) -> None:
    """Validate the resolved SaaS subscription-assignment provider selection."""
    if not contract_required:
        if monetization_provider:
            raise ValueError(
                "AppBuildPlan.monetization_provider is only valid when the approved "
                "subscription contract has contract_required=true."
            )
        return

    existing_ids = {
        _pack_id_from_descriptor(pack)
        for pack in capability_packs
        if isinstance(pack, dict)
    } - {""}
    has_mozaikspay = MOZAIKSPAY_PACK_ID in existing_ids
    has_entitlement_dispatch = SELF_MANAGED_PROVIDER_ID in existing_ids
    managed_write_path_owners: list[str] = []
    for pack in capability_packs:
        if not isinstance(pack, dict):
            continue
        if str(pack.get("capability_source") or "").strip() != "managed_capability":
            continue
        inline = pack.get("provides_capabilities")
        if isinstance(inline, list) and SUBSCRIPTION_WRITE_PATH_CAPABILITY in inline:
            managed_write_path_owners.append(_pack_id_from_descriptor(pack))

    if not monetization_provider:
        raise ValueError(
            "AppBuildPlan.monetization_provider is required when the approved subscription "
            "contract has contract_required=true. "
            "Choose 'mozaiks_pay' for the managed MozaiksPay connector or "
            "'entitlement_dispatch' for the self-managed OSS assignment path."
        )
    if has_mozaikspay and has_entitlement_dispatch:
        raise ValueError(
            "MozaiksPay and entitlement_dispatch must not both be selected; "
            "only one subscription assignment write path may own config/subscriptions.yaml."
        )
    if len(set(managed_write_path_owners)) > 1:
        raise ValueError(
            "Multiple managed capability packs provide subscription_write_path: "
            f"{sorted(set(managed_write_path_owners))}. Select exactly one subscription assignment owner."
        )
    if monetization_provider == MOZAIKS_PAY_PROVIDER_ID:
        if not has_mozaikspay:
            raise ValueError(
                "AppBuildPlan.monetization_provider='mozaiks_pay' requires the "
                "mozaikspay managed capability pack to be explicitly selected."
            )
        if has_entitlement_dispatch:
            raise ValueError(
                "AppBuildPlan.monetization_provider='mozaiks_pay' cannot include entitlement_dispatch."
            )
        return
    if monetization_provider == SELF_MANAGED_PROVIDER_ID:
        if has_mozaikspay or managed_write_path_owners:
            raise ValueError(
                "AppBuildPlan.monetization_provider='entitlement_dispatch' cannot include "
                "MozaiksPay or another managed subscription_write_path owner."
            )
        if not has_entitlement_dispatch:
            raise ValueError(
                "AppBuildPlan.monetization_provider='entitlement_dispatch' requires the "
                "entitlement_dispatch pack to be explicitly selected."
            )
        return


def _pack_facades(descriptor: dict[str, Any]) -> list[dict[str, Any]]:
    facades = _normalize_object_list(descriptor.get("facades"))
    if facades:
        return facades
    pack_section = descriptor.get("pack")
    if isinstance(pack_section, dict):
        return _normalize_object_list(pack_section.get("facades"))
    return []


def _facade_pack_descriptor(
    facade: dict[str, Any],
    *,
    approved_surface: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    facade_id = str(facade.get("module_id") or facade.get("facade_id") or "").strip()
    if not facade_id:
        return None
    pages = _normalize_object_list(facade.get("pages"))
    operations = _dedupe_preserving_order(
        action
        for page in pages
        for action in _normalize_string_list(page.get("primary_actions"))
    )
    return {
        "capability_pack_id": facade_id,
        "surface_id": facade_id,
        "surface_kind": "module",
        "pack_type": "custom_domain",
        "label": facade.get("label") or facade_id.replace("_", " ").title(),
        "summary": facade.get("summary") or f"App-owned facade for {facade_id}.",
        "implementation_mode": "declarative_module",
        "capability_source": "generated_module",
        "primary_entities": _normalize_string_list(approved_surface.get("primary_entities"))
        if approved_surface is not None else _dedupe_preserving_order(
            entity
            for page in pages
            for entity in _normalize_string_list(page.get("primary_entities"))
        ),
        "primary_pages": [
            str(page.get("name") or page.get("page_id") or "").strip().lower().replace(" ", "_")
            for page in pages
            if str(page.get("name") or page.get("page_id") or "").strip()
        ],
        "operations": operations,
        # Connector setup belongs to the separate managed capability.
        "required_integrations": [],
    }


def _apply_selected_pack_files(
    *,
    capability_packs: list[dict[str, Any]],
    pages: list[dict[str, Any]],
    build_tasks: list[dict[str, Any]],
    context_variables: Any | None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Apply deterministic facade pages from selected packs."""
    available_packs = _context_available_pack_map(context_variables)
    if not available_packs:
        return capability_packs, pages, build_tasks

    def _merge_missing_page_metadata(target: dict[str, Any], source: dict[str, Any]) -> None:
        for key in (
            "page_type",
            "page_type_hint",
            "ui_layout",
            "shell_mode",
            "shell_mode_hint",
            "ui_surface",
            "design_intent",
            "primary_entities",
            "primary_actions",
        ):
            if key not in source:
                continue
            current = target.get(key)
            if current not in (None, "", [], {}):
                continue
            value = source.get(key)
            if value in (None, "", [], {}):
                continue
            target[key] = value

    selected_managed_capability_ids = {
        _pack_id_from_descriptor(pack)
        for pack in capability_packs
        if isinstance(pack, dict) and str(pack.get("capability_source") or "").strip() == "managed_capability"
    } - {""}
    if not selected_managed_capability_ids:
        return capability_packs, pages, build_tasks

    result_packs = [dict(pack) for pack in capability_packs]
    existing_pack_ids = {
        _pack_id_from_descriptor(pack)
        for pack in result_packs
        if isinstance(pack, dict)
    } - {""}

    result_pages = [dict(page) for page in pages]
    existing_page_routes = {
        str(page.get("route") or "").strip()
        for page in result_pages
        if isinstance(page, dict)
    } - {""}
    existing_page_names = {
        str(page.get("name") or page.get("page_id") or "").strip().lower()
        for page in result_pages
        if isinstance(page, dict)
    } - {""}

    result_tasks = [dict(task) for task in build_tasks]
    design = _context_get(context_variables, "design_surface_map", {}) or {}
    approved_surfaces = {
        surface["surface_id"]: surface
        for surface in design.get("surfaces") or []
        if surface.get("owner") == "app" and surface.get("surface_kind") == "module"
    }

    for pack_id in sorted(selected_managed_capability_ids):
        descriptor = available_packs.get(pack_id) or {}
        facades = _pack_facades(descriptor)
        for facade in facades:
            facade_id = str(facade.get("module_id") or facade.get("facade_id") or "").strip()
            approved_surface = approved_surfaces.get(facade_id)
            facade_pack = _facade_pack_descriptor(facade, approved_surface=approved_surface)
            if facade_pack:
                facade_pack_id = _pack_id_from_descriptor(facade_pack)
                if facade_pack_id not in existing_pack_ids:
                    result_packs.append(facade_pack)
                    existing_pack_ids.add(facade_pack_id)
                else:
                    for index, existing_pack in enumerate(result_packs):
                        if _pack_id_from_descriptor(existing_pack) == facade_pack_id:
                            merged = {**existing_pack, **facade_pack}
                            # The registry may project less page detail than the
                            # contract already applied during plan review.
                            merged["operations"] = _dedupe_preserving_order([
                                *_normalize_string_list(existing_pack.get("operations")),
                                *_normalize_string_list(facade_pack.get("operations")),
                            ])
                            existing_pages = _normalize_string_list(existing_pack.get("primary_pages"))
                            page_ids = {page.lower().replace(" ", "_") for page in existing_pages}
                            merged["primary_pages"] = existing_pages + [
                                page for page in facade_pack["primary_pages"]
                                if page.lower().replace(" ", "_") not in page_ids
                            ]
                            if approved_surface is None and "primary_entities" in existing_pack:
                                merged["primary_entities"] = existing_pack["primary_entities"]
                            result_packs[index] = merged
                            break

            for page in _normalize_object_list(facade.get("pages")):
                route = str(page.get("route") or "").strip()
                name = str(page.get("name") or page.get("page_id") or "").strip().lower()
                matched_page: dict[str, Any] | None = None
                if route and route in existing_page_routes:
                    for existing_page in result_pages:
                        if isinstance(existing_page, dict) and str(existing_page.get("route") or "").strip() == route:
                            matched_page = existing_page
                            break
                elif name and name in existing_page_names:
                    for existing_page in result_pages:
                        if not isinstance(existing_page, dict):
                            continue
                        existing_name = str(existing_page.get("name") or existing_page.get("page_id") or "").strip().lower()
                        if existing_name == name:
                            matched_page = existing_page
                            break
                if matched_page is not None:
                    _merge_missing_page_metadata(matched_page, page)
                    continue
                result_pages.append(page)
                if route:
                    existing_page_routes.add(route)
                if name:
                    existing_page_names.add(name)

    return result_packs, result_pages, sorted(result_tasks, key=_task_sort_key)


def _selected_managed_capability_descriptors(
    capability_packs: list[dict[str, Any]],
    *,
    context_variables: Any | None,
) -> dict[str, dict[str, Any]]:
    available_packs = _context_available_pack_map(context_variables)
    descriptors: dict[str, dict[str, Any]] = {}
    for pack in capability_packs:
        if not isinstance(pack, dict) or str(pack.get("capability_source") or "").strip() != "managed_capability":
            continue
        pack_id = _pack_id_from_descriptor(pack)
        if not pack_id:
            continue
        descriptor = dict(available_packs.get(pack_id) or pack)
        descriptors[pack_id] = descriptor
    return descriptors


def _managed_facade_route_rules(
    capability_packs: list[dict[str, Any]],
    *,
    context_variables: Any | None,
) -> dict[tuple[str, str], str]:
    rules: dict[tuple[str, str], str] = {}
    for pack_id, descriptor in _selected_managed_capability_descriptors(
        capability_packs,
        context_variables=context_variables,
    ).items():
        for facade in _pack_facades(descriptor):
            provider_module = str(facade.get("provider_module") or pack_id).strip()
            facade_module = str(facade.get("module_id") or facade.get("facade_id") or "").strip()
            if not provider_module or not facade_module:
                continue
            for action in facade.get("provider_actions") or []:
                action_id = str(action or "").strip()
                if action_id:
                    rules[(provider_module, action_id)] = facade_module
    return rules


def _route_page_data_sources_to_facades(value: Any, rules: dict[tuple[str, str], str]) -> Any:
    """Apply only explicitly registered provider-to-facade action bindings."""
    if isinstance(value, dict):
        rewritten: dict[str, Any] = {}
        for key, nested in value.items():
            if key == "data_source" and isinstance(nested, dict):
                source = dict(nested)
                module_id, action_id = source.get("module_id"), source.get("action_id")
                target = rules.get((module_id, action_id)) if isinstance(module_id, str) and isinstance(action_id, str) else None
                if target:
                    source["module_id"] = target
                rewritten[key] = source
            elif key == "config_hint" and isinstance(nested, str):
                rewritten[key] = json.dumps(_route_page_data_sources_to_facades(json.loads(nested), rules))
            else:
                rewritten[key] = _route_page_data_sources_to_facades(nested, rules)
        return rewritten
    if isinstance(value, list):
        return [_route_page_data_sources_to_facades(item, rules) for item in value]
    return value


def _strip_endpoint_hints(value: Any) -> Any:
    if isinstance(value, dict):
        mutation = value.get("action_type") in {"submit", "delete"}
        return {
            key: nested if key == "data_source" else _strip_endpoint_hints(nested)
            for key, nested in value.items()
            if key != "api_endpoint" and not (mutation and key == "href")
        }
    if isinstance(value, list):
        return [_strip_endpoint_hints(item) for item in value]
    return value


def _normalize_page_config_hints(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Discard authored endpoint hints; module/action choices remain authoritative."""
    normalized = []
    for page in pages:
        item = dict(page)
        if isinstance(page.get("sections_hint"), list):
            hints = []
            for index, section in enumerate(page["sections_hint"]):
                hint = dict(section)
                raw = hint.get("config_hint")
                if isinstance(raw, str):
                    try:
                        config = json.loads(raw)
                    except json.JSONDecodeError as exc:
                        page_name = page.get("name") or page.get("page_id") or "<unknown>"
                        section_name = hint.get("section_id_hint") or f"sections_hint[{index}]"
                        raise ValueError(
                            f"Page '{page_name}', section '{section_name}' has invalid config_hint JSON: {exc.msg}"
                        ) from exc
                    cleaned = _strip_endpoint_hints(config)
                    if cleaned != config:
                        hint["config_hint"] = json.dumps(cleaned)
                hints.append(hint)
            item["sections_hint"] = hints
        normalized.append(item)
    return normalized


def _normalize_managed_capability_page_bindings(
    pages: list[dict[str, Any]],
    *,
    capability_packs: list[dict[str, Any]],
    context_variables: Any | None,
) -> list[dict[str, Any]]:
    rules = _managed_facade_route_rules(
        capability_packs,
        context_variables=context_variables,
    )
    if not rules:
        return pages
    return [
        _route_page_data_sources_to_facades(dict(page), rules)
        for page in pages
        if isinstance(page, dict)
    ]


def _normalize_managed_capability_adapter_task_pack_ids(
    build_tasks: list[dict[str, Any]],
    *,
    managed_capability_ids: frozenset[str],
) -> list[dict[str, Any]]:
    if not managed_capability_ids:
        return build_tasks
    normalized: list[dict[str, Any]] = []
    for task in build_tasks:
        item = dict(task)
        if (
            str(item.get("task_type") or "").strip() == "api_surface"
            and str(item.get("surface_kind") or "").strip() == "external_integration"
        ):
            for owned_path in _normalized_owned_paths(item):
                inferred_pack_id = _infer_pack_id_from_integration_path(owned_path)
                if inferred_pack_id and inferred_pack_id in managed_capability_ids:
                    declared_id = str(item.get("capability_pack_id") or "").strip()
                    if declared_id != inferred_pack_id:
                        _logger.info(
                            "Normalized managed capability adapter task %s capability_pack_id from %r to %r based on %s",
                            item.get("task_id") or "<unknown>",
                            declared_id or None,
                            inferred_pack_id,
                            owned_path,
                        )
                        item["capability_pack_id"] = inferred_pack_id
                    break
        normalized.append(item)
    return normalized


def _normalize_page_task_dependencies(
    build_tasks: list[dict[str, Any]], *, pages: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Ensure page tasks explicitly depend on their app-owned module contract."""
    module_contract_by_pack: dict[str, str] = {}
    module_contract_task_ids: list[str] = []
    service_task_by_pack: dict[str, str] = {}
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        task_type = str(task.get("task_type") or "").strip()
        pack_id = str(task.get("capability_pack_id") or "").strip()
        task_id = str(task.get("task_id") or "").strip()
        if task_type == "module_contract" and pack_id and task_id:
            module_contract_by_pack.setdefault(pack_id, task_id)
        if task_type == "module_contract" and task_id:
            module_contract_task_ids.append(task_id)
        if task_type == "business_services" and pack_id and task_id:
            service_task_by_pack.setdefault(pack_id, task_id)

    normalized: list[dict[str, Any]] = []
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        item = dict(task)
        if str(item.get("task_type") or "").strip() == "page_bundle":
            pack_id = str(item.get("capability_pack_id") or "").strip()
            facade_task_id = module_contract_by_pack.get(pack_id)
            if not facade_task_id:
                deps = set(_normalize_string_list(item.get("depends_on")))
                candidate_packs = [
                    candidate_pack
                    for candidate_pack, service_task_id in service_task_by_pack.items()
                    if service_task_id in deps
                ]
                if len(candidate_packs) == 1:
                    facade_task_id = module_contract_by_pack.get(candidate_packs[0])
            if not facade_task_id and len(module_contract_task_ids) == 1:
                facade_task_id = module_contract_task_ids[0]
            if facade_task_id:
                deps = _normalize_string_list(item.get("depends_on"))  # type: ignore[assignment]
                if facade_task_id not in deps:
                    deps.insert(0, facade_task_id)  # type: ignore[attr-defined]
                item["depends_on"] = deps
            owned_paths = {normalize_app_path(str(path)) for path in item.get("owned_paths") or []}
            dependencies = _normalize_string_list(item.get("depends_on"))
            for page in pages or []:
                if planned_page_path(page) not in owned_paths:
                    continue
                for source in _iter_page_data_sources(page):
                    contract_task = module_contract_by_pack.get(source["module_id"])
                    if contract_task and contract_task not in dependencies:
                        dependencies.append(contract_task)
            item["depends_on"] = dependencies
        normalized.append(item)
    return normalized


def _normalize_facade_task_dependencies(
    build_tasks: list[dict[str, Any]],
    *,
    capability_packs: list[dict[str, Any]],
    managed_capability_ids: frozenset[str],
    context_variables: Any | None,
) -> list[dict[str, Any]]:
    """Connect only facade/provider bindings declared by registered contracts."""
    adapter_tasks_by_pack: dict[str, list[str]] = {}
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        if str(task.get("task_type") or "").strip() != "api_surface":
            continue
        pack_id = str(task.get("capability_pack_id") or "").strip()
        task_id = str(task.get("task_id") or "").strip()
        if task_id and pack_id in managed_capability_ids:
            adapter_tasks_by_pack.setdefault(pack_id, []).append(task_id)

    if not adapter_tasks_by_pack:
        return build_tasks

    registered = _context_available_pack_map(context_variables)
    facade_providers: dict[str, set[str]] = {}
    for pack in capability_packs:
        pack_id = _pack_id_from_descriptor(pack)
        if pack_id not in managed_capability_ids:
            continue
        for facade in _pack_facades(registered.get(pack_id) or {}):
            facade_id = str(facade.get("module_id") or facade.get("facade_id") or "").strip()
            if facade_id:
                facade_providers.setdefault(facade_id, set()).add(pack_id)

    normalized: list[dict[str, Any]] = []
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        item = dict(task)
        if str(item.get("task_type") or "").strip() == "module_contract":
            pack_id = str(item.get("capability_pack_id") or "").strip()
            if pack_id and pack_id not in managed_capability_ids:
                deps = _normalize_string_list(item.get("depends_on"))
                providers = facade_providers.get(pack_id, set())
                if len(providers) > 1:
                    raise ValueError(
                        f"Facade '{pack_id}' has competing registered providers {sorted(providers)}; "
                        "resolve the facade/provider ownership before planning dependencies."
                    )
                for provider in providers:
                    candidates = adapter_tasks_by_pack.get(provider, [])
                    if len(candidates) > 1 and not set(candidates).intersection(deps):
                        raise ValueError(
                            f"Facade '{pack_id}' has multiple adapter tasks for '{provider}': {candidates}; "
                            "declare the required adapter task dependency explicitly."
                        )
                    if len(candidates) == 1 and candidates[0] not in deps:
                        deps.insert(0, candidates[0])
                item["depends_on"] = deps
        normalized.append(item)
    return normalized


def _managed_capability_backing_module_ids(
    capability_packs: list[dict[str, Any]],
    *,
    context_variables: Any | None,
) -> frozenset[str]:
    available_packs = _context_available_pack_map(context_variables)
    module_ids: set[str] = set()
    managed_capability_ids = {
        str(pack.get("capability_pack_id") or pack.get("id") or pack.get("pack_id") or "").strip()
        for pack in capability_packs
        if isinstance(pack, dict) and pack.get("capability_source") == "managed_capability"
    } - {""}
    for pack_id in managed_capability_ids:
        available = available_packs.get(pack_id) or {}
        for key in ("backing_module",):
            value = str(available.get(key) or "").strip()
            if value:
                module_ids.add(value)
        for value in available.get("requires_modules") or []:
            value = str(value or "").strip()
            if value:
                module_ids.add(value)
        for capability in available.get("capabilities") or []:
            if isinstance(capability, dict):
                value = str(capability.get("module") or "").strip()
                if value:
                    module_ids.add(value)
    return frozenset(module_ids - managed_capability_ids)


def _iter_page_data_sources(
    value: Any,
    *,
    page_name: str | None = None,
    section_name: str = "<page>",
    forbidden_module_ids: frozenset[str] = frozenset(),
) -> Iterable[dict[str, str]]:
    if isinstance(value, dict):
        if page_name is None:
            page_name = str(value.get("name") or value.get("page_id") or "<unknown>")
        section_name = str(
            value.get("section_id_hint")
            or (value.get("id") if "primitive" in value else None)
            or section_name
        )
        location = f"Page '{page_name}', section '{section_name}'"
        if value.get("action_type") in {"submit", "delete"} and value.get("href") is not None:
            raise ValueError(f"{location}: mutations must select data_source {{module_id, action_id}}; endpoint URLs are rendered by code")
        for key, nested in value.items():
            if key == "api_endpoint" and nested is not None:
                raise ValueError(f"{location}: sections must select data_source {{module_id, action_id}}; endpoint URLs are rendered by code")
            if key == "data_source" and nested is not None:
                if (not isinstance(nested, dict) or set(nested) != {"module_id", "action_id"}
                        or any(not isinstance(v, str) or not v.strip() for v in nested.values())):
                    raise ValueError(f"{location}: data_source requires exactly module_id and action_id")
                if nested["module_id"] in forbidden_module_ids:
                    raise ValueError(
                        f"{location} binds data_source directly to managed "
                        f"module '{nested['module_id']}'. Managed capability pages must bind to an app-owned "
                        "facade module action instead."
                    )
                yield nested
            else:
                if key == "config_hint" and isinstance(nested, str):
                    nested = json.loads(nested)
                if key in {"sections", "sections_hint"} and isinstance(nested, list):
                    for index, section in enumerate(nested):
                        yield from _iter_page_data_sources(
                            section, page_name=page_name, section_name=f"{key}[{index}]",
                            forbidden_module_ids=forbidden_module_ids,
                        )
                else:
                    yield from _iter_page_data_sources(
                        nested, page_name=page_name, section_name=section_name,
                        forbidden_module_ids=forbidden_module_ids,
                    )
    elif isinstance(value, list):
        for item in value:
            yield from _iter_page_data_sources(
                item, page_name=page_name, section_name=section_name,
                forbidden_module_ids=forbidden_module_ids,
            )


def _validate_page_bindings(
    pages: list[dict[str, Any]],
    *,
    managed_capability_ids: frozenset[str],
    managed_capability_backing_module_ids: frozenset[str],
) -> None:
    forbidden_ids = managed_capability_ids | managed_capability_backing_module_ids
    for page in pages:
        list(_iter_page_data_sources(page, forbidden_module_ids=forbidden_ids))


def _managed_capability_reference_tokens(pack: dict[str, Any]) -> frozenset[str]:
    tokens: set[str] = set()
    pack_id = _pack_id_from_descriptor(pack)
    for value in [pack_id, pack.get("surface_id"), pack.get("label"), pack.get("display_name")]:
        for token in str(value or "").lower().replace("-", "_").split("_"):
            if len(token) >= 3:
                tokens.add(token)
    for operation in _normalize_string_list(pack.get("operations")):
        for token in operation.lower().replace(".", "_").replace("-", "_").split("_"):
            if len(token) >= 3:
                tokens.add(token)
    return frozenset(tokens)


def _page_reference_text(page: dict[str, Any]) -> str:
    values: list[str] = []
    for key in ("name", "page_id", "route", "purpose"):
        value = page.get(key)
        if value:
            values.append(str(value))
    for key in ("primary_entities", "primary_actions"):
        values.extend(_normalize_string_list(page.get(key)))
    return " ".join(values).lower().replace("-", "_")


def _managed_capability_is_user_facing(pack: dict[str, Any], pages: list[dict[str, Any]]) -> bool:
    if _normalize_string_list(pack.get("primary_pages")):
        return True
    tokens = _managed_capability_reference_tokens(pack)
    if not tokens:
        return False
    for page in pages:
        if not isinstance(page, dict):
            continue
        page_text = _page_reference_text(page)
        if any(token in page_text for token in tokens):
            return True
    return False


def _validate_user_facing_managed_capability_tasks(
    capability_packs: list[dict[str, Any]],
    pages: list[dict[str, Any]],
    build_tasks: list[dict[str, Any]],
    *,
    managed_capability_ids: frozenset[str],
    pack_paths: frozenset[str] = frozenset(),
) -> None:
    """A user-facing managed capability needs an app-owned facade and pages bound to it.

    The selected pack's templates may provide both (its facade ``module.yaml``
    and its pages); those are never model work, so no task is required for them.
    """
    if not managed_capability_ids or not pages:
        return
    template_facade = any(re.fullmatch(r"modules/[^/]+/module\.yaml", path) for path in pack_paths)
    authored_pages = [page for page in pages if planned_page_path(page) not in pack_paths]

    page_bundle_tasks = [
        task
        for task in build_tasks
        if isinstance(task, dict) and str(task.get("task_type") or "").strip() == "page_bundle"
    ]
    facade_module_tasks = [
        task
        for task in build_tasks
        if isinstance(task, dict)
        and str(task.get("task_type") or "").strip() == "module_contract"
        and str(task.get("capability_pack_id") or "").strip() not in managed_capability_ids
    ]

    for pack in capability_packs:
        if not isinstance(pack, dict) or str(pack.get("capability_source") or "").strip() != "managed_capability":
            continue
        pack_id = _pack_id_from_descriptor(pack)
        if not pack_id or pack_id not in managed_capability_ids:
            continue
        if not _managed_capability_is_user_facing(pack, pages):
            continue
        if not page_bundle_tasks and authored_pages:
            raise ValueError(
                f"Managed capability '{pack_id}' appears in page intent but no page_bundle build task was planned. "
                "User-facing managed capabilities must include a page_bundle task whose endpoints bind to an app-owned facade module."
            )
        if not facade_module_tasks and not template_facade:
            raise ValueError(
                f"Managed capability '{pack_id}' appears in page intent but no app-owned facade module_contract task was planned. "
                f"Do not generate modules/{pack_id}/. Plan a separate generated facade module and bind pages to that facade."
            )


def _validate_build_tasks(build_tasks: list[dict[str, Any]], managed_capability_ids: frozenset[str] | None = None) -> None:
    managed_capability_ids = managed_capability_ids or frozenset()
    for task in build_tasks:
        task_id = str(task.get("task_id") or "<unknown>")
        task_type = str(task.get("task_type") or "<missing>")
        if task_type == "agent_backend_integration":
            raise ValueError(
                f"Build task '{task_id}' uses retired task_type 'agent_backend_integration'. "
                "This type is non-materializing after module-interface retirement "
                "and is not valid AppGenerator build-task authority."
            )

        if task_type == "admin_config":
            raise ValueError(
                "Build task "
                f"'{task_id}' uses obsolete task_type 'admin_config'. "
                "Admin bootstrap lives in app/app.json admins; use module_contract for feature panels "
                "and api_surface for split service admin APIs."
            )

        if task_type not in _ALLOWED_TASK_TYPES:
            allowed = ", ".join(sorted(_ALLOWED_TASK_TYPES))
            raise ValueError(
                "Build task "
                f"'{task_id}' uses unsupported task_type '{task_type}'. "
                f"Use only the canonical AppGenerator task types: {allowed}."
            )

        initial_agent = str(task.get("initial_agent") or "<missing>")
        capability_pack_id = task.get("capability_pack_id")
        owned_paths = _normalized_owned_paths(task)
        surface_kind_raw = task.get("surface_kind")
        normalized_capability_pack_id = str(capability_pack_id or "").strip()

        if APP_AUTH_CONFIG_PATH in owned_paths:
            raise ValueError(
                f"Build task '{task_id}' cannot own {APP_AUTH_CONFIG_PATH}. "
                "The admitted app baseline or save_auth_scaffold owns auth; "
                "a generated task cannot grant permissions to itself or later tasks."
            )

        deployment_artifact_paths = _deployment_contract_artifact_paths(owned_paths)
        if deployment_artifact_paths:
            raise ValueError(
                "Build task "
                f"'{task_id}' owns deployment contract artifact path(s): "
                f"{deployment_artifact_paths}. AppBuildPlan build tasks must not own "
                "Dockerfile, docker-compose.yml, .env.example, .env.staging.example, "
                ".env.production.example, deployment.manifest.json, "
                "or .github/workflows/*. Deployment artifacts are emitted by the "
                "generate_and_download deployment contract renderer through DownloadRequest "
                "deployment_profile/include_* fields."
            )

        if normalized_capability_pack_id in managed_capability_ids:
            managed_capability_module_prefix = f"modules/{normalized_capability_pack_id}/"
            if task_type == "module_contract":
                raise ValueError(
                    "Build task "
                    f"'{task_id}' tries to generate module_contract files for managed capability "
                    f"'{normalized_capability_pack_id}'. Managed capabilities must use api_surface adapters "
                    "with surface_kind=external_integration, not app-local module ownership."
                )
            if any(path.replace("\\", "/").startswith(managed_capability_module_prefix) for path in owned_paths):
                raise ValueError(
                    "Build task "
                    f"'{task_id}' owns '{managed_capability_module_prefix}' for managed capability "
                    f"'{normalized_capability_pack_id}'. Managed capability adapters must use the app-bundle-relative "
                    "services/integrations/ lane, which assembles under app/services/integrations/."
                )
            if any(path.replace("\\", "/").startswith(_ADAPTERS_PREFIX) for path in owned_paths):
                raise ValueError(
                    "Build task "
                    f"'{task_id}' owns services/adapters/ for managed capability "
                    f"'{normalized_capability_pack_id}'. Managed capability adapters must be thin API clients under "
                    "app-bundle-relative services/integrations/."
                )
            if task_type == "service_foundation":
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses service_foundation for managed capability "
                    f"'{normalized_capability_pack_id}'. Managed capabilities must use api_surface adapters under "
                    "app-bundle-relative services/integrations/."
                )
            if task_type == "api_surface" and surface_kind_raw and surface_kind_raw != "external_integration":
                raise ValueError(
                    f"Build task '{task_id}' is an adapter for managed capability '{normalized_capability_pack_id}' "
                    f"but declares surface_kind='{surface_kind_raw}'. "
                    "Managed capability adapter tasks must use surface_kind='external_integration'."
                )

        if surface_kind_raw == _WORKFLOW_SURFACE_KIND:
            raise ValueError(
                f"Build task '{task_id}' declares surface_kind='workflow'. "
                "Workflow surfaces are owned by AgentGenerator, not AppGenerator. "
                "Remove this task from AppBuildPlan and use a workflow_touchpoint entry instead."
            )

        if surface_kind_raw in _SURFACE_KIND_ALLOWED_TASK_TYPES:
            permitted = _SURFACE_KIND_ALLOWED_TASK_TYPES[surface_kind_raw]
            if task_type not in permitted:
                permitted_str = ", ".join(sorted(permitted))
                raise ValueError(
                    f"Build task '{task_id}' uses task_type='{task_type}' with "
                    f"surface_kind='{surface_kind_raw}'. Only these task types are valid "
                    f"for surface_kind='{surface_kind_raw}': {permitted_str}."
                )

        if task_type == "page_bundle" and initial_agent != "AppSchemaAgent":
            raise ValueError(
                "Build task "
                f"'{task_id}' assigns persistent page output to a non-schema owner "
                f"({initial_agent}). `page_bundle` must start at AppSchemaAgent and emit "
                "declarative pages or the typed custom route bundle."
            )
        if "admin/admin_registry.yaml" in owned_paths and task_type != "page_bundle":
            raise ValueError(
                f"'{task_id}' owns admin/admin_registry.yaml; only AppSchemaAgent/page_bundle "
                "may materialize this typed registry."
            )
        if any(_page_stem_from_path(path) for path in owned_paths) and task_type != "page_bundle":
            raise ValueError(
                f"Build task '{task_id}' owns declarative ui/pages/*.yaml artifacts; "
                "these require task_type='page_bundle' and initial_agent='AppSchemaAgent'."
            )

        if task_type in _MODULE_LOCAL_TASK_TYPES:
            if not normalized_capability_pack_id:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses task_type '{task_type}' but capability_pack_id is null. "
                    "Module-local tasks must identify the generated module folder."
                )
            module_prefix = f"modules/{normalized_capability_pack_id}/"
            invalid_module_paths = [
                path
                for path in owned_paths
                if not path.replace("\\", "/").startswith(module_prefix)
            ]
            if invalid_module_paths:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' owns paths outside module '{normalized_capability_pack_id}': "
                    f"{invalid_module_paths}."
                )

            backend_paths = [
                path
                for path in owned_paths
                if "/backend/" in path.replace("\\", "/")
            ]
            if task_type == "module_contract" and backend_paths:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' mixes module contract YAML with backend Python files: "
                    f"{backend_paths}. `module_contract` tasks must emit module.yaml, contracts/*, "
                    "and optional runtime_extensions.yaml only. Use `data_models` and "
                    "`business_services` tasks for backend Python."
                )

            if task_type == "data_models":
                expected = f"{module_prefix}backend/schemas.py"
                invalid = [
                    path
                    for path in owned_paths
                    if path.replace("\\", "/") != expected
                ]
                if invalid:
                    raise ValueError(
                        "Build task "
                        f"'{task_id}' uses task_type 'data_models' but owns non-schema paths: "
                        f"{invalid}. `data_models` tasks may only own {expected}."
                    )

            if task_type == "business_services":
                schemas_path = f"{module_prefix}backend/schemas.py"
                invalid = [
                    path
                    for path in owned_paths
                    if not path.replace("\\", "/").startswith(f"{module_prefix}backend/")
                    or path.replace("\\", "/") == schemas_path
                ]
                if invalid:
                    raise ValueError(
                        "Build task "
                        f"'{task_id}' uses task_type 'business_services' but owns invalid "
                        f"backend paths: {invalid}. `business_services` tasks own handler.py, "
                        "service.py, repo.py, policy.py, and declared hooks; schemas.py belongs "
                        "to the `data_models` task."
                    )

        if task_type == "data_migrations":
            if not normalized_capability_pack_id:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses task_type 'data_migrations' but capability_pack_id is null. "
                    "data_migrations tasks must identify the owning capability pack."
                )
            invalid = [
                path
                for path in owned_paths
                if not path.replace("\\", "/").startswith(_DATA_MIGRATIONS_PREFIX)
            ]
            if invalid:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses task_type 'data_migrations' but owns paths outside "
                    f"'{_DATA_MIGRATIONS_PREFIX}': {invalid}. "
                    "`data_migrations` tasks may only own data/migrations/*.json files."
                )

        # Managed-capability adapter tasks must declare capability_pack_id so that template
        # expansion (resolve_managed_capability_templates) can locate the correct pack template.
        # This check fires only when the path pattern matches a known managed capability
        # (e.g. services/integrations/provider_client.py -> inferred pack id "provider").
        if (
            task_type == "api_surface"
            and surface_kind_raw == "external_integration"
            and not normalized_capability_pack_id
        ):
            for owned_path in owned_paths:
                inferred_pack_id = _infer_pack_id_from_integration_path(owned_path)
                if inferred_pack_id and inferred_pack_id in managed_capability_ids:
                    raise ValueError(
                        f"Build task '{task_id}' generates '{owned_path}' for managed_capability "
                        f"'{inferred_pack_id}' but has capability_pack_id=null. "
                        f"Set capability_pack_id: '{inferred_pack_id}' so that "
                        "resolve_managed_capability_templates can locate the managed capability template. "
                        "The capability_pack_id on api_surface adapter tasks identifies "
                        "which managed capability template to copy into the generated app."
                    )

        raw_frontend_path = _raw_frontend_source_path(task)
        if raw_frontend_path:
            raise ValueError(
                "Build task "
                f"'{task_id}' plans raw frontend source output ('{raw_frontend_path}'). "
                "Persistent app UI must compile through AppSchemaAgent/page_bundle plus "
                "shell/theme artifacts. A custom JSX page requires the same page_bundle "
                "to own its ui/route_manifest.json and ui/index.js. Other raw frontend source is not allowed."
            )

        # Plan review strips a leading workspace app/ from owned paths, so the
        # bundle-relative spelling is the same obsolete file.
        if {_OBSOLETE_HOST_ADMIN_CONFIG_PATH, _OBSOLETE_HOST_ADMIN_CONFIG_PATH.removeprefix("app/")} & set(owned_paths):
            raise ValueError(
                "Build task "
                f"'{task_id}' owns obsolete path '{_OBSOLETE_HOST_ADMIN_CONFIG_PATH}'. "
                "Admin bootstrap lives in app/app.json admins; do not generate app/config/admin.json."
            )

        has_app_service_admin_path = bool(_APP_SERVICE_ADMIN_PATHS.intersection(owned_paths))
        if has_app_service_admin_path:
            if task_type != "api_surface":
                raise ValueError(
                    "Build task "
                    f"'{task_id}' owns split service admin files but uses task_type '{task_type}'. "
                    "Use the explicit api_surface task for services/admin_config.py + services/routes/admin.py."
                )
            if initial_agent != "ControllerAgent":
                raise ValueError(
                    "Build task "
                    f"'{task_id}' assigns split service admin files to {initial_agent}. "
                    "`api_surface` must start at ControllerAgent."
                )
            if capability_pack_id is not None:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' must keep capability_pack_id null for app-level split admin APIs."
                )
            if _required_selected_task_paths(task).difference(owned_paths):
                raise ValueError(
                    "Build task "
                    f"'{task_id}' must own both services/admin_config.py and services/routes/admin.py together."
                )

        legacy_paths = disallowed_legacy_app_paths(owned_paths)
        if legacy_paths:
            raise ValueError(
                "Build task "
                f"'{task_id}' owns removed app path(s) that are no longer canonical: "
                f"{legacy_paths}. Use data/contract.json, data/migrations/*.json, "
                f"and {APP_SECURITY_SECRETS_PATH}."
            )

        invalid_roots = noncanonical_app_root_paths(owned_paths)
        if invalid_roots:
            raise ValueError(
                "Build task "
                f"'{task_id}' owns path(s) outside canonical app planes: {invalid_roots}. "
                "Allowed app-root planes are admin, backend, brand, config, dashboard, "
                "data, modules, refinement_harness, security, services, and ui, plus "
                f"canonical root files such as app.json and {APP_PROVENANCE_PATH}."
            )

        invalid_config_paths = noncanonical_app_config_paths(owned_paths)
        if invalid_config_paths:
            raise ValueError(
                "Build task "
                f"'{task_id}' owns noncanonical app config path(s): {invalid_config_paths}. "
                "Use config/ai.json, config/shell.json, config/asset_manifest.json, "
                "config/refinement_policy.yaml, config/subscriptions.yaml, config/targets.json, "
                "or safe metadata under config/integrations/."
            )

        invalid_service_paths = _noncanonical_service_paths(owned_paths)
        if invalid_service_paths:
            raise ValueError(
                "Build task "
                f"'{task_id}' owns noncanonical services path(s): {invalid_service_paths}. "
                "Use services/integrations/, services/adapters/, services/routes/, or "
                "services/config.py. Data and security are first-class planes under "
                f"data/ and {APP_SECURITY_SECRETS_PATH}."
            )

        if task_type == "service_foundation":
            invalid_foundation_paths = _invalid_service_foundation_paths(owned_paths)
            if invalid_foundation_paths:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses service_foundation but owns non-service-foundation "
                    f"path(s): {invalid_foundation_paths}. service_foundation may only own "
                    "services/config.py, services/integrations/, services/adapters/, "
                    f"services/routes/, and {APP_SECURITY_SECRETS_PATH}."
                )

        if task_type == "refinement_harness":
            if normalized_capability_pack_id:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses task_type 'refinement_harness' but capability_pack_id is not null. "
                    "Refinement harnesses are app-level artifacts, not capability-pack modules."
                )
            if surface_kind_raw != "refinement":
                raise ValueError(
                    "Build task "
                    f"'{task_id}' uses task_type 'refinement_harness' but surface_kind is "
                    f"'{surface_kind_raw}'. Use surface_kind='refinement'."
                )
            invalid = [
                path
                for path in owned_paths
                if path not in _REFINEMENT_CONFIG_PATHS
                and not (
                    path.startswith("refinement_harness/prompts/")
                    and PurePosixPath(path).suffix == ".yaml"
                )
            ]
            if invalid:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' owns invalid refinement harness paths: {invalid}. "
                    "Refinement harness tasks may only own config/refinement_policy.yaml, "
                    "refinement_harness/config/*, and refinement_harness/prompts/*.yaml."
                )
            missing = sorted(_required_selected_task_paths(task).difference(owned_paths))
            if missing:
                raise ValueError(
                    "Build task "
                    f"'{task_id}' is missing required refinement harness paths: {missing}."
                )

        expected_initial_agent = _CANONICAL_INITIAL_AGENTS.get(task_type)
        if expected_initial_agent and initial_agent != expected_initial_agent:
            raise ValueError(
                "Build task "
                f"'{task_id}' assigns task_type '{task_type}' to {initial_agent}. "
                f"`{task_type}` must start at {expected_initial_agent}."
            )


def _validate_unique_owned_paths(build_tasks: list[dict[str, Any]]) -> None:
    owners_by_path: dict[str, list[str]] = {}
    for task in build_tasks:
        if not isinstance(task, dict):
            continue
        task_id = str(task.get("task_id") or "<unknown>").strip()
        for path in _normalized_owned_paths(task):
            if path in _SHARED_OWNED_PATHS:
                continue
            owners_by_path.setdefault(path, []).append(task_id)

    duplicates = {
        path: _dedupe_preserving_order(task_ids)
        for path, task_ids in owners_by_path.items()
        if len(set(task_ids)) > 1
    }
    if duplicates:
        raise ValueError(
            "Build tasks declare overlapping owned_paths: "
            f"{duplicates}. Each generated artifact must have one owner task; "
            "merge the work or split paths so task batches cannot race."
        )


def _validate_carry_forward_decisions(
    decisions: list[dict[str, Any]],
    task_ids: frozenset[str],
) -> None:
    """Validate carry_forward_decisions entries.

    Rules:
    - module_id must be a non-empty string.
    - decision must be one of: reuse, adapt, regenerate, drop.
    - reason must be non-empty.
    - source must be one of: carry_forward_candidate, human_override, planner.
    - affected_build_tasks entries must reference existing task ids when provided.
    """
    for i, decision in enumerate(decisions):
        if not isinstance(decision, dict):
            raise ValueError(
                f"carry_forward_decisions[{i}] must be a dict, got {type(decision).__name__}"
            )
        label = f"carry_forward_decisions[{i}]"

        module_id = str(decision.get("module_id") or "").strip()
        if not module_id:
            raise ValueError(f"{label}: module_id must be a non-empty string")

        decision_value = str(decision.get("decision") or "").strip()
        if decision_value not in _CARRY_FORWARD_DECISION_VALUES:
            allowed = ", ".join(sorted(_CARRY_FORWARD_DECISION_VALUES))
            raise ValueError(
                f"{label} (module_id={module_id!r}): decision must be one of [{allowed}], "
                f"got {decision_value!r}"
            )

        reason = str(decision.get("reason") or "").strip()
        if not reason:
            raise ValueError(
                f"{label} (module_id={module_id!r}): reason must be a non-empty string"
            )

        source = str(decision.get("source") or "").strip()
        if source and source not in _CARRY_FORWARD_SOURCE_VALUES:
            allowed_src = ", ".join(sorted(_CARRY_FORWARD_SOURCE_VALUES))
            raise ValueError(
                f"{label} (module_id={module_id!r}): source must be one of [{allowed_src}], "
                f"got {source!r}"
            )

        affected = decision.get("affected_build_tasks")
        if affected:
            if not isinstance(affected, list):
                raise ValueError(
                    f"{label} (module_id={module_id!r}): "
                    "affected_build_tasks must be a list when provided"
                )
            unknown = [t for t in affected if isinstance(t, str) and t not in task_ids]
            if unknown:
                raise ValueError(
                    f"{label} (module_id={module_id!r}): "
                    f"affected_build_tasks references unknown task ids: {unknown}. "
                    "Task ids must exist in build_tasks."
                )


def _validate_task_dependencies(
    build_tasks: list[dict[str, Any]],
    task_ids: frozenset[str],
) -> None:
    """Validate depends_on references on build tasks.

    Rules:
    - depends_on must be a list when provided.
    - Every entry in depends_on must reference a task_id that exists in
      build_tasks. Unknown references indicate typos or missing tasks and
      will produce broken generation ordering at runtime.
    """
    for task in build_tasks:
        task_id = str(task.get("task_id") or "<unknown>")
        depends_on = task.get("depends_on")

        if depends_on is None:
            continue

        if not isinstance(depends_on, list):
            raise ValueError(
                f"Build task '{task_id}': depends_on must be a list when provided."
            )

        unknown = [
            d for d in depends_on
            if isinstance(d, str) and d not in task_ids
        ]
        if unknown:
            raise ValueError(
                f"Build task '{task_id}': depends_on references unknown task "
                f"ids: {unknown}. All depends_on entries must reference "
                "task_ids declared in build_tasks."
            )


def app_build_plan(
    *,
    AppBuildPlan: Annotated[
        dict[str, Any] | None,
        Field(description="Canonical app build plan emitted by AppPlanAgent."),
    ],
    context_variables: Annotated[
        Any | None,
        Field(description="AG2-injected workflow context variables."),
    ] = None,
) -> str:
    invalidate_requirement_plan(context_variables)
    AppBuildPlan = detach(AppBuildPlan)
    if not AppBuildPlan or not isinstance(AppBuildPlan, dict):
        raise ValueError("AppBuildPlan payload is required and must be a dictionary")
    AppBuildPlan = _unwrap_app_build_plan_payload(AppBuildPlan)
    if "data_contract" in AppBuildPlan:
        raise ValueError(
            "AppBuildPlan must not author data_contract; use the approved DesignDocs data_contract from context."
        )

    agent_message = str(AppBuildPlan.get("agent_message") or "").strip()
    app_kind = str(AppBuildPlan.get("app_kind") or "").strip()
    pages = _normalize_object_list(AppBuildPlan.get("pages"))
    entities = _normalize_object_list(AppBuildPlan.get("entities"))
    roles = _normalize_string_list(AppBuildPlan.get("roles"))
    auth_strategy = AppBuildPlan.get("auth_strategy")
    auth_required_from_strategy(auth_strategy, roles=roles, field="AppBuildPlan.auth_strategy")
    service_scope = _normalize_string_list(AppBuildPlan.get("service_scope"))
    frontend_scope = _normalize_string_list(AppBuildPlan.get("frontend_scope"))
    theme_preferences = AppBuildPlan.get("theme_preferences")
    brand_intent = AppBuildPlan.get("brand_intent")
    _valid_profile_layouts = frozenset({"sidebar_left", "top_nav", "drawer", "icon_rail"})
    profile_layout = str(AppBuildPlan.get("profile_layout") or "").strip() or None
    if profile_layout and profile_layout not in _valid_profile_layouts:
        profile_layout = None
    readiness_profile = _infer_readiness_profile(AppBuildPlan, context_variables=context_variables)
    _raw_monetization_provider = AppBuildPlan.get("monetization_provider") or (
        (AppBuildPlan.get("monetization_plan") or {}).get("monetization_provider")
    )
    monetization_provider = normalize_monetization_provider(_raw_monetization_provider)
    capability_packs = _ensure_context_selected_capability_packs(
        _normalize_object_list(AppBuildPlan.get("capability_packs")),
        context_variables=context_variables,
    )
    capability_packs = _normalize_capability_pack_sources(
        capability_packs,
        context_variables=context_variables,
    )
    external_integrations = _normalize_object_list(AppBuildPlan.get("external_integrations"))
    build_tasks = _merge_persistence_contract_tasks(
        sorted(
            [
                _normalize_build_task_identity(task)
                for task in _normalize_object_list(AppBuildPlan.get("build_tasks"))
            ],
            key=_task_sort_key,
        ),
        requirement_deliveries=AppBuildPlan.get("requirement_deliveries"),
    )
    contract_required = _subscription_contract_required(context_variables)
    capability_packs, monetization_provider = _resolve_monetization_provider(
        capability_packs,
        contract_required=contract_required,
        monetization_provider=monetization_provider,
        context_variables=context_variables,
    )
    capability_packs = _normalize_capability_pack_sources(
        capability_packs,
        context_variables=context_variables,
    )
    inferred_managed_capability_ids = _infer_managed_capability_ids_from_adapter_tasks(
        build_tasks,
        context_variables=context_variables,
    )
    if inferred_managed_capability_ids:
        capability_packs = _ensure_managed_capability_entries(
            capability_packs,
            managed_capability_ids=inferred_managed_capability_ids,
            context_variables=context_variables,
        )
        capability_packs = _normalize_capability_pack_sources(
            capability_packs,
            context_variables=context_variables,
        )
        build_tasks = _normalize_managed_capability_adapter_task_pack_ids(
            build_tasks,
            managed_capability_ids=inferred_managed_capability_ids,
        )
    capability_packs = _normalize_capability_pack_sources(
        capability_packs,
        context_variables=context_variables,
    )
    pending_schema_migration = AppBuildPlan.get("pending_schema_migration")
    generation_order = _normalize_string_list(AppBuildPlan.get("generation_order"))
    agent_backend_required = bool(AppBuildPlan.get("agent_backend_required", False))
    carry_forward_decisions = _normalize_object_list(AppBuildPlan.get("carry_forward_decisions"))
    demo_fixture_sets = _normalize_object_list(AppBuildPlan.get("demo_fixture_sets"))

    managed_capability_ids = frozenset(
        _pack_id_from_descriptor(p)
        for p in capability_packs
        if isinstance(p, dict) and p.get("capability_source") == "managed_capability"
    ) - {""}
    capability_packs, pages, build_tasks = _apply_selected_pack_files(
        capability_packs=capability_packs,
        pages=pages,
        build_tasks=build_tasks,
        context_variables=context_variables,
    )
    # The cached plan never schedules model work for an output or facade module a selected pack owns,
    # including a pack only this plan selects (the build context selecting none).
    pack_selection = _pack_selection_context(context_variables, capability_packs)
    released: dict[str, Any] = {"build_tasks": build_tasks, "generation_order": generation_order,
                               "requirement_deliveries": AppBuildPlan.get("requirement_deliveries")}
    for repair in (
        *release_pack_owned_paths(released, pack_selection),
        *release_pack_facade_paths(released, pack_selection),
        *release_subscriptions_config(released),
    ):
        _logger.info("[AppGenerator] plan normalized: %s", repair)
    build_tasks, generation_order = released["build_tasks"], released["generation_order"]
    pages = _normalize_page_config_hints(pages)
    pages = _normalize_managed_capability_page_bindings(
        pages,
        capability_packs=capability_packs,
        context_variables=context_variables,
    )
    managed_capability_ids = frozenset(
        _pack_id_from_descriptor(p)
        for p in capability_packs
        if isinstance(p, dict) and p.get("capability_source") == "managed_capability"
    ) - {""}
    build_tasks = _normalize_page_task_dependencies(build_tasks, pages=pages)
    build_tasks = _normalize_facade_task_dependencies(
        build_tasks,
        capability_packs=capability_packs,
        managed_capability_ids=managed_capability_ids,
        context_variables=context_variables,
    )
    build_tasks = _reserve_module_event_contract_paths(build_tasks)
    managed_capability_backing_module_ids = _managed_capability_backing_module_ids(
        capability_packs,
        context_variables=context_variables,
    )
    _validate_build_tasks(build_tasks, managed_capability_ids=managed_capability_ids)
    _validate_unique_owned_paths(build_tasks)
    _validate_page_bindings(
        pages,
        managed_capability_ids=managed_capability_ids,
        managed_capability_backing_module_ids=managed_capability_backing_module_ids,
    )
    _validate_user_facing_managed_capability_tasks(
        capability_packs,
        pages,
        build_tasks,
        managed_capability_ids=managed_capability_ids,
        pack_paths=pack_owned_output_paths(pack_selection),
    )
    _validate_monetization_provider_selection(
        capability_packs,
        contract_required=contract_required,
        monetization_provider=monetization_provider,
    )

    task_ids: frozenset[str] = frozenset(
        str(t.get("task_id") or "") for t in build_tasks if t.get("task_id")
    )
    _validate_task_dependencies(build_tasks, task_ids=task_ids)
    if carry_forward_decisions:
        _validate_carry_forward_decisions(carry_forward_decisions, task_ids=task_ids)

    if not app_kind:
        raise ValueError("AppBuildPlan.app_kind is required")
    if not pages:
        raise ValueError("AppBuildPlan.pages must contain at least one page")

    task_batch_items: list[dict[str, Any]] = []
    normalized_build_tasks: list[dict[str, Any]] = []
    for task in build_tasks:
        normalized_task = dict(task)
        normalized_context = _normalize_context_variables(normalized_task.get("context_variables"))
        if normalized_context is not None:
            normalized_task["context_variables"] = normalized_context
        task_id = str(normalized_task.get("task_id") or "").strip()
        task_type = str(normalized_task.get("task_type") or "").strip()
        item = {
            **normalized_task,
            "task_run_mode": True,
            "current_build_task_id": task_id,
            "current_build_task_type": task_type,
            "current_build_task": dict(normalized_task),
        }
        task_batch_items.append(item)
        normalized_build_tasks.append(normalized_task)

    normalized_plan = {
        **AppBuildPlan,
        "agent_message": agent_message or "App build plan cached successfully.",
        "app_kind": app_kind,
        "pages": pages,
        "entities": entities,
        "roles": roles,
        "auth_strategy": auth_strategy,
        "service_scope": service_scope,
        "frontend_scope": frontend_scope,
        "theme_preferences": theme_preferences,
        "brand_intent": brand_intent if isinstance(brand_intent, dict) else None,
        "profile_layout": profile_layout,
        "readiness_profile": readiness_profile,
        "monetization_provider": monetization_provider,
        "capability_packs": capability_packs,
        "external_integrations": external_integrations,
        "agent_backend_required": agent_backend_required,
        "build_tasks": normalized_build_tasks,
        "pending_schema_migration": pending_schema_migration if isinstance(pending_schema_migration, dict) else None,
        "generation_order": generation_order,
        "carry_forward_decisions": carry_forward_decisions,
        "demo_fixture_sets": demo_fixture_sets,
    }

    normalized_plan["requirement_accounting"] = compile_requirement_delivery(normalized_plan, context_variables)

    if context_variables is not None and hasattr(context_variables, "set"):
        try:
            context_variables.set("app_build_plan", normalized_plan)
            context_variables.set("app_plan_ready", True)
            context_variables.set("app_task_batch_items", task_batch_items)
            context_variables.set("app_task_batch_status", "planned")
            _logger.info(
                "Cached AppBuildPlan: kind=%s pages=%d entities=%d packs=%d build_tasks=%d integrations=%d batch_items=%d",
                app_kind,
                len(pages),
                len(entities),
                len(capability_packs),
                len(build_tasks),
                len(external_integrations),
                len(task_batch_items),
            )
        except Exception as exc:
            _logger.error("Failed to cache AppBuildPlan: %s", exc)
            return f"Error caching AppBuildPlan: {exc}"
    else:
        _logger.warning("context_variables not available or missing 'set' method")

    return (
        f"{normalized_plan['agent_message']}\n\n"
        f"App kind: {app_kind}\n"
        f"Pages: {len(pages)}\n"
        f"Entities: {len(entities)}\n"
        f"Capability packs: {len(capability_packs)}\n"
        f"Build tasks: {len(build_tasks)}\n"
        f"Task batch items: {len(task_batch_items)}\n"
        f"Roles: {len(roles)}\n"
        f"Agent backend required: {agent_backend_required}\n"
        f"Integrations: {len(external_integrations)}"
    )


__all__ = ["app_build_plan"]

