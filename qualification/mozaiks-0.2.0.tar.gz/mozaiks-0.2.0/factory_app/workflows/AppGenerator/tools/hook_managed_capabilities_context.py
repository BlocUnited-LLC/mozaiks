"""
Hook: Inject Selected Capability Ownership Context

Fires as an prompt middleware function on AppPlanAgent.

When ``capability_packs`` is present and non-empty in context_variables
(populated by an operator at launch), this hook injects a compact
[MANAGED CAPABILITIES CONTEXT] block into the AppPlanAgent system message.

Each selected descriptor retains its declared capability_source. Managed-provider
restrictions apply only to managed_capability entries; app-owned modules use
deterministic pack/template/schema outputs before bounded custom generation.

When capability_packs is null or empty this hook is a complete no-op.
The block is never injected and factory workflow behaviour is unchanged.
"""

from __future__ import annotations

import logging
from typing import Any

from factory_app.workflows._shared.hook_utils import update_agent_section
from mozaiksai.core.workflow.context.frozen import detach

logger = logging.getLogger(__name__)

_MANAGED_CAP_HEADER = "[MANAGED CAPABILITIES CONTEXT]"

# ---------------------------------------------------------------------------
# Guidance for the existing AppCapabilityPack capability_source values.
# ---------------------------------------------------------------------------

_CAPABILITY_SOURCE_GUIDANCE = {
    "host_universal": (
        "Built-in platform behavior. Reference the runtime; do not scaffold its internals."
    ),
    "managed_capability": (
        "Managed provider: do not generate modules/{capability_pack_id}/ or provider internals. "
        "Use its declared app-owned facade actions and managed API client."
    ),
    "framework_pack": (
        "Reuse the registered framework pack's declared outputs; generate only its permitted app-specific difference."
    ),
    "generated_module": (
        "Deliver complete app-owned module behavior: deterministic pack/template/schema outputs first, "
        "then bounded custom generation only for the missing difference. This source is not a hosted provider."
    ),
    "operator_pack": (
        "Retain operator_pack ownership and compose its declared templates and contracts; "
        "generate only the permitted app-specific difference."
    ),
    "external_adapter": (
        "Generate declared adapter/client wiring only; the explicitly selected external system owns its internals."
    ),
    "config_file": "Use the registered declarative configuration outputs, not an invented backend module.",
    "operator_extension": "Use the registered operator extension's declared boundary and permitted wiring.",
}


def _is_empty(value: Any) -> bool:
    """Return True if value is None, empty list, or empty dict."""
    if value is None:
        return True
    if isinstance(value, (list, dict)):
        return len(value) == 0
    return False


def _format_managed_capabilities(packs: list[Any]) -> str:
    lines = [
        "Selected capabilities and declared ownership:",
        "Preserve each resolved capability_pack_id and capability_source; category names confer no ownership.",
    ]
    for pack in packs:
        if isinstance(pack, dict):
            pack_id = pack.get("id") or pack.get("pack_id") or "<unresolved>"
            label = pack.get("display_name") or pack.get("label") or pack_id
            description = pack.get("description") or ""
            caps = pack.get("capabilities") or []
            cap_source = str(pack.get("capability_source") or "").strip()
            guidance = _CAPABILITY_SOURCE_GUIDANCE.get(cap_source)
            source_label = f"capability_source: {cap_source}" if guidance else "source missing or unsupported; no ownership inferred"
            line = (
                f"  - {pack_id} ({label}) "
                f"[capability_pack_id: {pack_id}; {source_label}]"
            )
            if description:
                line += f": {description.strip().split(chr(10))[0]}"
            if caps:
                cap_ids = [
                    (c.get("capability_id") or c) if isinstance(c, dict) else str(c)
                    for c in caps[:4]
                ]
                line += f" | capabilities: {', '.join(cap_ids)}"  # type: ignore[arg-type]
            lines.append(line)
            lines.append(f"      {guidance}" if guidance else "      Resolve the canonical source before planning this entry.")
        else:
            lines.append(f"  - {pack}: source missing; resolve a canonical descriptor before planning ownership.")
    return "\n".join(lines)


def _format_pack_surfaces(packs: list[Any]) -> str | None:
    """Render surface groupings and facade hints.

    Accepts two data shapes:

    1. ``surfaces`` list (declarative surface schema):
       Each entry may carry ``generation_hint.facade_module_id`` and
       ``generation_hint.pages`` / ``generation_hint.page_routes``.

    2. ``facades`` list (contract.yaml facade schema):
       Each entry has ``module_id``, ``provider_module``, and ``pages``.
       Rendered as declared facade references. Templates remain canonical;
       only permitted missing outputs need model tasks. Managed-provider
       restrictions apply only when that source is explicitly declared.

    Returns None when neither key is declared on any pack.
    """
    surface_lines: list[str] = []
    for pack in packs:
        if not isinstance(pack, dict):
            continue
        pack_id = pack.get("id") or pack.get("pack_id") or "?"
        label = pack.get("display_name") or pack.get("label") or pack_id

        # Shape 1: explicit surfaces list with optional generation_hint
        surfaces = pack.get("surfaces") or []
        if surfaces:
            surface_lines.append(f"{pack_id} ({label}) surfaces:")
            for surface in surfaces:
                if not isinstance(surface, dict):
                    continue
                surface_id = surface.get("surface_id") or "?"
                surface_label = surface.get("label") or surface_id
                status = surface.get("status") or "unknown"
                hint = surface.get("generation_hint") or {}
                facade_module_id = hint.get("facade_module_id") or ""
                pages = hint.get("pages") or []
                page_routes = hint.get("page_routes") or {}
                line = f"  - {surface_id} ({surface_label}) [{status}]"
                if facade_module_id:
                    line += f" → facade_module: {facade_module_id}"
                if pages:
                    line += f" | pages: {', '.join(str(p) for p in pages)}"
                surface_lines.append(line)
                if page_routes and isinstance(page_routes, dict):
                    for page_name, route in page_routes.items():
                        surface_lines.append(f"      route: {page_name} → {route}")

        # Shape 2: facades list from contract.yaml build_provider_values output
        facades = pack.get("facades") or []
        if facades and not surfaces:
            surface_lines.append(f"{pack_id} ({label}) declared facade modules:")
            if pack.get("capability_source") == "managed_capability":
                surface_lines.append(f"  Managed provider {pack_id}: do NOT generate modules/{pack_id}/.")
            for facade in facades:
                if not isinstance(facade, dict):
                    continue
                module_id = facade.get("module_id") or "?"
                provider = facade.get("provider_module") or pack_id
                pages = facade.get("pages") or []
                actions = facade.get("provider_actions") or []
                line = (
                    f"  - Declared facade module '{module_id}' wraps {provider}."
                    " Reuse its declared template outputs before planning any permitted custom tasks."
                )
                if pages:
                    page_names = [
                        p.get("name") if isinstance(p, dict) else str(p)
                        for p in pages
                    ]
                    routes = [
                        p.get("route") if isinstance(p, dict) else ""
                        for p in pages
                    ]
                    line += f" | pages: {', '.join(str(n) for n in page_names)}"
                    line += f" | routes: {', '.join(str(r) for r in routes if r)}"
                if actions:
                    line += f" | provider_actions: {', '.join(str(a) for a in actions[:4])}"
                surface_lines.append(line)

    if not surface_lines:
        return None
    return "Pack surfaces:\n" + "\n".join(surface_lines)


def _format_pack_supported_domains(packs: list[Any]) -> str | None:
    """Render domain fit hints. Returns None when no domains are declared."""
    domain_lines: list[str] = []
    for pack in packs:
        if not isinstance(pack, dict):
            continue
        domains = pack.get("supported_domains") or []
        if not domains:
            continue
        pack_id = pack.get("id") or pack.get("pack_id") or "?"
        label = pack.get("display_name") or pack.get("label") or pack_id
        domain_lines.append(f"{pack_id} ({label}) domain fit:")
        for domain_entry in domains:
            if not isinstance(domain_entry, dict):
                continue
            domain = domain_entry.get("domain") or "?"
            fit = domain_entry.get("fit") or "?"
            surfaces = domain_entry.get("surfaces") or []
            blocked = domain_entry.get("blocked_surfaces") or []
            line = f"  - {domain}: fit={fit}"
            if surfaces:
                line += f" | surfaces: {', '.join(str(s) for s in surfaces)}"
            if blocked:
                line += f" | blocked: {', '.join(str(s) for s in blocked)}"
            domain_lines.append(line)
    if not domain_lines:
        return None
    return "Pack domain fit:\n" + "\n".join(domain_lines)


def _format_pack_branding(packs: list[Any]) -> str | None:
    """Render branding hints. Returns None when no packs declare branding."""
    branding_lines: list[str] = []
    for pack in packs:
        if not isinstance(pack, dict):
            continue
        branding = pack.get("branding") or {}
        if not branding:
            continue
        pack_id = pack.get("id") or pack.get("pack_id") or "?"
        label = pack.get("display_name") or pack.get("label") or pack_id
        branding_lines.append(f"{pack_id} ({label}) branding:")
        attribution = branding.get("attribution") or ""
        if attribution:
            branding_lines.append(f"  - attribution: {attribution}")
        app_branded = branding.get("app_branded_surfaces") or []
        if app_branded:
            branding_lines.append(
                f"  - app-branded surfaces: {', '.join(str(s) for s in app_branded)}"
            )
        co_branded = branding.get("co_branded_surfaces") or []
        if co_branded:
            branding_lines.append(
                f"  - co-branded surfaces: {', '.join(str(s) for s in co_branded)}"
            )
        redirect_surfaces = branding.get("hosted_redirect_surfaces") or []
        if redirect_surfaces:
            branding_lines.append(
                f"  - hosted redirect surfaces: {', '.join(str(s) for s in redirect_surfaces)}"
            )
    if not branding_lines:
        return None
    return "Pack branding:\n" + "\n".join(branding_lines)


def _format_contract_list_items(items: Any, *, key: str) -> list[str]:
    lines: list[str] = []
    if not isinstance(items, list):
        return lines
    for item in items:
        if not isinstance(item, dict):
            continue
        value = item.get(key)
        if value:
            owner = f" [owner: {item['owner']}]" if key == "path" and item.get("owner") else ""
            lines.append(f"  - {value}{owner}")
    return lines


def _format_selection_rules(items: Any) -> list[str]:
    lines: list[str] = []
    if not isinstance(items, list):
        return lines
    for item in items:
        if not isinstance(item, dict):
            continue
        rule_id = item.get("id") or "rule"
        action = item.get("action") or ""
        when = item.get("when") if isinstance(item.get("when"), dict) else {}
        suffix = f" -> {action}" if action else ""
        conditions: list[str] = []
        intents = when.get("intent_any") if isinstance(when, dict) else []
        if isinstance(intents, list) and intents:
            conditions.append("intent_any: " + ", ".join(str(i) for i in intents))
        declares = when.get("app_declares") if isinstance(when, dict) else []
        if isinstance(declares, list) and declares:
            conditions.append("app_declares: " + ", ".join(str(d) for d in declares))
        condition_text = "; ".join(conditions)
        lines.append(f"  - {rule_id}{suffix}" + (f" when {condition_text}" if condition_text else ""))
    return lines


def _format_facade_contracts(facades: Any) -> list[str]:
    lines: list[str] = []
    if not isinstance(facades, list):
        return lines
    for facade in facades:
        if not isinstance(facade, dict):
            continue
        module_id = facade.get("module_id") or facade.get("facade_id")
        provider_module = facade.get("provider_module")
        if module_id:
            line = f"  - {module_id}"
            if provider_module:
                line += f" wraps {provider_module}"
            lines.append(line)
        for page in facade.get("pages") or []:
            if isinstance(page, dict) and page.get("route"):
                actions = page.get("primary_actions") or []
                action_text = f" actions: {', '.join(str(action) for action in actions)}" if actions else ""
                lines.append(f"      page {page.get('route')}{action_text}")
    return lines


def _format_operator_contracts(contracts: list[Any]) -> str | None:
    blocks: list[str] = []
    for contract in contracts:
        if not isinstance(contract, dict):
            continue
        contract_id = contract.get("contract_id") or "operator_contract"
        lines = [f"{contract_id} ({contract.get('contract_type') or 'contract'}):"]
        selection = _format_selection_rules(contract.get("selection_rules"))
        if selection:
            lines.append("  selection_rules:")
            lines.extend(selection)
        required = _format_contract_list_items(contract.get("required_outputs"), key="path")
        if required:
            lines.append("  required_outputs:")
            lines.extend(required)
        forbidden = _format_contract_list_items(contract.get("forbidden_outputs"), key="path_prefix")
        if forbidden:
            lines.append("  forbidden_outputs:")
            lines.extend(forbidden)
        boundaries = _format_contract_list_items(contract.get("runtime_boundaries"), key="rule")
        if boundaries:
            lines.append("  runtime_boundaries:")
            lines.extend(boundaries)
        facades = _format_facade_contracts(contract.get("facades"))
        if facades:
            lines.append("  facades:")
            lines.extend(facades)
        inactive = contract.get("inactive_surfaces") or []
        if isinstance(inactive, list) and inactive:
            lines.append("  inactive_surfaces:")
            lines.extend(f"  - {surface}" for surface in inactive)
        blocks.append("\n".join(lines))
    if not blocks:
        return None
    return "Operator build-pack contracts:\n" + "\n".join(blocks)


_MANAGED_PLANNING_RULES = (
    "Planning rules for managed_capability entries:\n"
    "1. Include each managed_capability needed by approved scope in AppBuildPlan.capability_packs exactly once with\n"
    "   these REQUIRED fields and values:\n"
    "   - capability_pack_id: the managed capability id exactly as listed above\n"
    "   - capability_source: managed_capability\n"
    "   - implementation_mode: external_integration\n"
    "   - surface_kind: external_integration\n"
    "   The capability_source field MUST be present and MUST be \"managed_capability\".\n"
    "   Do not substitute pack_type: managed_capability for capability_source.\n"
    "   Do not mark the managed capability entry as generated_module.\n"
    "2. Do NOT generate a module_contract build task for the managed_capability itself —\n"
    "   its provider owns those internals; consume its declared API.\n"
    "3. Pack-owned outputs are never model work. Reuse template-owned required_outputs and\n"
    "   template-provided workspace outputs at genesis; preserve shared composition roots.\n"
    "   The tasks below apply only to declared generator-owned outputs or permitted app-owned extensions.\n"
    "   For each managed_capability with surface_kind: external_integration, generate one api_surface adapter task\n"
    "   only if templates do not already provide that declared client. For each selected active\n"
    "   pack surface that needs app-owned actions or page endpoints, generate the\n"
    "   corresponding app-owned facade module and page tasks declared by the typed\n"
    "   operator contract, only for outputs not already supplied deterministically:\n"
    "   a) task_type: api_surface — surface_kind: external_integration\n"
    "      capability_pack_id: {pack_id}  (REQUIRED — do NOT set to null)\n"
    "      initial_agent: ControllerAgent\n"
    "      owned_paths: [\"services/integrations/{pack_id}_client.py\"]\n"
    "      This thin adapter is app-level service code and wraps calls to the managed capability API.\n"
    "      Do not place it under modules/{facade_id}/services/ or modules/{pack_id}/services/.\n"
    "      The capability_pack_id identifies which managed capability template to copy.\n"
    "   b) task_type: module_contract — surface_kind: module  (NOT external_integration)\n"
    "      initial_agent: ConfigMiddlewareAgent\n"
    "      capability_pack_id: {app_owned_facade_id}  (e.g. {pack_id}_dashboard)\n"
    "      This is an app-owned facade module that uses the adapter above.\n"
    "      depends_on: [the api_surface task id above, only when that task is required]\n"
    "      The facade module is generated_module; the managed capability remains managed_capability.\n"
    "      Also plan the matching data_models and business_services tasks for this\n"
    "      facade module unless selected pack templates provide those outputs.\n"
    "   c) task_type: page_bundle — surface_kind: ui_only\n"
    "      initial_agent: AppSchemaAgent\n"
    "      owned_paths: UI page yaml files for this feature\n"
    "      depends_on: [the module_contract task id above, only when that task is required]\n"
    "4. Page bundles select data_source module/action pairs from the app-owned facade inventory.\n"
    "5. Before emitting AppBuildPlan, verify each section data_source.module_id for\n"
    "   managed-capability features is the declared app-owned facade module.\n"
    "   Direct managed backing module, wallet, managed_billing, managed_usage, or\n"
    "   managed_entitlements bindings are invalid. Code renders endpoint URLs.\n"
    "6. If the operator contract declares required_outputs, forbidden_outputs, facades,\n"
    "   or pages, treat those typed values as authoritative. Do not invent alternate\n"
    "   facade ids, adapter paths, or page routes for the selected managed capability."
)


def _build_managed_context_body(capability_packs: list[Any], operator_contracts: list[Any] | None = None) -> str:
    parts = [
        _format_managed_capabilities(capability_packs),
        "Reuse-first planning for every selected source:\n"
        "- Preserve approved behavior; a selected pack covers only behavior its contract actually provides.\n"
        "- Compose deterministic framework, static/Jinja templates and schemas first, then generate the bounded custom difference.\n"
        "- Complete app-owned output does not mean model-writing every file. Never overwrite protected pack/template outputs.\n"
        "- required_outputs owned by templates are deterministic; template-provided workspace outputs are supplied at genesis.\n"
        "  Shared composition roots retain their canonical app/pack merge contract. Generator-owned outputs remain bounded model work.\n"
        "- Plan only permitted app-specific wiring or extension tasks. Missing ownership or runtime contracts require repair, not invented sources.",
    ]
    managed_ids = [
        str(pack.get("id") or pack.get("pack_id") or "?")
        for pack in capability_packs
        if isinstance(pack, dict) and pack.get("capability_source") == "managed_capability"
    ]
    if managed_ids:
        parts.append("Managed-provider rules below apply only to: " + ", ".join(managed_ids))
        parts.append(_MANAGED_PLANNING_RULES)

    surfaces_block = _format_pack_surfaces(capability_packs)
    if surfaces_block is not None:
        parts.append(surfaces_block)

    domains_block = _format_pack_supported_domains(capability_packs)
    if domains_block is not None:
        parts.append(domains_block)

    branding_block = _format_pack_branding(capability_packs)
    if branding_block is not None:
        parts.append(branding_block)

    contracts_block = _format_operator_contracts(operator_contracts or [])
    if contracts_block is not None:
        parts.append(contracts_block)

    return "\n\n".join(parts)


def inject_managed_capabilities_context(
    agent: Any,
    messages: list[dict[str, Any]],
) -> None:
    """
    prompt middleware function for AppPlanAgent.

    Reads ``capability_packs`` from context_variables. No-ops when the list is
    null or empty. Injects [MANAGED CAPABILITIES CONTEXT] when packs
    are present.
    """
    agent_name = getattr(agent, "name", "")
    if agent_name != "AppPlanAgent":
        return

    try:
        context_variables: Any = getattr(agent, "context_variables", None)
        if context_variables is None:
            return
        # Live containers freeze reads (tuples and mapping proxies); every
        # formatter below type-tests plain lists and dicts.
        capability_packs = detach(context_variables.get("capability_packs"))
        operator_contracts = detach(context_variables.get("operator_contracts")) or []

        # No selected capability packs to project.
        if _is_empty(capability_packs):
            return

        body = _build_managed_context_body(capability_packs, operator_contracts)  # type: ignore[arg-type]
        update_agent_section(agent, _MANAGED_CAP_HEADER, body)

        pack_ids = [
            (p.get("id") or p.get("pack_id") or "?") if isinstance(p, dict) else str(p)
            for p in capability_packs  # type: ignore[union-attr]
        ]
        logger.info(
            "[%s] Injected managed capabilities context (packs: %s)",
            agent_name,
            ", ".join(pack_ids),
        )

    except Exception as exc:
        logger.error(
            "[%s] Failed to inject managed capabilities context: %s",
            agent_name,
            exc,
        )


__all__ = ["inject_managed_capabilities_context"]


