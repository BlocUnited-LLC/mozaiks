"""Load the selected revision baseline before AppGenerator reasons or assembles."""

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from typing import TYPE_CHECKING, Any, NamedTuple

from factory_app.workflows._shared.artifact_bundle import read_artifact_bundle
from factory_app.workflows._shared.platform.build_target import require_build_binding
from factory_app.workflows._shared.platform.genesis_import import require_accepted_genesis_baseline
from mozaiksai.core.artifacts.models import BuildAcceptanceAuthority, BuildRecord, BuildRecordStatus
from mozaiksai.core.artifacts.store import build_record_generation, get_artifact_store
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.code_files import (
    extract_deleted_file_paths_from_payload,
)

if TYPE_CHECKING:
    from mozaiksai.control_plane.contracts import CodingWorkerRequest


class BoundRefinementContext(NamedTuple):
    """A read of existing authorities, not caller-supplied acceptance evidence."""

    parent: BuildRecord
    files: dict[str, str]
    context: dict[str, Any]
    digest: str
    authority: BuildAcceptanceAuthority


async def _dependency_generations(store: Any, *, app_id: str, parent_id: str | None,
                                  refs: dict[str, str]) -> dict[str, str]:
    dependencies = {}
    seen = set()
    link = parent_id
    while link:
        if link in seen or len(seen) >= 32:
            raise ValueError("refinement_authority_lineage_incomplete")
        seen.add(link)
        record = await store.get_build_record(app_id=app_id, build_record_id=link)
        if record is None or record.app_id != app_id or record.build_family != "app_bundle":
            raise ValueError("refinement_authority_lineage_unavailable")
        dependencies[link] = build_record_generation(record)
        link = record.parent_build_record_id
    for family, record_id in refs.items():
        record = await store.get_build_record(app_id=app_id, build_record_id=record_id)
        if (record is None or record.app_id != app_id or record.build_family != family
                or record.lifecycle_status != BuildRecordStatus.CURRENT):
            raise ValueError("refinement_authority_input_unavailable: " + family)
        dependencies[record_id] = build_record_generation(record)
    return dependencies


async def capture_app_validation_authority(context: Any) -> BuildAcceptanceAuthority:
    """Checkpoint normal AG2 task provenance before expensive validation.

    This is the existing source session, not another context store. Registration
    copies this identity; it cannot substitute newer approval after validation.
    """
    from mozaiksai.core.artifacts.summary_artifacts import resolve_latest_artifact_version_refs
    from mozaiksai.core.data.persistence.artifact_store import BuilderArtifactStore
    from mozaiksai.core.data.persistence.persistence_manager import (
        AG2PersistenceManager,
        _context_authority_policy_for_workflow,
    )
    from mozaiksai.core.session.build_binding import RunBuildBinding
    from mozaiksai.core.workflow.context.variables import _load_context_async

    from .task_integrity import source_context_digests, source_context_values

    binding = require_build_binding(context)
    host, owner, chat = (context.get(key) for key in ("app_id", "user_id", "chat_id"))
    if not all((host, owner, chat)):
        raise ValueError("validation_authority_source_identity_missing")
    persistence, semantic, store = AG2PersistenceManager(), BuilderArtifactStore(), get_artifact_store()
    before = await semantic.acceptance_authority(app_id=binding.target_app_id)
    selection = await store.selection_revision(app_id=binding.target_app_id, build_family="app_bundle", build_key="app_bundle")
    replay = await persistence.fetch_chat_session_extra_context(
        chat_id=chat, app_id=host, user_id=owner, workflow_name="AppGenerator")
    if RunBuildBinding.model_validate(replay.get("run_build_binding")) != binding:
        raise ValueError("validation_authority_source_binding_mismatch")
    fresh = await _load_context_async("AppGenerator", host, runtime_context={
        "app_id": host, "chat_id": chat, "user_id": owner, "workflow_name": "AppGenerator",
        "run_build_binding": binding.model_dump(),
    })
    policy = _context_authority_policy_for_workflow("AppGenerator")
    for key, declaration in policy.variables.items():
        if declaration.source_type == "data_reference" and detach(context.get(key)) != detach(fresh.get(key)):
            raise ValueError("validation_authority_semantic_input_changed: " + key)
    values = source_context_values(context)
    await persistence.persist_context_variables(chat_id=chat, app_id=host, workflow_name="AppGenerator", variables=values)
    replay = await persistence.fetch_chat_session_extra_context(
        chat_id=chat, app_id=host, user_id=owner, workflow_name="AppGenerator")
    digests = source_context_digests(context)
    if source_context_digests(replay) != digests:
        raise ValueError("validation_authority_task_checkpoint_mismatch")
    refs = await resolve_latest_artifact_version_refs(app_id=binding.target_app_id, artifact_store=store,
        artifact_kinds=("design_docs", "subscription_contract", "workflow_bundle", "theme_capture"))
    parent_id = app_bundle_parent_id(context)
    dependencies = await _dependency_generations(store, app_id=binding.target_app_id, parent_id=parent_id, refs=refs)
    if before != await semantic.acceptance_authority(app_id=binding.target_app_id):
        raise ValueError("validation_authority_semantic_input_changed")
    return BuildAcceptanceAuthority(binding=binding, execution_app_id=host, owner_user_id=owner,
        source_chat_id=chat, source_binding=binding, source_context_digests=digests,
        parent_build_record_id=parent_id, canonical_inputs_version=refs,
        selection_revision=selection, build_records=dependencies, **before)


async def resolve_refinement_validation_context(
    request: CodingWorkerRequest, *, artifact_store: Any = None,
) -> BoundRefinementContext:
    """Rehydrate the exact source through the normal AG2 context authority path.

    Inline patches cannot approve new requirements or replace semantic inputs.
    Changed approval/input versions require the existing workflow re-entry. No
    candidate context, proposed metadata, mutable workspace or latest plan is
    a fallback. These reads detect drift; they are not a storage transaction.
    """
    from factory_app.app.modules.app_registry.backend.service import AppRegistryService
    from mozaiksai.control_plane.contracts import acceptance_evidence_names
    from mozaiksai.control_plane.implementations.coding_worker import newer_accepted_work
    from mozaiksai.core.artifacts.summary_artifacts import resolve_latest_artifact_version_refs
    from mozaiksai.core.data.persistence.artifact_store import BuilderArtifactStore
    from mozaiksai.core.data.persistence.persistence_manager import (
        SERVER_OWNED_SESSION_FIELDS,
        AG2PersistenceManager,
    )
    from mozaiksai.core.session.build_binding import RunBuildBinding
    from mozaiksai.core.workflow.context.variables import _load_context_async
    from mozaiksai.core.workflow.execution.run_bootstrap import merge_persisted_extra_context
    from mozaiksai.core.workflow.task_batches import task_evidence_digest

    from .repair_policy import prepare_bundle_repair
    from .requirement_delivery import validate_cached_requirement_delivery
    from .task_integrity import (
        admit_refinement_task_outputs,
        artifact_snapshot_digest,
        planned_artifact_diagnostics,
        source_context_digests,
    )

    binding = request.run_build_binding
    if (binding is None or binding.phase != "refinement" or not request.user_id
            or not request.build_record_id or binding.target_app_id != request.artifact_app_id):
        raise ValueError("refinement_authority_binding_missing")
    registry = (await AppRegistryService().get_app_record(
        owner_user_id=request.user_id, build_registry_id=binding.build_registry_id,
    )).get("app")
    if (not isinstance(registry, dict) or registry.get("app_id") != binding.target_app_id
            or registry.get("chat_app_id") != request.app_id
            or (registry.get("current_build_run") or {}).get("build_id") != binding.build_id
            or (registry.get("current_build_run") or {}).get("phase") != "refinement"):
        raise ValueError("refinement_authority_registry_mismatch")
    store = artifact_store or get_artifact_store()
    semantic = BuilderArtifactStore()
    semantic_generation = await semantic.acceptance_authority(app_id=binding.target_app_id)
    selection = await store.selection_revision(app_id=binding.target_app_id, build_family="app_bundle", build_key="app_bundle")
    parent = await store.get_build_record(app_id=binding.target_app_id, build_record_id=request.build_record_id)
    if (parent is None or parent.id != request.build_record_id or parent.app_id != binding.target_app_id
            or parent.build_family != "app_bundle" or parent.build_key != (request.build_key or "app_bundle")):
        raise ValueError("refinement_authority_parent_mismatch")
    parent = parent.model_copy(deep=True)
    if parent.lifecycle_status in {BuildRecordStatus.ARCHIVED, BuildRecordStatus.DELETED}:
        raise ValueError("refinement_authority_parent_retired")
    newer = await newer_accepted_work(store, app_id=binding.target_app_id, record=parent)
    if newer is not None:
        raise ValueError("refinement_authority_parent_ineligible: " + newer.reason)
    metadata = parent.commit_metadata.metadata
    if (parent.commit_metadata.author_user_id != request.user_id
            or metadata.get("target_app_id") != binding.target_app_id
            or metadata.get("build_registry_id") != binding.build_registry_id):
        raise ValueError("refinement_authority_parent_owner_mismatch")
    # Inline children retain their own identity. Follow only verified accepted
    # lineage to the actual generator source; never copy a chat ID onto a child.
    inline = []
    source_record = parent
    seen = set()
    while source_record.source_workflow != "AppGenerator" or not source_record.source_chat_id:
        if source_record.id in seen or len(seen) >= 32 or not source_record.parent_build_record_id:
            raise ValueError("refinement_authority_source_session_missing: re-enter the owning workflow")
        seen.add(source_record.id)
        saved = source_record.commit_metadata.metadata
        if (source_record.app_id != binding.target_app_id
                or source_record.commit_metadata.author_user_id != request.user_id
                or saved.get("build_registry_id") != binding.build_registry_id
                or source_record.canonical_inputs_version != parent.canonical_inputs_version
                or not acceptance_evidence_names(source_record, saved.get("acceptance") or {})):
            raise ValueError("refinement_authority_inline_provenance_conflict")
        BuildAcceptanceAuthority.model_validate(saved.get("acceptance_authority"))
        inline.append(source_record)
        source_record = await store.get_build_record(app_id=binding.target_app_id,
            build_record_id=source_record.parent_build_record_id)
        if source_record is None:
            raise ValueError("refinement_authority_lineage_unavailable")
    source_metadata = source_record.commit_metadata.metadata
    if (source_record.commit_metadata.author_user_id != request.user_id
            or source_metadata.get("build_registry_id") != binding.build_registry_id
            or source_record.canonical_inputs_version != parent.canonical_inputs_version):
        raise ValueError("refinement_authority_source_owner_mismatch")
    original_binding = RunBuildBinding.model_validate({key: source_metadata.get(key) for key in RunBuildBinding.model_fields})
    persistence = AG2PersistenceManager()
    replay = await persistence.fetch_chat_session_extra_context(
        chat_id=source_record.source_chat_id, app_id=request.app_id, workflow_name="AppGenerator", user_id=request.user_id,
    )
    if RunBuildBinding.model_validate(replay.get("run_build_binding")) != original_binding:
        raise ValueError("refinement_authority_source_binding_mismatch")
    source_digests = source_context_digests(replay)
    source_context = await _load_context_async("AppGenerator", request.app_id, runtime_context={
        **{key: value for key, value in replay.items() if key in SERVER_OWNED_SESSION_FIELDS},
        "app_id": request.app_id, "chat_id": source_record.source_chat_id,
        "user_id": request.user_id, "workflow_name": "AppGenerator",
    })
    merge_persisted_extra_context(source_context, {
        key: value for key, value in replay.items() if key not in SERVER_OWNED_SESSION_FIELDS
    })
    context = source_context.snapshot()
    # Session replay deliberately does not restore caller identity. Earlier
    # registry/source-owner checks bind this identity before a workflow revision
    # reads its own baseline; it is not a grant from persisted/candidate context.
    context.update(app_id=request.app_id, user_id=request.user_id)
    validate_cached_requirement_delivery(context)
    parent_context = {
        "app_id": request.app_id, "user_id": request.user_id, "run_build_binding": binding.model_dump(),
        "build_mode": "revision", "revision_source_artifact_version_id": parent.id,
    }
    files = await read_bound_revision_files({**parent_context, "revision_source_artifact_version_id": source_record.id})
    original_baseline = await read_bound_revision_files(context) if revision_baseline_required(context) else None
    if original_baseline is not None:
        # Derived asset evidence is not persisted session input. Reconstruct it
        # from the verified revision baseline, as the original acceptance did.
        _, context["revision_asset_evidence"] = await revision_asset_evidence(context, files)
    diagnostics = planned_artifact_diagnostics(context, files, revision_baseline=original_baseline)
    if diagnostics:
        raise ValueError("refinement_authority_parent_output_unverified: " + "; ".join(row["error"] for row in diagnostics))
    acceptance = source_metadata.get("app_bundle_acceptance") or {}
    if (acceptance.get("status") != "passed" or acceptance.get("passed") is not True
            or acceptance.get("snapshot_digest") != artifact_snapshot_digest(context, files)):
        raise ValueError("refinement_authority_parent_snapshot_mismatch")
    previous = source_record
    for child in reversed(inline):
        saved = child.commit_metadata.metadata
        captured = BuildAcceptanceAuthority.model_validate(saved["acceptance_authority"])
        if (captured.source_chat_id != source_record.source_chat_id or captured.source_binding != original_binding
                or captured.source_build_record_id != source_record.id
                or captured.source_context_digests != source_digests
                or captured.concept_review_id != semantic_generation["concept_review_id"]
                or captured.semantic_revision != semantic_generation["semantic_revision"]):
            raise ValueError("refinement_authority_inline_source_changed")
        child_files = await read_bound_revision_files({**parent_context, "revision_source_artifact_version_id": child.id})
        # Replay does not restore a caller identity from persisted context.
        # Asset reads use the request owner already checked against the scoped
        # registry and every lineage record above, just like the final context.
        context.update(app_id=request.app_id, user_id=request.user_id,
                       build_mode="revision", revision_source_artifact_version_id=previous.id,
                       run_build_binding=captured.binding.model_dump(), deleted_files=[])
        admit_refinement_task_outputs(context, child_files, baseline=files,
            selected_paths=saved.get("applied_paths") or [], request_id=saved.get("refinement_authority_digest") or "")
        # Replay the same successful settlement as the original gate. This is
        # local context only; the generator's persisted source remains unchanged.
        prepare_bundle_repair({"passed": True, "diagnostics": []}, context, select_repairs=False)
        _, context["revision_asset_evidence"] = await revision_asset_evidence(context, child_files)
        diagnostics = planned_artifact_diagnostics(context, child_files, revision_baseline=files)
        acceptance = saved.get("app_bundle_acceptance") or {}
        if (diagnostics or acceptance.get("status") != "passed" or acceptance.get("passed") is not True
                or acceptance.get("snapshot_digest") != artifact_snapshot_digest(context, child_files)):
            raise ValueError("refinement_authority_inline_output_unverified")
        files, previous = child_files, child
    # This is the same canonical input selection used at registration. Never
    # silently overwrite a retained reference with a newer approved input.
    current_refs = await resolve_latest_artifact_version_refs(
        app_id=binding.target_app_id, artifact_store=store,
        artifact_kinds=("design_docs", "subscription_contract", "workflow_bundle", "theme_capture"),
    )
    if current_refs != parent.canonical_inputs_version:
        raise ValueError("refinement_authority_inputs_changed: re-enter the owning workflow")
    dependencies = await _dependency_generations(store, app_id=binding.target_app_id, parent_id=parent.id, refs=current_refs)
    replay_after = await persistence.fetch_chat_session_extra_context(
        chat_id=source_record.source_chat_id, app_id=request.app_id, workflow_name="AppGenerator", user_id=request.user_id)
    if source_context_digests(replay_after) != source_digests:
        raise ValueError("refinement_authority_source_session_changed")
    if semantic_generation != await semantic.acceptance_authority(app_id=binding.target_app_id):
        raise ValueError("refinement_authority_inputs_changed: re-enter the owning workflow")
    authority = BuildAcceptanceAuthority(binding=binding, execution_app_id=request.app_id, owner_user_id=request.user_id,
        source_chat_id=source_record.source_chat_id, source_binding=original_binding, source_context_digests=source_digests,
        source_build_record_id=source_record.id, parent_build_record_id=parent.id, canonical_inputs_version=current_refs,
        selection_revision=selection, build_records=dependencies, **semantic_generation)
    digest = task_evidence_digest(authority.model_dump(mode="json"))
    # Never inherit behavior/validation receipts into a child. Current gates
    # consume the original task/requirement evidence with the verified baseline.
    context.update(parent_context)
    context["run_build_binding"] = binding.model_dump()
    for key in ("app_bundle_acceptance_result", "app_bundle_validation_evidence", "app_validation_result",
                "integration_test_result", "revision_asset_evidence", "app_ui_quality_result"):
        context[key] = None
    context.update(app_bundle_acceptance_status="pending", app_validation_status="pending",
                   app_ui_quality_status="pending", app_ui_quality_warnings=[],
                   integration_tests_passed=False, generated_files={}, deleted_files=[])
    return BoundRefinementContext(parent, dict(files), deepcopy(context), digest, authority)


def revision_baseline_required(context_variables: Any) -> bool:
    return bool(
        context_variables is not None
        and context_variables.get("build_mode") == "revision"
        and context_variables.get("workflow_sequence") not in {"conceptual_replan", "full_rebuild"}
    )


def revision_source_artifact_id(context_variables: Any) -> str | None:
    """Keep the selected source stable after artifact_version_id becomes the result."""
    source = context_variables.get("revision_source_artifact_version_id") or context_variables.get("artifact_version_id")
    return source if isinstance(source, str) and source else None


def app_bundle_parent_id(context_variables: Any) -> str | None:
    """Lineage survives rebuild/replan; reuse of the parent's files does not."""
    binding = require_build_binding(context_variables)
    if binding.phase != "refinement":
        return None
    parent_id = revision_source_artifact_id(context_variables)
    if parent_id is None:
        raise ValueError("refinement_lineage_parent_missing: re-enter the owning workflow")
    return parent_id


async def read_bound_revision_files(
    context_variables: Any, *, include_binary: bool = False,
) -> dict[str, str | bytes]:
    """Recheck the selected immutable source and its owner on every read."""
    binding = require_build_binding(context_variables)
    artifact_id = revision_source_artifact_id(context_variables)
    if binding.phase != "refinement" or not artifact_id:
        raise ValueError("revision_baseline_binding_missing")
    artifact = await get_artifact_store().get_build_record(
        app_id=binding.target_app_id, build_record_id=artifact_id,
    )
    if artifact is None or artifact.app_id != binding.target_app_id or artifact.id != artifact_id:
        raise ValueError("revision_baseline_artifact_unavailable")
    if artifact.lifecycle_status in {BuildRecordStatus.ARCHIVED, BuildRecordStatus.DELETED}:
        raise ValueError("revision_baseline_artifact_retired")
    metadata = artifact.commit_metadata.metadata
    if (
        not context_variables.get("user_id")
        or artifact.commit_metadata.author_user_id != context_variables.get("user_id")
        or metadata.get("target_app_id") != binding.target_app_id
        or metadata.get("build_registry_id") != binding.build_registry_id
    ):
        raise ValueError("revision_baseline_owner_mismatch")

    await require_accepted_genesis_baseline(
        artifact, owner_user_id=context_variables.get("user_id"),
        execution_app_id=context_variables.get("app_id"),
        build_registry_id=binding.build_registry_id,
    )

    # The selected version can be stale after refinement invalidation. Its
    # committed archive remains the baseline; mutable workspace copies do not.
    files, diagnostics = await read_artifact_bundle(artifact, include_binary=include_binary)
    blocking = [item for item in diagnostics if item["blocking"]]
    if blocking:
        raise ValueError("revision_baseline_incomplete: " + ", ".join(
            str(item["code"]) for item in blocking
        ))
    manifest = files.get("app.json")
    if not isinstance(manifest, str) or json.loads(manifest).get("appId") != binding.target_app_id:
        raise ValueError("revision_baseline_app_identity_mismatch")
    return files


async def read_bound_revision_binary_assets(context_variables: Any) -> dict[str, bytes]:
    files = await read_bound_revision_files(context_variables, include_binary=True)
    return {path: content for path, content in files.items() if isinstance(content, bytes)}


async def revision_asset_evidence(
    context_variables: Any, files: dict[str, str],
) -> tuple[dict[str, bytes], dict[str, Any]]:
    """Describe the exact retained source bytes and current tombstones."""
    source_id = revision_source_artifact_id(context_variables)
    assets = await read_bound_revision_binary_assets(context_variables)
    if revision_source_artifact_id(context_variables) != source_id:
        raise ValueError("revision source changed while assets were read")
    conflicts = set(assets) & set(files)
    if conflicts:
        raise ValueError("revision_binary_text_replacement: " + ", ".join(sorted(conflicts)))
    deleted = set(extract_deleted_file_paths_from_payload({
        "deleted_files": detach(context_variables.get("deleted_files")),
    }))
    # The existing task inventory has no binary deletion grant. A free-form
    # deleted_files entry must not remove an opaque source asset.
    unowned = set(assets) & deleted
    if unowned:
        raise ValueError("revision_binary_deletion_unowned: " + ", ".join(sorted(unowned)))
    evidence = {
        "source_artifact_version_id": source_id,
        "opaque_assets": [
            {"path": path, "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}
            for path, data in sorted(assets.items())
        ],
        "deleted_files": sorted(deleted),
    }
    return assets, evidence


async def hydrate_app_revision_context(context_variables: Any = None) -> dict[str, Any]:
    if context_variables is None or context_variables.get("build_mode") != "revision":
        return {"status": "skipped", "reason": "not_revision"}
    if not revision_baseline_required(context_variables):
        return {"status": "skipped", "reason": "explicit_rebuild"}

    files = await read_bound_revision_files(context_variables)
    artifact_id = revision_source_artifact_id(context_variables)
    current = detach(context_variables.get("generated_files")) or {}
    if not isinstance(current, dict):
        raise ValueError("revision_baseline_generated_files_invalid")
    files.update(current)
    for path in detach(context_variables.get("deleted_files")) or []:
        files.pop(path, None)
    if isinstance(context_variables, dict):
        context_variables["generated_files"] = files
    else:
        context_variables.set("generated_files", files)
    return {"status": "hydrated", "artifact_version_id": artifact_id, "file_count": len(files)}
