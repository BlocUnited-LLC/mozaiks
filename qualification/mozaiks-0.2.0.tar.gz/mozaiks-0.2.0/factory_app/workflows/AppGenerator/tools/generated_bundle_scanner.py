"""generated_bundle_scanner — scan a generated app bundle for forbidden patterns.

Checks that the generated app does not:

- Embed raw provider secret-looking literals.
  Credentials must be collected and resolved through the configured secret
  backend, not checked into generated app artifacts.

- Declare persistent module surfaces in data/contract.json without matching
  modules/{module_id}/module.yaml artifacts. Such bundles can pass page-level
  validation but fail promotion/runtime acceptance because there is no module
  endpoint to own the declared app business data.

- Emit removed data/security locations or unknown app-root folders. The
  generated app bundle has finite app planes; build-time context belongs at the
  workspace root under build_context/, not inside generated app bundles.

Called by generate_and_download.py after the full files_map is assembled.
Returns a list of human-readable error strings. An empty list means clean.
"""

from __future__ import annotations

import json
import re
from pathlib import Path, PurePosixPath
from typing import Any

import yaml
from pydantic import ValidationError as PydanticValidationError

from factory_app.workflows._shared.generated_ui_contract import resolve_registered_component_files
from factory_app.workflows.AppGenerator.tools.module_persistence_guard import (
    scan_module_persistence,
)
from factory_app.workflows.AppGenerator.tools.resolve_managed_capability_templates import (
    AUTHORITY_INSTALLED,
    AUTHORITY_PACKAGED_BUILD_CONTEXT,
    AUTHORITY_SELECTED_PINS,
    AUTHORITY_WORKSPACE_BUILD_CONTEXT,
    ManagedCapabilityTemplateError,
    PackIntegrityError,
    declared_output_owners,
    pack_identity,
    resolve_declared_pack_output_paths,
    selected_pack_id,
    static_pack_templates,
    verified_pack_data_contracts,
    verified_pack_template_inventory,
    verified_selected_pack_sources,
)
from mozaiksai.builder.messaging import MessagingConfiguration, reconcile_messaging_configurations
from mozaiksai.builder.resources import resolve_packaged_build_context
from mozaiksai.builder.storefront import StorefrontRecipe, normalize_storefront_recipe
from mozaiksai.core.runtime.app.auth_contract import (
    APP_AUTH_COMPONENTS,
    AppAuthContractError,
    validate_app_auth_contract,
    validate_app_auth_route_bindings,
)
from mozaiksai.core.runtime.app.layout_registry import (
    ExtensionSlot,
    LayoutExtension,
    PathScope,
    build_app_layout_registry,
)
from mozaiksai.core.runtime.app.layout_validation import (
    filter_layout_scannable_file_map,
    layout_extensions_from_selected_packs,
    layout_validation_errors,
    validate_file_map_layout,
)
from mozaiksai.core.runtime.app.module_loader import validate_action_timeout
from mozaiksai.core.runtime.app.page_schema import (
    PageSchemaValidationError,
    validate_page_schema,
)
from mozaiksai.core.runtime.app.paths import (
    APP_AUTH_CONFIG_PATH,
    APP_DATA_CONTRACT_PATH,
    APP_SECURITY_SECRETS_PATH,
    disallowed_legacy_app_paths,
    is_sensitive_app_config_path,
    noncanonical_app_config_paths,
    noncanonical_app_root_paths,
    unsafe_app_paths,
)
from mozaiksai.core.runtime.app.theme_contract import validate_page_title_theme
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.code_files import (
    compile_data_contract,
    data_contract_requires_auth,
)
from mozaiksai.core.workflow.generator_support.module_action_inventory import (
    SHARED_PACK_OUTPUT_PATHS,
)
from mozaiksai.core.workflow.generator_support.module_entitlement_gates import (
    capability_id_for_feature,
    resolve_subscription_contract,
)
from mozaiksai.core.workflow.generator_support.persistence_artifacts import (
    managed_data_owners,
    materialize_data_migrations,
)
from mozaiksai.core.workflow.generator_support.subscription_data_contract import (
    ensure_subscription_assignment_stores,
)
from mozaiksai.core.workflow.generator_support.ui_registry_composition import SHELL_ROUTE_COMPONENTS

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# Generic payment-provider secret placeholder used by generated fixtures. Exact
# hosted-processor key fingerprints belong in hosted/private validation packs.
_PAYMENT_PROVIDER_SECRET_LITERAL_RE = re.compile(
    r"\b(?:payment_provider|provider)_(?:live|test)_[A-Za-z0-9]{10,}"
)
_PAYMENT_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^\s*(?:import\s+payment_provider\b|from\s+payment_provider\s+import\b)"
)
_RAW_PAYMENT_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^\s*(?:import\s+(stripe|paddle|paypal|braintree|square)\b|"
    r"from\s+(stripe|paddle|paypal|braintree|square)\s+import\b)",
    re.IGNORECASE,
)
# Cloud provider SDK imports are forbidden in generated app bundles.
# Generated apps must route all cloud operations through the bounded MozaiksCloud
# sub-clients; they must not import Azure, Cloudflare, or GitHub SDKs directly.
_RAW_CLOUD_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^\s*(?:import\s+(azure(?:\.[a-zA-Z0-9_.]+)?|cloudflare)\b|"
    r"from\s+(azure(?:\.[a-zA-Z0-9_.]+)?|cloudflare)\s+import\b)",
    re.IGNORECASE,
)

_MANAGED_SETUP_RAW_PROVIDER_ENV_RE = re.compile(
    r"\b(?:STRIPE|PADDLE|PAYPAL|BRAINTREE|SQUARE)_[A-Z0-9_]*"
    r"(?:SECRET|KEY|TOKEN|PRIVATE|WEBHOOK|CLIENT_ID|PUBLISHABLE)[A-Z0-9_]*\b"
)
_MANAGED_SETUP_PROVIDER_ROUTE_RE = re.compile(
    r"(?:^|[\"'\s:=])/?(?:api/)?(?:webhooks/(stripe|paddle|paypal|braintree|square)\b|"
    r"(stripe|paddle|paypal|braintree|square)/webhooks?\b|"
    r"(stripe|paddle|paypal|braintree|square)/(?:checkout|payment|billing)\b)",
    re.IGNORECASE,
)
_MANAGED_SETUP_PROVIDER_MECHANIC_RE = re.compile(
    r"\b(?:stripe|paddle|paypal|braintree|square)\s*\.\s*"
    r"(?:checkout|webhooks|PaymentIntent|Customer|Subscription|Refund|refunds)\b|"
    r"\bStripe-Signature\b|"
    r"\brequire\s*\(\s*[\"'](?:stripe|paddle|paypal|braintree|square)[\"']\s*\)",
    re.IGNORECASE,
)
_PAYMENT_PROVIDER_API_KEY_RE = re.compile(r"\bpayment_provider\s*\.\s*api_key\s*=")
_PAYMENT_PROVIDER_REFUND_CALL_RE = re.compile(
    r"\bpayment_provider\s*\.\s*(?:Refund\s*\.\s*create|refunds\s*\.\s*create)\s*\(",
    re.IGNORECASE,
)
_PAYMENT_PROVIDER_REFUNDS_ENDPOINT_RE = re.compile(r"['\"]?/refunds\b")
_APP_LOCAL_LEDGER_PATH_RE = re.compile(
    r"(?:^|/)(?:(?:token_)?wallet|(?:token_)?usage)_ledger\.(?:py|js|ts|tsx|jsx)$"
    r"|(?:^|/)ledgers?/(?:[^/]*)(?:wallet|usage)(?:[^/]*)\.(?:py|js|ts|tsx|jsx)$",
    re.IGNORECASE,
)
_APP_LOCAL_LEDGER_CODE_RE = re.compile(
    r"\bclass\s+(?:TokenWalletLedger|WalletLedger|RuntimeUsageLedger|UsageLedger|TokenUsageLedger)\b"
    r"|from\s+mozaiksai\.core\.(?:tokens\.wallet|usage\.ledger)\s+import\s+"
    r"(?:TokenWalletLedger|get_token_wallet_ledger|RuntimeUsageLedger|get_runtime_usage_ledger)"
    r"|RuntimeTokenWalletEntries|RuntimeTokenWalletBalances|RuntimeUsageEvents",
    re.IGNORECASE,
)

# File suffixes and compound endings that carry executable or config content.
# Checked via str.endswith so compound extensions like .env.example work.
_SCANNABLE_SUFFIXES = (
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".yaml",
    ".yml",
    ".env.example",
    ".env.staging.example",
    ".env.production.example",
    ".env",
    # Pack-declared workspace scripts ship to customers and must never carry
    # raw credentials or provider leaks.
    ".ps1",
    ".sh",
)


# Canonical action api_surface values — controls HTTP exposure posture.
# Must match the typed literal in structured_outputs.yaml ModuleApiSurface
# and the runtime ActionDef.api_surface field.
_CANONICAL_API_SURFACE_VALUES = frozenset(
    {
        "public",
        "public_readonly",
        "internal",
        "admin_internal",
    }
)

# Canonical reaction target kinds — must match file_contracts.yaml and the
# mozaiks.reactions.v1 schema.  service_adapter is intentionally present here
# and in the runtime loader but absent from structured_outputs.yaml: it is a
# pack-only extension (capability packs can generate service_adapter reactions
# via templates, but the AppGenerator LLM should not produce them directly).
_CANONICAL_REACTION_TARGET_KINDS = frozenset(
    {
        "handler",
        "capability",
        "notification",
        "service_adapter",
    }
)

# Platform-provided event namespaces — events in these namespaces are NOT
# declared in the bundle's events.yaml and must be skipped during closure checks.
_PLATFORM_EVENT_NAMESPACES = ("hosted.", "platform.", "mozaiks.")

# The shell's routable core pages (a subset of chat-ui/src/registry/coreComponents.js), shared with
# UI registry composition. A route manifest entry naming one does NOT require a ui/pages/custom/*.jsx
# file; one naming any other core component does.
_SHELL_ROUTE_COMPONENTS = SHELL_ROUTE_COMPONENTS


def _is_scannable(path: str) -> bool:
    """Return True if this file path should be scanned for forbidden patterns."""
    lpath = path.lower()
    return any(lpath.endswith(s) for s in _SCANNABLE_SUFFIXES)


def _normalized_path(raw_path: str) -> str:
    return str(raw_path or "").replace("\\", "/").strip()


def _normalized_files_map(files_map: dict[str, str]) -> dict[str, str]:
    normalized: dict[str, str] = {}
    for raw_path, content in files_map.items():
        path = _normalized_path(raw_path)
        if path:
            normalized[path] = str(content)
    return normalized


def _app_manifest_auth_required(files_map: dict[str, str]) -> bool:
    normalized = _normalized_files_map(files_map)
    for path in ("app.json", "app/app.json"):
        raw = normalized.get(path)
        if not raw:
            continue
        try:
            payload = json.loads(raw)
        except (ValueError, TypeError):
            raise AppAuthContractError("app.json must be a valid JSON object") from None
        if not isinstance(payload, dict):
            raise AppAuthContractError("app.json must be a valid JSON object")
        required = payload.get("authRequired", False)
        if type(required) is not bool:
            raise AppAuthContractError("app.json.authRequired must be a boolean")
        return required
    return False


def _iter_module_yaml_paths(files_map: dict[str, str]) -> dict[str, str]:
    modules: dict[str, str] = {}
    for raw_path in files_map:
        path = _normalized_path(raw_path)
        pure = PurePosixPath(path)
        if len(pure.parts) != 3 or pure.parts[0] != "modules" or pure.parts[2] != "module.yaml":
            continue
        module_id = str(pure.parts[1]).strip()
        if module_id:
            modules[module_id] = path
    return modules


def _declared_module_id_from_yaml(path: str, content: str) -> str | None:
    try:
        parsed = yaml.safe_load(content) or {}
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    module_block = parsed.get("module") if isinstance(parsed.get("module"), dict) else parsed
    if not isinstance(module_block, dict):
        return None
    module_id = str(module_block.get("id") or "").strip()
    return module_id or None


def _load_data_contract(files_map: dict[str, str]) -> tuple[dict[str, Any] | None, str | None]:
    raw = files_map.get(APP_DATA_CONTRACT_PATH)
    if raw is None:
        return None, None
    try:
        parsed = json.loads(str(raw))
    except Exception as exc:
        return None, f"{APP_DATA_CONTRACT_PATH}: data contract must be valid JSON: {exc}"
    if not isinstance(parsed, dict):
        return None, f"{APP_DATA_CONTRACT_PATH}: data contract must be a JSON object."
    return parsed, None


def _module_surface_ids(data_contract: dict[str, Any]) -> set[str]:
    module_ids: set[str] = set()
    surfaces = data_contract.get("surfaces")
    if not isinstance(surfaces, list):
        return module_ids

    for surface in surfaces:
        if not isinstance(surface, dict):
            continue
        surface_kind = str(surface.get("surface_kind") or "").strip()
        surface_id = str(surface.get("surface_id") or "").strip()
        if surface_kind == "module" and surface_id:
            module_ids.add(surface_id)

        collections = surface.get("collections")
        if not isinstance(collections, list):
            continue
        for collection in collections:
            if not isinstance(collection, dict):
                continue
            ownership_value = collection.get("ownership")
            ownership = ownership_value if isinstance(ownership_value, dict) else {}
            module_id = str(
                collection.get("module_id") or ownership.get("surface_id") or ""
            ).strip()
            ownership_kind = str(ownership.get("surface_kind") or surface_kind).strip()
            if ownership_kind == "module" and module_id:
                module_ids.add(module_id)
            elif surface_kind == "module" and surface_id:
                module_ids.add(surface_id)
    return module_ids


def _scan_data_contract_module_alignment(files_map: dict[str, str]) -> list[str]:
    errors: list[str] = []
    normalized_files = _normalized_files_map(files_map)
    data_contract, load_error = _load_data_contract(normalized_files)
    if load_error:
        return [load_error]
    if not data_contract:
        return errors

    module_surface_ids = _module_surface_ids(data_contract)
    if not module_surface_ids:
        return errors

    module_yaml_paths = _iter_module_yaml_paths(normalized_files)
    missing = sorted(module_surface_ids - set(module_yaml_paths))
    if missing:
        errors.append(
            f"{APP_DATA_CONTRACT_PATH} declares module surface(s) without matching module artifacts: "
            f"{missing}. Add modules/{{module_id}}/module.yaml plus the canonical backend files, "
            f"or remove the module surface from {APP_DATA_CONTRACT_PATH}. Page-only bundles must not "
            "declare app business data owned by missing modules."
        )

    for folder_module_id, path in sorted(module_yaml_paths.items()):
        if folder_module_id not in module_surface_ids:
            continue
        declared_module_id = _declared_module_id_from_yaml(path, normalized_files.get(path, ""))
        if declared_module_id and declared_module_id != folder_module_id:
            errors.append(
                f"{path}: module.id {declared_module_id!r} must match folder module id "
                f"{folder_module_id!r} declared by {APP_DATA_CONTRACT_PATH}."
            )
    return errors


def _scan_reserved_app_paths(files_map: dict[str, str]) -> list[str]:
    """Enforce path boundaries shared by generated and authored apps."""
    errors: list[str] = []
    unsafe_paths = unsafe_app_paths(files_map)
    if unsafe_paths:
        errors.append(
            "App bundle contains absolute or traversal paths outside the app root: "
            f"{unsafe_paths}. Every app path must be app-root-relative."
        )
    normalized_paths = sorted(_normalized_files_map(files_map))
    legacy_paths = disallowed_legacy_app_paths(normalized_paths)
    if legacy_paths:
        errors.append(
            "App bundle contains removed app paths that are no longer canonical: "
            f"{legacy_paths}. Use {APP_DATA_CONTRACT_PATH}, data/migrations/*.json, "
            f"and {APP_SECURITY_SECRETS_PATH}."
        )
    # Authored hosts may own additional typed declarative policies. Imperative
    # code in these planes is prohibited for every app, independent of the
    # generated-output file allowlist applied by the layout validator.
    code_suffixes = {".py", ".js", ".jsx", ".ts", ".tsx"}
    misplaced = [
        path
        for path in normalized_paths
        if (
            (
                path.startswith(("security/", "data/"))
                and PurePosixPath(path).suffix in code_suffixes
            )
            or is_sensitive_app_config_path(path)
        )
        and path not in legacy_paths
    ]
    if misplaced:
        errors.append(
            "App bundle contains imperative helpers in declarative data/security planes or misplaced secret config: "
            f"{misplaced}. Keep backend code in modules/services and secret references in "
            f"{APP_SECURITY_SECRETS_PATH}."
        )
    return errors


def _scan_canonical_app_paths(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None = None,
) -> list[str]:
    errors = _scan_reserved_app_paths(files_map)
    normalized_paths = sorted(_normalized_files_map(files_map))
    try:
        declared_pack_paths = resolve_declared_pack_output_paths(capability_packs)
    except ManagedCapabilityTemplateError as exc:
        return [*errors, f"Selected CapabilityPack output contract is invalid: {exc}"]

    invalid_config_paths = sorted(
        set(noncanonical_app_config_paths(normalized_paths)) - declared_pack_paths
    )
    if invalid_config_paths:
        errors.append(
            "Generated app bundle contains noncanonical app config files: "
            f"{invalid_config_paths}. Keep app config limited to config/ai.json, "
            "config/shell.json, config/asset_manifest.json, config/targets.json, "
            "and safe integration metadata under config/integrations/. Brownfield "
            "descriptors, credential metadata, and build-time prompting context do "
            "not belong under app/config/."
        )

    invalid_root_paths = sorted(
        set(noncanonical_app_root_paths(normalized_paths)) - declared_pack_paths
    )
    if invalid_root_paths:
        errors.append(
            "Generated app bundle contains files outside the canonical app planes: "
            f"{invalid_root_paths}. Allowed app-root planes are admin, backend, brand, "
            "config, dashboard, data, modules, refinement_harness, security, services, "
            "and ui, plus provenance.yaml and explicit deployment files."
        )
    return errors


def _scan_security_secret_contract(files_map: dict[str, str]) -> list[str]:
    raw = _normalized_files_map(files_map).get(APP_SECURITY_SECRETS_PATH)
    if raw is None:
        return []
    from mozaiksai.core.secrets import SecretContractError, validate_secret_contract

    try:
        parsed = yaml.safe_load(raw)
    except yaml.YAMLError:
        return [f"{APP_SECURITY_SECRETS_PATH}: secrets contract must be valid YAML"]
    try:
        validate_secret_contract(parsed)
    except SecretContractError as exc:
        return [f"{APP_SECURITY_SECRETS_PATH}: {exc}; raw credential fields are forbidden"]
    return []


def _pack_id_from_descriptor(pack: Any) -> str:
    """The resolver's one pack-identity precedence (``id``, ``pack_id``, ``capability_pack_id``)."""
    return selected_pack_id(pack)


def _selected_managed_capability_ids(capability_packs: list[dict[str, Any]] | None) -> set[str]:
    ids: set[str] = set()
    for pack in capability_packs or []:
        if not isinstance(pack, dict):
            continue
        if str(pack.get("capability_source") or "").strip() != "managed_capability":
            continue
        pack_id = _pack_id_from_descriptor(pack)
        if pack_id:
            ids.add(pack_id)
    return ids


def _selected_pack_descriptor(
    capability_packs: list[dict[str, Any]] | None,
    pack_id: str,
) -> dict[str, Any] | None:
    for pack in capability_packs or []:
        if not isinstance(pack, dict):
            continue
        if _pack_id_from_descriptor(pack) == pack_id:
            return pack
    return None


def _packs_providing(
    capability_packs: list[dict[str, Any]] | None,
    capability: str,
) -> list[dict[str, Any]]:
    """Return pack descriptors whose contract declares that they provide the given capability.

    The capability comes only from ``provides_capabilities`` in the
    ``contract.yaml`` at the row's ``pack_source_path``. The scanner passes
    resolved rows, whose path is the verified source; a caller's inline
    ``provides_capabilities`` claim grants nothing. This lets operator packs
    declare their capabilities without the OSS scanner hardcoding any pack name.
    """
    result: list[dict[str, Any]] = []
    for pack in capability_packs or []:
        if not isinstance(pack, dict):
            continue
        raw_source_path = str(pack.get("pack_source_path") or "").strip()
        if not raw_source_path:
            continue
        contract_path = Path(raw_source_path) / "contract.yaml"
        try:
            contract = yaml.safe_load(contract_path.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if isinstance(contract, dict):
            from_contract = contract.get("provides_capabilities") or []
            if isinstance(from_contract, list) and capability in from_contract:
                result.append(pack)
    return result


def _normalized_forbidden_output_prefix(value: Any) -> str:
    raw = value
    if isinstance(value, dict):
        raw = value.get("path_prefix") or value.get("path") or ""
    prefix = _normalized_path(str(raw or "")).lstrip("/")
    if prefix.startswith("app/"):
        prefix = prefix.removeprefix("app/")
    return prefix.rstrip("/")


def _forbidden_output_prefixes_from_pack(pack: dict[str, Any]) -> list[str]:
    """Forbidden output prefixes from the ``contract.yaml`` at the row's (verified) ``pack_source_path``.

    A caller's inline ``forbidden_outputs`` is not a pack contract and is not read.
    """
    prefixes: list[str] = []

    def add_many(items: Any) -> None:
        if not isinstance(items, list):
            return
        for item in items:
            prefix = _normalized_forbidden_output_prefix(item)
            if prefix and prefix not in prefixes:
                prefixes.append(prefix)

    raw_source_path = str(pack.get("pack_source_path") or "").strip()
    if raw_source_path:
        contract_path = Path(raw_source_path) / "contract.yaml"
        try:
            contract = yaml.safe_load(contract_path.read_text(encoding="utf-8")) or {}
        except Exception:
            contract = {}
        if isinstance(contract, dict):
            add_many(contract.get("forbidden_outputs"))

    return sorted(prefixes)


def _path_matches_prefix(path: str, prefix: str) -> bool:
    normalized_path = _normalized_path(path).rstrip("/")
    normalized_prefix = _normalized_path(prefix).rstrip("/")
    return normalized_path == normalized_prefix or normalized_path.startswith(
        f"{normalized_prefix}/"
    )


def _iter_api_endpoint_literals(content: str) -> list[str]:
    return re.findall(r'(?:["\']|:\s*)(/api/modules/[^"\'\s]+)', content)


def _load_integration_requirements(
    files_map: dict[str, str],
) -> tuple[list[dict[str, Any]], list[str]]:
    normalized_files = _normalized_files_map(files_map)
    requirements: list[dict[str, Any]] = []
    errors: list[str] = []
    for path in (
        "config/integrations.yaml",
        "app/config/integrations.yaml",
    ):
        raw = normalized_files.get(path)
        if raw is None:
            continue
        try:
            parsed = yaml.safe_load(raw) or {}
        except Exception as exc:
            errors.append(f"{path}: integration contract must be valid YAML: {exc}")
            continue
        if not isinstance(parsed, dict):
            errors.append(f"{path}: integration contract must be an object.")
            continue
        raw_requirements = parsed.get("requirements")
        if raw_requirements is None:
            raw_requirements = parsed.get("integrations")
        if raw_requirements is None:
            continue
        if not isinstance(raw_requirements, list):
            errors.append(f"{path}: integration requirements must be a list.")
            continue
        requirements.extend(item for item in raw_requirements if isinstance(item, dict))
    return requirements, errors


def _requirement_uses_managed_lane(requirement: dict[str, Any]) -> bool:
    allowed = requirement.get("allowed_setup_lanes")
    lanes: set[str] = set()
    if isinstance(allowed, list):
        lanes.update(str(item or "").strip() for item in allowed)
    preferred = str(requirement.get("preferred_setup_lane") or "").strip()
    if preferred:
        lanes.add(preferred)
    return "managed" in lanes


def _managed_requirement_labels(requirements: list[dict[str, Any]]) -> list[str]:
    labels: list[str] = []
    for requirement in requirements:
        if not _requirement_uses_managed_lane(requirement):
            continue
        label = str(
            requirement.get("integration_id")
            or requirement.get("service")
            or requirement.get("provider")
            or "<unknown>"
        ).strip()
        if label and label not in labels:
            labels.append(label)
    return sorted(labels)


def _scan_managed_setup_provider_leaks(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None,
) -> list[str]:
    requirements, errors = _load_integration_requirements(files_map)
    managed_labels = _managed_requirement_labels(requirements)
    selected_managed = sorted(_selected_managed_capability_ids(capability_packs))
    if not managed_labels and not selected_managed:
        return errors

    context = sorted(set(managed_labels + selected_managed))
    context_label = ", ".join(context) if context else "managed setup"
    normalized_files = _normalized_files_map(files_map)
    for path, content in sorted(normalized_files.items()):
        if not isinstance(content, str):
            continue
        if _MANAGED_SETUP_RAW_PROVIDER_ENV_RE.search(content):
            errors.append(
                f"{path}: managed setup lane ({context_label}) must not expose raw "
                "payment-provider environment handles. Use the managed capability "
                "client contract and names-only Mozaiks-managed handles instead."
            )
        if _MANAGED_SETUP_PROVIDER_ROUTE_RE.search(content):
            errors.append(
                f"{path}: managed setup lane ({context_label}) must not generate raw "
                "payment-provider webhook or checkout routes. Provider callbacks "
                "belong in the managed/hosted product boundary."
            )
        if _MANAGED_SETUP_PROVIDER_MECHANIC_RE.search(content):
            errors.append(
                f"{path}: managed setup lane ({context_label}) must not contain raw "
                "payment-provider SDK mechanics. Generated apps should call an "
                "app-owned facade or managed capability client."
            )
    return errors


def _scan_selected_managed_capability_boundaries(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None,
) -> list[str]:
    managed_capability_ids = _selected_managed_capability_ids(capability_packs)
    if not managed_capability_ids:
        return []

    normalized_files = _normalized_files_map(files_map)
    errors: list[str] = []
    for pack_id in sorted(managed_capability_ids):
        pack = _selected_pack_descriptor(capability_packs, pack_id) or {"id": pack_id}
        forbidden_prefixes = _forbidden_output_prefixes_from_pack(pack)
        forbidden_output_paths = {
            path
            for path in normalized_files
            for prefix in forbidden_prefixes
            if _path_matches_prefix(path, prefix)
        }
        if forbidden_output_paths:
            errors.append(
                f"Selected managed capability '{pack_id}' declares forbidden output prefixes "
                f"{forbidden_prefixes}; generated bundle contains forbidden paths: "
                f"{sorted(forbidden_output_paths)}."
            )

        managed_capability_module_prefix = f"modules/{pack_id}/"
        managed_capability_module_paths = [
            path for path in normalized_files if path.startswith(managed_capability_module_prefix)
        ]
        if managed_capability_module_paths:
            errors.append(
                f"Selected managed capability '{pack_id}' must not generate provider internals: "
                f"{managed_capability_module_paths}. Generate app-owned facade modules instead."
            )

        adapter_path = f"services/integrations/{pack_id}_client.py"
        if adapter_path not in normalized_files:
            errors.append(
                f"Selected managed capability '{pack_id}' requires app-owned adapter "
                f"{adapter_path}."
            )

        direct_endpoint_prefix = f"/api/modules/{pack_id}/"
        for path, content in normalized_files.items():
            if not _is_scannable(path):
                continue
            for endpoint in _iter_api_endpoint_literals(content):
                if endpoint.startswith(direct_endpoint_prefix):
                    errors.append(
                        f"{path}: calls managed capability endpoint "
                        f"{endpoint} directly. Use an app-owned facade module instead."
                    )
    return errors


def _load_yaml_mapping_from_file(
    files_map: dict[str, str],
    path: str,
) -> tuple[dict[str, Any] | None, str | None]:
    raw = files_map.get(path)
    if raw is None:
        return None, None
    try:
        parsed = yaml.safe_load(str(raw)) or {}
    except Exception as exc:
        return None, f"{path}: must be valid YAML: {exc}"
    if not isinstance(parsed, dict):
        return None, f"{path}: must be a YAML object."
    return parsed, None


def _module_actions_from_yaml(path: str, content: str) -> set[str]:
    parsed, error = _load_yaml_mapping_from_file({path: content}, path)
    if error or not isinstance(parsed, dict):
        return set()
    actions = parsed.get("actions")
    if not isinstance(actions, list):
        return set()
    return {
        str(action.get("id") or "").strip()
        for action in actions
        if isinstance(action, dict) and str(action.get("id") or "").strip()
    }


def _page_endpoint_literals(content: str) -> list[str]:
    return re.findall(r'(?:["\']|:\s*)(/api/modules/[^"\'\s]+)', content)


def _validate_subscriptions_contract(
    files_map: dict[str, str],
    *,
    path: str = "config/subscriptions.yaml",
) -> list[str]:
    raw, error = _load_yaml_mapping_from_file(files_map, path)
    if error:
        return [error]
    if not isinstance(raw, dict):
        return [f"{path}: generated SaaS apps must include config/subscriptions.yaml."]

    try:
        from mozaiksai.core.runtime.app.subscriptions_loader import SubscriptionsConfig

        config = SubscriptionsConfig.model_validate(raw)
    except Exception as exc:
        return [f"{path}: invalid subscriptions contract: {exc}"]

    errors: list[str] = []
    plans_with_token_allowances = [plan.plan_id for plan in config.plans if plan.token_allowances]
    plans_with_usage_limits = [plan.plan_id for plan in config.plans if plan.usage_limits]
    if not config.token_wallets:
        if plans_with_token_allowances:
            errors.append(f"{path}: token_allowances require declared token_wallets.")
        if config.top_up_products:
            errors.append(f"{path}: top_up_products require declared token_wallets.")
        return errors

    if not (
        plans_with_token_allowances
        or plans_with_usage_limits
        or config.top_up_products
        or config.usage_charge_policies
    ):
        errors.append(
            f"{path}: token_wallets must be emitted only for generated apps that sell "
            "AI usage, credits, quotas, top-ups, or usage-charge estimates."
        )
    return errors


def _scan_token_wallets_require_mozaikspay(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None,
) -> list[str]:
    """Generated apps that declare top_up_products must select the mozaikspay pack.

    top_up_products requires a hosted payment processor to create checkout sessions.
    The OSS runtime ledger can track balances without MozaiksPay, but token top-ups
    need a billing provider. This gate enforces the selection so the billing_portal
    module is generated and the checkout/top-up surfaces are wired correctly.

    Note: token_wallets alone without top_up_products is valid for self-hosted OSS
    apps that use entitlement_dispatch for plan enforcement and do not sell top-ups.
    """
    normalized_files = _normalized_files_map(files_map)
    subs_path = "config/subscriptions.yaml"
    raw, _ = _load_yaml_mapping_from_file(normalized_files, subs_path)
    if not isinstance(raw, dict):
        return []

    top_up_products = raw.get("top_up_products")
    if not top_up_products or not isinstance(top_up_products, list) or len(top_up_products) == 0:
        return []

    # top_up_products declared — mozaikspay must be selected as a managed_capability
    pack = _selected_pack_descriptor(capability_packs, "mozaikspay")
    if pack and str(pack.get("capability_source") or "").strip() == "managed_capability":
        return []

    return [
        f"{subs_path}: declares top_up_products but the mozaikspay managed capability pack "
        "is not selected. Token top-up products require a hosted billing provider to create "
        "checkout sessions. Add mozaikspay to AppBuildPlan.capability_packs with "
        "capability_source: managed_capability."
    ]


def _scan_mozaikspay_saas_contract(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None,
) -> list[str]:
    pack = _selected_pack_descriptor(capability_packs, "mozaikspay")
    if not pack or str(pack.get("capability_source") or "").strip() != "managed_capability":
        return []

    normalized_files = _normalized_files_map(files_map)
    errors: list[str] = []

    required_paths = {
        "config/subscriptions.yaml",
        "services/integrations/mozaikspay_client.py",
        "modules/billing_portal/module.yaml",
        "modules/billing_portal/backend/handler.py",
        "modules/billing_portal/backend/service.py",
        "modules/billing_portal/backend/schemas.py",
        "ui/pages/billing.yaml",
        "ui/pages/usage.yaml",
        "ui/pages/pricing.yaml",
    }
    missing = sorted(path for path in required_paths if path not in normalized_files)
    if missing:
        errors.append(
            "Selected mozaikspay SaaS capability requires deterministic generated app files: "
            f"{missing}."
        )

    errors.extend(_validate_subscriptions_contract(normalized_files))

    client_content = normalized_files.get("services/integrations/mozaikspay_client.py", "")
    if client_content:
        required_markers = {
            "_CONNECTOR_SERVICE": "_CONNECTOR_SERVICE",
            "mozaikspay": "mozaikspay",
            "ConnectorStore": "ConnectorStore",
            "get_connector_vault_backend": "get_connector_vault_backend",
            "MOZAIKSPAY_API_BASE": "MOZAIKSPAY_API_BASE",
            "MOZAIKSPAY_API_KEY": "MOZAIKSPAY_API_KEY",
        }
        missing_markers = [
            label for label, marker in required_markers.items() if marker not in client_content
        ]
        if missing_markers:
            errors.append(
                "services/integrations/mozaikspay_client.py must resolve the app-scoped "
                f"mozaikspay connector and env fallback; missing markers: {missing_markers}."
            )

    env_example = normalized_files.get(".env.example", "")
    if env_example:
        required_env_handles = {
            "MOZAIKS_APP_URL",
            "MOZAIKSPAY_API_BASE",
            "MOZAIKSPAY_CLIENT_ID",
            "MOZAIKSPAY_CLIENT_SECRET",
            "MOZAIKSPAY_API_KEY",
        }
        missing_env_handles = sorted(
            name for name in required_env_handles if f"{name}=" not in env_example
        )
        if missing_env_handles:
            errors.append(
                ".env.example must document the MozaiksPay connector/env fallback handles "
                f"for generated SaaS apps: {missing_env_handles}."
            )

    module_content = normalized_files.get("modules/billing_portal/module.yaml", "")
    if module_content:
        actions = _module_actions_from_yaml("modules/billing_portal/module.yaml", module_content)
        required_actions = {
            "get_subscription_status",
            "get_usage_status",
            "list_plans",
            "open_billing_portal",
        }
        missing_actions = sorted(required_actions - actions)
        if missing_actions:
            errors.append(
                "modules/billing_portal/module.yaml must expose app-owned SaaS billing facade "
                f"actions: {missing_actions}."
            )
        parsed_module, module_parse_error = _load_yaml_mapping_from_file(
            {"modules/billing_portal/module.yaml": module_content},
            "modules/billing_portal/module.yaml",
        )
        if not module_parse_error and isinstance(parsed_module, dict):
            for action in parsed_module.get("actions") or []:
                if not isinstance(action, dict) or action.get("id") != "list_plans":
                    continue
                surface = str(action.get("api_surface") or "").strip()
                if surface not in {"public", "public_readonly"} or action.get("permissions"):
                    errors.append(
                        "modules/billing_portal/module.yaml: 'list_plans' is the canonical "
                        "anonymous data source for the public /pricing page and must declare "
                        "api_surface public_readonly with no permissions."
                    )
        declared_module_id = _declared_module_id_from_yaml(
            "modules/billing_portal/module.yaml",
            module_content,
        )
        if declared_module_id != "billing_portal":
            errors.append(
                "modules/billing_portal/module.yaml must declare module.id 'billing_portal'."
            )

    service_content = normalized_files.get("modules/billing_portal/backend/service.py", "")
    if service_content:
        service_markers = {
            "MozaiksPayClient": "MozaiksPayClient",
            "get_subscription_status_for_scope": "get_subscription_status_for_scope",
            "get_runtime_ai_usage": "get_runtime_ai_usage",
            "create_billing_portal_session": "create_billing_portal_session",
        }
        missing_service_markers = [
            label for label, marker in service_markers.items() if marker not in service_content
        ]
        if missing_service_markers:
            errors.append(
                "modules/billing_portal/backend/service.py must delegate subscription, usage, "
                f"and portal operations through MozaiksPayClient; missing markers: {missing_service_markers}."
            )
        forbidden_terms = [
            "assign_plan",
            "cancel_subscription",
            "expire_subscription",
            "record_usage",
            "upsert_grants",
            "PaymentProviderBillingClient",
            "import payment_provider",
            "from payment_provider import",
        ]
        leaked_terms = sorted(term for term in forbidden_terms if term in service_content)
        if leaked_terms:
            errors.append(
                "modules/billing_portal/backend/service.py must not expose managed billing internals "
                f"or provider credentials: {leaked_terms}."
            )

    page_requirements = {
        "ui/pages/billing.yaml": {
            "/api/modules/billing_portal/get_subscription_status",
            "/api/modules/billing_portal/open_billing_portal",
        },
        "ui/pages/usage.yaml": {
            "/api/modules/billing_portal/get_usage_status",
        },
        "ui/pages/pricing.yaml": {
            "/api/modules/billing_portal/list_plans",
        },
    }
    for page_path, required_endpoints in page_requirements.items():
        content = normalized_files.get(page_path, "")
        if not content:
            continue
        endpoints = set(_page_endpoint_literals(content))
        missing_endpoints = sorted(required_endpoints - endpoints)
        if missing_endpoints:
            errors.append(
                f"{page_path}: generated SaaS page must bind through billing_portal facade endpoints: "
                f"{missing_endpoints}."
            )
        direct_forbidden = [
            endpoint
            for endpoint in endpoints
            if endpoint.startswith(
                (
                    "/api/modules/mozaikspay/",
                    "/api/modules/wallet/",
                )
            )
        ]
        if direct_forbidden:
            errors.append(
                f"{page_path}: generated SaaS page must not bind directly to managed/provider modules: "
                f"{sorted(direct_forbidden)}."
            )

    return errors


def _scan_outcome_feedback_contract(files_map: dict[str, str]) -> list[str]:
    """Keep the shipped feedback sink private and free from authored evidence writes."""
    module_path = "modules/outcome_feedback/module.yaml"
    if module_path not in files_map:
        return []
    from mozaiksai.core.runtime.persistence.intent_loader import iter_data_contract_collections
    from mozaiksai.core.workflow.outcome_feedback import WorkflowFeedbackEvidence

    try:
        contract = json.loads(files_map.get("data/contract.json", "{}"))
        collections = [
            item for owner, kind, item in iter_data_contract_collections(contract)
            if owner == "outcome_feedback" and kind == "module"
        ]
    except (ValueError, TypeError) as exc:
        return [f"outcome_feedback requires an approved private data contract: {exc}"]
    if len(collections) != 1 or collections[0].get("name") != "records":
        return ["outcome_feedback requires exactly its approved records collection"]
    collection = collections[0]
    expected = {"scope": "app", "tenancy": "per_user", "owner_field": "user_id", "entity": "WorkflowFeedback"}
    errors = []
    if any(collection.get(key) != value for key, value in expected.items()):
        errors.append("outcome_feedback.records requires app scope and per_user ownership of WorkflowFeedback")
    lifecycle = collection.get("lifecycle")
    if not isinstance(lifecycle, dict) or lifecycle.get("write_mode") != "workflow_write":
        errors.append("outcome_feedback.records requires lifecycle.write_mode=workflow_write; arbitrary evidence CRUD is forbidden")
    fields = {item.get("name") for item in collection.get("fields") or [] if isinstance(item, dict)}
    missing = sorted((set(WorkflowFeedbackEvidence.model_fields) | {"feedback_id"}) - fields)
    if missing:
        errors.append(f"outcome_feedback.records must declare receipt fields for private storage and account export: {missing}")
    try:
        manifest = yaml.safe_load(files_map[module_path])
        if not isinstance(manifest, dict):
            raise ValueError("module must be an object")
        actions = {action["id"] for action in manifest.get("actions") or []}
        extra = actions - {"record_workflow_feedback", "list_my_feedback", "get_records", "list_records"}
        if extra:
            errors.append(f"outcome_feedback cannot expose authored evidence mutations: {sorted(extra)}")
        record = next(action for action in manifest.get("actions") or [] if action["id"] == "record_workflow_feedback")
        schema = record.get("input_schema") or {}
        if (
            set(schema.get("properties") or {}) != {"ui_event_id", "outcome_id"}
            or set(schema.get("required") or []) != {"ui_event_id", "outcome_id"}
            or schema.get("additionalProperties") is not False
        ):
            errors.append("outcome_feedback.record_workflow_feedback must accept only ui_event_id and outcome_id")
    except (AttributeError, ValueError, TypeError, KeyError, StopIteration, yaml.YAMLError):
        errors.append("outcome_feedback requires its declared receipt-only record action")
    return errors


def _scan_mozaiks_cloud_connector_contract(
    files_map: dict[str, Any],
    *,
    capability_packs: list[dict[str, Any]] | None,
) -> list[str]:
    """Validate Mozaiks Cloud connector contract when the pack is selected.

    When mozaiks_cloud is selected as managed_capability:
    - All four client files must be present.
    - The transport client must resolve credentials from ConnectorStore/env.
    - Both facade module YAMLs must declare expected actions.
    - No Azure SDK or Cloudflare SDK imports may appear anywhere in the bundle.
    When the pack is NOT selected, this check is a no-op — absence is proven
    by the fact that the templates were never materialized.
    """
    pack = _selected_pack_descriptor(capability_packs, "mozaiks_cloud")
    if not pack or str(pack.get("capability_source") or "").strip() != "managed_capability":
        return []

    normalized_files = _normalized_files_map(files_map)
    errors: list[str] = []

    required_paths = {
        "services/integrations/mozaiks_cloud_client.py",
        "services/integrations/mozaiks_cloud_deployment_client.py",
        "services/integrations/mozaiks_cloud_domain_client.py",
        "modules/cloud_deployment/module.yaml",
        "modules/cloud_domain/module.yaml",
    }
    missing = sorted(path for path in required_paths if path not in normalized_files)
    if missing:
        errors.append(
            "Selected mozaiks_cloud connector capability requires deterministic generated app "
            f"files: {missing}."
        )

    client_content = normalized_files.get("services/integrations/mozaiks_cloud_client.py", "")
    if client_content:
        required_markers = {
            "_CONNECTOR_SERVICE": "_CONNECTOR_SERVICE",
            "mozaiks_cloud": "mozaiks_cloud",
            "ConnectorStore": "ConnectorStore",
            "get_connector_vault_backend": "get_connector_vault_backend",
            "MOZAIKS_CLOUD_API_BASE": "MOZAIKS_CLOUD_API_BASE",
            "MOZAIKS_CLOUD_API_KEY": "MOZAIKS_CLOUD_API_KEY",
        }
        missing_markers = [
            label for label, marker in required_markers.items() if marker not in client_content
        ]
        if missing_markers:
            errors.append(
                "services/integrations/mozaiks_cloud_client.py must resolve the app-scoped "
                f"mozaiks_cloud connector and env fallback; missing markers: {missing_markers}."
            )

    deployment_module = normalized_files.get("modules/cloud_deployment/module.yaml", "")
    if deployment_module:
        actions = _module_actions_from_yaml(
            "modules/cloud_deployment/module.yaml", deployment_module
        )
        required_actions = {
            "submit_deployment",
            "get_deployment_status",
            "get_environment_endpoints",
            "request_rollback",
        }
        missing_actions = sorted(required_actions - actions)
        if missing_actions:
            errors.append(
                "modules/cloud_deployment/module.yaml must expose cloud_deployment facade "
                f"actions: {missing_actions}."
            )
        declared_id = _declared_module_id_from_yaml(
            "modules/cloud_deployment/module.yaml", deployment_module
        )
        if declared_id != "cloud_deployment":
            errors.append(
                "modules/cloud_deployment/module.yaml must declare module.id 'cloud_deployment'."
            )

    domain_module = normalized_files.get("modules/cloud_domain/module.yaml", "")
    if domain_module:
        actions = _module_actions_from_yaml("modules/cloud_domain/module.yaml", domain_module)
        required_actions = {
            "connect_domain",
            "get_domain_verification",
            "get_dns_instructions",
            "request_domain_activation",
            "get_domain_status",
            "disconnect_domain",
        }
        missing_actions = sorted(required_actions - actions)
        if missing_actions:
            errors.append(
                "modules/cloud_domain/module.yaml must expose cloud_domain facade "
                f"actions: {missing_actions}."
            )
        declared_id = _declared_module_id_from_yaml(
            "modules/cloud_domain/module.yaml", domain_module
        )
        if declared_id != "cloud_domain":
            errors.append("modules/cloud_domain/module.yaml must declare module.id 'cloud_domain'.")

    return errors


def _entitlement_gates_from_module_yaml(path: str, content: str) -> set[str]:
    parsed, error = _load_yaml_mapping_from_file({path: content}, path)
    if error or not isinstance(parsed, dict):
        return set()
    gates: set[str] = set()
    for action in parsed.get("actions") or []:
        if not isinstance(action, dict):
            continue
        gate = str(action.get("entitlement_gate") or "").strip()
        if gate:
            gates.add(gate)
    return gates


def _entitlement_gate_map_from_module_yaml(path: str, content: str) -> dict[str, str]:
    """Return {action_id: entitlement_gate} for every gated action in module.yaml."""
    parsed, error = _load_yaml_mapping_from_file({path: content}, path)
    if error or not isinstance(parsed, dict):
        return {}
    result: dict[str, str] = {}
    for action in parsed.get("actions") or []:
        if not isinstance(action, dict):
            continue
        gate = str(action.get("entitlement_gate") or "").strip()
        action_id = str(action.get("id") or "").strip()
        if gate and action_id:
            result[action_id] = gate
    return result


def _subscriptions_config_from_yaml(path: str, content: str) -> tuple[Any | None, str | None]:
    raw, error = _load_yaml_mapping_from_file({path: content}, path)
    if error:
        return None, error
    try:
        from mozaiksai.core.runtime.app.subscriptions_loader import SubscriptionsConfig

        return SubscriptionsConfig.model_validate(raw), None
    except Exception as exc:
        return None, f"{path}: invalid subscriptions contract: {exc}"


def _capability_ids_from_subscriptions_config(config: Any) -> set[str]:
    """Extract capability_ids using the canonical subscriptions loader output."""
    capability_ids: set[str] = set()
    for plan in getattr(config, "plans", None) or []:
        capability_ids.update(
            str(cap).strip() for cap in (plan.capabilities or []) if str(cap).strip()
        )
    for product in getattr(config, "products", None) or []:
        for plan in getattr(product, "plans", None) or []:
            capability_ids.update(
                str(cap).strip() for cap in (plan.capabilities or []) if str(cap).strip()
            )
    return capability_ids


def _capability_ids_from_subscriptions_yaml(content: str) -> set[str]:
    """Extract plan-granted capability_ids from canonical subscriptions parsing."""
    config, error = _subscriptions_config_from_yaml("config/subscriptions.yaml", content)
    if error or config is None:
        return set()
    return _capability_ids_from_subscriptions_config(config)


def _scan_subscription_assignment_storage(files_map: dict[str, str]) -> list[str]:
    """Require configured assignment aliases to close even without build context."""
    content = files_map.get("config/subscriptions.yaml")
    if not content:
        return []
    config, error = _subscriptions_config_from_yaml("config/subscriptions.yaml", content)
    if error or config is None:
        return []  # The subscription contract scan reports parsing errors.
    stores = [owner.assignment_store for owner in [config, *config.products] if owner.assignment_store is not None]
    if not stores:
        return []
    actual, error = _load_data_contract(files_map)
    if error or actual is None:
        return [error or "data/contract.json: configured assignment_store requires declared aliases and collections."]
    try:
        compiled = ensure_subscription_assignment_stores(actual, {
            "contract_required": True,
            "subscription_config_file": config.model_dump(mode="json"),
        })
    except ValueError as exc:
        return [f"data/contract.json: {exc}"]
    if compiled != actual:
        return ["data/contract.json: configured assignment_store aliases and collections must be materialized before promotion."]
    return []


def _scan_self_hosted_entitlement_dispatch_contract(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None,
) -> list[str]:
    """Validate the self-hosted entitlement_dispatch module contract.

    Fires when config/subscriptions.yaml declares an assignment_store and
    no selected managed-capability pack declares provides_capabilities:
    [subscription_write_path]. In that case the generated app owns the
    subscription assignment write path, and an entitlement_dispatch module is
    required.
    """
    # Any managed capability pack that declares provides_capabilities:
    # [subscription_write_path] owns the subscription assignment write path.
    # entitlement_dispatch is only needed when no such pack is selected.
    managed_writers = [
        p
        for p in _packs_providing(capability_packs, "subscription_write_path")
        if str(p.get("capability_source") or "").strip() == "managed_capability"
    ]
    if managed_writers:
        return []

    normalized_files = _normalized_files_map(files_map)
    subs_content = normalized_files.get("config/subscriptions.yaml")
    if not subs_content:
        return []

    try:
        subs_config = yaml.safe_load(subs_content) or {}
    except Exception:
        return []

    if not isinstance(subs_config, dict) or not subs_config.get("assignment_store"):
        return []

    errors: list[str] = []
    dispatch_path = "modules/entitlement_dispatch/module.yaml"
    dispatch_content = normalized_files.get(dispatch_path)
    if not dispatch_content:
        errors.append(
            "config/subscriptions.yaml declares assignment_store but "
            f"{dispatch_path} is missing. Self-hosted apps require an "
            "entitlement_dispatch module to write subscription assignment records."
        )
        return errors

    declared_id = _declared_module_id_from_yaml(dispatch_path, dispatch_content)
    if declared_id != "entitlement_dispatch":
        errors.append(
            f"{dispatch_path}: module.id must be 'entitlement_dispatch', got {declared_id!r}."
        )

    actions = _module_actions_from_yaml(dispatch_path, dispatch_content)
    required_actions = {"activate_subscription", "deactivate_subscription"}
    missing_actions = sorted(required_actions - actions)
    if missing_actions:
        errors.append(
            f"{dispatch_path}: entitlement_dispatch module must declare actions "
            f"{sorted(required_actions)}; missing: {missing_actions}."
        )

    return errors


def _scan_entitlement_gate_capability_alignment(files_map: dict[str, str]) -> list[str]:
    """Validate entitlement_gate ↔ subscriptions.yaml compile-time closure.

    For every module action that declares an entitlement_gate capability_id,
    that capability_id must appear in at least one plan's capabilities list in
    config/subscriptions.yaml. An unresolvable gate causes permanent runtime
    denial for all callers regardless of their subscription tier.

    Skips apps without config/subscriptions.yaml (ungated apps, NoOp adapter).
    Apps with config/subscriptions.yaml use ConfiguredEntitlementAdapter at
    platform startup; assignment_store controls persisted assignment lookup, not
    adapter selection.

    Diagnostics include:
    - module path and action id of the gated action
    - the unresolvable capability_id
    - typo near-matches found in the declared plan capabilities
    - confirmation location (config/subscriptions.yaml plans[].capabilities[])
    - whether no plan grants any capabilities at all

    Errors are returned in deterministic sorted order.
    """
    import difflib

    normalized_files = _normalized_files_map(files_map)
    subs_content = normalized_files.get("config/subscriptions.yaml")
    if not subs_content:
        # No subscriptions.yaml -> ungated app, so ModuleExecutor uses NoOp.
        return []

    subscriptions_config, subscriptions_error = _subscriptions_config_from_yaml(
        "config/subscriptions.yaml",
        subs_content,
    )
    if subscriptions_error:
        return [subscriptions_error]
    assert subscriptions_config is not None
    plan_capabilities = _capability_ids_from_subscriptions_config(subscriptions_config)
    shared_capabilities: set[str] = set()
    if subscriptions_config.schema_version == "mozaiks.subscriptions.v1" and subscriptions_config.plans:
        shared_capabilities = set.intersection(*(
            set(plan.capabilities) for plan in subscriptions_config.plans
        ))
    plan_specific_capabilities = plan_capabilities - shared_capabilities
    workflow_capabilities = sorted(
        capability for capability in plan_capabilities
        if capability.startswith("feature.workflow.")
    )
    if workflow_capabilities:
        return [
            "config/subscriptions.yaml grants workflow features "
            f"{workflow_capabilities}, but workflow launch does not enforce plan grants "
            "(issue #770). Remove these features from the approved plan selections "
            "and rerun SubscriptionContractDesigner."
        ]
    derived_module_capabilities = {
        capability for capability in plan_specific_capabilities
        if capability.startswith("feature.module.")
    }

    # Collect (module_path, action_id, gate) for every gated action.
    gate_contexts: list[tuple[str, str, str]] = []
    for path, content in sorted(normalized_files.items()):
        if not path.startswith("modules/") or not path.endswith("/module.yaml"):
            continue
        gate_map = _entitlement_gate_map_from_module_yaml(path, content)
        for action_id, gate in sorted(gate_map.items()):
            gate_contexts.append((path, action_id, gate))

    if not gate_contexts:
        module_paths = sorted(
            path
            for path in normalized_files
            if path.startswith("modules/") and path.endswith("/module.yaml")
        )
        if plan_specific_capabilities and (module_paths or derived_module_capabilities):
            # A capability that differs by plan needs an enforced action gate.
            return [
                "config/subscriptions.yaml grants plan-specific capabilities "
                f"{sorted(plan_specific_capabilities)} but no module action declares an "
                "entitlement_gate. A SaaS bundle that sells capabilities must "
                "enforce at least one of them: correct the approved subscription "
                "plan's feature selections for an approved write or declared custom "
                "read, then rerun deterministic gate compilation "
                f"for {module_paths}. Do not author entitlement_gate in model output; "
                "canonical list/get and managed facade actions cannot be gated."
            ]
        return []

    errors: list[str] = []
    matched_module_capabilities: set[str] = set()
    for module_path, action_id, gate in gate_contexts:
        module_id = PurePosixPath(module_path).parts[1]
        try:
            derived_gate = capability_id_for_feature(f"module.{module_id}.{action_id}")
        except ValueError:
            derived_gate = None  # The module contract validator reports invalid action ids.
        if gate == derived_gate:
            matched_module_capabilities.add(gate)
        if gate.startswith("feature.module.") and gate in shared_capabilities:
            errors.append(
                f"{module_path}: action '{action_id}' declares entitlement_gate '{gate}' "
                "for a feature included in every plan. Remove the derived gate so "
                "cancelled or unsubscribed users retain this shared feature."
            )
            continue
        if gate in plan_capabilities:
            continue

        msg = (
            f"{module_path}: action '{action_id}' declares "
            f"entitlement_gate '{gate}' which is not granted by any plan in "
            f"config/subscriptions.yaml. "
            f"Actions with an unresolvable gate permanently deny all callers "
            f"regardless of subscription tier. "
            "Correct the approved plan's selected features, then regenerate "
            "derived plan capabilities and module gates from that contract. "
            "Do not edit generated capabilities or author entitlement_gate in model output. "
            f"Derived plan capability location: config/subscriptions.yaml → "
            f"plans[].capabilities[] (v1) or "
            f"products[].plans[].capabilities[] (v2)."
        )
        if plan_capabilities:
            close = difflib.get_close_matches(gate, sorted(plan_capabilities), n=3, cutoff=0.7)
            if close:
                msg += f" Near-matches in declared plan capabilities: {close}."
        else:
            msg += " No plan currently grants any capabilities."
        errors.append(msg)

    missing_module_capabilities = sorted(derived_module_capabilities - matched_module_capabilities)
    if missing_module_capabilities:
        errors.append(
            "config/subscriptions.yaml grants derived module capabilities "
            f"{missing_module_capabilities} without matching module action entitlement_gate values. "
            "Correct the approved plan's selected features and rerun deterministic gate compilation; "
            "do not edit generated plan capabilities or author entitlement_gate in model output."
        )

    return sorted(errors)


def _scan_deployment_artifacts_contract(files_map: dict[str, str]) -> list[str]:
    normalized_files = _normalized_files_map(files_map)
    deployment_artifacts: dict[str, str] = {
        path: normalized_files[path]
        for path in (
            "Dockerfile",
            ".env.example",
            ".env.staging.example",
            ".env.production.example",
            "deployment.manifest.json",
            ".github/workflows/readiness.yml",
            ".github/workflows/deploy.yml",
        )
        if path in normalized_files
    }
    try:
        from .deployment_contract import validate_generated_deployment_bundle

        deployment_errors = validate_generated_deployment_bundle(
            deployment_artifacts,
            include_dockerfiles=True,
            include_readiness_workflow=".github/workflows/readiness.yml" in deployment_artifacts,
            include_workflow=".github/workflows/deploy.yml" in deployment_artifacts,
        )
    except Exception as exc:
        deployment_errors = [f"deployment artifact validation failed: {exc}"]
    if deployment_errors:
        return [
            "Generated app bundle must include valid provider-neutral deployment artifacts: "
            f"{deployment_errors}."
        ]
    return []


def _scan_auth_deployment_contract(files_map: dict[str, str]) -> list[str]:
    """Match app auth intent to deploy-time OIDC contract metadata."""
    try:
        required = _app_manifest_auth_required(files_map)
    except AppAuthContractError as exc:
        return [str(exc)]
    normalized_files = _normalized_files_map(files_map)
    errors: list[str] = []

    if required:
        env_example = normalized_files.get(".env.example", "")
        required_env_handles = {
            "AUTH_ENABLED",
            "AUTH_PROVIDER",
            "MOZAIKS_OIDC_DISCOVERY_URL",
            "MOZAIKS_OIDC_AUTHORITY",
            "AUTH_ISSUER",
            "AUTH_JWKS_URL",
            "VITE_OIDC_CLIENT_ID",
            "VITE_OIDC_REDIRECT_URI",
        }
        missing_env_handles = sorted(
            name for name in required_env_handles if f"{name}=" not in env_example
        )
        if missing_env_handles:
            errors.append(
                "Authenticated generated apps must document provider-neutral OIDC/JWT "
                "runtime and frontend env handles in .env.example: "
                f"{missing_env_handles}."
            )

    manifest_text = normalized_files.get("deployment.manifest.json", "")
    if manifest_text:
        try:
            manifest = json.loads(manifest_text)
        except Exception as exc:
            errors.append(
                f"deployment.manifest.json must be valid JSON for auth contract scan: {exc}"
            )
            return errors

        if not isinstance(manifest, dict):
            errors.append("deployment.manifest.json must be an object for auth contract scan.")
            return errors

        auth = manifest.get("auth")
        if required and (not isinstance(auth, dict) or auth.get("required") is not True):
            errors.append(
                "Authenticated generated apps must carry auth.required=true in "
                "deployment.manifest.json."
            )
        elif not required and isinstance(auth, dict) and auth.get("required") is True:
            errors.append(
                "Public generated apps must carry auth.required=false in "
                "deployment.manifest.json."
            )

    return errors


def _scan_auth_app_contract(
    files_map: dict[str, str],
    *,
    require_generated_adapter: bool = True,
) -> list[str]:
    """Consume the runtime auth schema and the deterministic shared-adapter facade."""
    normalized = _normalized_files_map(files_map)
    try:
        required = _app_manifest_auth_required(files_map)
    except AppAuthContractError as exc:
        return [str(exc)]
    raw_contract = normalized.get(APP_AUTH_CONFIG_PATH)
    if raw_contract is None:
        if required:
            return [
                f"Authenticated apps must include {APP_AUTH_CONFIG_PATH} "
                "with schema_version mozaiks.auth.v1."
            ]
        return []

    try:
        contract = validate_app_auth_contract(yaml.safe_load(raw_contract))
    except yaml.YAMLError:
        return [f"{APP_AUTH_CONFIG_PATH}: auth contract must be valid YAML."]
    except AppAuthContractError as exc:
        return [f"{APP_AUTH_CONFIG_PATH}: {exc}"]

    errors: list[str] = []
    if contract.auth_required != required:
        errors.append(f"{APP_AUTH_CONFIG_PATH}: auth_required must match app.json.authRequired.")
    try:
        route_manifest = json.loads(normalized.get("ui/route_manifest.json", "{}"))
        pages = route_manifest.get("pages") if isinstance(route_manifest, dict) else None
        validate_app_auth_route_bindings(contract, pages)
    except (TypeError, ValueError) as exc:
        if not isinstance(exc, AppAuthContractError):
            errors.append("ui/route_manifest.json must be valid JSON for auth routes")
        elif str(exc).startswith("Auth routes."):
            # A login or callback route binding is declared in the route manifest:
            # the path routes the diagnostic to that file's owner for repair.
            errors.append(f"ui/route_manifest.json: {exc}")
        else:
            errors.append(str(exc))
    if not require_generated_adapter:
        return errors

    adapter = normalized.get("ui/auth/authAdapter.js", "")
    profile = resolve_packaged_build_context("webapp_builder")
    if profile is None:
        raise FileNotFoundError("Installed webapp_builder profile is missing")
    expected = (profile / "templates/ui/auth/authAdapter.js").read_text(encoding="utf-8")
    if adapter.strip() != expected.strip():
        errors.append(
            "ui/auth/authAdapter.js must use the generated facade for "
            "@mozaiks/chat-ui/auth; regenerate the auth scaffold. "
            "OIDC and local-development behavior belong in the shared adapter."
        )
    return errors


def _scan_route_manifest_consistency(files_map: dict[str, str]) -> list[str]:
    """Validate ui/route_manifest.json structure when present.

    Checks that each page entry has a path starting with '/' and a non-empty
    component name. These are the minimum fields required for the runtime to
    resolve a page route.
    """
    errors: list[str] = []
    normalized = _normalized_files_map(files_map)
    manifest_raw = normalized.get("ui/route_manifest.json")
    if not manifest_raw:
        return errors

    try:
        manifest = json.loads(manifest_raw)
    except Exception:
        errors.append("ui/route_manifest.json: invalid JSON — cannot parse route manifest")
        return errors

    pages = manifest.get("pages") if isinstance(manifest, dict) else None
    if not isinstance(pages, list):
        errors.append("ui/route_manifest.json: 'pages' must be a list")
        return errors

    for i, page in enumerate(pages):
        if not isinstance(page, dict):
            errors.append(f"ui/route_manifest.json: pages[{i}] must be a dict")
            continue
        path = page.get("path")
        if not isinstance(path, str) or not path.startswith("/"):
            errors.append(
                f"ui/route_manifest.json: pages[{i}] 'path' must be a string starting with '/'"
            )
        component = page.get("component")
        if not isinstance(component, str) or not component.strip():
            errors.append(
                f"ui/route_manifest.json: pages[{i}] 'component' must be a non-empty string"
            )

    return errors


def _scan_page_schema_structure(files_map: dict[str, str]) -> list[str]:
    """Validate declarative page YAML with the runtime page-schema contract."""
    errors: list[str] = []
    normalized = _normalized_files_map(files_map)

    for path, content in normalized.items():
        if not path.startswith("ui/pages/"):
            continue
        if not path.endswith(".yaml"):
            continue
        if "/custom/" in path:
            # Custom React escape-hatch pages — skip schema validation.
            continue

        try:
            schema = yaml.safe_load(content)
        except Exception:
            errors.append(f"{path}: invalid YAML in schema-native page")
            continue

        if not isinstance(schema, dict):
            errors.append(f"{path}: page schema must be a YAML mapping")
            continue

        try:
            validate_page_schema(schema)
        except PageSchemaValidationError as exc:
            errors.extend(
                f"{path}: {diagnostic.location}: {diagnostic.code}"
                for diagnostic in exc.diagnostics
            )

    return errors


_PACK_PROVENANCE_PATH = ".mozaiks/pack_provenance.json"
_PACK_PROVENANCE_SCHEMA_VERSION = "mozaiks.pack_provenance.v1"

_PROVENANCE_REQUIRED_KEYS = frozenset(
    {"schema_version", "framework_version", "generated_at", "packs"}
)
_PROVENANCE_PACK_REQUIRED_KEYS = frozenset(
    {
        "pack_id",
        "version",
        "source",
        "digest",
        "materialized_owned_files",
    }
)


def _scan_pack_provenance_manifest(files_map: dict[str, str]) -> list[str]:
    """Validate .mozaiks/pack_provenance.json schema when present.

    The file is optional — emitted only when packs were selected.  When present
    it must conform to the ``mozaiks.pack_provenance.v1`` schema so future tooling
    can rely on the structure for upgrade/diff decisions.
    """
    raw = files_map.get(_PACK_PROVENANCE_PATH)
    if raw is None:
        return []

    errors: list[str] = []
    try:
        manifest = json.loads(raw)
    except Exception as exc:
        return [f"{_PACK_PROVENANCE_PATH}: invalid JSON — {exc}"]

    if not isinstance(manifest, dict):
        return [f"{_PACK_PROVENANCE_PATH}: pack_provenance.json must be a JSON object"]

    # Check required top-level keys
    missing_keys = _PROVENANCE_REQUIRED_KEYS - set(manifest.keys())
    for key in sorted(missing_keys):
        errors.append(f"{_PACK_PROVENANCE_PATH}: missing required field '{key}'")
    unknown_keys = sorted(set(manifest.keys()) - _PROVENANCE_REQUIRED_KEYS - {"composed_outputs"})
    for key in unknown_keys:
        errors.append(f"{_PACK_PROVENANCE_PATH}: unsupported field '{key}'")

    # Check schema_version value
    sv = manifest.get("schema_version")
    if sv and sv != _PACK_PROVENANCE_SCHEMA_VERSION:
        errors.append(
            f"{_PACK_PROVENANCE_PATH}: schema_version must be "
            f"'{_PACK_PROVENANCE_SCHEMA_VERSION}', got '{sv}'"
        )

    # Validate packs entries
    packs = manifest.get("packs")
    if packs is not None:
        if not isinstance(packs, list):
            errors.append(f"{_PACK_PROVENANCE_PATH}: 'packs' must be a JSON array")
        else:
            for i, entry in enumerate(packs):
                if not isinstance(entry, dict):
                    errors.append(f"{_PACK_PROVENANCE_PATH}: packs[{i}] must be a JSON object")
                    continue
                missing_pack_keys = _PROVENANCE_PACK_REQUIRED_KEYS - set(entry.keys())
                for key in sorted(missing_pack_keys):
                    errors.append(
                        f"{_PACK_PROVENANCE_PATH}: packs[{i}] missing required field '{key}'"
                    )
                unknown_pack_keys = sorted(set(entry.keys()) - _PROVENANCE_PACK_REQUIRED_KEYS - {
                    "storefront_recipe", "recipe_digest", "messaging_configuration", "messaging_configuration_digest",
                })
                for key in unknown_pack_keys:
                    errors.append(f"{_PACK_PROVENANCE_PATH}: packs[{i}] unsupported field '{key}'")
                if "storefront_recipe" in entry or "recipe_digest" in entry:
                    try:
                        recipe = normalize_storefront_recipe(entry.get("storefront_recipe"), pack_id=entry.get("pack_id"))
                        if recipe is None or StorefrontRecipe.model_validate(recipe).digest() != entry.get("recipe_digest"):
                            raise ValueError("recipe digest does not match the canonical storefront recipe")
                    except (TypeError, ValueError) as exc:
                        errors.append(f"{_PACK_PROVENANCE_PATH}: packs[{i}] invalid storefront recipe: {exc}")
                if "messaging_configuration" in entry or "messaging_configuration_digest" in entry:
                    try:
                        configuration = reconcile_messaging_configurations(entry.get("pack_id"), entry.get("messaging_configuration"))
                        if configuration is None or MessagingConfiguration.model_validate(configuration).digest() != entry.get("messaging_configuration_digest"):
                            raise ValueError("configuration digest does not match the canonical Messaging selection")
                    except (TypeError, ValueError) as exc:
                        errors.append(f"{_PACK_PROVENANCE_PATH}: packs[{i}] invalid Messaging configuration: {exc}")
                digest = str(entry.get("digest") or "")
                if digest and not re.fullmatch(r"sha256:[0-9a-f]{64}", digest):
                    errors.append(
                        f"{_PACK_PROVENANCE_PATH}: packs[{i}].digest must be a canonical sha256 digest"
                    )
                files = entry.get("materialized_owned_files")
                if files is not None and not isinstance(files, list):
                    errors.append(
                        f"{_PACK_PROVENANCE_PATH}: packs[{i}].materialized_owned_files must be a JSON array"
                    )
                for file in files if isinstance(files, list) else []:
                    if isinstance(file, dict) and file.get("path") in SHARED_PACK_OUTPUT_PATHS:
                        errors.append(
                            f"{_PACK_PROVENANCE_PATH}: packs[{i}] claims shared composition root "
                            f"{file['path']!r} as an exclusive materialized_owned_files entry. A shared root is "
                            "composed from the app's and every pack's declarations and recorded under "
                            "composed_outputs; this provenance predates composition. Reassemble the app to "
                            "recompose its shared roots."
                        )

    composed = manifest.get("composed_outputs", {})
    if not isinstance(composed, dict):
        errors.append(f"{_PACK_PROVENANCE_PATH}: composed_outputs must be a JSON object")
    else:
        identities = {"pack_id", "version", "source", "digest"}
        pack_entries = [entry for entry in packs if isinstance(entry, dict)] if isinstance(packs, list) else []
        for path, contributors in composed.items():
            location = f"{_PACK_PROVENANCE_PATH}: composed_outputs[{path!r}]"
            if path not in SHARED_PACK_OUTPUT_PATHS or path not in files_map:
                errors.append(f"{location} must identify a present shared composition root")
            if not isinstance(contributors, list) or not contributors:
                errors.append(f"{location} must contain pack contributors")
                continue
            seen = set()
            for contributor in contributors:
                if not isinstance(contributor, dict) or set(contributor) != identities or not all(
                    isinstance(value, str) and value for value in contributor.values()
                ):
                    errors.append(f"{location} contributor must contain pack_id, version, source, and digest")
                    continue
                pack_id = contributor["pack_id"]
                matches = [entry for entry in pack_entries if entry.get("pack_id") == pack_id]
                if len(matches) != 1 or any(matches[0].get(key) != contributor[key] for key in identities):
                    errors.append(f"{location} contributor must match one selected pack identity")
                if pack_id in seen:
                    errors.append(f"{location} contains duplicate contributors")
                seen.add(pack_id)

    return errors


def _scan_page_api_endpoint_alignment(files_map: dict[str, str]) -> list[str]:
    """Validate that api_endpoint values in schema-native page sections reference
    modules and actions declared in the same bundle.

    Only fires when module.yaml files are present — bundles without modules are
    either page-only bundles or capability-only bundles, both of which may
    legitimately call external modules.

    Endpoints that do not match /api/modules/{module_id}/{action_id} exactly are
    already flagged by the ui_quality gate; this check only verifies that
    well-formed endpoints resolve to declared bundle artifacts.
    """
    normalized_files = _normalized_files_map(files_map)

    # Build module_id → set[action_id] from all module.yaml files in the bundle.
    module_actions: dict[str, set[str]] = {}
    internal_actions: set[tuple[str, str]] = set()
    for path, content in normalized_files.items():
        if not (path.startswith("modules/") and path.endswith("/module.yaml")):
            continue
        parts = PurePosixPath(path).parts
        if len(parts) != 3:
            continue
        module_id = parts[1]
        actions = _module_actions_from_yaml(path, content)
        module_actions[module_id] = actions
        document, _ = _load_yaml_mapping_from_file(normalized_files, path)
        for action in (document or {}).get("actions", []):
            if isinstance(action, dict) and action.get("api_surface") in {
                "internal",
                "admin_internal",
            }:
                action_id = action.get("id")
                if isinstance(action_id, str):
                    internal_actions.add((module_id, action_id))

    if not module_actions:
        return []  # No modules in bundle — skip reference closure.

    def endpoints(node, location):
        if isinstance(node, dict):
            for key, value in node.items():
                if key in {"api_endpoint", "href"} and isinstance(value, str):
                    yield location, value
                elif isinstance(value, (dict, list)):
                    yield from endpoints(value, f"{location}.{key}")
        elif isinstance(node, list):
            for index, value in enumerate(node):
                yield from endpoints(value, f"{location}[{index}]")

    errors: list[str] = []
    for path, content in sorted(normalized_files.items()):
        if not path.startswith("ui/pages/") or not path.endswith(".yaml") or "/custom/" in path:
            continue
        try:
            schema = yaml.safe_load(content) or {}
        except Exception:
            continue
        if not isinstance(schema, dict):
            continue
        sections = schema.get("sections")
        if not isinstance(sections, list):
            continue
        for location, ep in endpoints(sections, "sections"):
            ep = ep.strip()
            if not ep.startswith("/api/modules/"):
                continue
            ep_parts = ep.split("/")
            # Expected: ['', 'api', 'modules', module_id, action_id]
            if len(ep_parts) != 5:
                continue
            ref_module, ref_action = ep_parts[3], ep_parts[4]
            if not ref_module or not ref_action:
                continue
            if ref_module not in module_actions:
                errors.append(
                    f"{path}: {location} api_endpoint '{ep}' references "
                    f"module '{ref_module}' which is not declared in this bundle."
                )
            elif ref_action not in module_actions[ref_module]:
                errors.append(
                    f"{path}: {location} api_endpoint '{ep}' references "
                    f"action '{ref_action}' which is not declared in "
                    f"modules/{ref_module}/module.yaml."
                )
            elif (ref_module, ref_action) in internal_actions:
                errors.append(
                    f"modules/{ref_module}/module.yaml: action '{ref_action}' is internal-only "
                    f"but {path}: {location} calls it through HTTP. Use null api_surface "
                    "for authenticated UI actions and retain permissions; do not make it public."
                )
    return errors


def _scan_route_manifest_component_files(files_map: dict[str, str]) -> list[str]:
    """Resolve custom route keys through registered imports to existing pages."""
    errors: list[str] = []
    normalized = _normalized_files_map(files_map)
    manifest_raw = normalized.get("ui/route_manifest.json")
    if not manifest_raw:
        return errors

    try:
        manifest = json.loads(manifest_raw)
    except Exception:
        return errors  # Already caught by _scan_route_manifest_consistency.

    pages = manifest.get("pages") if isinstance(manifest, dict) else None
    if not isinstance(pages, list):
        return errors

    registered_files, registry_errors = resolve_registered_component_files(
        normalized, source_label="ui/route_manifest.json:",
    )
    errors.extend(registry_errors)

    for i, page in enumerate(pages):
        if not isinstance(page, dict):
            continue
        component = str(page.get("component") or "").strip()
        if not component:
            continue
        # Shell-built-in components are always available — no custom JSX file required.
        if component in _SHELL_ROUTE_COMPONENTS or component in APP_AUTH_COMPONENTS:
            continue
        if not any(
            path.startswith("ui/pages/custom/") and path.endswith(".jsx")
            for path in registered_files.get(component, set())
        ):
            route_path = str(page.get("path") or "<unknown>").strip()
            errors.append(
                f"ui/route_manifest.json: pages[{i}] route '{route_path}' declares "
                f"component '{component}' but no registered import resolves to an existing "
                "ui/pages/custom/*.jsx file. Preserve the approved page path and bind its "
                "import to this component key in ui/index.js."
            )
    return errors


def _scan_action_api_surface(files_map: dict[str, str]) -> list[str]:
    """Validate action exposure and execution metadata against the runtime contract.

    Only the four declared strings and actual null are canonical. Keep this
    diagnostic aligned with runtime ActionDef validation.
    """
    errors: list[str] = []
    normalized = _normalized_files_map(files_map)

    for path, content in normalized.items():
        if not (path.startswith("modules/") and path.endswith("/module.yaml")):
            continue
        parts = PurePosixPath(path).parts
        if len(parts) != 3:
            continue
        module_id = parts[1]

        try:
            parsed = yaml.safe_load(content) or {}
        except Exception:
            continue
        if not isinstance(parsed, dict):
            continue

        actions = parsed.get("actions")
        if not isinstance(actions, list):
            continue

        for action in actions:
            if not isinstance(action, dict):
                continue
            action_id = str(action.get("id") or "").strip()
            try:
                validate_action_timeout(action.get("timeout_seconds"))
            except ValueError:
                errors.append(
                    f"{path}: action '{action_id}' timeout_seconds must be null or an integer from 1 through 3600."
                )
            api_surface = action.get("api_surface")
            if api_surface is None:
                continue
            api_surface_str = str(api_surface)
            if not isinstance(api_surface, str) or api_surface not in _CANONICAL_API_SURFACE_VALUES:
                errors.append(
                    f"modules/{module_id}/module.yaml: action '{action_id}' "
                    f"api_surface '{api_surface_str}' is not a canonical value. "
                    f"Must be one of: {', '.join(sorted(_CANONICAL_API_SURFACE_VALUES))}."
                )

    return errors


def _scan_event_reaction_closure(files_map: dict[str, str]) -> list[str]:
    """Validate event/reaction reference closure within a generated bundle.

    Checks:
    1. Every reaction's event_type resolves to a declared event in the bundle's
       events.yaml files (platform-namespace events are exempt and always pass).
    2. Every reaction target.kind is a canonical value.
    3. Target-kind-specific required fields are present and non-empty.

    Only fires when at least one reactions.yaml is present in the bundle.
    Platform events (hosted.*, platform.*, mozaiks.*) are not bundle-declared
    and are always treated as resolvable.
    """
    errors: list[str] = []
    normalized = _normalized_files_map(files_map)

    # Collect all declared event_types from modules/*/contracts/events.yaml.
    declared_event_types: set[str] = set()
    for path, content in normalized.items():
        if not re.match(r"modules/[^/]+/contracts/events\.yaml", path):
            continue
        try:
            parsed = yaml.safe_load(content) or {}
        except Exception:
            continue
        if not isinstance(parsed, dict):
            continue
        events = parsed.get("events")
        if not isinstance(events, list):
            continue
        for event in events:
            if isinstance(event, dict):
                event_type = str(event.get("type") or "").strip()
                if event_type:
                    declared_event_types.add(event_type)

    # Validate each reaction in modules/*/contracts/reactions.yaml.
    for path, content in sorted(normalized.items()):
        if not re.match(r"modules/[^/]+/contracts/reactions\.yaml", path):
            continue
        try:
            parsed = yaml.safe_load(content) or {}
        except Exception:
            continue
        if not isinstance(parsed, dict):
            continue

        reactions = parsed.get("reactions")
        if not isinstance(reactions, list):
            continue

        for i, reaction in enumerate(reactions):
            if not isinstance(reaction, dict):
                continue
            reaction_id = str(reaction.get("id") or f"[{i}]").strip()
            label = f"{path}: reaction '{reaction_id}'"

            # 1. event_type closure.
            event_type = str(reaction.get("event_type") or "").strip()
            if not event_type:
                errors.append(f"{label} missing required 'event_type'.")
            elif not any(event_type.startswith(ns) for ns in _PLATFORM_EVENT_NAMESPACES):
                # Only validate domain events that must be bundle-declared.
                if declared_event_types and event_type not in declared_event_types:
                    errors.append(
                        f"{label} event_type '{event_type}' is not declared in any "
                        f"modules/*/contracts/events.yaml in this bundle."
                    )

            # 2. target.kind validation.
            target = reaction.get("target")
            if not isinstance(target, dict):
                errors.append(f"{label} missing required 'target' mapping.")
                continue

            kind = str(target.get("kind") or "").strip()
            if not kind:
                errors.append(f"{label} target missing required 'kind'.")
            elif kind not in _CANONICAL_REACTION_TARGET_KINDS:
                errors.append(
                    f"{label} target.kind '{kind}' is not canonical. "
                    f"Must be one of: {', '.join(sorted(_CANONICAL_REACTION_TARGET_KINDS))}."
                )
            else:
                # 3. Target-kind-specific required fields.
                if kind == "handler":
                    method = str(target.get("handler_method") or "").strip()
                    if not method:
                        errors.append(
                            f"{label} target.kind='handler' requires non-empty 'handler_method'."
                        )
                elif kind == "capability":
                    cap_id = str(target.get("capability_id") or "").strip()
                    if not cap_id:
                        errors.append(
                            f"{label} target.kind='capability' requires non-empty 'capability_id'."
                        )
                elif kind == "notification":
                    notif_id = str(target.get("notification_id") or "").strip()
                    if not notif_id:
                        errors.append(
                            f"{label} target.kind='notification' requires non-empty 'notification_id'."
                        )
                elif kind == "service_adapter":
                    adapter = str(target.get("adapter") or "").strip()
                    if not adapter:
                        errors.append(
                            f"{label} target.kind='service_adapter' requires non-empty 'adapter'."
                        )

    return errors


def _layout_extensions_for_selected_packs(
    capability_packs: list[dict[str, Any]] | None,
) -> tuple[LayoutExtension, ...]:
    extensions = list(layout_extensions_from_selected_packs(capability_packs))
    claimed_paths: dict[str, str] = {}
    for pack in capability_packs or []:
        pack_id = _pack_id_from_descriptor(pack)
        if not pack_id:
            continue
        for path in sorted(resolve_declared_pack_output_paths([pack])):
            prior_owner = claimed_paths.get(path)
            # Shared roots have several contributors by design; composition and
            # composed_outputs provenance validate them. Every other path is exclusive.
            if prior_owner is not None and prior_owner != pack_id and path not in SHARED_PACK_OUTPUT_PATHS:
                raise ManagedCapabilityTemplateError(
                    f"Selected packs '{prior_owner}' and '{pack_id}' both declare "
                    f"output path {path!r}; duplicate pack output claims fail closed"
                )
            claimed_paths[path] = pack_id
            if _path_matches_core_layout(path):
                continue
            try:
                extensions.append(
                    LayoutExtension(
                        slot=ExtensionSlot.CAPABILITY_PACK_OUTPUT,
                        pack_id=pack_id,
                        path=path,
                    )
                )
            except (ValueError, PydanticValidationError) as exc:
                raise ManagedCapabilityTemplateError(
                    f"Pack '{pack_id}' declares output {path!r} outside the "
                    f"permitted pack output lanes: {exc}"
                ) from exc
    return tuple(
        sorted(extensions, key=lambda item: (item.slot.value, item.pack_id, item.path or ""))
    )


def _path_matches_core_layout(path: str) -> bool:
    """True when the core registry (no extensions) already classifies the path."""
    registry = build_app_layout_registry(())
    scopes = (
        PathScope.APP_BUNDLE_ROOT,
        PathScope.DEPLOYMENT_DERIVED,
        PathScope.WORKSPACE_ROOT,
        PathScope.GENERATED_STAGING,
    )
    for scope in scopes:
        try:
            registry.match_path(path, scope)
        except ValueError:
            continue
        return True
    return False


def _scan_declared_pack_repo_support_outputs(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None = None,
) -> list[str]:
    try:
        declared_paths = (
            resolve_declared_pack_output_paths(capability_packs)
            if capability_packs
            else frozenset()
        )
    except ManagedCapabilityTemplateError as exc:
        return [f"Selected CapabilityPack output contract is invalid: {exc}"]

    repo_support = (
        ".claude/",
        ".github/",
        "docs/",
        "scripts/",
        "tests/",
    )
    invalid = sorted(
        path
        for path in _normalized_files_map(files_map)
        if path.startswith(repo_support)
        and path not in {".github/workflows/deploy.yml", ".github/workflows/readiness.yml"}
        and path not in declared_paths
    )
    if not invalid:
        return []
    return [
        "Generated app bundle contains undeclared repository-support pack outputs: "
        f"{invalid}. Selected capability packs must declare generated docs, scripts, "
        "and repository-support files explicitly."
    ]


def scan_app_contracts(files_map: dict[str, str]) -> list[str]:
    """Validate shared app declarations, independent of generation output policy."""
    errors: list[str] = []
    for scan in (
        _scan_reserved_app_paths,
        _scan_security_secret_contract,
        _scan_route_manifest_consistency,
        _scan_page_schema_structure,
        _scan_page_api_endpoint_alignment,
        _scan_action_api_surface,
        _scan_event_reaction_closure,
        _scan_data_contract_module_alignment,
        _scan_entitlement_gate_capability_alignment,
    ):
        errors.extend(scan(files_map))
    errors.extend(_scan_auth_app_contract(files_map, require_generated_adapter=False))
    return errors


def _scan_planned_user_data_scope(
    files_map: dict[str, str], capability_packs: list[dict[str, Any]] | None
) -> list[str]:
    errors: list[str] = []
    for pack in capability_packs or []:
        if pack.get("capability_source") != "generated_module" or "user_data_scope" not in pack:
            continue
        module_id = str(pack.get("capability_pack_id") or "")
        path = f"modules/{module_id}/module.yaml"
        manifest, error = _load_yaml_mapping_from_file(files_map, path)
        if error or manifest is None:
            continue  # Layout/module validation reports missing or invalid manifests.
        metadata = manifest.get("module") or {}
        if not isinstance(metadata, dict):
            continue
        if metadata.get("user_data_scope", False) is not pack["user_data_scope"]:
            errors.append(
                f"{path}: module.user_data_scope must match the approved capability plan ({str(pack['user_data_scope']).lower()})."
            )
        handler = f"modules/{module_id}/backend/account_data_handler.py"
        if pack["user_data_scope"] is True and handler not in files_map:
            errors.append(f"{handler}: required by planned module.user_data_scope=true.")
    return errors


def _scan_planned_data_fields(
    files_map: dict[str, str], planned: dict[str, Any] | None,
    *, subscription_contract: dict[str, Any] | None = None,
    context_variables: Any = None,
) -> list[str]:
    if not planned:
        return []
    actual, error = _load_data_contract(files_map)
    if error or not actual:
        return [error or "data/contract.json: missing approved data contract."]
    try:
        inventory = verified_pack_template_inventory(context_variables=context_variables)
        planned = compile_data_contract(
            planned, subscription_contract=subscription_contract, context_variables=context_variables,
            pack_data_contracts=verified_pack_data_contracts(inventory),
        )
    except (ValueError, ManagedCapabilityTemplateError) as exc:
        return [f"data/contract.json: {exc}"]
    collections = {
        (surface["surface_id"], collection["name"]): collection
        for surface in actual.get("surfaces") or []
        for collection in surface.get("collections") or []
    }
    errors = []
    if actual != planned:
        errors.append("data/contract.json: must match the compiled approved DesignDocs and subscription contracts.")
    for surface in planned.get("surfaces") or []:
        for collection in surface.get("collections") or []:
            key = (surface["surface_id"], collection["name"])
            emitted = collections.get(key)
            if emitted is None:
                errors.append(f"data/contract.json: missing approved collection {key!r}.")
                continue
            fields = {field["name"]: field for field in emitted.get("fields") or []}
            for field in collection.get("fields") or []:
                result = fields.get(field["name"])
                if result is None or any(
                    result.get(attr, False) != field.get(attr, False)
                    for attr in ("type", "required")
                ):
                    errors.append(
                        f"data/contract.json: {key!r}.{field['name']} must preserve the approved field "
                        f"(type={field.get('type')}, required={field.get('required', False)})."
                    )
    return errors


def _scan_owned_collection_auth(files_map: dict[str, str]) -> list[str]:
    contract, error = _load_data_contract(files_map)
    if error or contract is None:
        return []  # The contract scanner reports parse errors.
    try:
        if data_contract_requires_auth(contract) and not _app_manifest_auth_required(files_map):
            return ["app.json: authRequired must be true for per_user/per_workspace collections; regenerate app auth."]
    except ValueError as exc:
        return [str(exc)]
    return []


class _ResolvedPackContext:
    """Read-only view of a caller context whose pack selection is the scan's resolved rows."""

    def __init__(self, base: Any, capability_packs: list[dict[str, Any]], subscription_contract: Any = None) -> None:
        self._base = base
        self._capability_packs = capability_packs
        self._subscription_contract = subscription_contract

    def get(self, key: str, default: Any = None) -> Any:
        if key == "capability_packs":
            return self._capability_packs
        if key == "subscription_contract" and self._subscription_contract is not None:
            return self._subscription_contract
        return self._base.get(key, default)


def _resolved_pack_context(context_variables: Any, resolved_rows: list[dict[str, Any]]) -> Any:
    """The caller's context with its pack selection replaced by the resolved, verified rows."""
    if context_variables is None:
        return {"capability_packs": resolved_rows}
    if isinstance(context_variables, dict):
        return {**context_variables, "capability_packs": resolved_rows}
    return _ResolvedPackContext(context_variables, resolved_rows)


def _context_pack_selection(context_variables: Any) -> list[dict[str, Any]]:
    """The build context's own pack selection: its capability_packs, else its AppBuildPlan's."""
    if context_variables is None:
        return []
    rows = detach(context_variables.get("capability_packs")) or []
    if not rows:
        plan = detach(context_variables.get("app_build_plan")) or {}
        rows = (plan.get("capability_packs") or []) if isinstance(plan, dict) else []
    return [dict(row) for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []


def _resolve_scan_packs(
    capability_packs: list[dict[str, Any]] | None, context_variables: Any,
) -> list[dict[str, Any]]:
    """Resolve the scan's selected packs to verified entries (see ``verified_selected_pack_sources``).

    A build context that selects packs is authoritative. A caller row for one
    of its packs adds nothing but pins, which must equal the resolved identity;
    a caller row for any other pack resolves on its own, without a source path
    of its own (one the context never selected and compared). Without a
    context selection the caller's rows are the selection. Rows that claim no
    pack and resolve nowhere (planned generated modules) select nothing.
    """
    caller_rows = [dict(pack) for pack in capability_packs or [] if isinstance(pack, dict)]
    context_rows = _context_pack_selection(context_variables)
    rows = caller_rows
    if context_rows:
        selected_ids = {selected_pack_id(row) for row in context_rows}
        outside = [row for row in caller_rows if selected_pack_id(row) not in selected_ids]
        injected = sorted({selected_pack_id(row) or "<unnamed>" for row in outside if row.get("pack_source_path")})
        if injected:
            raise PackIntegrityError(
                f"explicit capability_packs rows {injected} carry a pack_source_path outside the verified pack "
                "selection of the build context. Select those packs in the build context so their source is "
                "verified, or select them without a source path so installed state or the installed factory "
                "catalog resolves them."
            )
        rows = [*context_rows, *outside]
    entries = verified_selected_pack_sources(rows, context_variables=context_variables)
    by_id = {entry["pack_id"]: entry for entry in entries}
    for row in caller_rows:
        entry = by_id.get(selected_pack_id(row))
        if entry is None:
            continue
        for key in ("version", "digest"):
            pinned = row.get(key)
            if pinned is not None and pinned != "" and str(pinned) != entry[key]:
                raise PackIntegrityError(
                    f"Pack '{entry['pack_id']}' selected {key} does not match freshly verified source: the "
                    f"caller row pins {pinned!r}, the {entry['resolution']} source is {entry[key]!r}."
                )
    return entries


def _resolved_pack_rows(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Selection rows for the pack-aware checks, built only from verified entries.

    Each names the verified source, the pack's declared ``capability_source``
    and its identity; no caller field (inline ``provides_capabilities`` or
    ``forbidden_outputs``, a claimed ``capability_source``) carries over.
    """
    return [
        {
            "id": entry["pack_id"],
            "capability_source": entry["capability_source"],
            "pack_source_path": entry["source_path"],
            **pack_identity(entry),
        }
        for entry in entries
    ]


def _provenance_pack_records(files_map: dict[str, str]) -> list[tuple[int, dict[str, Any]]]:
    try:
        manifest = json.loads(files_map.get(_PACK_PROVENANCE_PATH) or "{}")
    except (TypeError, ValueError):
        return []  # The provenance schema scan reports the invalid manifest.
    packs = manifest.get("packs") if isinstance(manifest, dict) else None
    return [(index, entry) for index, entry in enumerate(packs or []) if isinstance(entry, dict)] if isinstance(
        packs, list
    ) else []


def _normalized_text(value: str) -> str:
    """Text with CRLF and CR line endings as LF, so a checkout's line endings never decide a comparison."""
    return value.replace("\r\n", "\n").replace("\r", "\n")


def _template_bytes_match(path: str, actual: Any, rendered: str, managed_owners: set[str]) -> bool:
    if not isinstance(actual, str):
        return False
    if _normalized_text(actual) == _normalized_text(rendered):
        return True
    if path.startswith("data/migrations/") and path.endswith(".json"):
        # Assembly compiles a migration template (headers, index names, managed owners); compare that form.
        try:
            compiled = materialize_data_migrations({path: rendered}, managed_owners=managed_owners)[path]
            return bool(json.loads(actual) == json.loads(compiled))
        except (TypeError, ValueError):
            return False
    return False


# A revision of the build re-materializes its packs and becomes the app's build once accepted; a
# regenerated app is a new parentless draft, which acceptance refuses while the app has an accepted build.
_PACK_REMEDIES = {
    AUTHORITY_PACKAGED_BUILD_CONTEXT: (
        "This pack ships with the installed mozaiks package: run an AppGenerator revision of the build, and accept "
        "it, so assembly re-materializes the pack at this version."
    ),
    AUTHORITY_INSTALLED: (
        "Run an AppGenerator revision of the build with this pack version, or upgrade the installed component "
        "through the pack lifecycle."
    ),
    AUTHORITY_SELECTED_PINS: (
        "Run an AppGenerator revision of the build from the pinned source, or select the source and pins the bundle "
        "was built from."
    ),
    AUTHORITY_WORKSPACE_BUILD_CONTEXT: (
        "This pack is registered in the workspace build context: run an AppGenerator revision of the build, and "
        "accept it, so assembly re-materializes the pack at this version, or restore the registered pack the bundle "
        "was built from."
    ),
}


def _scan_resolved_pack_outputs(
    files_map: dict[str, str],
    entries: list[dict[str, Any]],
    *,
    managed_owners: set[str],
    context_variables: Any = None,
) -> list[str]:
    """Hold the bundle to each resolved pack's verified identity and template content.

    The bundle's provenance cannot vouch for itself. Every provenance entry for
    a resolved pack must record that pack's resolved version; the digest it
    records is not compared, because the pack digest hashes the source's raw
    bytes and so differs between checkouts with different line endings. The
    content is rechecked instead: every template-owned output the pack ships
    (shared composition roots aside) must be present, and the output of every
    static template (one that renders without build-time context, any file
    but ``.j2``) must equal the verified template text, line endings
    normalized. A ``.j2`` output renders from the build's template variables,
    which this check does not have, so nothing is rendered here: it is
    verified through the pack's declared outputs and its pinned identity.
    """
    errors: list[str] = []
    records = _provenance_pack_records(files_map)
    for entry in entries:
        pack_id = entry["pack_id"]
        label = (
            f"selected pack '{pack_id}' {entry['version']} ({entry['digest']}, resolved from "
            f"{entry['resolution']}, vouched for by {entry['authority']})"
        )
        remedy = _PACK_REMEDIES[entry["authority"]]
        for index, record in records:
            if record.get("pack_id") != pack_id:
                continue
            if record.get("version") != entry["version"]:
                errors.append(
                    f"{_PACK_PROVENANCE_PATH}: packs[{index}] records pack '{pack_id}' with version "
                    f"{record.get('version')!r}, but the {label} differs. {remedy}"
                )
        source = Path(entry["source_path"])
        try:
            static, context_outputs = static_pack_templates(source, pack_id)
            owners = declared_output_owners(source)
        except ManagedCapabilityTemplateError as exc:
            errors.append(f"Selected pack '{pack_id}' templates cannot be read to verify the bundle: {exc}")
            continue
        # Module gate fields have one deterministic compiler. Compare its exact
        # authorized output, not the ungated/model copy or raw template defaults.
        # Without an explicit contract no gate removal is inferred.
        if resolve_subscription_contract(context_variables) is not None:
            from .module_entitlement_gates import apply_entitlement_gates

            manifests = [{"filename": path, "content": content} for path, content in static.items()
                         if path.startswith("modules/") and path.endswith("/module.yaml")]
            try:
                compiled = apply_entitlement_gates(
                    manifests, context_variables=context_variables, require_all_modules=False,
                )
                static.update({item["filename"]: item["content"] for item in compiled})
            except (TypeError, ValueError) as exc:
                errors.append(f"Selected pack '{pack_id}' entitlement composition is invalid: {exc}")
                continue
        for path in sorted({*static, *context_outputs}):
            if path in SHARED_PACK_OUTPUT_PATHS or owners.get(path, "templates") != "templates":
                continue
            if path not in files_map:
                errors.append(f"{path}: template-owned output of the {label} is missing. {remedy}")
            elif path in static and not _template_bytes_match(path, files_map[path], static[path], managed_owners):
                errors.append(
                    f"{path}: differs from the verified template of the {label}. A template-owned pack output "
                    f"must be the verified template content, whatever the bundle's provenance records. {remedy}"
                )
    return errors


def scan_generated_bundle(
    files_map: dict[str, str],
    *,
    capability_packs: list[dict[str, Any]] | None = None,
    planned_data_contract: dict[str, Any] | None = None,
    subscription_contract: dict[str, Any] | None = None,
    context_variables: Any = None,
    require_deployment_artifacts: bool = False,
    resolved_capability_packs: list[dict[str, str]] | None = None,
) -> list[str]:
    """Scan files_map for forbidden patterns.

    Returns a list of human-readable error strings.
    An empty list means the bundle is clean and safe to deliver.

    Selected packs are resolved first (``_resolve_scan_packs``); an
    unresolvable, unverified or mismatched pack selection is the only error
    returned. Every pack-aware check then reads only the resolved rows and
    their verified contracts. When ``resolved_capability_packs`` is a list,
    the verified identity ``{pack_id, version, digest, source, resolution, authority}``
    of each selected pack is appended to it.

    Checks applied per file type:
    - All scannable files: raw provider secret key literals.
    - .mozaiks/pack_provenance.json: schema validation when present, and each
      resolved pack's recorded version (the digest is a same-host value and is not compared).
    - Template-owned outputs of each resolved pack: present, with the verified bytes.
    - ui/route_manifest.json: required path/component fields; component file existence.
    - ui/pages/*.yaml (schema-native): required fields, canonical page_type, canonical primitives,
      api_endpoint → module/action closure.
    - modules/*/module.yaml: action api_surface canonical vocabulary.
    - modules/*/contracts/reactions.yaml: event_type closure, target.kind taxonomy,
      target-kind-specific required fields.
    """
    try:
        entries = _resolve_scan_packs(capability_packs, context_variables)
        resolved_rows = _resolved_pack_rows(entries)
        selected_layout_extensions = _layout_extensions_for_selected_packs(resolved_rows)
    except ManagedCapabilityTemplateError as exc:
        return [f"Selected CapabilityPack output contract is invalid: {exc}"]
    if resolved_capability_packs is not None:
        resolved_capability_packs.extend(pack_identity(entry) for entry in entries)
    persistence_context = _resolved_pack_context(context_variables, resolved_rows)
    layout_report = validate_file_map_layout(
        files_map,
        selected_extensions=selected_layout_extensions,
    )
    errors: list[str] = layout_validation_errors(layout_report)
    errors.extend(
        _scan_declared_pack_repo_support_outputs(
            files_map,
            capability_packs=resolved_rows,
        )
    )
    scannable_files_map = filter_layout_scannable_file_map(files_map, layout_report)
    # Scanner inputs are bundle-relative; layout rejects a workspace-prefixed copy.
    theme_path = "brand/theme_config.json"
    if theme_path in scannable_files_map:
        try:
            validate_page_title_theme(json.loads(scannable_files_map[theme_path]))
        except ValueError as exc:
            errors.append(f"{theme_path}: {exc}")
    errors.extend(
        _scan_canonical_app_paths(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    errors.extend(error for error in scan_app_contracts(scannable_files_map) if error not in errors)
    errors.extend(_scan_planned_user_data_scope(scannable_files_map, capability_packs))
    errors.extend(_scan_subscription_assignment_storage(scannable_files_map))
    errors.extend(_scan_planned_data_fields(
        scannable_files_map, planned_data_contract, subscription_contract=subscription_contract,
        context_variables=persistence_context,
    ))
    managed_owners: set[str] = set()
    try:
        managed_owners = managed_data_owners(persistence_context)
        compiled_migrations = materialize_data_migrations(
            scannable_files_map, managed_owners=managed_owners,
        )
        for path, content in scannable_files_map.items():
            if path.startswith("data/migrations/") and path.endswith(".json"):
                if json.loads(content) != json.loads(compiled_migrations[path]):
                    errors.append(f"{path}: must contain compiled migration versions, named indexes, and no managed collections.")
    except ValueError as exc:
        errors.append(str(exc))
    errors.extend(_scan_owned_collection_auth(scannable_files_map))
    errors.extend(_scan_outcome_feedback_contract(scannable_files_map))
    errors.extend(scan_module_persistence(scannable_files_map))
    # Generation also requires the canonical frontend adapter artifact.
    auth_errors = _scan_auth_app_contract(scannable_files_map)
    errors.extend(error for error in auth_errors if error not in errors)
    errors.extend(_scan_pack_provenance_manifest(scannable_files_map))
    entitlement_context = _ResolvedPackContext(persistence_context, resolved_rows, subscription_contract)
    errors.extend(_scan_resolved_pack_outputs(
        files_map, entries, managed_owners=managed_owners, context_variables=entitlement_context,
    ))
    errors.extend(_scan_route_manifest_component_files(scannable_files_map))
    errors.extend(
        _scan_selected_managed_capability_boundaries(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    errors.extend(
        _scan_managed_setup_provider_leaks(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    errors.extend(
        _scan_token_wallets_require_mozaikspay(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    errors.extend(
        _scan_mozaikspay_saas_contract(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    errors.extend(
        _scan_mozaiks_cloud_connector_contract(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    errors.extend(
        _scan_self_hosted_entitlement_dispatch_contract(
            scannable_files_map,
            capability_packs=resolved_rows,
        )
    )
    if require_deployment_artifacts:
        errors.extend(_scan_deployment_artifacts_contract(scannable_files_map))
        errors.extend(_scan_auth_deployment_contract(scannable_files_map))

    for path, content in files_map.items():
        if not isinstance(path, str) or not isinstance(content, str):
            continue

        if not _is_scannable(path):
            continue

        # ---- checks that apply to all scannable file types ----

        if _PAYMENT_PROVIDER_SECRET_LITERAL_RE.search(content):
            errors.append(
                f"{path}: contains a raw provider secret key literal "
                "in generated source. Generated apps must not embed "
                "raw credentials. Store credential values only through the "
                "configured secret backend."
            )

        if _PAYMENT_PROVIDER_API_KEY_RE.search(content):
            errors.append(
                f"{path}: assigns payment_provider.api_key directly. Generated apps must "
                "resolve provider credentials through the configured secret "
                "backend or managed capability adapter boundary."
            )

        if _PAYMENT_PROVIDER_REFUND_CALL_RE.search(content):
            errors.append(
                f"{path}: calls payment provider refunds APIs directly. Generated apps "
                "must route refund mutations through an app-owned facade or "
                "managed payment adapter."
            )

        if _PAYMENT_PROVIDER_REFUNDS_ENDPOINT_RE.search(content):
            errors.append(
                f"{path}: references a refunds endpoint (/refunds) directly. Generated apps must "
                "route refund mutations through an app-owned facade or managed "
                "payment adapter."
            )

        if _APP_LOCAL_LEDGER_PATH_RE.search(
            _normalized_path(path)
        ) or _APP_LOCAL_LEDGER_CODE_RE.search(content):
            errors.append(
                f"{path}: contains app-local token wallet or usage ledger code. Generated apps must "
                "use OSS runtime token wallet and usage endpoints instead of duplicate ledgers."
            )

        if path.lower().endswith(".py") and _PAYMENT_PROVIDER_IMPORT_RE.search(content):
            errors.append(
                f"{path}: imports the payment provider SDK directly. Generated apps must "
                "use generated service boundaries or managed capability adapter clients "
                "instead of provider SDKs in app business code."
            )

        if path.lower().endswith((".py", ".js", ".jsx", ".ts", ".tsx")):
            for raw_provider_import in _RAW_PAYMENT_PROVIDER_IMPORT_RE.finditer(content):
                provider_name = raw_provider_import.group(1) or raw_provider_import.group(2) or ""
                errors.append(
                    f"{path}: imports raw payment provider SDK {provider_name!r}. Generated apps must "
                    "use app-owned facade modules and managed/provider-neutral adapter clients."
                )

            for raw_cloud_import in _RAW_CLOUD_PROVIDER_IMPORT_RE.finditer(content):
                provider_name = raw_cloud_import.group(1) or raw_cloud_import.group(2) or ""
                errors.append(
                    f"{path}: imports raw cloud provider SDK {provider_name!r}. Generated apps must "
                    "route cloud operations through the bounded MozaiksCloud sub-clients, not "
                    "provider SDKs (azure, cloudflare, etc.) directly."
                )

    return errors


__all__ = ["scan_generated_bundle"]
