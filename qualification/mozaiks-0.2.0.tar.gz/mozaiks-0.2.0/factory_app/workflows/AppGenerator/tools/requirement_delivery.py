"""Compile approved requirements against existing pack, task and artifact owners.

This projection is not another task graph or executor. The final normalized
AppBuildPlan and verified resource inventory supply all execution identities.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

from factory_app.workflows._shared.platform.build_target import require_build_binding
from factory_app.workflows._shared.workflow_integration import (
    workflow_integration_metadata_from_context,
)
from factory_app.workflows.AppGenerator.tools.module_api_template import get_module_api_template
from factory_app.workflows.AppGenerator.tools.resolve_managed_capability_templates import (
    _context_to_dict,
    static_pack_templates,
    verified_pack_template_inventory,
)
from mozaiksai.builder.requirements import (
    approved_requirement_inventory,
    validate_requirement_deliveries,
)
from mozaiksai.core.semantics.canonical import canonical_digest
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.dependency_graph import deterministic_topological_order
from mozaiksai.core.workflow.generator_support.code_files import planned_page_path
from mozaiksai.core.workflow.generator_support.module_action_inventory import (
    SHARED_PACK_OUTPUT_PATHS,
    all_module_actions,
    approved_workflow_surface_ids,
    pack_owned_outputs,
)
from mozaiksai.core.workflow.path_ownership import normalize_owned_paths


def _get(context: Any, key: str, default: Any = None) -> Any:
    return detach(context.get(key, default)) if context is not None else default


def reference_behavior_owner(value: Any):
    """Select only installed finite case code; candidate paths are never imported."""
    from . import paired_reference_cases, storefront_reference_cases

    spec = value.get("spec") if isinstance(value, dict) else None
    spec_id = spec.get("id") if isinstance(spec, dict) else None
    for owner in (storefront_reference_cases, paired_reference_cases):
        if spec_id == owner.spec_identity()["id"]:
            return owner
    raise ValueError("Reference behavior has no installed reviewed interpreter")


def validate_reference_request(value: Any):
    return reference_behavior_owner(value).validate_reference_request(value)


def reference_browser_contract(value: Any) -> tuple[str, str, list[dict[str, Any]]]:
    """One closed UI mapping shared by the contained launcher and acceptance reader."""
    from mozaiksai.builder.ui_acceptance import (
        PAIRED_UI_SUITE,
        STOREFRONT_UI_CASES,
        STOREFRONT_UI_SUITE,
        paired_ui_cases,
    )

    from . import paired_reference_cases

    owner = reference_behavior_owner(value)
    request = owner.validate_reference_request(value)
    projects = ("generated-desktop", "generated-mobile")
    if owner is paired_reference_cases:
        cases = [{"id": f"route:{route}", "route": route, "project": project,
                  "requirement_ids": sorted(request.cases[owner.CASE_IDS[group]] for group in groups)}
                 for route, groups in paired_ui_cases(request.presentation, request.pack.get("messaging_configuration")).items()
                 for project in projects]
        return PAIRED_UI_SUITE, "paired-app.real-host.acceptance.spec.js", cases
    cases = [{"id": case_id, "route": contract["route"], "project": project,
              "requirement_ids": [request.cases[owner.CASE_IDS[contract["requirement"]]]]}
             for case_id, contract in STOREFRONT_UI_CASES.items() for project in projects]
    return STOREFRONT_UI_SUITE, "generated-app.real-host.acceptance.spec.js", cases


def reference_browser_refinement(value: Any) -> dict[str, str] | None:
    """Project the finite request binding; never read a candidate/env test flag."""
    request = validate_reference_request(value)
    refinement = getattr(request, "refinement", None)
    return ({"kind": refinement.kind, "request_digest": refinement.request_digest}
            if refinement is not None else None)


def approved_inventory_from_context(context: Any):
    binding = require_build_binding(context)
    return approved_requirement_inventory(_get(context, "approved_concept"), app_id=binding.target_app_id)


def invalidate_requirement_plan(context: Any) -> None:
    """Clear dispatch authority, never execution history or failure evidence."""
    for key, value in (("app_plan_ready", False), ("app_build_plan", None),
                       ("app_task_batch_items", []), ("app_task_batch_status", None)):
        if isinstance(context, dict):
            context[key] = value
        elif context is not None and hasattr(context, "set"):
            context.set(key, value)


def _task_dependencies(tasks: dict[str, dict[str, Any]]) -> dict[str, list[str]]:
    dependencies = {key: list(task.get("depends_on") or []) for key, task in tasks.items()}
    for key in tasks:
        if len(dependencies[key]) != len(set(dependencies[key])):
            raise ValueError(f"Task {key!r} repeats a dependency")
    deterministic_topological_order(tasks.values(), item_id=lambda task: task["task_id"],
                                    dependencies=lambda task: task.get("depends_on") or [])
    return {key: sorted(value) for key, value in dependencies.items()}


def compile_requirement_delivery(plan: dict[str, Any], context: Any) -> dict[str, Any]:
    """Fail before dispatch if scope, ownership, references or dependencies drift."""
    inventory = approved_inventory_from_context(context)
    if plan.get("requirement_inventory_digest") != inventory.digest():
        raise ValueError("AppBuildPlan requirement_inventory_digest differs from the current approved review")
    deliveries = validate_requirement_deliveries(plan.get("requirement_deliveries"), inventory)
    raw_tasks = plan.get("build_tasks")
    if not isinstance(raw_tasks, list) or any(not isinstance(task, dict) for task in raw_tasks):
        raise ValueError("Requirement delivery requires the normalized build task inventory")
    tasks = {task.get("task_id"): task for task in raw_tasks}
    if len(tasks) != len(raw_tasks) or any(not isinstance(key, str) or not key for key in tasks):
        raise ValueError("Requirement task inventory has missing or duplicate identities")
    dependencies = _task_dependencies(tasks)
    task_paths = {key: set(normalize_owned_paths(task.get("owned_paths"), reject_duplicates=True))
                  for key, task in tasks.items()}
    all_task_paths = [path for paths in task_paths.values() for path in paths]
    if len(all_task_paths) != len(set(all_task_paths)):
        raise ValueError("Requirement output has multiple task owners")

    # Only these selection fields supplement the existing authoritative context.
    selection = _context_to_dict(context)
    selection.update(app_build_plan=plan, capability_packs=plan.get("capability_packs") or [])
    packs = {entry["pack_id"]: entry for entry in verified_pack_template_inventory(context_variables=selection)}
    exclusive_pack_outputs = pack_owned_outputs(selection)
    actions = {key: set(value) for key, value in all_module_actions(selection).items()}
    routes = {page.get("route"): planned_page_path(page) for page in plan.get("pages") or []}
    rendered_by_pack: dict[str, dict[str, str]] = {}
    for pack_id, entry in packs.items():
        rendered = {file["filename"]: file["content"] for file in entry["files"]}
        rendered_by_pack[pack_id] = rendered
        for path, content in rendered.items():
            if path.startswith("modules/") and path.endswith("/module.yaml"):
                document = yaml.safe_load(content) or {}
                actions.setdefault(path.split("/")[1], set()).update(row["id"] for row in document.get("actions") or [])
            elif path.startswith("ui/pages/") and path.endswith(".yaml"):
                document = yaml.safe_load(content) or {}
                routes[document.get("route")] = path
            elif path == "ui/route_manifest.json":
                for page in json.loads(content).get("pages") or []:
                    routes[page.get("path")] = path

    compiled = []
    for delivery in deliveries:
        if not any(part.action_refs or part.page_routes for part in delivery.realizations):
            raise ValueError("Each approved requirement needs a concrete app action or page acceptance anchor; support files alone are not delivery")
        realizations = []
        for realization in delivery.realizations:
            paths = list(normalize_owned_paths(realization.output_paths, reject_duplicates=True))
            if paths != realization.output_paths:
                raise ValueError("Requirement outputs must use exact canonical app-relative paths")
            kind, separator, owner = realization.owner_ref.partition(":")
            if not set(realization.task_ids) <= tasks.keys():
                raise ValueError("Requirement references unknown implementing task identities")
            evidence: dict[str, Any]
            if kind == "pack" and separator and realization.strategy in {"pack", "static_template", "jinja_template"}:
                if owner not in packs:
                    raise ValueError(f"Requirement names unselected pack {owner!r}")
                entry = packs[owner]
                rendered = rendered_by_pack[owner]
                if realization.task_ids:
                    raise ValueError("Reusable pack materialization must not schedule model tasks")
                if not set(paths) <= rendered.keys():
                    raise ValueError(f"Requirement output is not rendered by pack {owner!r}")
                for path in paths:
                    if path in SHARED_PACK_OUTPUT_PATHS:
                        if entry["owner_map"].get(path) != "templates":
                            raise ValueError("Shared pack contribution lacks declared template ownership")
                    elif path not in exclusive_pack_outputs or exclusive_pack_outputs[path].pack_id != owner:
                        raise ValueError(f"Pack {owner!r} does not own requirement output {path!r} in this build phase")
                static, dynamic = static_pack_templates(Path(entry["source_path"]), owner)
                if realization.strategy == "static_template" and not set(paths) <= static.keys():
                    raise ValueError("Static template claim includes non-static output")
                if realization.strategy == "jinja_template" and not set(paths) <= dynamic:
                    raise ValueError("Jinja template claim includes non-parameterized output")
                if any(path in all_task_paths and path not in SHARED_PACK_OUTPUT_PATHS for path in paths):
                    raise ValueError("A model task cannot replace a reusable requirement output")
                evidence = {
                    "pack_identity": {key: entry[key] for key in ("pack_id", "version", "digest", "authority")},
                    "recipe_digest": entry.get("recipe_digest"),
                    **({"messaging_configuration_digest": entry["messaging_configuration_digest"]}
                       if entry.get("messaging_configuration") is not None else {}),
                    "output_digests": {path: hashlib.sha256(rendered[path].encode()).hexdigest() for path in paths},
                    "composed_outputs": sorted(set(paths) & SHARED_PACK_OUTPUT_PATHS),
                }
            elif kind == "task" and separator and realization.strategy in {"schema", "custom_generation"}:
                if owner not in tasks or realization.task_ids != [owner] or not set(paths) <= task_paths[owner]:
                    raise ValueError(f"Requirement must reference exact outputs and task identity for {owner!r}")
                if set(paths) & exclusive_pack_outputs.keys():
                    raise ValueError("Custom requirement tasks cannot take reusable pack output ownership")
                if realization.strategy == "schema" and any(not path.endswith((".yaml", ".json")) for path in paths):
                    raise ValueError("Schema delivery must name declarative YAML/JSON outputs")
                if realization.strategy == "custom_generation" and tasks[owner].get("task_type") in {"persistence_contract", "data_migrations"}:
                    raise ValueError("Deterministic persistence contracts are not custom generation")
                evidence = {"task_contract_digest": canonical_digest(tasks[owner])}
            elif realization.owner_ref == "framework:module_api" and realization.strategy == "framework":
                if paths != ["ui/lib/moduleApi.js"] or realization.task_ids:
                    raise ValueError("Framework module API has one deterministic output and no model task")
                evidence = {"output_digests": {paths[0]: hashlib.sha256(get_module_api_template().encode()).hexdigest()}}
            elif kind == "workflow" and separator and realization.strategy == "workflow":
                metadata = workflow_integration_metadata_from_context(context) or {}
                known = {row["capability_id"] for row in metadata.get("workflows") or []}
                if owner not in approved_workflow_surface_ids(context) or owner not in known or not metadata.get("source_artifact_version_id"):
                    raise ValueError("Workflow delivery requires an approved workflow and its concrete artifact identity")
                artifact_id = _get(context, "workflow_bundle_artifact_version_id")
                if (not isinstance(artifact_id, str) or not artifact_id.strip()
                        or artifact_id != metadata["source_artifact_version_id"]):
                    raise ValueError("Workflow delivery artifact identity differs from its concrete hydrated binding")
                owned = set().union(*(task_paths.get(key, set()) for key in realization.task_ids))
                if not realization.task_ids or not set(paths) <= owned:
                    raise ValueError("Workflow integration outputs require concrete app task ownership")
                evidence = {"workflow_artifact_version_id": artifact_id}
            else:
                raise ValueError(f"Unsupported requirement strategy/owner pair: {realization.strategy}/{realization.owner_ref}")

            for ref in realization.action_refs:
                if ref.action_id not in actions.get(ref.module_id, set()):
                    raise ValueError(f"Requirement references unknown action {ref.module_id}/{ref.action_id}")
                if not any(path.startswith(f"modules/{ref.module_id}/") for path in paths):
                    raise ValueError("Requirement action evidence must include an output of that module")
            for route in realization.page_routes:
                if route not in routes or routes[route] not in paths:
                    raise ValueError(f"Requirement route {route!r} has no matching concrete output")
            realizations.append({
                **realization.model_dump(mode="json"),
                "depends_on": {key: dependencies[key] for key in realization.task_ids},
                "evidence_contract": evidence,
            })
        compiled.append({"requirement_id": delivery.requirement_id, "realizations": realizations})
    return {
        "schema_version": "mozaiks.requirement_delivery.v1",
        "review_id": inventory.review_id,
        "inventory_digest": inventory.digest(),
        "requirements": compiled,
    }


def validate_cached_requirement_delivery(context: Any) -> None:
    plan = _get(context, "app_build_plan")
    if not isinstance(plan, dict) or plan.get("requirement_accounting") != compile_requirement_delivery(plan, context):
        raise ValueError("Cached requirement accounting differs from its current approval, plan or resource owners")


def admit_reference_behavior(
    context: Any, files: dict[str, str], *, revision_baseline: dict[str, str] | None = None,
    refinement_request: Any = None, refinement_authority: Any = None,
) -> dict[str, Any] | None:
    """Select installed reviewed cases, never a candidate-provided spec or receipt.

    This is deliberately finite reference coverage, not a claim that arbitrary
    custom requirements can supply their own executable acceptance authority.
    """
    from mozaiksai.core.workflow.generator_support.module_write_actions import auth_contract_scopes

    from . import paired_reference_cases, storefront_reference_cases
    from .app_runtime_smoke import _generated_source_digests, _source_content_sha256
    from .generated_bundle_scanner import scan_generated_bundle
    from .task_integrity import planned_artifact_diagnostics

    inventory = approved_inventory_from_context(context)
    owners = [owner for owner in (storefront_reference_cases, paired_reference_cases)
              if any(row.source == "core_features" and row.value in owner.STATEMENTS.values()
                     for row in inventory.requirements)]
    if not owners:
        return None
    if len(owners) != 1:
        raise ValueError("Reference behavior inventory ambiguously selects multiple finite suites")
    owner = owners[0]
    try:
        manifest = json.loads(files.get("app.json", "null"))
        contract = json.loads(files.get("data/contract.json", "null"))
    except (TypeError, ValueError) as exc:
        raise ValueError("Reference behavior output closure has invalid app/data JSON") from exc
    if (not isinstance(manifest, dict) or manifest.get("appId") != inventory.app_id
            or not isinstance(contract, dict) or contract.get("app_id", inventory.app_id) != inventory.app_id):
        raise ValueError("Reference behavior candidate identity differs from the approved app")
    if set(auth_contract_scopes(files)) - owner.IDENTITY_SCOPES:
        raise ValueError("Reference behavior requires identity-only base scopes; candidate grants are unsupported")
    validate_cached_requirement_delivery(context)
    diagnostics = planned_artifact_diagnostics(context, files, revision_baseline=revision_baseline)
    if diagnostics:
        raise ValueError("Reference behavior requires current accepted task and deterministic output closure: "
                         + "; ".join(row["code"] for row in diagnostics))
    plan = _get(context, "app_build_plan")
    pack_errors = scan_generated_bundle(files, capability_packs=plan.get("capability_packs") or [],
                                       context_variables=context)
    if pack_errors:
        raise ValueError("Reference behavior requires verified pack/output closure: " + "; ".join(pack_errors))
    selection = _context_to_dict(context)
    selection.update(app_build_plan=plan, capability_packs=plan.get("capability_packs") or [])
    pack_id = "messaging" if owner is paired_reference_cases else "commerce"
    packs = [entry for entry in verified_pack_template_inventory(context_variables=selection)
             if entry["pack_id"] == pack_id]
    if len(packs) != 1:
        raise ValueError(f"Reference behavior requires one freshly verified {pack_id} pack")
    pack = (owner.fresh_reference_pack(packs[0].get("messaging_configuration")) if owner is paired_reference_cases
            else owner.fresh_reference_pack(packs[0].get("storefront_recipe")))
    if any(packs[0].get(key) != value for key, value in pack.items()):
        raise ValueError("Reference behavior cannot use a caller-owned or stale pack")
    reference = owner.reference_request(inventory, plan["requirement_accounting"], plan["build_tasks"], pack,
                                        _source_content_sha256(_generated_source_digests(files)))
    if owner is paired_reference_cases and refinement_request is not None:
        reference["refinement"] = owner.refinement_expectation(reference, refinement_request, refinement_authority)
        reference = owner.validate_reference_request(reference).model_dump(mode="json")
    return reference
