import json
import logging
import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Annotated, Any
from urllib.parse import urlsplit

import yaml
from pydantic import Field

from factory_app.workflows._shared.generated_ui_contract import (
    audit_app_ui_bundle_integrity,
    audit_custom_route_bundle_integrity,
    audit_generated_react_files,
    audit_page_schemas,
    custom_route_bundle_page_files,
    dedupe,
)
from factory_app.workflows._shared.platform.build_target import require_build_binding
from factory_app.workflows.AppGenerator.tools.audit_module_contracts import (
    audit_admin_registry_file_map,
)
from factory_app.workflows.AppGenerator.tools.code_file_utils import (
    _assembled_data_contract,
    extract_code_file_map_from_payload,
)
from factory_app.workflows.AppGenerator.tools.default_runtime_configs import (
    load_default_ai_config,
)
from factory_app.workflows.AppGenerator.tools.resolve_managed_capability_templates import (
    ManagedCapabilityTemplateError,
    verified_pack_template_inventory,
)
from factory_app.workflows.AppGenerator.tools.task_integrity import (
    RepairOwnershipError,
    approved_task_inventory,
    mark_repair_rejected,
    mark_repair_responded,
    task_allowed_paths,
    validate_admin_registry_task_output,
    validate_repair_candidate,
)
from mozaiksai.core.runtime.app.page_schema import (
    PageSchemaValidationError,
    validate_page_schema,
)
from mozaiksai.core.runtime.app.provenance import (
    build_default_app_provenance,
    dump_app_provenance_yaml,
)
from mozaiksai.core.runtime.app.theme_contract import validate_page_title_theme
from mozaiksai.core.runtime.persistence.intent_loader import (
    validate_complete_data_contract_ownership,
)
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.code_files import (
    _custom_route_bundle_code_files,
    _page_file_stem,
    auth_required_from_strategy,
    compile_data_contract,
    data_contract_requires_auth,
    safe_relpath,
    validate_custom_page_files,
)
from mozaiksai.core.workflow.generator_support.module_action_inventory import (
    pack_owned_output_paths,
)
from mozaiksai.core.workflow.generator_support.module_entitlement_gates import (
    resolve_subscription_contract,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _key_value_entries_to_dict as _key_value_entries_to_dict,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _normalize_action_data as _normalize_action_data,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _normalize_blank_optional_strings as _normalize_blank_optional_strings,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _normalize_config_actions as _normalize_config_actions,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _normalize_custom_route_bundle,
    _strip_none,
    _to_plain,
    compile_page_data_sources,
    materialize_modal_targets,
    module_action_index_from_context,
    resolve_modal_action_targets,
    workflow_names_from_context,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    _normalize_page_section as _normalize_page_section,
)
from mozaiksai.core.workflow.generator_support.page_plan_utils import (
    normalize_page_schema as _normalize_page_schema,
)
from mozaiksai.core.workflow.ui_primitives import (
    validate_page_ui_primitives,
)

_logger = logging.getLogger("tools.save_app_schema")

PROMOTABLE_APP_ENTRIES = (
    "app.json",
    "provenance.yaml",
    "ui",
    "brand",
    "config",
    "data",
    "security",
    "services",
    "admin",
)


def _repo_root() -> Path:
    here = Path(__file__).resolve()
    for parent in [here] + list(here.parents):
        if (parent / "mozaiksai").is_dir():
            return parent
    return here.parents[-1]


def _resolve_generated_artifacts_root() -> Path:
    raw = os.getenv("MOZAIKS_GENERATED_ARTIFACTS_PATH", "generated").strip()
    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = _repo_root() / candidate
    return candidate.resolve()


def _context_get(context_variables: Any | None, key: str) -> Any | None:
    """Read a context value as plain data.

    Every live container freezes on read, so without detach() this returns a
    MappingProxyType and every `isinstance(..., dict)` on the result is False.
    That is silent: the caller takes the else branch and derives nothing.
    """
    if context_variables is None:
        return None
    if hasattr(context_variables, "get"):
        try:
            value = context_variables.get(key)
            if value is not None:
                return detach(value)
        except Exception:
            pass
    data = getattr(context_variables, "data", None)
    if isinstance(data, dict):
        return detach(data.get(key))
    if isinstance(context_variables, dict):
        return detach(context_variables.get(key))
    return None


def _context_text(context_variables: Any | None, key: str) -> str | None:
    value = _context_get(context_variables, key)
    if not isinstance(value, str):
        return None
    text = value.strip()
    return text or None


def _safe_path_segment(value: Any, *, fallback: str) -> str:
    text = str(value or "").strip()
    if not text:
        text = fallback
    text = re.sub(r"[^A-Za-z0-9_.-]+", "-", text).strip(".-")
    return text or fallback


def _resolve_artifact_ids(
    *,
    context_variables: Any | None,
    manifest_dict: dict[str, Any] | None = None,
) -> tuple[str, str]:
    binding = require_build_binding(context_variables)
    return binding.target_app_id, binding.build_id


def _normalize_list(value: Any) -> list[Any]:
    if not isinstance(value, list):
        return []
    return list(value)


def _normalize_shell_config(shell_config: Any) -> Any:
    return _strip_none(_to_plain(shell_config))


def _require_dict(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"AppSchemaOutput.{field} must be a dict, got {type(value).__name__}")
    return value


def _deep_merge_dicts(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = dict(base)
    for key, value in overlay.items():
        if (
            isinstance(value, dict)
            and isinstance(base.get(key), dict)
        ):
            merged[key] = _deep_merge_dicts(base[key], value)
        else:
            merged[key] = value
    return merged


def resolve_app_theme_config(captured_theme_config: Any, theme_config_patch: Any) -> dict[str, Any] | None:
    """Apply explicit visual deltas without losing the approved ThemeCapture base."""
    captured = detach(captured_theme_config)
    patch = _strip_none(_to_plain(theme_config_patch))
    if captured is not None and not isinstance(captured, dict):
        raise ValueError("captured_theme_config must be an object or null")
    if patch is not None and not isinstance(patch, dict):
        raise ValueError("theme_config_patch must be an object or null")
    resolved = _deep_merge_dicts(captured or {}, patch or {}) or None
    if resolved is not None:
        validate_page_title_theme(resolved)
    return resolved


def _resolve_output_dir(
    *,
    context_variables: Any | None = None,
    manifest_dict: dict[str, Any] | None = None,
) -> Path:
    """Resolve the generated app artifact directory.

    Generator output is staged under:
      $MOZAIKS_GENERATED_ARTIFACTS_PATH/apps/{app_id}/{build_id}/app
    """
    app_id, build_id = _resolve_artifact_ids(
        context_variables=context_variables,
        manifest_dict=manifest_dict,
    )
    return _resolve_generated_artifacts_root() / "apps" / app_id / build_id / "app"


def _write_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        yaml.dump(data, fh, allow_unicode=True, sort_keys=False, default_flow_style=False)


def _app_artifact_target(root: Path, relative: str) -> Path:
    safe = safe_relpath(relative)
    if safe != relative or safe == "." or ":" in relative or "\x00" in relative:
        raise ValueError(f"App schema artifact path must be app-relative and canonical: {relative!r}")
    resolved_root = root.resolve()
    target = (resolved_root / safe).resolve()
    if not target.is_relative_to(resolved_root):
        raise ValueError(f"App schema artifact path escapes the app root: {relative!r}")
    return target


VALID_ACTION_TYPES = {"navigate", "event", "workflow", "submit", "delete"}
VALID_ALERT_VARIANTS = {"default", "info", "success", "warning", "destructive"}
VALID_FIELD_TYPES = {"text", "email", "password", "number", "textarea", "select", "checkbox"}
VALID_GRID_GAPS = {"sm", "md", "lg", "1", "2", "3", "4", "6", "8", "10", "12"}
VALID_MODAL_SIZES = {"small", "medium", "large", "full"}
VALID_SELECTION_MODES = {"none", "single", "multi"}
VALID_ASSET_SOURCES = {"local", "remote", "uploaded", "generated", "stock"}
VALID_SHELL_MODES = {"standard", "workspace", "conversation", "focused", "immersive", "public"}
VALID_SHELL_ACTION_SURFACES = {"studio", "app", "user", "workflow_session", "transition", "public", "page"}
VALID_SHELL_ACTION_WHEN_FIELDS = {
    "surface",
    "surfaces",
    "shellMode",
    "shell_mode",
    "routeGroup",
    "route_group",
    "workflow",
    "workflow_id",
    "workflowSequence",
    "workflow_sequence",
    "sequence",
    "transition",
    "transition_id",
    "appLifecycle",
    "app_lifecycle",
    "hasActiveApp",
    "has_active_app",
}
NON_CONTRACT_SHELL_ACTION_FIELDS = {"route_overrides", "routeOverrides", "route_variants", "routeVariants"}


def _is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _validate_string_list(value: Any, *, field: str) -> None:
    if value is None:
        return
    if not isinstance(value, list):
        raise ValueError(f"{field} must be a list of strings")
    for index, item in enumerate(value):
        if not _is_non_empty_string(item):
            raise ValueError(f"{field}[{index}] must be a non-empty string")


def _validate_optional_string(value: Any, *, field: str) -> None:
    if value is None:
        return
    if not _is_non_empty_string(value):
        raise ValueError(f"{field} must be a non-empty string or null")


def _validate_api_endpoint(value: Any, *, field: str) -> None:
    _validate_optional_string(value, field=field)
    if value is None:
        return
    endpoint = str(value).strip()
    parsed = urlsplit(endpoint)
    if parsed.scheme or parsed.netloc:
        raise ValueError(f"{field} must be an app-relative API path, not an absolute URL")
    if parsed.query or parsed.fragment:
        raise ValueError(
            f"{field} must not include query strings or fragments; put filters in "
            "page_size, payload, or form/input config instead"
        )
    if not parsed.path.startswith("/"):
        raise ValueError(f"{field} must start with /")


def _validate_shell_mode(value: Any, *, field: str) -> None:
    if value is None:
        return
    if value not in VALID_SHELL_MODES:
        raise ValueError(f"{field} must be one of {sorted(VALID_SHELL_MODES)}")


def _validate_shell_path(value: Any, *, field: str) -> None:
    if value is None:
        return
    if not _is_non_empty_string(value) or not str(value).startswith("/"):
        raise ValueError(f"{field} must be a route path starting with /")


def _validate_shell_string_or_list(value: Any, *, field: str) -> None:
    if value is None:
        return
    if _is_non_empty_string(value):
        return
    if isinstance(value, list) and all(_is_non_empty_string(item) for item in value):
        return
    raise ValueError(f"{field} must be a non-empty string or list of non-empty strings")


def _validate_asset_manifest(asset_manifest: Any) -> None:
    if asset_manifest is None:
        return
    if not isinstance(asset_manifest, dict):
        raise ValueError("asset_manifest must be an object")
    if not _is_non_empty_string(asset_manifest.get("version")):
        raise ValueError("asset_manifest.version is required")

    assets = asset_manifest.get("assets")
    if not isinstance(assets, list):
        raise ValueError("asset_manifest.assets must be a list")

    for index, asset in enumerate(assets):
        path = f"asset_manifest.assets[{index}]"
        if not isinstance(asset, dict):
            raise ValueError(f"{path} must be an object")
        if not _is_non_empty_string(asset.get("asset_id")):
            raise ValueError(f"{path}.asset_id is required")
        if not _is_non_empty_string(asset.get("kind")):
            raise ValueError(f"{path}.kind is required")

        source = asset.get("source")
        if source not in VALID_ASSET_SOURCES:
            raise ValueError(f"{path}.source must be one of {sorted(VALID_ASSET_SOURCES)}")

        _validate_optional_string(asset.get("path"), field=f"{path}.path")
        _validate_optional_string(asset.get("url"), field=f"{path}.url")
        _validate_optional_string(asset.get("alt"), field=f"{path}.alt")
        _validate_optional_string(asset.get("license"), field=f"{path}.license")
        _validate_string_list(asset.get("usage"), field=f"{path}.usage")
        _validate_string_list(asset.get("tags"), field=f"{path}.tags")

        has_path = _is_non_empty_string(asset.get("path"))
        has_url = _is_non_empty_string(asset.get("url"))
        if not has_path and not has_url:
            raise ValueError(f"{path} must include at least one of path or url")


def _validate_data_contract(data_contract: Any, *, composed_contract: dict[str, Any] | None = None) -> None:
    if data_contract is None:
        return
    if not isinstance(data_contract, dict):
        raise ValueError("data_contract must be an object")
    if not _is_non_empty_string(data_contract.get("version")):
        raise ValueError("data_contract.version is required")

    surfaces = data_contract.get("surfaces")
    if not isinstance(surfaces, list):
        raise ValueError("data_contract.surfaces must be a list")

    validate_complete_data_contract_ownership(composed_contract if composed_contract is not None else data_contract)

    aliases = data_contract.get("aliases") or []
    if not isinstance(aliases, list):
        raise ValueError("data_contract.aliases must be a list when provided")
    seen_aliases: set[str] = set()
    for index, alias in enumerate(aliases):
        path = f"data_contract.aliases[{index}]"
        if not isinstance(alias, dict):
            raise ValueError(f"{path} must be an object")
        alias_id = alias.get("alias")
        if not _is_non_empty_string(alias_id):
            raise ValueError(f"{path}.alias is required")
        if alias_id in seen_aliases:
            raise ValueError(f"{path}.alias must be unique")
        seen_aliases.add(alias_id)  # type: ignore[arg-type]
        if not _is_non_empty_string(alias.get("collection")):
            raise ValueError(f"{path}.collection is required")
        if not _is_non_empty_string(alias.get("owner_module")):
            raise ValueError(f"{path}.owner_module is required")


def _bundle_data_contract(context_variables: Any, approved: dict[str, Any]) -> tuple[dict[str, Any] | None, str | None]:
    """data/contract.json as assembly compiles it, or None and the reason it cannot be compiled here.

    The admitted projection overlays this copy on the assembled bundle, so the
    approved contract alone would drop the verified pack contributions and the
    subscription assignment stores there. When the selected packs cannot be
    verified, or their contributions do not compose with the approved contract,
    the app schema author cannot repair either, and no contract compiled
    without them is written: this save leaves data/contract.json to assembly,
    which fails with the same pack error, and returns the reason.
    """
    subscription_contract = resolve_subscription_contract(context_variables)
    try:
        assembled: dict[str, Any] = _assembled_data_contract(context_variables, subscription_contract)
        return assembled, None
    except ValueError as exc:
        # Without the pack contributions the approved contract still compiles,
        # so the packs are the reason. Its own compile error raises here.
        compile_data_contract(
            approved, subscription_contract=subscription_contract, context_variables=context_variables,
        )
        _logger.warning(
            "APP_SCHEMA_PACK_DATA_CONTRACT_NOT_WRITTEN: the selected packs' data contributions do not compose "
            "with the approved data contract, so this save writes no data/contract.json; assembly reports "
            "the pack failure: %s", exc,
        )
        return None, str(exc)


def _validate_route_auth(route_auth: Any, *, field: str) -> None:
    if route_auth is None:
        return
    if not isinstance(route_auth, dict):
        raise ValueError(f"{field} must be an object or null")
    if not _is_non_empty_string(route_auth.get("module")):
        raise ValueError(f"{field}.module is required")
    if not _is_non_empty_string(route_auth.get("action")):
        raise ValueError(f"{field}.action is required")
    params = route_auth.get("params")
    if params is not None and not isinstance(params, dict):
        raise ValueError(f"{field}.params must be an object or null")
    if isinstance(params, dict):
        for key in params:
            if not _is_non_empty_string(key):
                raise ValueError(f"{field}.params keys must be non-empty strings")


def _validate_custom_route_bundle(custom_route_bundle: Any) -> None:
    if custom_route_bundle is None:
        return
    if not isinstance(custom_route_bundle, dict):
        raise ValueError("custom_route_bundle must be an object")

    route_manifest = custom_route_bundle.get("route_manifest")
    page_files = custom_route_bundle.get("page_files")
    if not isinstance(route_manifest, list) or not route_manifest:
        raise ValueError("custom_route_bundle.route_manifest must be a non-empty list")
    if not isinstance(page_files, list) or not page_files:
        raise ValueError("custom_route_bundle.page_files must be a non-empty list")

    route_ids: set[str] = set()
    route_paths: set[str] = set()
    registry_keys: set[str] = set()
    for index, entry in enumerate(route_manifest):
        path = f"custom_route_bundle.route_manifest[{index}]"
        if not isinstance(entry, dict):
            raise ValueError(f"{path} must be an object")
        route_id = entry.get("id")
        route_path = entry.get("path")
        component = entry.get("component")
        if not _is_non_empty_string(route_id):
            raise ValueError(f"{path}.id is required")
        if route_id in route_ids:
            raise ValueError(f"{path}.id must be unique")
        if not _is_non_empty_string(entry.get("label")):
            raise ValueError(f"{path}.label is required")
        if not _is_non_empty_string(route_path):
            raise ValueError(f"{path}.path is required")
        if route_path in route_paths:
            raise ValueError(f"{path}.path must be unique")
        if not _is_non_empty_string(component):
            raise ValueError(f"{path}.component is required")
        if component in registry_keys:
            raise ValueError(f"{path}.component must be unique")
        if not isinstance(entry.get("requiresAuth"), bool):
            raise ValueError(f"{path}.requiresAuth must be a boolean")
        order = entry.get("order")
        if order is not None and not isinstance(order, int):
            raise ValueError(f"{path}.order must be an integer or null")
        meta = entry.get("meta")
        if meta is not None and not isinstance(meta, dict):
            raise ValueError(f"{path}.meta must be an object or null")
        if isinstance(meta, dict):
            _validate_shell_mode(
                meta.get("shellMode", meta.get("shell_mode")),
                field=f"{path}.meta.shellMode",
            )
            _validate_route_auth(meta.get("routeAuth"), field=f"{path}.meta.routeAuth")
        if not _is_non_empty_string(entry.get("purpose")):
            raise ValueError(f"{path}.purpose is required")
        route_ids.add(route_id)  # type: ignore[arg-type]
        route_paths.add(route_path)  # type: ignore[arg-type]
        registry_keys.add(component)  # type: ignore[arg-type]

    validate_custom_page_files(custom_route_bundle)


def _validate_action(action: Any, *, path: str) -> None:
    if not isinstance(action, dict):
        raise ValueError(f"{path} must be an object")
    if not _is_non_empty_string(action.get("label")):
        raise ValueError(f"{path}.label is required")

    # action_type is the discriminator: every variant declares it, so an action
    # that arrives without one did not come from the contract.
    action_type = action.get("action_type")
    if not _is_non_empty_string(action_type):
        raise ValueError(f"{path}.action_type is required")

    if action_type not in VALID_ACTION_TYPES:
        raise ValueError(f"{path}.action_type must be one of {sorted(VALID_ACTION_TYPES)}")

    _validate_optional_string(action.get("id"), field=f"{path}.id")
    _validate_optional_string(action.get("variant"), field=f"{path}.variant")
    _validate_optional_string(action.get("href"), field=f"{path}.href")
    _validate_optional_string(action.get("event_type"), field=f"{path}.event_type")
    _validate_optional_string(action.get("workflow_id"), field=f"{path}.workflow_id")

    payload = action.get("payload")
    if payload is not None and not isinstance(payload, dict):
        raise ValueError(f"{path}.payload must be an object or null")

    context_variables = action.get("context_variables")
    if context_variables is not None and not isinstance(context_variables, dict):
        raise ValueError(f"{path}.context_variables must be an object or null")

    requires_selection = action.get("requires_selection")
    if requires_selection is not None and not isinstance(requires_selection, bool):
        raise ValueError(f"{path}.requires_selection must be a boolean")

    closes_modal = action.get("closes_modal")
    if closes_modal is not None and not isinstance(closes_modal, bool):
        raise ValueError(f"{path}.closes_modal must be a boolean")



def _validate_action_list(actions: Any, *, path: str) -> None:
    if actions is None:
        return
    if not isinstance(actions, list):
        raise ValueError(f"{path} must be a list")
    for index, action in enumerate(actions):
        _validate_action(action, path=f"{path}[{index}]")


def _validate_column(column: Any, *, path: str) -> None:
    if isinstance(column, str):
        if not column.strip():
            raise ValueError(f"{path} must not be empty")
        return

    if not isinstance(column, dict):
        raise ValueError(f"{path} must be a string or object")

    key = column.get("key") or column.get("field") or column.get("name") or column.get("id")
    if not _is_non_empty_string(key):
        raise ValueError(f"{path}.key is required")

    _validate_optional_string(column.get("label"), field=f"{path}.label")

    sortable = column.get("sortable")
    if sortable is not None and not isinstance(sortable, bool):
        raise ValueError(f"{path}.sortable must be a boolean")

    _validate_optional_string(column.get("type"), field=f"{path}.type")
    _validate_optional_string(column.get("width"), field=f"{path}.width")


def _validate_empty_state(empty_state: Any, *, path: str) -> None:
    if empty_state is None:
        return
    if not isinstance(empty_state, dict):
        raise ValueError(f"{path} must be an object")

    _validate_optional_string(empty_state.get("title"), field=f"{path}.title")
    _validate_optional_string(empty_state.get("message"), field=f"{path}.message")

    action = empty_state.get("action")
    if action is not None:
        _validate_action(action, path=f"{path}.action")


def _validate_form_field(field: Any, *, path: str) -> None:
    if not isinstance(field, dict):
        raise ValueError(f"{path} must be an object")

    name = field.get("name") or field.get("id")
    if not _is_non_empty_string(name):
        raise ValueError(f"{path}.name is required")
    if not _is_non_empty_string(field.get("label")):
        raise ValueError(f"{path}.label is required")

    resolved_type = field.get("type")
    if resolved_type not in VALID_FIELD_TYPES:
        raise ValueError(f"{path}.type must be one of {sorted(VALID_FIELD_TYPES)}")

    required = field.get("required")
    if required is not None and not isinstance(required, bool):
        raise ValueError(f"{path}.required must be a boolean")

    _validate_optional_string(field.get("placeholder"), field=f"{path}.placeholder")

    options = field.get("options")
    if options is not None:
        if not isinstance(options, list):
            raise ValueError(f"{path}.options must be a list")
        for option_index, option in enumerate(options):
            if not isinstance(option, dict):
                raise ValueError(f"{path}.options[{option_index}] must be an object")
            if option.get("value") is None:
                raise ValueError(f"{path}.options[{option_index}].value is required")
            if not _is_non_empty_string(option.get("label")):
                raise ValueError(f"{path}.options[{option_index}].label is required")


def _validate_children(children: Any, *, path: str, required: bool = False) -> None:
    if children is None:
        if required:
            raise ValueError(f"{path} is required")
        return
    if not isinstance(children, list):
        raise ValueError(f"{path} must be a list")
    if required and not children:
        raise ValueError(f"{path} must contain at least one child section")
    for child_index, child in enumerate(children):
        _validate_page_section(
            child,
            path=f"{path}[{child_index}]",
            require_id=False,
        )


def _validate_section_config(primitive: str, config: Any, *, path: str) -> None:
    if not isinstance(config, dict):
        raise ValueError(f"{path} must be an object")

    _validate_api_endpoint(config.get("api_endpoint"), field=f"{path}.api_endpoint")

    if primitive == "DataTable":
        columns = config.get("columns")
        if not isinstance(columns, list) or not columns:
            raise ValueError(f"{path}.columns must be a non-empty list")
        for column_index, column in enumerate(columns):
            _validate_column(column, path=f"{path}.columns[{column_index}]")

        selection = config.get("selection")
        if selection is not None and selection not in VALID_SELECTION_MODES:
            raise ValueError(f"{path}.selection must be one of {sorted(VALID_SELECTION_MODES)}")

        for field_name in ("pagination", "search"):
            value = config.get(field_name)
            if value is not None and not isinstance(value, bool):
                raise ValueError(f"{path}.{field_name} must be a boolean")

        page_size = config.get("page_size") or config.get("pageSize")
        if page_size is not None and (not isinstance(page_size, int) or page_size <= 0):
            raise ValueError(f"{path}.page_size must be a positive integer")

        _validate_action_list(config.get("actions"), path=f"{path}.actions")
        _validate_empty_state(config.get("empty"), path=f"{path}.empty")
        return

    if primitive == "Form":
        fields = config.get("fields")
        if not isinstance(fields, list) or not fields:
            raise ValueError(f"{path}.fields must be a non-empty list")
        for field_index, field in enumerate(fields):
            _validate_form_field(field, path=f"{path}.fields[{field_index}]")

        layout = config.get("layout")
        if layout is not None and layout not in {"vertical", "horizontal", "grid"}:
            raise ValueError(f"{path}.layout must be one of ['grid', 'horizontal', 'vertical']")

        columns = config.get("columns")
        if columns is not None and (not isinstance(columns, int) or columns <= 0):
            raise ValueError(f"{path}.columns must be a positive integer")

        _validate_optional_string(config.get("submit_label"), field=f"{path}.submit_label")
        _validate_optional_string(config.get("cancel_label"), field=f"{path}.cancel_label")

        disabled = config.get("disabled")
        if disabled is not None and not isinstance(disabled, bool):
            raise ValueError(f"{path}.disabled must be a boolean")

        submit_action = config.get("submit_action")
        if submit_action is not None:
            _validate_action(submit_action, path=f"{path}.submit_action")

        cancel_action = config.get("cancel_action")
        if cancel_action is not None:
            _validate_action(cancel_action, path=f"{path}.cancel_action")
        return

    if primitive == "Grid":
        columns = config.get("columns")
        if not isinstance(columns, int) or not 1 <= columns <= 6:
            raise ValueError(f"{path}.columns must be an integer between 1 and 6")

        gap = config.get("gap")
        if gap is not None and str(gap) not in VALID_GRID_GAPS:
            raise ValueError(f"{path}.gap must be one of {sorted(VALID_GRID_GAPS)}")

        _validate_children(config.get("children"), path=f"{path}.children", required=True)
        return

    if primitive == "Button":
        if not _is_non_empty_string(config.get("label")):
            raise ValueError(f"{path}.label is required")
        _validate_optional_string(config.get("variant"), field=f"{path}.variant")
        _validate_optional_string(config.get("size"), field=f"{path}.size")

        action = config.get("action")
        if action is not None:
            _validate_action(action, path=f"{path}.action")
            return

        if any(config.get(field) is not None for field in ("action_type", "event_type", "workflow_id", "href")):
            _validate_action(
                {
                    "label": config.get("label"),
                    "action_type": config.get("action_type"),
                    "event_type": config.get("event_type"),
                    "workflow_id": config.get("workflow_id"),
                    "context_variables": config.get("context_variables"),
                    "href": config.get("href"),
                },
                path=f"{path}.action",
            )
        return

    if primitive == "Modal":
        _validate_optional_string(config.get("title"), field=f"{path}.title")
        _validate_optional_string(config.get("description"), field=f"{path}.description")
        size = config.get("size")
        if size is not None and size not in VALID_MODAL_SIZES:
            raise ValueError(f"{path}.size must be one of {sorted(VALID_MODAL_SIZES)}")

        _validate_action_list(config.get("actions"), path=f"{path}.actions")

        open_value = config.get("open")
        if open_value is not None and not isinstance(open_value, bool):
            raise ValueError(f"{path}.open must be a boolean")

        _validate_children(config.get("children"), path=f"{path}.children")
        return

    if primitive == "Alert":
        if not _is_non_empty_string(config.get("message")):
            raise ValueError(f"{path}.message is required")

        _validate_optional_string(config.get("title"), field=f"{path}.title")
        variant = config.get("variant")
        if variant is not None and variant not in VALID_ALERT_VARIANTS:
            raise ValueError(f"{path}.variant must be one of {sorted(VALID_ALERT_VARIANTS)}")

        dismissible = config.get("dismissible")
        if dismissible is not None and not isinstance(dismissible, bool):
            raise ValueError(f"{path}.dismissible must be a boolean")
        return

    if primitive == "Skeleton":
        rows = config.get("rows")
        if rows is not None and (not isinstance(rows, int) or rows <= 0):
            raise ValueError(f"{path}.rows must be a positive integer")
        _validate_optional_string(config.get("height"), field=f"{path}.height")
        return

    if primitive == "Empty":
        _validate_optional_string(config.get("title"), field=f"{path}.title")
        _validate_optional_string(config.get("message"), field=f"{path}.message")

        action = config.get("action")
        if action is not None:
            _validate_action(action, path=f"{path}.action")
            return

        return


def _validate_page_section(section: dict[str, Any], *, path: str, require_id: bool = True) -> None:
    if not isinstance(section, dict):
        raise ValueError(f"{path} must be an object")

    section_id = section.get("id")
    if require_id and not _is_non_empty_string(section_id):
        raise ValueError(f"{path}.id is required")
    if section_id is not None and not _is_non_empty_string(section_id):
        raise ValueError(f"{path}.id must be a non-empty string")

    primitive = section.get("primitive")
    validated = validate_page_ui_primitives([primitive], context=f"{path}.primitive")  # type: ignore[list-item]
    if not validated:
        raise ValueError(f"{path}.primitive is required")

    if section.get("title") is not None and not _is_non_empty_string(section.get("title")):
        raise ValueError(f"{path}.title must be a non-empty string or null")

    _validate_string_list(section.get("roles"), field=f"{path}.roles")
    _validate_string_list(section.get("event_triggers"), field=f"{path}.event_triggers")

    _validate_section_config(validated[0], section.get("config"), path=f"{path}.config")


def _validate_manifest_against_pages(
    manifest_dict: dict[str, Any],
    page_list: list[dict[str, Any]],
    custom_route_bundle: dict[str, Any] | None,
) -> None:
    page_names = [page["name"] for page in page_list]
    if len(page_names) != len(set(page_names)):
        raise ValueError("Each AppPageSchema.name must be unique")

    page_routes = [page["route"] for page in page_list]
    if len(page_routes) != len(set(page_routes)):
        raise ValueError("Each AppPageSchema.route must be unique")

    manifest_pages = manifest_dict.get("pages")
    if manifest_pages != page_names:
        raise ValueError("manifest.pages must exactly match the generated page names")

    custom_route_entries = list((custom_route_bundle or {}).get("route_manifest") or [])
    custom_route_ids = [route["id"] for route in custom_route_entries]
    custom_route_paths = [route["path"] for route in custom_route_entries]
    if len(custom_route_paths) != len(set(custom_route_paths)):
        raise ValueError("Each custom route path must be unique")
    if set(page_routes).intersection(custom_route_paths):
        raise ValueError("Declarative page routes and custom route paths must not overlap")

    manifest_custom_routes = manifest_dict.get("custom_routes")
    expected_custom_routes = custom_route_ids or []
    if manifest_custom_routes is None:
        manifest_custom_routes = []
    if manifest_custom_routes != expected_custom_routes:
        raise ValueError("manifest.custom_routes must exactly match the generated custom route ids")

    default_route = manifest_dict.get("default_route")
    if default_route not in page_routes + custom_route_paths:
        raise ValueError("manifest.default_route must match one of the generated declarative or custom page routes")


def _canonicalize_manifest_routes(
    manifest_dict: dict[str, Any],
    page_list: list[dict[str, Any]],
    custom_route_bundle: dict[str, Any] | None,
) -> None:
    """Derive manifest route indexes from the emitted page/custom route objects.

    The real runtime artifact is the page/custom route definition. The manifest
    lists are redundant indexes, so the persistence layer owns canonicalization
    to avoid letting duplicate model output drift.
    """

    manifest_dict["pages"] = [page["name"] for page in page_list]
    custom_route_entries = list((custom_route_bundle or {}).get("route_manifest") or [])
    manifest_dict["custom_routes"] = [route["id"] for route in custom_route_entries]


def _validate_shell_action_when(when: Any, *, field: str) -> None:
    if not isinstance(when, dict):
        raise ValueError(f"{field}.when must be an object with semantic shell context")

    for key in when:
        if key not in VALID_SHELL_ACTION_WHEN_FIELDS:
            raise ValueError(f"{field}.when.{key} is not supported")

    has_condition = any(
        value is not None and (not isinstance(value, list) or len(value) > 0)
        for value in when.values()
    )
    if not has_condition:
        raise ValueError(f"{field}.when must include at least one semantic match field")

    surface = when.get("surface", when.get("surfaces"))
    if surface is not None:
        surfaces = surface if isinstance(surface, list) else [surface]
        for item in surfaces:
            if item not in VALID_SHELL_ACTION_SURFACES:
                raise ValueError(f"{field}.when.surface must be one of {sorted(VALID_SHELL_ACTION_SURFACES)}")

    shell_mode = when.get("shellMode", when.get("shell_mode"))
    if shell_mode is not None:
        modes = shell_mode if isinstance(shell_mode, list) else [shell_mode]
        for item in modes:
            _validate_shell_mode(item, field=f"{field}.when.shellMode")

    for key in (
        "routeGroup",
        "route_group",
        "workflow",
        "workflow_id",
        "workflowSequence",
        "workflow_sequence",
        "sequence",
        "transition",
        "transition_id",
        "appLifecycle",
        "app_lifecycle",
    ):
        _validate_shell_string_or_list(when.get(key), field=f"{field}.when.{key}")

    for key in ("hasActiveApp", "has_active_app"):
        value = when.get(key)
        if value is not None and not isinstance(value, bool):
            raise ValueError(f"{field}.when.{key} must be a boolean")


def _validate_shell_action_variant(variant: Any, *, field: str) -> None:
    if not isinstance(variant, dict):
        raise ValueError(f"{field} must be an object")
    _validate_shell_action_when(variant.get("when"), field=field)
    _validate_shell_path(variant.get("path"), field=f"{field}.path")
    _validate_shell_path(variant.get("pathTemplate", variant.get("path_template")), field=f"{field}.pathTemplate")
    _validate_shell_path(variant.get("fallbackPath", variant.get("fallback_path")), field=f"{field}.fallbackPath")
    if variant.get("href") is not None and not _is_non_empty_string(variant.get("href")):
        raise ValueError(f"{field}.href must be a non-empty string")


def _validate_shell_header_actions(shell_config: dict[str, Any] | None) -> None:
    if not shell_config:
        return
    if not isinstance(shell_config, dict):
        raise ValueError("shell_config must be an object")

    header = shell_config.get("header")
    if header is None:
        return
    if not isinstance(header, dict):
        raise ValueError("shell_config.header must be an object")

    actions = header.get("actions")
    if actions is None:
        return
    if not isinstance(actions, list):
        raise ValueError("shell_config.header.actions must be a list")

    for index, action in enumerate(actions):
        field = f"shell_config.header.actions[{index}]"
        if not isinstance(action, dict):
            raise ValueError(f"{field} must be an object")
        for key in NON_CONTRACT_SHELL_ACTION_FIELDS:
            if key in action:
                raise ValueError(f"{field}.{key} is not supported; use variants[].when")
        _validate_shell_path(action.get("path"), field=f"{field}.path")
        _validate_shell_path(action.get("pathTemplate", action.get("path_template")), field=f"{field}.pathTemplate")
        _validate_shell_path(action.get("fallbackPath", action.get("fallback_path")), field=f"{field}.fallbackPath")
        if action.get("href") is not None and not _is_non_empty_string(action.get("href")):
            raise ValueError(f"{field}.href must be a non-empty string")
        variants = action.get("variants")
        if variants is not None:
            if not isinstance(variants, list):
                raise ValueError(f"{field}.variants must be a list")
            for variant_index, variant in enumerate(variants):
                _validate_shell_action_variant(variant, field=f"{field}.variants[{variant_index}]")


def _validate_shell_shortcuts(shell_config: dict[str, Any] | None) -> None:
    if not shell_config:
        return
    if not isinstance(shell_config, dict):
        raise ValueError("shell_config must be an object")

    shortcuts = shell_config.get("shortcuts")
    if shortcuts is None:
        return
    if not isinstance(shortcuts, dict):
        raise ValueError("shell_config.shortcuts must be an object")

    shortcut_list_fields = {"header", "profile", "mobile", "footer"}
    for field in shortcut_list_fields:
        value = shortcuts.get(field)
        if value is None:
            continue
        if not isinstance(value, list) or any(not _is_non_empty_string(item) for item in value):
            raise ValueError(f"shell_config.shortcuts.{field} must be a list of primitive ids")

    allowed_fields = shortcut_list_fields | {"footerHideOnMobile"}
    for field in shortcuts:
        if field not in allowed_fields:
            raise ValueError(
                f"shell_config.shortcuts.{field} is not supported; use only "
                "header, profile, mobile, footer, and footerHideOnMobile"
            )

    footer_hide = shortcuts.get("footerHideOnMobile")
    if footer_hide is not None and not isinstance(footer_hide, bool):
        raise ValueError("shell_config.shortcuts.footerHideOnMobile must be a boolean")


def _validate_shell_navigation(shell_config: dict[str, Any] | None) -> None:
    if not shell_config:
        return
    if not isinstance(shell_config, dict):
        raise ValueError("shell_config must be an object")

    navigation = shell_config.get("navigation")
    if navigation is None:
        return
    if not isinstance(navigation, dict):
        raise ValueError("shell_config.navigation must be an object")

    policy = navigation.get("policy") if isinstance(navigation.get("policy"), dict) else navigation
    for viewport in ("desktop", "mobile"):
        value = policy.get(viewport)  # type: ignore[union-attr]
        if value is None:
            continue
        if not isinstance(value, dict):
            raise ValueError(f"shell_config.navigation.{viewport} must be an object")
        for field in ("global", "local", "footer"):
            if value.get(field) is not None and not _is_non_empty_string(value.get(field)):
                raise ValueError(f"shell_config.navigation.{viewport}.{field} must be a non-empty string")

    max_mobile = policy.get("maxMobileItems")  # type: ignore[union-attr]
    if max_mobile is not None and (not isinstance(max_mobile, int) or max_mobile < 1 or max_mobile > 5):
        raise ValueError("shell_config.navigation.maxMobileItems must be an integer from 1 to 5")
    if "max_mobile_items" in policy:  # type: ignore[operator]
        raise ValueError("shell_config.navigation.max_mobile_items is not supported; use maxMobileItems")

    auto_from_pages = policy.get("autoFromPages")  # type: ignore[union-attr]
    if auto_from_pages is not None and not isinstance(auto_from_pages, bool):
        raise ValueError("shell_config.navigation.autoFromPages must be a boolean")
    if "auto_from_pages" in policy:  # type: ignore[operator]
        raise ValueError("shell_config.navigation.auto_from_pages is not supported; use autoFromPages")

    items = navigation.get("items")
    if items is None:
        return
    if isinstance(items, dict):
        iterable = items.values()
    elif isinstance(items, list):
        iterable = items  # type: ignore[assignment]
    else:
        raise ValueError("shell_config.navigation.items must be a list or object")
    for item in iterable:
        if isinstance(item, str):
            continue
        if not isinstance(item, dict):
            raise ValueError("shell_config.navigation.items entries must be objects or shortcut ids")
        if item.get("id") is not None and not _is_non_empty_string(item.get("id")):
            raise ValueError("shell_config.navigation.items[*].id must be a non-empty string")
        scope = item.get("scope")
        if scope is not None and scope not in {"global", "local", "profile", "footer"}:
            raise ValueError("shell_config.navigation.items[*].scope must be global, local, profile, or footer")
        placement = item.get("placement")
        if placement is not None and not isinstance(placement, (str, dict)):
            raise ValueError("shell_config.navigation.items[*].placement must be a string or object")


def _validate_shell_chrome(shell_config: dict[str, Any] | None) -> None:
    if not shell_config:
        return
    if not isinstance(shell_config, dict):
        raise ValueError("shell_config must be an object")

    chrome = shell_config.get("chrome")
    if chrome is None:
        return
    if not isinstance(chrome, dict):
        raise ValueError("shell_config.chrome must be an object")

    if "default_mode" in chrome:
        raise ValueError("shell_config.chrome.default_mode is not supported; use defaultMode")
    _validate_shell_mode(chrome.get("defaultMode"), field="shell_config.chrome.defaultMode")

    modes = chrome.get("modes")
    if modes is None:
        return
    if not isinstance(modes, dict):
        raise ValueError("shell_config.chrome.modes must be an object")

    for mode, mode_policy in modes.items():
        _validate_shell_mode(mode, field="shell_config.chrome.modes key")
        if mode_policy is None:
            continue
        if not isinstance(mode_policy, dict):
            raise ValueError(f"shell_config.chrome.modes.{mode} must be an object")
        for field in ("topBar", "top_bar", "bottom_bar", "local_nav"):
            if field in mode_policy:
                raise ValueError(
                    f"shell_config.chrome.modes.{mode}.{field} is not supported; "
                    "use header, bottomBar, or localNav"
                )
        for viewport in ("desktop", "mobile"):
            viewport_policy = mode_policy.get(viewport)
            if viewport_policy is None:
                continue
            if not isinstance(viewport_policy, dict):
                raise ValueError(f"shell_config.chrome.modes.{mode}.{viewport} must be an object")
            for field in ("topBar", "top_bar", "bottom_bar", "local_nav"):
                if field in viewport_policy:
                    raise ValueError(
                        f"shell_config.chrome.modes.{mode}.{viewport}.{field} is not supported; "
                        "use header, bottomBar, or localNav"
                    )
            for field in ("header", "footer", "bottomBar"):
                value = viewport_policy.get(field)
                if value is not None and not isinstance(value, bool):
                    raise ValueError(f"shell_config.chrome.modes.{mode}.{viewport}.{field} must be a boolean")
            local_nav = viewport_policy.get("localNav")
            if local_nav is not None and not isinstance(local_nav, (bool, str)):
                raise ValueError(f"shell_config.chrome.modes.{mode}.{viewport}.localNav must be a boolean or string")


def _persist_to_filesystem(
    output_dir: Path,
    manifest_dict: dict[str, Any],
    page_list: list[dict[str, Any]],
    theme_config_patch: dict[str, Any] | None,
    shell_config: dict[str, Any] | None,
    asset_manifest: dict[str, Any] | None,
    data_contract: dict[str, Any] | None,
    custom_route_bundle: dict[str, Any] | None,
    context_variables: Any | None = None,
    profile_layout: str | None = None,
    auth_data_contract: dict[str, Any] | None = None,
) -> list[str]:
    """Write app.json, ui/pages/*.yaml, optional custom route artifacts, and optional config artifacts.

    Returns a list of written file paths (relative to output_dir).
    Tools are dumb — no reasoning here, just serialize what AppSchemaAgent produced.
    ``auth_data_contract`` is the contract app.json's ``authRequired`` is
    derived from when it is not the ``data_contract`` written (the approved
    contract, when the pack contributions could not be composed and no
    data/contract.json is written).
    """
    written: list[str] = []

    # app.json — app-level startup and product intent.
    default_route = manifest_dict.get("default_route") or "/"
    auth_required = auth_required_from_strategy(
        manifest_dict.get("auth_strategy"), roles=manifest_dict.get("roles")
    )
    app_json = {
        "appId": require_build_binding(context_variables).target_app_id,
        "appName": manifest_dict["app_name"],
        "startup": {"landing_spot": default_route},
        "targets": {"web": True, "mobile": False},
        "authRequired": auth_required or data_contract_requires_auth(
            data_contract if data_contract is not None else auth_data_contract
        ),
        "admins": [],
    }
    for manifest_key, app_json_key in (
        ("description", "description"),
        ("tagline", "tagline"),
        ("value_proposition", "value_proposition"),
    ):
        value = manifest_dict.get(manifest_key)
        if _is_non_empty_string(value):
            app_json[app_json_key] = str(value).strip()
    app_json_path = output_dir / "app.json"
    app_json_path.parent.mkdir(parents=True, exist_ok=True)
    app_json_path.write_text(json.dumps(app_json, indent=2, ensure_ascii=False), encoding="utf-8")
    written.append("app.json")

    workflow_sequence = _context_text(context_variables, "workflow_sequence")
    build_id = require_build_binding(context_variables).build_id
    generated_artifact_id = _context_text(context_variables, "generated_artifact_id")
    artifact_version_id = _context_text(context_variables, "artifact_version_id")
    app_context_version_id = _context_text(context_variables, "app_context_version_id")

    provenance_path = output_dir / "provenance.yaml"
    provenance_path.write_text(
        dump_app_provenance_yaml(
            build_default_app_provenance(
                app_kind="generated",
                created_mode="factory",
                workflow="AppGenerator",
                workflow_sequence=workflow_sequence,
                build_id=build_id,
                artifact_version_id=artifact_version_id,
                app_context_version_id=app_context_version_id,
                artifact_refs={
                    "generated_artifact_ids": [generated_artifact_id]
                    if generated_artifact_id
                    else [],
                    "accepted_artifact_version_ids": [artifact_version_id]
                    if artifact_version_id
                    else [],
                    "app_context_version_ids": [app_context_version_id]
                    if app_context_version_id
                    else [],
                },
            )
        ),
        encoding="utf-8",
    )
    written.append("provenance.yaml")

    # config/ai.json — runtime startup contract seeded from the current factory default.
    ai_config_path = output_dir / "config" / "ai.json"
    ai_config_path.parent.mkdir(parents=True, exist_ok=True)
    ai_config_path.write_text(
        json.dumps(load_default_ai_config(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    written.append("config/ai.json")

    # ui/pages/{name}.yaml — one file per page
    for page in page_list:
        name = _page_file_stem(page)
        page_path = _app_artifact_target(output_dir, f"ui/pages/{name}.yaml")
        _write_yaml(page_path, page)
        written.append(f"ui/pages/{name}.yaml")

    if custom_route_bundle and isinstance(custom_route_bundle, dict):
        for entry in _custom_route_bundle_code_files(custom_route_bundle):
            file_path = _app_artifact_target(output_dir, entry["filename"])
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(str(entry["content"]), encoding="utf-8")
            written.append(entry["filename"])

    # brand/theme_config.json — deep-merge theme_config_patch when provided
    if theme_config_patch and isinstance(theme_config_patch, dict):
        theme_path = output_dir / "brand" / "theme_config.json"
        existing: dict[str, Any] = {}
        if theme_path.exists():
            try:
                existing = json.loads(theme_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        existing = _deep_merge_dicts(existing, theme_config_patch)
        theme_path.parent.mkdir(parents=True, exist_ok=True)
        theme_path.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")
        written.append("brand/theme_config.json")

    # config/shell.json — deep-merge shell_config when provided
    if shell_config and isinstance(shell_config, dict):
        shell_path = output_dir / "config" / "shell.json"
        existing_shell: dict[str, Any] = {}
        if shell_path.exists():
            try:
                existing_shell = json.loads(shell_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        existing_shell = _deep_merge_dicts(existing_shell, shell_config)
        shell_path.parent.mkdir(parents=True, exist_ok=True)
        shell_path.write_text(json.dumps(existing_shell, indent=2, ensure_ascii=False), encoding="utf-8")
        written.append("config/shell.json")

    # config/asset_manifest.json — deep-merge asset_manifest when provided
    if asset_manifest and isinstance(asset_manifest, dict):
        manifest_path = output_dir / "config" / "asset_manifest.json"
        existing_manifest: dict[str, Any] = {}
        if manifest_path.exists():
            try:
                existing_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        existing_manifest = _deep_merge_dicts(existing_manifest, asset_manifest)
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(existing_manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        written.append("config/asset_manifest.json")

    if data_contract and isinstance(data_contract, dict):
        data_contract_path = output_dir / "data" / "contract.json"
        data_contract_path.parent.mkdir(parents=True, exist_ok=True)
        data_contract_path.write_text(
            json.dumps(data_contract, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        written.append("data/contract.json")

    # config/profile.yaml — profile page layout variant chosen by AppPlanAgent.
    # Written only when profile_layout is set; runtime defaults to top_nav when absent.
    if profile_layout:
        profile_config_path = output_dir / "config" / "profile.yaml"
        profile_config_path.parent.mkdir(parents=True, exist_ok=True)
        with profile_config_path.open("w", encoding="utf-8") as _fh:
            yaml.dump(
                {"schema_version": "mozaiks.profile.v1", "layout": profile_layout},
                _fh,
                allow_unicode=True,
                sort_keys=False,
                default_flow_style=False,
            )
        written.append("config/profile.yaml")

    return written


def _copy_entry(source: Path, target: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, target, dirs_exist_ok=True)
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def promote_generated_app(source_dir: str | Path, target_root: str | Path) -> dict[str, Any]:
    """Explicitly promote a generated app bundle into an active app root."""
    source = Path(source_dir).resolve()
    target = Path(target_root).resolve()

    if not source.is_dir():
        raise ValueError(f"Generated app source_dir does not exist: {source}")
    if source == target or source in target.parents:
        raise ValueError("target_root must not be the generated source_dir or inside it")

    copied: list[str] = []
    target.mkdir(parents=True, exist_ok=True)
    for entry in PROMOTABLE_APP_ENTRIES:
        src = source / entry
        if not src.exists():
            continue
        _copy_entry(src, target / entry)
        copied.append(entry)

    if not copied:
        raise ValueError(f"No promotable app artifacts found in {source}")

    return {
        "status": "success",
        "source_dir": str(source),
        "target_root": str(target),
        "copied": copied,
    }


def save_app_schema(
    *,
    agent_message: Annotated[
        str | None,
        Field(description="Short summary of the schema produced by AppSchemaAgent."),
    ] = None,
    manifest: Annotated[
        dict[str, Any] | None,
        Field(description="AppManifest object used to persist app.json startup and validate page routes."),
    ] = None,
    pages: Annotated[
        list[dict[str, Any]] | None,
        Field(description="List of AppPageSchema objects, each persisted as ui/pages/{name}.yaml."),
    ] = None,
    theme_config_patch: Annotated[
        dict[str, Any] | None,
        Field(description="Partial theme_config.json patch to merge into brand/theme_config.json. None to skip."),
    ] = None,
    shell_config: Annotated[
        dict[str, Any] | None,
        Field(description="Optional shell config to merge into config/shell.json. None to skip."),
    ] = None,
    asset_manifest: Annotated[
        dict[str, Any] | None,
        Field(description="Optional asset manifest to merge into config/asset_manifest.json. None to skip."),
    ] = None,
    custom_route_bundle: Annotated[
        dict[str, Any] | None,
        Field(description="Optional bounded custom full-page React route bundle persisted to ui/route_manifest.json and ui/pages/custom/*.jsx."),
    ] = None,
    admin_registry: Annotated[
        dict[str, Any] | None,
        Field(description="Typed admin page registry; requires explicit approved page_bundle ownership."),
    ] = None,
    context_variables: Annotated[
        Any | None,
        Field(description="AG2-injected workflow context variables."),
    ] = None,
) -> str:
    """
    Persist AppSchemaOutput: write files to disk + store in context_variables.

    Writes:
      - app.json                         → app-level startup + product intent
      - ui/pages/{name}.yaml per page    → AppPageSchema
      - ui/route_manifest.json           → custom_route_bundle.route_manifest when set
      - ui/pages/custom/*.jsx            → custom_route_bundle.page_files when set
      - ui/index.js                      → deterministic registry barrel for custom_route_bundle.page_files
      - brand/theme_config.json (merge)  → theme_config_patch when set
      - config/shell.json (merge)        → shell_config when set
      - config/asset_manifest.json       → asset_manifest when set
      - admin/admin_registry.yaml        → admin_registry when explicitly owned
      - data/contract.json                 → approved DesignDocs data_contract from context, compiled
                                           as assembly compiles it (verified pack contributions,
                                           subscription assignment stores); not written when the
                                           packs cannot be verified or composed, for assembly to
                                           report

    Stores in context_variables:
      - app_manifest, app_pages, app_theme_config_patch, app_shell_config,
        app_asset_manifest, app_custom_route_bundle,
        app_schema_ready
      - code_files: the rendered files, in the admitted repair overlay.
        generated_files stays the last assembled bundle: the rendered
        ui/index.js and ui/route_manifest.json hold only the app's routes, and
        assembly (or the admitted projection) composes them with the selected
        packs' declarations.

    Compile explicit module/action references against the closed inventory,
    validate runtime schemas, and persist only the accepted canonical artifacts.
    """
    try:
        admin_registry = _to_plain(admin_registry)
        # Use the same typed serializer as real task admission and assembly.
        registry_files = extract_code_file_map_from_payload({
            "manifest": None, "pages": [], "admin_registry": admin_registry,
        })
        validate_admin_registry_task_output(context_variables, admin_registry)
        if manifest is None:
            raise ValueError("save_app_schema: manifest is required")

        manifest_dict = _require_dict(_strip_none(_to_plain(manifest)), "manifest")
        if not manifest_dict.get("app_name"):
            raise ValueError("manifest.app_name is required")
        auth_required_from_strategy(
            manifest_dict.get("auth_strategy"), roles=manifest_dict.get("roles")
        )

        raw_page_list = _normalize_list(_to_plain(pages))
        for page in raw_page_list:
            if isinstance(page, dict) and "extensions" in page:
                raise ValueError("AppPageSchema.extensions is removed and must not be emitted")
        typed_pages = [_normalize_page_schema(page) for page in raw_page_list]
        # Selected packs ship these pages from their templates (the same file
        # identity the worker lane materializes, so Billing -> billing.yaml):
        # the author's copy is discarded, never validated or persisted. The
        # manifest still lists them, because the app ships them.
        pack_paths = pack_owned_output_paths(context_variables)
        discarded_pack_pages = [page for page in typed_pages if f"ui/pages/{_page_file_stem(page)}.yaml" in pack_paths]
        if discarded_pack_pages:
            _logger.info(
                "PACK_OWNED_OUTPUT_DISCARDED: pages=%s; selected pack templates provide them",
                sorted(f"ui/pages/{_page_file_stem(page)}.yaml" for page in discarded_pack_pages),
            )
        page_list = [page for page in typed_pages if page not in discarded_pack_pages]
        # Validate routes against the actual installed templates, even before
        # assembly or when the worker emits only its custom delta. These pages
        # remain pack-owned and are never persisted as model output here.
        try:
            pack_inventory = verified_pack_template_inventory(context_variables=context_variables)
        except ManagedCapabilityTemplateError as exc:
            # The page worker cannot repair pack selection/integrity. Admit no
            # routes from that pack; assembly still reports the blocking error.
            _logger.warning("APP_SCHEMA_PACK_PAGES_UNAVAILABLE: %s", exc)
            pack_inventory = []
        pack_pages = [
            yaml.safe_load(file["content"])
            for pack in pack_inventory
            for file in pack["files"]
            if re.fullmatch(r"ui/pages/[^/]+\.yaml", file["filename"])
            and pack["owner_map"].get(file["filename"]) == "templates"
        ]
        modules = module_action_index_from_context(context_variables)
        workflows = workflow_names_from_context(context_variables)
        data_contract = detach(_context_get(context_variables, "data_contract"))
        surface_map = detach(_context_get(context_variables, "design_surface_map"))
        # Close every page before rejecting so one corrected output fixes them all.
        page_failures: list[str] = []
        for page in page_list:
            page_path = f"ui/pages/{_page_file_stem(page)}.yaml"
            try:
                compile_page_data_sources(
                    page, modules, reject_api_endpoints=True, workflow_names=workflows,
                    data_contract=data_contract, design_surface_map=surface_map, path=page_path,
                )
            except ValueError as exc:
                page_failures.append(f"{page_path}: {exc}")
        if page_failures:
            raise ValueError("\n".join(page_failures))
        baseline_files = detach(_context_get(context_variables, "generated_files")) or {}
        code_files = extract_code_file_map_from_payload(
            {"code_files": detach(_context_get(context_variables, "code_files")) or []}
        )
        baseline_files = {**baseline_files, **code_files}
        if baseline_files:
            # Repairs are partial typed outputs; unchanged pages still own their routes.
            baseline_pages = {}
            for path, content in baseline_files.items():
                parts = Path(path).parts
                if len(parts) == 3 and parts[:2] == ("ui", "pages") and path.endswith(".yaml") and path not in pack_paths:
                    page = yaml.safe_load(content)
                    baseline_pages[page["name"]] = page
            baseline_pages.update({page["name"]: page for page in page_list})
            page_list = list(baseline_pages.values())
            if custom_route_bundle is None:
                custom_route_bundle = detach(_context_get(context_variables, "app_custom_route_bundle"))
        if page_list and not isinstance(page_list, list):
            raise ValueError("save_app_schema: pages must be a list")
        # The same deterministic repairs the task-batch lane runs. This lane used to
        # validate without them, so a defect the repo already knew how to fix was
        # reported to the agent instead of corrected -- and a repair budget went on
        # four modal targets that were sitting inside the Modal that owned them.
        # Applied to baseline pages too: they are merged in above without ever
        # passing through _normalize_page_schema.
        for page in page_list:
            if not isinstance(page, dict):
                continue
            materialize_modal_targets(page)
            resolve_modal_action_targets(page)

        theme_config_patch = _strip_none(_to_plain(theme_config_patch))
        resolved_theme_config = resolve_app_theme_config(
            _context_get(context_variables, "captured_theme_config"), theme_config_patch,
        )
        shell_config = _normalize_shell_config(shell_config)
        asset_manifest = _strip_none(_to_plain(asset_manifest))
        custom_route_bundle = _normalize_custom_route_bundle(custom_route_bundle)

        # One rejection carries every defect it can see. Reporting the first one and
        # stopping meant a page with three independent faults needed three turns
        # against a two-turn budget, and the run died one fix short.
        page_defects: list[str] = []
        for page in page_list:
            if not isinstance(page, dict):
                raise ValueError("Each entry in pages must be a dict (AppPageSchema)")
            if not page.get("name"):
                raise ValueError("Each AppPageSchema must have a 'name' field")
            if not _is_non_empty_string(page.get("route")):
                raise ValueError(f"Page '{page.get('name')}' must have a valid route")
            if not _is_non_empty_string(page.get("title")):
                raise ValueError(f"Page '{page.get('name')}' must have a valid title")
            _validate_shell_mode(page.get("shell_mode", page.get("shellMode")), field=f"Page '{page.get('name')}'.shell_mode")
            page_meta = page.get("meta")
            if page_meta is not None and not isinstance(page_meta, dict):
                raise ValueError(f"Page '{page.get('name')}'.meta must be an object or null")
            if isinstance(page_meta, dict):
                _validate_shell_mode(
                    page_meta.get("shellMode", page_meta.get("shell_mode")),
                    field=f"Page '{page.get('name')}'.meta.shellMode",
                )
                _validate_route_auth(page_meta.get("routeAuth"), field=f"Page '{page.get('name')}'.meta.routeAuth")
            if not page.get("sections"):
                raise ValueError(f"Page '{page.get('name')}' must have at least one section")
            if not isinstance(page.get("sections"), list):
                raise ValueError(f"Page '{page.get('name')}' sections must be a list")

            seen_section_ids = set()
            for section_index, section in enumerate(page["sections"]):
                if not isinstance(section, dict):
                    raise ValueError(
                        f"Page '{page.get('name')}' sections[{section_index}] must be an object, "
                        f"got {type(section).__name__}"
                    )
                section_id = section.get("id")
                if section_id in seen_section_ids:
                    raise ValueError(f"Page '{page.get('name')}' has duplicate section id '{section_id}'")
                seen_section_ids.add(section_id)
                _validate_page_section(
                    section,
                    path=f"pages[{page.get('name')}].sections[{section_index}]",
                )
            try:
                validate_page_schema(page)
            except PageSchemaValidationError as exc:
                # The runtime's diagnostics name the section, field and allowed
                # values without echoing the author's value back at them.
                page_defects.extend(
                    f"Page '{page.get('name')}' {diagnostic.location}: {diagnostic.code}"
                    + (f" - {diagnostic.message}" if diagnostic.message else "")
                    for diagnostic in exc.diagnostics
                )

        if page_defects:
            # Sorted so the same page always produces the same text: the repair loop
            # fingerprints this to decide whether an attempt made progress.
            raise ValueError(
                "Pages violate mozaiks.app_page.v1: " + "; ".join(sorted(page_defects))
            )

        if not page_list and not pack_pages and custom_route_bundle is None:
            raise ValueError("save_app_schema: at least one declarative page or custom route bundle is required")

        _validate_custom_route_bundle(custom_route_bundle)
        shipped_names = {page["name"] for page in page_list}
        shipped_pages = [*page_list, *(page for page in pack_pages if page.get("name") not in shipped_names)]
        _canonicalize_manifest_routes(manifest_dict, shipped_pages, custom_route_bundle)
        _validate_manifest_against_pages(manifest_dict, shipped_pages, custom_route_bundle)
        _validate_shell_header_actions(shell_config)
        _validate_shell_shortcuts(shell_config)
        _validate_shell_navigation(shell_config)
        _validate_shell_chrome(shell_config)
        _validate_asset_manifest(asset_manifest)
        resolved_data_contract = detach(_context_get(context_variables, "data_contract"))
        # data/contract.json is written as assembly compiles it: the approved
        # contract with the verified pack contributions and subscription stores.
        bundle_data_contract, data_contract_deferred = (
            _bundle_data_contract(context_variables, resolved_data_contract) if resolved_data_contract
            else (None, None)
        )
        # A reference-only approved contract resolves against the same verified
        # pack owners assembly composes, not copied owner metadata in the input.
        _validate_data_contract(resolved_data_contract, composed_contract=bundle_data_contract)
        app_ui_quality_warnings = dedupe(
            audit_page_schemas(page_list)
            + audit_custom_route_bundle_integrity(
                custom_route_bundle,
                app_manifest=manifest_dict,
            )
            + audit_generated_react_files(
                custom_route_bundle_page_files(custom_route_bundle),
                source_label="custom route React",
                require_jsx=False,
                include_ui_index=False,
            )
            + audit_app_ui_bundle_integrity(
                _custom_route_bundle_code_files(custom_route_bundle),
                source_label="custom_route_bundle",
            )
        )
    except RepairOwnershipError as exc:
        return f"App schema repair rejected: {exc}"
    except (TypeError, ValueError) as exc:
        if mark_repair_rejected(context_variables, str(exc)):
            return f"App schema repair rejected: {exc}"
        raise

    # Read profile_layout from the app_build_plan stored by AppPlanAgent.
    _build_plan = _context_get(context_variables, "app_build_plan") or {}
    _profile_layout = str(_build_plan.get("profile_layout") or "").strip() or None

    output_dir = _resolve_output_dir(
        context_variables=context_variables, manifest_dict=manifest_dict,
    )
    # Render with the canonical serializer before touching the accepted bundle.
    # Seed only the existing merge inputs, preserving the same materialization.
    with tempfile.TemporaryDirectory(prefix="mozaiks-schema-candidate-") as candidate_dir:
        staging = Path(candidate_dir)
        for path in ("brand/theme_config.json", "config/shell.json", "config/asset_manifest.json"):
            content = baseline_files.get(path)
            if content is None and (output_dir / path).is_file():
                content = (output_dir / path).read_text(encoding="utf-8")
            if content is not None:
                target = staging / path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
        try:
            rendered_paths = _persist_to_filesystem(
                staging, manifest_dict, page_list, resolved_theme_config,
                shell_config, asset_manifest, bundle_data_contract, custom_route_bundle,
                context_variables=context_variables, profile_layout=_profile_layout,
                # Only data/contract.json is skipped when the packs fail; auth still follows the approved contract.
                auth_data_contract=resolved_data_contract,
            )
        except OSError as exc:
            raise RuntimeError("Could not write schema files to disk") from exc
        except (TypeError, ValueError) as exc:
            if mark_repair_rejected(context_variables, str(exc)):
                return f"App schema repair rejected: {exc}"
            raise
        rendered_files = {
            path: _app_artifact_target(staging, path).read_text(encoding="utf-8") for path in rendered_paths
        }
        rendered_files.update(registry_files)

    # An unrelated page may precede the explicitly planned registry owner.
    # Registry saves close the available panels now; final artifact diagnostics
    # always close the complete snapshot, including an absent registry.
    registry_warnings = audit_admin_registry_file_map({**baseline_files, **rendered_files}) if registry_files else []
    if registry_warnings:
        error = "; ".join(registry_warnings)
        if mark_repair_rejected(context_variables, error):
            return f"App schema repair rejected: {error}"
        raise ValueError(error)

    active_repair = (detach(_context_get(context_variables, "bundle_repair_result")) or {}).get("active")
    if isinstance(active_repair, dict):
        # These values come from deterministic scaffolding, not the repair worker.
        # A page repair cannot replace a previously accepted scaffold version.
        # A page repair has no authority over data/contract.json either: the
        # approved DesignDocs contract owns it and assembly recompiles it, so
        # the bundle's copy is kept.
        for path in ("config/ai.json", "provenance.yaml", "config/profile.yaml", "data/contract.json"):
            if path in baseline_files:
                rendered_files[path] = baseline_files[path]
            elif path not in (active_repair.get("allowed_paths") or []):
                rendered_files.pop(path, None)
        # Typed full-schema readback can serialize differently without changing a
        # contract. Preserve the original bytes before checking task ownership.
        for path, content in list(rendered_files.items()):
            original = baseline_files.get(path)
            if original is None or not path.endswith((".json", ".yaml")):
                continue
            try:
                if yaml.safe_load(content) == yaml.safe_load(original):
                    rendered_files[path] = original
            except yaml.YAMLError:
                pass
    try:
        if registry_files and not isinstance(active_repair, dict):
            task = _context_get(context_variables, "current_build_task") or {}
            allowed = task_allowed_paths(task, approved_task_inventory(context_variables))
            # These scaffold companions are assembly-owned, not new authority
            # granted to a registry-bearing page worker by this full-schema saver.
            for path in ("config/ai.json", "config/profile.yaml", "data/contract.json"):
                if path not in allowed:
                    rendered_files.pop(path, None)
            foreign = sorted(set(rendered_files) - allowed)
            if foreign:
                raise ValueError(f"App schema registry save emitted files outside owned_paths: {foreign}")
        rendered_files = validate_repair_candidate(
            context_variables, rendered_files, existing=baseline_files,
        )
    except RepairOwnershipError as exc:
        return f"App schema repair rejected: {exc}"

    written = sorted(rendered_files)
    try:
        for path, content in rendered_files.items():
            target = _app_artifact_target(output_dir, path)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        _logger.info(
            "Wrote app schema to %s: %s",
            output_dir,
            ", ".join(written),
        )
        if context_variables is not None:
            code_files.update(rendered_files)
            values = {
                "app_manifest": manifest_dict, "app_pages": page_list,
                "app_theme_config_patch": theme_config_patch, "app_shell_config": shell_config,
                "app_asset_manifest": asset_manifest,
                "app_custom_route_bundle": custom_route_bundle, "app_schema_ready": True,
                "app_ui_quality_warnings": app_ui_quality_warnings,
                "generated_app_dir": str(output_dir),
                "code_files": [
                    {"filename": path, "content": content}
                    for path, content in sorted(code_files.items())
                ],
            }
            for key, value in values.items():
                if isinstance(context_variables, dict):
                    context_variables[key] = value
                else:
                    context_variables.set(key, value)
            # As in save_generated_code: the shared UI roots an admitted repair
            # saved are newer than its task's output, so assembly lets them
            # supersede that task even where they restate the revision baseline.
            mark_repair_responded(context_variables, saved_paths=written)
    except Exception as exc:
        _logger.exception("Could not write schema files to disk")
        raise RuntimeError("Could not write schema files to disk") from exc

    msg = (agent_message or "App schema persisted.").strip()
    files_written = f"\nFiles written: {', '.join(written)}" if written else ""
    if data_contract_deferred:
        files_written += (
            "\ndata/contract.json not written: the selected capability packs' data contributions cannot be "
            f"composed with the approved data contract ({data_contract_deferred}); assembly reports this pack failure."
        )
    return (
        f"{msg}\n\n"
        f"App: {manifest_dict.get('app_name')}\n"
        f"Pages: {len(page_list)}\n"
        f"Auth strategy: {manifest_dict.get('auth_strategy') or 'null'}\n"
        f"Theme config patch: {'yes' if theme_config_patch else 'no'}\n"
        f"Shell config: {'yes' if shell_config else 'no'}\n"
        f"Asset manifest: {'yes' if asset_manifest else 'no'}\n"
        f"Data contract: {'yes' if resolved_data_contract else 'no'}\n"
        f"Profile layout: {_profile_layout or 'none (runtime default: top_nav)'}"
        f"{files_written}"
    )


__all__ = ["save_app_schema", "promote_generated_app"]


