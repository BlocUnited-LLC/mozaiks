"""Inject factory build-context file, module, and workflow archetypes into prompts."""

from __future__ import annotations

import hashlib
import inspect
import json
import logging
from pathlib import Path
from typing import Any

from factory_app.workflows._shared.hook_utils import update_agent_section, workflow_context_path
from factory_app.workflows.AppGenerator.tools.app_build_plan import (
    _ALLOWED_TASK_TYPES,
    _CANONICAL_INITIAL_AGENTS,
)
from mozaiksai.core.runtime.persistence.adapter import PersistenceCollection
from mozaiksai.core.runtime.persistence.naming import collection_name_for
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.generator_support.code_files import planned_page_path
from mozaiksai.core.workflow.generator_support.module_account_data import owns_per_user_collections

logger = logging.getLogger(__name__)

_FILE_CONTRACTS_PATH = workflow_context_path("AppGenerator", "file_contracts.yaml")
_MODULE_ARCHETYPES_PATH = workflow_context_path("AppGenerator", "module_archetypes.yaml")
_WORKFLOW_ARCHETYPES_PATH = workflow_context_path("AppGenerator", "workflow_archetypes.yaml")

_FILE_CONTRACTS_HEADER = "[FILE CONTRACTS CONTEXT]"
_MODULE_ARCHETYPES_HEADER = "[MODULE ARCHETYPES CONTEXT]"
_WORKFLOW_ARCHETYPES_HEADER = "[WORKFLOW ARCHETYPE CONTEXT]"

# Every task contract in file_contracts.yaml, because the planner is told to
# copy owned_paths from this context and can only copy what it is shown. A
# contract left out here still reaches the planner as a legal task type through
# the vocabulary line, so the omission reads to the model as a task that owns
# nothing. test_planner_contract_surface.py fails when the two drift apart.
_PLANNING_CONTRACT_ORDER = (
    "page_bundle",
    "module_contract",
    "persistence_contract",
    "service_foundation",
    "refinement_harness",
    "api_surface",
)

_AGENT_DEFAULT_CONTRACTS = {
    "DatabaseAgent": ["persistence_contract"],
    "ModelAgent": ["persistence_contract"],
    "AppSchemaAgent": ["page_bundle"],
    "RefinementHarnessAgent": ["refinement_harness"],
    "ServiceAgent": ["module_contract"],
    "FrontendStubAgent": ["module_contract"],
    "ControllerAgent": ["api_surface"],
}
# Legacy writers still require admission, but are not given invented task types.
_SCOPED_WORKERS = frozenset(_CANONICAL_INITIAL_AGENTS.values()) | _AGENT_DEFAULT_CONTRACTS.keys()


def _load_yaml(path: Path) -> dict[str, Any] | None:
    try:
        import yaml  # type: ignore

        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        return data if isinstance(data, dict) else None
    except Exception as exc:
        logger.warning("Failed to load %s: %s", path.name, exc)
        return None


def _context_get(context_variables: Any, key: str, default: Any = None) -> Any:
    if context_variables is None:
        return default
    getter = getattr(context_variables, "get", None)
    if callable(getter):
        try:
            return detach(getter(key, default))
        except TypeError:
            value = getter(key)
            return default if value is None else detach(value)
    data = getattr(context_variables, "data", None)
    if isinstance(data, dict):
        return data.get(key, default)
    if isinstance(context_variables, dict):
        return context_variables.get(key, default)
    return default


def _format_list_block(title: str, items: list[str]) -> list[str]:
    if not items:
        return []
    lines = [title]
    lines.extend(f"  - {item}" for item in items)
    return lines


def _build_contract_block(contract_name: str, contract: dict[str, Any]) -> str:
    lines = [f"{contract_name}:"]
    owner_agent = str(contract.get("owner_agent") or "").strip()
    summary = str(contract.get("summary") or "").strip()
    if owner_agent:
        lines.append(f"  owner_agent: {owner_agent}")
    if summary:
        lines.append(f"  summary: {summary}")

    required_outputs = [str(item) for item in contract.get("required_outputs") or [] if str(item).strip()]
    optional_outputs = [str(item) for item in contract.get("optional_outputs") or [] if str(item).strip()]
    downstream_python = [str(item) for item in contract.get("downstream_python_defaults") or [] if str(item).strip()]
    optional_python_hooks = [str(item) for item in contract.get("optional_python_hooks") or [] if str(item).strip()]
    optional_js_stubs = [str(item) for item in contract.get("optional_js_stubs") or [] if str(item).strip()]
    hard_constraints = [str(item) for item in contract.get("hard_constraints") or [] if str(item).strip()]

    lines.extend(_format_list_block("  required_outputs:", required_outputs))
    lines.extend(_format_list_block("  optional_outputs:", optional_outputs))
    lines.extend(_format_list_block("  downstream_python_defaults:", downstream_python))
    lines.extend(_format_list_block("  optional_python_hooks:", optional_python_hooks))
    lines.extend(_format_list_block("  optional_js_stubs:", optional_js_stubs))
    lines.extend(_format_list_block("  hard_constraints:", hard_constraints))
    return "\n".join(lines)


def _current_task_type(agent: Any) -> str:
    context_variables = getattr(agent, "context_variables", None)
    current_build_task = _context_get(context_variables, "current_build_task", {}) or {}
    if isinstance(current_build_task, dict):
        task_type = str(current_build_task.get("task_type") or current_build_task.get("current_build_task_type") or "").strip()
        if task_type:
            return task_type
    return str(_context_get(context_variables, "current_build_task_type", "") or "").strip()


def _worker_task_context(agent: Any) -> dict[str, Any] | None:
    """Project existing approval/task/source owners into a worker's prompt only.

    This is neither execution state nor acceptance evidence. In particular a
    verified template is available for composition, not proof of delivered
    behavior. Never mutate the context bridge or use a planner-authored brief
    in place of the reviewed requirement inventory.
    """
    if getattr(agent, "name", "") not in _SCOPED_WORKERS:
        return None
    from factory_app.workflows.AppGenerator.tools.code_file_utils import (
        extract_code_file_map_from_payload,
    )
    from factory_app.workflows.AppGenerator.tools.requirement_delivery import (
        approved_inventory_from_context,
        validate_cached_requirement_delivery,
    )
    from factory_app.workflows.AppGenerator.tools.resolve_managed_capability_templates import (
        _context_to_dict,
        verified_pack_template_inventory,
    )
    from factory_app.workflows.AppGenerator.tools.task_integrity import (
        _task_contract,
        approved_task_inventory,
        task_allowed_paths,
        verified_repair_overlay,
    )
    from mozaiksai.core.workflow.generator_support.code_files import (
        extract_deleted_file_paths_from_payload,
        safe_relpath,
    )
    from mozaiksai.core.workflow.generator_support.module_action_inventory import (
        SHARED_PACK_OUTPUT_PATHS,
        pack_owned_outputs,
    )
    from mozaiksai.core.workflow.generator_support.page_plan_utils import (
        module_action_index_from_context,
    )

    context = getattr(agent, "context_variables", None)
    task = _context_get(context, "current_build_task", {}) or {}
    if not isinstance(task, dict) or not task.get("task_id"):
        raise ValueError("Worker task or repair dispatch is missing its approved task context")
    generated = _context_get(context, "generated_files", {}) or {}
    if not isinstance(generated, dict):
        raise ValueError("Worker source context requires an app-relative generated file map")
    # Persisted typed page snapshots are another source representation, not a
    # second prompt-wide implementation channel. Materialize through the same
    # owner as assembly, then apply the task/graph source selection below.
    files = extract_code_file_map_from_payload({
        "manifest": None, "pages": _context_get(context, "app_pages", []) or [],
        "custom_route_bundle": _context_get(context, "app_custom_route_bundle"),
    }, build_timestamp=_context_get(context, "build_timestamp"))
    files.update(generated)
    overlay = extract_code_file_map_from_payload({"code_files": _context_get(context, "code_files")})
    files.update(overlay)
    for path in extract_deleted_file_paths_from_payload({"deleted_files": _context_get(context, "deleted_files")}):
        files.pop(path, None)
    validate_cached_requirement_delivery(context)
    inventory = approved_inventory_from_context(context)
    tasks = approved_task_inventory(context)
    by_id = {item["task_id"]: item for item in tasks}
    task_id = task.get("task_id")
    canonical = by_id.get(task_id)
    if canonical is None or _task_contract(task) != _task_contract(canonical):
        raise ValueError("Worker current task differs from the approved task inventory")
    if (canonical.get("initial_agent") != agent.name
            or _CANONICAL_INITIAL_AGENTS.get(canonical.get("task_type")) != agent.name):
        raise ValueError("Worker agent does not own the approved task")
    allowed = task_allowed_paths(canonical, tasks)
    repair = (_context_get(context, "bundle_repair_result", {}) or {}).get("active")
    if repair and repair.get("status") == "selected":
        repair_paths = repair.get("allowed_paths") or []
        if (repair.get("task_id") != task_id or repair.get("target_agent") != agent.name
                or not repair_paths or not set(repair_paths) <= allowed):
            raise ValueError("Worker repair context differs from its approved task ownership")
        allowed = set(repair_paths)
    protected = pack_owned_outputs(context)
    if allowed & protected.keys():
        raise ValueError("Worker writable scope overlaps protected reusable outputs")

    plan = _context_get(context, "app_build_plan")
    accounting = plan["requirement_accounting"]
    approved = {row.requirement_id: row.model_dump(mode="json") for row in inventory.requirements}
    ancestors: dict[str, set[str]] = {}

    def dependencies_of(key: str) -> set[str]:
        # The existing delivery compiler already rejects cycles/unknown tasks.
        if key not in ancestors:
            direct_dependencies = set(by_id[key].get("depends_on") or [])
            ancestors[key] = direct_dependencies | set().union(*(dependencies_of(dep) for dep in direct_dependencies))
        return ancestors[key]

    linked = []
    for row in accounting["requirements"]:
        implementing = {key for part in row["realizations"] for key in part["task_ids"]}
        supported = sorted(key for key in implementing if task_id in dependencies_of(key))
        if task_id in implementing or supported:
            linked.append({**approved[row["requirement_id"]], "realizations": row["realizations"],
                           "delivery_role": "direct_implementation" if task_id in implementing else "prerequisite_support",
                           "supports_task_ids": supported})
    if not linked:
        raise ValueError("Worker task is not linked to any approved requirement delivery")

    dependencies = dependencies_of(task_id)
    direct = _context_get(context, "dependency_task_outputs", {}) or {}
    if set(direct) != set(canonical.get("depends_on") or []):
        raise ValueError("Worker dependency outputs do not match the approved dependency graph")
    completed = _context_get(context, "completed_task_outputs", {}) or {}
    # Ordinary non-task repair uses the same persisted batch outputs, rather
    # than an invented second completion ledger.
    settled = _context_get(context, "app_task_batch_results", {}) or {}
    sources: dict[str, dict[str, Any]] = {}
    dependency_rows = []
    for dependency in sorted(dependencies):
        payload = completed.get(dependency, settled.get(dependency, direct.get(dependency)))
        if not isinstance(payload, dict):
            raise ValueError(f"Worker prerequisite output is unavailable: {dependency}")
        if dependency in direct and direct[dependency] != payload:
            raise ValueError(f"Worker prerequisite projection differs from its completed output: {dependency}")
        extracted = extract_code_file_map_from_payload(payload, build_timestamp=_context_get(context, "build_timestamp"))
        if not extracted or set(extracted) - task_allowed_paths(by_id[dependency], tasks):
            raise ValueError(f"Worker prerequisite has missing or out-of-scope source: {dependency}")
        dependency_rows.append({"task_id": dependency, "owner_ref": f"task:{dependency}",
                                "state": "prerequisite_output_available", "output_paths": sorted(extracted)})
        for path, content in extracted.items():
            sources[path] = {"owner_ref": f"task:{dependency}", "content": content,
                             "selection": "task_dependency"}

    repair_files, repair_deleted, repair_records = verified_repair_overlay(context, tasks)
    for path, row in sources.items():
        if path in repair_deleted:
            raise ValueError(f"Worker prerequisite source was deleted by an admitted repair: {path}")
        if path in repair_files:
            row.update(content=repair_files[path], selection="admitted_repair")
        elif path in overlay and overlay[path] != row["content"]:
            raise ValueError(f"Worker prerequisite overlay lacks admitted repair evidence: {path}")

    graph = _context_get(context, "context_graph_pack", {}) or {}
    selected = graph.get("relevant_paths") or graph.get("selected_file_paths") or graph.get("candidate_files") or []
    if selected and (graph.get("status") != "loaded" or graph.get("stale_status") not in {None, "current"}
                     or graph.get("app_id") not in {None, inventory.app_id}):
        raise ValueError("Worker context graph is stale, unavailable, or belongs to another app")
    graph_paths = set()
    for entry in selected:
        raw = entry.get("path") if isinstance(entry, dict) else entry
        path = safe_relpath(raw) if isinstance(raw, str) else None
        if not path or path != raw:
            raise ValueError("Worker context graph selected a noncanonical source path")
        graph_paths.add(path)
    # Owned source is needed for a bounded revision even without a pre-existing
    # graph (genesis legitimately has none). Graph selections are read-only.
    for path in sorted((allowed & files.keys()) | graph_paths):
        if path in protected:
            continue  # Expose its verified contract/identity below, not pack implementation bytes.
        if path in sources:
            continue
        if path not in files or not isinstance(files[path], str):
            raise ValueError(f"Worker graph-selected source is unavailable: {path}")
        owner = next((f"task:{item['task_id']}" for item in tasks if path in item.get("owned_paths", [])), "existing_artifact")
        sources[path] = {"owner_ref": owner, "content": files[path],
                         "selection": "writable_source" if path in allowed else "context_graph"}

    packs = verified_pack_template_inventory(context_variables=context)
    reusable = []
    for pack in packs:
        reusable.append({
            "owner_ref": "pack:" + pack["pack_id"],
            "identity": {key: pack[key] for key in ("pack_id", "version", "digest", "authority")},
            "recipe_digest": pack.get("recipe_digest"),
            **({"messaging_configuration": pack["messaging_configuration"],
                "messaging_configuration_digest": pack["messaging_configuration_digest"]}
               if pack.get("messaging_configuration") is not None else {}),
            "state": "verified_resource_available_not_behavior_accepted",
            "protected_outputs": sorted(path for path, owner in protected.items() if owner.pack_id == pack["pack_id"]),
            "shared_contributions": sorted(set(pack["owner_map"]) & SHARED_PACK_OUTPUT_PATHS),
            "extension_outputs": sorted(path for path, owner in pack["owner_map"].items() if owner == "workspace"),
        })
    # Reuse the canonical action interpreter on this selected file projection;
    # never introduce a second module/action schema in the prompt hook.
    action_context = {**_context_to_dict(context),
                      "generated_files": {
                          **{path: row["content"] for path, row in sources.items()},
                          **{file["filename"]: file["content"] for pack in packs for file in pack["files"]
                             if file["filename"].startswith("modules/") and file["filename"].endswith("/module.yaml")},
                      },
                      "code_files": [], "dependency_task_outputs": {},
                      "capability_packs": plan.get("capability_packs") or [],
                      "app_build_plan": plan,
                      "design_surface_map": _context_get(context, "design_surface_map"),
                      "data_contract": _context_get(context, "data_contract")}
    action_contracts = module_action_index_from_context(action_context)
    for row in sources.values():
        row["sha256"] = hashlib.sha256(row["content"].encode()).hexdigest()
    return {
        "mode": "approved_task_context", "task_id": task_id,
        "review_id": inventory.review_id, "inventory_digest": inventory.digest(),
        "requirements": linked, "acceptance_criteria": canonical.get("acceptance_criteria") or [],
        "writable_paths": sorted(allowed), "required_outputs": canonical.get("owned_paths") or [],
        "prerequisites": dependency_rows, "reusable_owners": reusable,
        "source_repairs": [{key: record[key] for key in ("task_id", "request_id", "saved_paths")}
                           for record in repair_records if record["task_id"] in dependencies],
        "supported_action_contracts": action_contracts, "selected_source": sources,
        "source_graph": {key: graph[key] for key in ("graph_id", "graph_hash", "source", "status", "stale_status") if key in graph},
        "rules": ["Implement the linked approved behavior; reuse is not permission to approximate it.",
                  "Do not reimplement or overwrite protected reusable outputs; use declared actions and extension outputs.",
                  "Read-only graph/dependency source does not extend writable scope.",
                  "An admitted_repair source supersedes the original task output at that path; use its verified bytes and digest.",
                  "A prerequisite_support role enables the named implementing tasks; it does not transfer their feature ownership.",
                  "Available resources and prerequisite outputs are not accepted requirement behavior."],
    }


def _build_file_contracts_body(agent: Any, file_contracts: dict[str, Any]) -> str:
    task_contracts = file_contracts.get("task_contracts") if isinstance(file_contracts.get("task_contracts"), dict) else {}
    agent_name = getattr(agent, "name", "")

    lines = [
        "These task/file contracts are prompt-time guidance aligned to the current structured outputs.",
        "They keep modular YAML and Python/JS outputs cookie-cutter across domains.",
        "Runtime truth remains build_tasks, owned_paths, structured outputs, and runtime loaders.",
        "The approved app_build_plan incorporates the latest interview decisions. Preserve its entity fields, optionality, ownership, actions, page routes, and exclusions. Older design documents and category defaults must not override it. Dependency outputs implement that plan, not a new product scope; report contradictions instead of silently copying them.",
    ]

    if agent_name == "AppPlanAgent":
        context = getattr(agent, "context_variables", None)
        experience = _context_get(context, "experience_spec", {}) or {}
        pages = experience.get("pages") or []
        if pages:
            lines.append("Exact case-sensitive page paths from the approved ExperienceSpec; copy these into page_bundle owned_paths, preserving display names separately:")
            lines.extend(
                f"- `{page['name']}` (`{page['route']}`) -> `{planned_page_path(page)}`"
                for page in pages
            )
            if any(page.get("ui_surface") == "custom_react_page" for page in pages):
                lines.append(
                    "Preserve each approved ui_surface. One page_bundle task must own all "
                    "custom page files together with `ui/route_manifest.json` and `ui/index.js`; "
                    "do not emit a declarative YAML substitute for an approved custom route."
                )
        lines.append("")
        lines.append(
            "Plan only with the active AppGenerator task vocabulary: "
            + ", ".join(sorted(_ALLOWED_TASK_TYPES))
            + "."
        )
        for contract_name in _PLANNING_CONTRACT_ORDER:
            contract = task_contracts.get(contract_name)  # type: ignore[union-attr]
            if isinstance(contract, dict):
                lines.append(_build_contract_block(contract_name, contract))
        return "\n\n".join(lines)

    target_contract_names = _AGENT_DEFAULT_CONTRACTS.get(agent_name, [])
    task_type = _current_task_type(agent)

    if agent_name == "ConfigMiddlewareAgent":
        if task_type in {"module_contract", "service_foundation"}:
            target_contract_names = [task_type]
        else:
            target_contract_names = ["module_contract", "service_foundation"]
    elif agent_name == "RefinementHarnessAgent":
        target_contract_names = ["refinement_harness"]
    elif agent_name == "ControllerAgent" and task_type == "module_contract":
        target_contract_names = ["api_surface", "module_contract"]

    for contract_name in target_contract_names:
        contract = task_contracts.get(contract_name)  # type: ignore[union-attr]
        if isinstance(contract, dict):
            lines.append("")
            lines.append(_build_contract_block(contract_name, contract))

    if agent_name in {"ServiceAgent", "ConfigMiddlewareAgent"}:
        context = getattr(agent, "context_variables", None)
        task = _context_get(context, "current_build_task", {}) or {}
        module = (_context_get(context, "module_contract", {}) or {}).get("module_yaml") or {}
        owns_handler = any(str(path).endswith("/backend/account_data_handler.py") for path in task.get("owned_paths") or [])
        module_id = str(task.get("capability_pack_id") or (module.get("module") or {}).get("id") or "")
        if module_id and owns_per_user_collections(module_id, _context_get(context, "data_contract")):
            lines.append(
                f"modules/{module_id}/backend/account_data_handler.py is rendered by code from the module's "
                "per_user collections (export and delete of the account owner's rows through runtime-scoped "
                "persistence). Do not author it; a written copy is replaced."
            )
        elif owns_handler or (module.get("module") or {}).get("user_data_scope"):
            contract = (file_contracts.get("backend_helper_files") or {}).get("account_data_handler")
            if contract:
                import yaml

                lines.append("Required account-data runtime contract:\n" + yaml.safe_dump(contract, sort_keys=False))
                lines.append(
                    "Account-data collection naming API:\n"
                    "from mozaiksai.core.runtime.persistence.naming import collection_name_for\n"
                    f"collection_name_for{inspect.signature(collection_name_for)}"
                )

    if agent_name == "ServiceAgent":
        lines.append(
            "module_contract.python_stubs, downstream_python_defaults, and current_build_task.owned_paths "
            "describe the final artifact inventory, not a request to author every file. "
            "Implement only model-owned source; policy.py is rendered from the approved data_contract. "
            "Do not emit a comment-only or pass stub for a code-rendered artifact. "
            "Keep its planned path so the canonical renderer can fulfill that task's ownership."
        )
        policy_paths = [
            str(path) for path in task.get("owned_paths") or []
            if str(path).endswith("/backend/policy.py")
        ]
        lines.extend(_format_list_block(
            "Code-rendered policy artifacts; omit from python_files and code_files:", policy_paths,
        ))
        methods = [
            f"async {name}{inspect.signature(method)}"
            for name, method in vars(PersistenceCollection).items()
            if not name.startswith("_") and inspect.iscoroutinefunction(method)
        ]
        lines.append(
            "PersistenceCollection is NOT a Motor collection. repo.py may call only these methods:\n"
            + "\n".join(methods)
            + "\nfind_many returns a list, not a cursor; count returns an integer. "
            "Do not use find, count_documents, find_one_and_update, sort/limit/to_list cursor chains. "
            "Use update_one then find_one with the SAME ownership-scoped query. "
            "Prefer allocating a string ID before insert_one and returning the submitted document; "
            "write-result types are provider-specific, not dictionaries. "
            "Persist every planned field, populate server-owned timestamps on create/update, "
            "and preserve optional fields and notes in request, storage, and response shapes."
        )

    return "\n".join(lines) if len(lines) > 3 else ""


def _selected_module_archetype(agent: Any) -> str:
    context_variables = getattr(agent, "context_variables", None)
    current_task = _context_get(context_variables, "current_build_task", {}) or {}
    if isinstance(current_task, dict):
        for key in ("module_archetype", "recommended_module_type"):
            value = str(current_task.get(key) or "").strip()
            if value:
                return value
    # Fall back to module type declared in the module contract
    module_contract = _context_get(context_variables, "module_contract", {}) or {}
    if isinstance(module_contract, dict):
        module_yaml = module_contract.get("module_yaml") or {}
        if isinstance(module_yaml, dict):
            module_meta = module_yaml.get("module") or {}
            if isinstance(module_meta, dict):
                value = str(module_meta.get("type") or "").strip()
                if value:
                    return value
    return ""


def _build_archetype_block(name: str, archetype: dict[str, Any]) -> str:
    lines = [f"{name}:"]
    summary = str(archetype.get("summary") or "").strip()
    if summary:
        lines.append(f"  summary: {summary}")
    canonical_module_type = str(archetype.get("canonical_module_type") or "").strip()
    if canonical_module_type:
        lines.append(f"  canonical_module_type: {canonical_module_type}")
    source_pack = str(archetype.get("source_pack") or "").strip()
    if source_pack:
        lines.append(f"  source_pack: {source_pack}")

    select_when = [str(item) for item in archetype.get("select_when") or [] if str(item).strip()]
    yaml_family = archetype.get("canonical_yaml_family") if isinstance(archetype.get("canonical_yaml_family"), dict) else {}
    always = [str(item) for item in yaml_family.get("always") or [] if str(item).strip()]  # type: ignore[union-attr]
    optional = [str(item) for item in yaml_family.get("optional") or [] if str(item).strip()]  # type: ignore[union-attr]
    python_defaults = [
        str(item)
        for item in (
            archetype.get("python_stub_defaults")
            or archetype.get("backend_stub_defaults")
            or []
        )
        if str(item).strip()
    ]
    hard_constraints = [str(item) for item in archetype.get("hard_constraints") or [] if str(item).strip()]

    lines.extend(_format_list_block("  select_when:", select_when[:3]))
    lines.extend(_format_list_block("  yaml_always:", always))
    lines.extend(_format_list_block("  yaml_optional:", optional))
    lines.extend(_format_list_block("  python_stub_defaults:", python_defaults))
    lines.extend(_format_list_block("  hard_constraints:", hard_constraints[:4]))
    return "\n".join(lines)


def _build_module_archetypes_body(agent: Any, module_archetypes: dict[str, Any]) -> str:
    agent_name = getattr(agent, "name", "")
    if agent_name not in {"ConfigMiddlewareAgent", "ServiceAgent"}:
        return ""

    archetypes = module_archetypes.get("archetypes") if isinstance(module_archetypes.get("archetypes"), dict) else {}
    behavior_patterns = (
        module_archetypes.get("behavior_patterns")
        if isinstance(module_archetypes.get("behavior_patterns"), dict)
        else {}
    )
    if not archetypes:
        return ""

    selected_type = _selected_module_archetype(agent)
    lines = [
        "Module archetypes keep backend layering cookie-cutter across domains.",
        "They guide conventions only; never serialize archetype names into module.yaml or replace owned_paths.",
    ]

    if selected_type and selected_type in archetypes:
        lines.append("")
        lines.append(f"Selected module type: {selected_type}")
        lines.append(_build_archetype_block(selected_type, archetypes[selected_type]))
        other_names = [name for name in archetypes.keys() if name != selected_type]
        if other_names:
            lines.append("")
            lines.append("Other available backend archetypes: " + ", ".join(other_names))
        if behavior_patterns:
            lines.append("")
            lines.append(
                "Available behavior patterns (map to canonical module types; do not serialize pattern names as module.type): "
                + ", ".join(str(name) for name in behavior_patterns)
            )
        return "\n\n".join(lines)

    for name, archetype in archetypes.items():
        if not isinstance(archetype, dict):
            continue
        lines.append("")
        lines.append(_build_archetype_block(name, archetype))

    if behavior_patterns:
        lines.append("")
        lines.append(
            "Behavior patterns map to supported module.type values; never serialize "
            "the behavior pattern key as module.type."
        )
        for name, pattern in behavior_patterns.items():
            if not isinstance(pattern, dict):
                continue
            lines.append("")
            lines.append(_build_archetype_block(str(name), pattern))

    return "\n\n".join(lines)


def _build_workflow_archetypes_body(agent: Any, workflow_archetypes: dict[str, Any]) -> str:
    """Render workflow archetype guidance for injection into AppPlanAgent."""
    agent_name = getattr(agent, "name", "")
    if agent_name != "AppPlanAgent":
        return ""

    archetypes = workflow_archetypes.get("archetypes")
    if not isinstance(archetypes, dict) or not archetypes:
        return ""

    lines = [
        "Workflow archetypes guide orchestrator shape, agent sequence, tool constraints,",
        "and output invariants for workflow-surface capability packs. Apply when planning",
        "any capability pack with surface_kind=workflow.",
    ]

    for name, archetype in archetypes.items():
        if not isinstance(archetype, dict):
            continue

        summary = str(archetype.get("summary", "")).strip()
        select_when = archetype.get("select_when") or []
        hard_constraints = archetype.get("hard_constraints") or []
        blocked_pattern = archetype.get("blocked_phase_pattern")

        lines.append("")
        lines.append(f"archetype: {name}")
        if summary:
            lines.append(f"  summary: {summary[:250]}")
        if select_when:
            lines.append("  select_when:")
            for sw in select_when[:5]:
                lines.append(f"    - {str(sw).strip()[:140]}")
        if hard_constraints:
            lines.append("  hard_constraints:")
            for hc in hard_constraints[:6]:
                lines.append(f"    - {str(hc).strip()[:140]}")
        if blocked_pattern and isinstance(blocked_pattern, dict):
            rule = str(blocked_pattern.get("rule", "")).strip()
            if rule:
                lines.append("  blocked_phase_rule:")
                lines.append(f"    {rule[:250]}")

    return "\n".join(lines)


def inject_cookie_cutter_contracts_context(agent: Any, messages: list[dict[str, Any]]) -> None:
    """Inject file contracts, module archetypes, and workflow archetypes into AppGenerator agents."""
    del messages

    agent_name = getattr(agent, "name", "")
    if agent_name not in {
        "AppPlanAgent",
        "AppSchemaAgent",
        "DatabaseAgent",
        "ModelAgent",
        "RefinementHarnessAgent",
        "ConfigMiddlewareAgent",
        "ServiceAgent",
        "FrontendStubAgent",
        "ControllerAgent",
    }:
        return

    # Required prompt middleware propagates these admission failures before the
    # provider. Keep this outside the optional catalog-rendering catch below.
    task_context = _worker_task_context(agent)
    file_contracts = _load_yaml(_FILE_CONTRACTS_PATH)
    if task_context is not None and not file_contracts:
        raise ValueError("Worker context requires the installed AppGenerator file contracts")
    if file_contracts:
        file_contracts_body = _build_file_contracts_body(agent, file_contracts)
        if task_context is not None:
            file_contracts_body += "\n\nEffective worker context:\n" + json.dumps(task_context, ensure_ascii=False, sort_keys=True)
        if file_contracts_body:
            update_agent_section(agent, _FILE_CONTRACTS_HEADER, file_contracts_body)
    try:
        module_archetypes = _load_yaml(_MODULE_ARCHETYPES_PATH)
        if module_archetypes:
            module_archetypes_body = _build_module_archetypes_body(agent, module_archetypes)
            if module_archetypes_body:
                update_agent_section(agent, _MODULE_ARCHETYPES_HEADER, module_archetypes_body)

        workflow_archetypes = _load_yaml(_WORKFLOW_ARCHETYPES_PATH)
        if workflow_archetypes:
            workflow_archetypes_body = _build_workflow_archetypes_body(agent, workflow_archetypes)
            if workflow_archetypes_body:
                update_agent_section(agent, _WORKFLOW_ARCHETYPES_HEADER, workflow_archetypes_body)

    except Exception as exc:
        logger.error("[%s] Failed to inject cookie-cutter contracts context: %s", agent_name, exc)


__all__ = ["inject_cookie_cutter_contracts_context"]



