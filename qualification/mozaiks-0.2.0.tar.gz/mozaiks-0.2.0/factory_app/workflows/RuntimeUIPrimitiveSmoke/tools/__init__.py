"""Tools for RuntimeUIPrimitiveSmoke."""
