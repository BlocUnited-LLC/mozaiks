"""Tools for SubscriptionContractDesigner."""
