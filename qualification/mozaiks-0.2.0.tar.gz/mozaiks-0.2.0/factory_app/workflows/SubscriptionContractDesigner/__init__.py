"""SubscriptionContractDesigner factory workflow."""
