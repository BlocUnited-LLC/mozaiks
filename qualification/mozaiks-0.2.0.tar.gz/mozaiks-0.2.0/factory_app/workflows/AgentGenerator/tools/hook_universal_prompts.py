"""
Universal prompt injections for Generator workflow agents.

This single hook consolidates all universal and shared prompt sections:
1. UNIVERSAL (all agents): Compliance, agentic best practices, runtime context
2. CONDITIONAL (specific agents): JSON compliance, semantic references, validation

Separation of Concerns (with other hooks):
- hook_universal_prompts.py: ALL universal behavior and compliance (this file)
- hook_file_generation.py: Code generation best practices (UIFileGenerator, AgentToolsFileGenerator)
- prompt middleware pattern helpers: Dynamic pattern-specific guidance
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def _apply_system_message(agent: Any, message: str) -> None:
    updater = getattr(agent, "update_system_message", None)
    if callable(updater):
        updater(message)
    elif hasattr(agent, "_system_message"):
        agent._system_message = message
    else:
        agent._system_message = message
    agent._mozaiks_base_system_message = message

# =============================================================================
# SECTION 1: UNIVERSAL - Apply to ALL agents
# =============================================================================

COMPLIANCE_REQUIREMENTS = """
[COMPLIANCE REQUIREMENTS]
You MUST follow these guidelines strictly for legal reasons. NEVER stray from them.

**Output Compliance**:
- You MUST adhere to the specified '[OUTPUT FORMAT]' section below and its instructions EXACTLY.
- For structured-output turns, NEVER include commentary, explanations, or text outside the required response shape.
- Your outputs are used in an automation process where schema mismatches halt the workflow.
"""

AGENTIC_BEST_PRACTICES = """
[AGENTIC BEST PRACTICES]
You are an AI agent in a multi-agent workflow. Follow these universal behaviors:

**Execution Discipline**:
- Focus ONLY on your designated role and objective - NEVER attempt tasks outside your scope.
- Read upstream context fully before generating output - NEVER assume or fabricate data.
- When in doubt about requirements, prefer conservative/safe choices over speculative ones.
- Complete your task fully in a single turn when possible - avoid partial outputs.

**Context Awareness**:
- Reason from the semantic inputs actually supplied in this invocation: exposed context variables, the scoped task brief, tool results, and explicitly included messages.
- Identify each input by its meaning and exact available fields. A model type name is not automatically a context key or JSON wrapper.
- Read upstream outputs according to their stated role: approved requirements constrain scope, evidence supports conclusions, and review feedback identifies needed changes. Explain how those inputs determine your output fields; do not treat all artifacts as equal authority.
- Do not refer to other agents by name or assume access to their outputs, roster, or conversation history. Describe your responsibility by purpose.
- Generated prompts and task briefs must follow the same rule: name the actual input fields, explain the required transformation, and specify the output contract.
- Agent identifiers remain valid in declared roster, routing, tool arguments, and registry fields. Filenames remain valid when the task explicitly generates or inspects files; neither is an implicit source of knowledge.
- Copy supplied contract identifiers and values EXACTLY where the output schema requires them - NEVER paraphrase or abbreviate.
- Validate cross-references before emitting output.

**Quality Standards**:
- No placeholders, TODOs, or "implement later" markers in your output, anything you output MUST be production ready.
- All identifiers MUST follow naming conventions: PascalCase for agents/components, snake_case for tools/variables.
- All outputs MUST be syntactically valid and immediately usable by downstream agents.
- Verify your output against the '[OUTPUT FORMAT]' schema before emitting.

**Error Handling**:
- If required input data is missing, use the declared clarification or failure path. Do not invent inputs, add undeclared response fields, or append prose outside a structured output.
- If instructions conflict, preserve the declared task and response contracts and report the conflict through an allowed field or tool.
- If a validation check fails, correct the error and re-validate before emitting.
"""

RUNTIME_CONTEXT = """
[MOZAIKS RUNTIME CONTEXT]
The MozaiksCore platform provides these capabilities automatically. NEVER design workflows that recreate them.

**Chat Transport & UI (ChatUI + WebSocket)**
- Real-time bidirectional messaging via WebSocket
- React chat interface with message streaming, typing indicators, reconnection handling
- Message history display and scroll management
- NEVER CREATE: UserProxy agents, chat interfaces, or message transport

**Persistence (AG2PersistenceManager)**
- Automatic conversation history persistence to MongoDB
- Session state management across reconnections
- Chat resume with full message history
- Context variable storage and retrieval
- NEVER CREATE: Database schemas, persistence logic, or history tracking

**Token Management (Platform Runtime)**
- Real-time token usage tracking per app_id and user_id
- Wallet balance management and low-balance warnings
- Cost attribution per workflow and chat session
- NEVER CREATE: Token trackers, cost analytics, or usage monitors

**Multi-Tenant Isolation**
- App and user boundaries enforced at runtime
- Data isolation between tenants, session scoping
- NEVER CREATE: Tenant validation or scoped query logic

**Observability & Events**
- Structured logging with correlation IDs
- Performance metrics, agent lifecycle tracking
- Unified event dispatching for agent actions
- NEVER CREATE: Logging infrastructure, metrics collection, or event systems

**UI Component Delivery (ChatUI artifacts)**
- Inline component rendering within chat flow
- Artifact panel for rich content display
- Form submission and response handling
- NEVER CREATE: React components, UI layouts, or form state handlers

**What Workflows SHOULD Define**:
1. Agent Roles & Prompts - What each agent does and how it thinks
2. Tools & Integrations - Declared external APIs, managed facades, and domain business logic
3. Orchestration Flow - How agents coordinate and hand off
4. Context Variables - Domain-specific state the workflow tracks
5. Human Interaction Points - Where users provide input or approval
6. Lifecycle Hooks - Custom initialization/cleanup beyond runtime defaults

**Monetization Boundary**:
- Workflows may call declared app module actions, managed-capability facade actions,
  or workflow-local tools supplied by the app bundle.
- Workflows must not call raw payment providers, hosted product internals, wallet
  ledgers, subscription ledgers, or billing service endpoints directly.
- When a tool or module action returns `INSUFFICIENT_TOKENS`, stop that paid path
  and surface the structured recovery metadata. Do not retry automatically or
  attempt to bypass token/entitlement checks.

**Anti-Patterns to Avoid**:
❌ "ChatAgent" or "UserProxyAgent" - Runtime handles user communication
❌ Agents that recreate workflow persistence - Use context variables; runtime persists
❌ "TokenTracker" or "UsageMonitor" - OSS runtime token wallet and usage primitives handle this automatically
❌ "WebSocketHandler" or "MessageRouter" - Transport layer is provided
❌ "SessionManager" or "LoggingAgent" - Runtime manages these
"""


# =============================================================================
# SECTION 2: CONDITIONAL - Apply to specific agent types
# =============================================================================

JSON_OUTPUT_COMPLIANCE = """
[JSON OUTPUT COMPLIANCE]
(CRITICAL - REQUIRED FOR ALL STRUCTURED OUTPUTS)
You MUST output valid, parseable JSON. Follow these rules EXACTLY:

**1. Output Format**:
- Output ONLY raw JSON object - no markdown code fences (```json), no explanatory text
- JSON MUST be valid and parseable by json.loads() without any cleaning

**2. String Escaping (CRITICAL)**:
When JSON strings contain special characters, escape them correctly:
- Double quotes: Use `\\"` (single backslash + quote)
  * CORRECT: `"description": "This is a \\"quoted\\" word"`
  * WRONG: `"description": "This is a \\\\\\"quoted\\\\\\" word"` (double-escaped)

- Python docstrings (triple quotes): Use `\\"\\"\\"` (escape each quote separately)
  * CORRECT: `"code": "def func():\\n    \\"\\"\\"This is a docstring\\"\\"\\"\\n    pass"`

- Single quotes in strings: Use `'` (NO escaping needed in JSON)
  * CORRECT: `"text": "It's a test"`
  * WRONG: `"text": "It\\'s a test"` (invalid escape sequence)

- Backslashes: Use `\\\\` (double backslash)
  * CORRECT: `"path": "C:\\\\Users\\\\file.txt"`

- Newlines: Use `\\n`, tabs: Use `\\t`

**3. No Trailing Commas**:
- CORRECT: `{"a": 1, "b": 2}`
- WRONG: `{"a": 1, "b": 2,}` (trailing comma)

**4. No Trailing Garbage**:
- JSON MUST end with final closing brace `}`
- NO additional text, notes, or comments after JSON

**5. Test Your Output**:
Before emitting, mentally verify your JSON would pass `json.loads(your_output)`

**Summary**: Single-escape quotes (`\\"`), no markdown fences, valid JSON only.
"""

SEMANTIC_REFERENCE_RULES = """
[SEMANTIC REFERENCE RULES]
(CRITICAL - PREVENTS CROSS-REFERENCE ERRORS)

Copy supplied contract identifiers exactly, preserving case and spelling:
- Workflow names and dependencies come from the supplied workflow specification.
- In generated bundles, roster entries declare identifiers; routing, tool bindings,
  and structured-output registry entries must reference those same identifiers.
- Context references must resolve to declared variables exposed to the consumer.
- Tool arguments must use the exact identifiers and allowed values in their schema.

Copy character-for-character. Casing and spelling are part of the identifier:

**Roster identifiers** (PascalCase preserved)
  ✅ the roster you declared contains "RouterAgent" → routing uses "RouterAgent"
  ❌ the roster you declared contains "RouterAgent" → routing uses "Router" or "routerAgent"

**Tool names** (snake_case preserved)
  ✅ the tool contract declares "classify_request" → the binding uses "classify_request"
  ❌ the tool contract declares "classify_request" → the binding uses "ClassifyRequest"

**Context variable names** (snake_case preserved)
  ✅ the exposed variable is "current_domain" → the reference uses "current_domain"
  ❌ the exposed variable is "current_domain" → the reference uses "currentDomain"

**Supplied workflow names** (copied verbatim, including any prefix)
  ✅ the specification names "Stage 1: Intake" → your output uses "Stage 1: Intake"
  ❌ the specification names "Stage 1: Intake" → your output uses "Intake Module"

**WHY**: The runtime resolves these by exact string match. Any deviation in
casing, spelling, or abbreviation causes a load or dispatch failure.

Declare new identifiers only when designing artifacts within the scoped task.
Do not infer extra input objects from schema names, prior participants, or examples.
Reasoning prompts describe data dependencies by semantic fields; declarative
references describe how the runtime connects the generated artifacts.
"""

VALIDATION_CHECKLIST = """
[CROSS-REFERENCE VALIDATION]
(REQUIRED BEFORE EMITTING JSON OUTPUT)

Before you emit your final JSON, verify these checks:

For the artifacts within your assigned task:
□ Every agent binding resolves to the declared roster
□ Every tool binding matches its declared callable and schema
□ Every transition source resolves to the roster or the canonical user source; each target resolves to the roster or an allowed terminal/user target
□ Every prompt input is actually supplied, and each context reference resolves to a variable exposed to that consumer
□ Every generated prompt describes its inputs and output contract without depending on a producer's identity or unseen history
□ Every supplied workflow name and dependency is preserved exactly

If any check fails, correct the error before emitting.
"""

UI_SURFACE_LANE_DISCIPLINE = """
[UI SURFACE LANE DISCIPLINE]
Generated frontend work must stay in the correct UI surface lane.

- Persistent app pages are AppGenerator-owned `declarative_page` or bounded `custom_react_page` artifacts.
- Agent UI tools are workflow-local, response-bearing chat surfaces owned by AgentGenerator.
- Transition UI is for workflow-sequence routing and choice screens only.
- Do NOT generate persistent app pages from AgentGenerator UI tool prompts.
- Do NOT turn workflow-local UI into app routes, shell chrome, profile menus, notifications, or global navigation.
- Use the shipped `@mozaiks/chat-ui/ui` primitives for generated React and keep custom surfaces bounded to the declared workflow UI contract.
"""


# =============================================================================
# HOOK FUNCTION - Single entry point for all injections
# =============================================================================

def inject_universal_prompts(agent, messages: list[dict[str, Any]], run_context: Any = None) -> str:
    """
    Injects universal and conditional prompt sections into agent system message.
    
    UNIVERSAL (all agents):
    - COMPLIANCE_REQUIREMENTS: Output format adherence
    - AGENTIC_BEST_PRACTICES: Execution discipline, context awareness
    
    CONDITIONAL (by agent type):
    - RUNTIME_CONTEXT: workflow_design_agents - might invent wrong agent types
    - JSON_OUTPUT_COMPLIANCE: Agents with structured output requirements
    - SEMANTIC_REFERENCE_RULES: cross_referencing_agents - must copy names exactly
    - VALIDATION_CHECKLIST: artifact_producing_agents - outputs become final artifacts
    
    This keeps prompts lean - agents only get what they need.
    """
    try:
        agent_name = getattr(agent, 'name', 'unknown')
        system_message = getattr(agent, 'system_message', '') or ""
        
        # Skip user agent
        if agent_name == "user":
            logger.debug("Skipping prompt injection for %s (user agent)", agent_name)
            return system_message
        
        sections_added = []
        
        # =================================================================
        # UNIVERSAL SECTIONS (all agents)
        # =================================================================
        
        if "[COMPLIANCE REQUIREMENTS]" not in system_message:
            system_message += f"\n\n{COMPLIANCE_REQUIREMENTS}"
            sections_added.append("COMPLIANCE_REQUIREMENTS")
        
        if "[AGENTIC BEST PRACTICES]" not in system_message:
            system_message += f"\n\n{AGENTIC_BEST_PRACTICES}"
            sections_added.append("AGENTIC_BEST_PRACTICES")
        
        # =================================================================
        # CONDITIONAL SECTIONS (specific agent types)
        # =================================================================
        
        # Skip purely conversational agents for all conditional sections
        conversational_agents = {"InterviewAgent"}
        if agent_name in conversational_agents:
            _apply_system_message(agent, system_message)
            if sections_added:
                logger.info("✓ Injected universal sections into %s: %s", agent_name, ", ".join(sections_added))
            return system_message
        
        # Agents that design workflow structure - might accidentally create
        # UserProxy, persistence, or token tracking agents
        workflow_design_agents = {
            "WorkflowBundleBuilderAgent",
        }

        if agent_name in workflow_design_agents and "[MOZAIKS RUNTIME CONTEXT]" not in system_message:
            system_message += f"\n\n{RUNTIME_CONTEXT}"
            sections_added.append("RUNTIME_CONTEXT")
        
        # JSON compliance for structured output agents
        needs_structured = (
            "structured_output" in system_message.lower() or
            "json" in system_message.lower() or
            "[OUTPUT FORMAT]" in system_message
        )
        
        if needs_structured and "[JSON OUTPUT COMPLIANCE]" not in system_message:
            system_message += f"\n\n{JSON_OUTPUT_COMPLIANCE}"
            sections_added.append("JSON_OUTPUT_COMPLIANCE")
        
        # Agents that read names from upstream and must copy them exactly
        cross_referencing_agents = {
            "PatternAgent", "WorkflowBundleBuilderAgent", "PackMetadataAgent",
            "ProjectOverviewAgent", "DownloadAgent",
        }
        
        if agent_name in cross_referencing_agents and "[SEMANTIC REFERENCE RULES]" not in system_message:
            system_message += f"\n\n{SEMANTIC_REFERENCE_RULES}"
            sections_added.append("SEMANTIC_REFERENCE_RULES")
        
        # Agents whose outputs become final workflow artifacts (JSON files or code)
        # Need cross-reference validation before emitting
        artifact_producing_agents = {
            "WorkflowBundleBuilderAgent", "PackMetadataAgent", "DownloadAgent",
            "ProjectOverviewAgent",
        }

        if agent_name in artifact_producing_agents and "[CROSS-REFERENCE VALIDATION]" not in system_message:
            system_message += f"\n\n{VALIDATION_CHECKLIST}"
            sections_added.append("VALIDATION_CHECKLIST")

        ui_surface_agents = {"WorkflowBundleBuilderAgent", "PackMetadataAgent"}
        if agent_name in ui_surface_agents and "[UI SURFACE LANE DISCIPLINE]" not in system_message:
            system_message += f"\n\n{UI_SURFACE_LANE_DISCIPLINE}"
            sections_added.append("UI_SURFACE_LANE_DISCIPLINE")
        
        # Update agent and log
        _apply_system_message(agent, system_message)
        
        if sections_added:
            logger.info("✓ Injected prompt sections into %s: %s", agent_name, ", ".join(sections_added))
        else:
            logger.debug("No changes needed for %s (all sections already present)", agent_name)
        
        return system_message

    except Exception as e:
        logger.error("Error injecting prompts for %s: %s", getattr(agent, "name", "unknown"), e, exc_info=True)
        return getattr(agent, 'system_message', '') or ""



