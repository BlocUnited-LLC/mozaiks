"""Persist ConceptBlueprint drafts and collect explicit, draft-bound reviews."""

import logging
from collections.abc import MutableMapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated, Any, Literal
from uuid import uuid4

import yaml
from pydantic import BaseModel, Field, StrictBool, StrictStr, ValidationError, model_validator

logger = logging.getLogger(__name__)

from factory_app.app.modules.app_registry.backend.policy import is_generic_app_name
from factory_app.app.modules.app_registry.backend.service import AppRegistryService
from factory_app.workflows._shared.platform.build_target import require_build_binding
from mozaiksai.builder.requirements import (
    IntentBrief,
    compile_requirement_inventory,
    require_original_intent,
    requirement_review_rows,
    validate_concept_coverage,
    validate_intent_revision,
    validate_requirement_inventory,
)
from mozaiksai.core.artifacts import persist_summary_artifact
from mozaiksai.core.artifacts.store import BuilderStorageCapabilityError
from mozaiksai.core.data.persistence.artifact_store import BuilderArtifactStore
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.declarative.contracts import ToolOutcomeSpec
from mozaiksai.core.workflow.ui_tools import use_ui_tool


class ConceptReviewResponse(BaseModel):
    action: Literal["approve", "request_changes", "cancel"]
    approved: StrictBool
    review_id: StrictStr
    rationale: StrictStr = Field(default="", max_length=4000)
    revised_intent: IntentBrief | None = None

    @model_validator(mode="after")
    def validate_feedback(self) -> "ConceptReviewResponse":
        self.rationale = self.rationale.strip()
        if self.action == "request_changes" and not self.rationale:
            raise ValueError("Requested changes require feedback")
        if self.revised_intent is not None and self.action != "request_changes":
            raise ValueError("A source amendment requires a new proposal and review")
        return self


def _proposal_remaining(context_variables: Any) -> int:
    """Read the owning declarative budget; do not create a second counter."""
    tools = yaml.safe_load((Path(__file__).resolve().parents[1] / "tools.yaml").read_text(encoding="utf-8"))["tools"]
    spec = ToolOutcomeSpec.model_validate(next(tool["outcome"] for tool in tools if tool["function"] == "save_value_manifest"))
    attempts = context_variables.get(spec.attempts_key, 0)
    if type(attempts) is not int or attempts < 0:
        raise ValueError("Invalid concept proposal counter")
    return max(0, spec.max_attempts - attempts)


def _set_context_value(context_variables: Any | None, key: str, value: Any) -> None:
    """Preserve runtime authority failures instead of silently dropping writes."""
    if context_variables is None:
        return
    if callable(getattr(context_variables, "set", None)):
        context_variables.set(key, value)
    elif isinstance(context_variables, MutableMapping):
        context_variables[key] = value
    else:
        raise TypeError("Concept review requires writable runtime context")


def _build_concept_record(
    *,
    app_id: str,
    manifest_id: str,
    structured_output: dict[str, Any],
    app_name: str,
    concept_overview: str,
    api_endpoints: list[Any],
    capability_pack_hints: list[Any],
    surface_candidate_hints: list[Any],
    agentic_capabilities: list[Any],
    now_iso: str,
) -> dict[str, Any]:
    """Build the canonical persisted concept artifact used by downstream workflows."""

    return {
        "concept_id": manifest_id,
        "app_id": str(app_id),
        "app_name": app_name,
        "ConceptOverview": concept_overview,
        "ApiEndpoints": api_endpoints,
        "Blueprint": structured_output,
        "capability_pack_hints": capability_pack_hints,
        "surface_candidate_hints": surface_candidate_hints,
        "agentic_capabilities": agentic_capabilities,
        "updated_at": now_iso,
        "status": "draft",
    }


def _concept_record_to_manifest(doc: dict[str, Any], app_id: str) -> dict[str, Any]:
    """Normalize the canonical Concepts record into the runtime manifest shape."""

    blueprint = doc.get("Blueprint")
    if not isinstance(blueprint, dict):
        blueprint = {}
    if doc.get("app_id") != str(app_id):
        raise ValueError("Concept requirement inventory belongs to another app")
    brief = require_original_intent(doc.get("intent_brief"))
    validate_concept_coverage(blueprint, brief, app_id=str(app_id))
    inventory = validate_requirement_inventory(
        doc.get("requirement_inventory"), blueprint, app_id=str(app_id), review_id=str(doc.get("review_id") or ""),
    )

    app_name = str(doc.get("app_name") or blueprint.get("app_name") or "Unnamed App")
    concept_overview = str(doc.get("ConceptOverview") or blueprint.get("concept_overview") or "")
    api_endpoints = doc.get("ApiEndpoints")
    if not isinstance(api_endpoints, list):
        api_endpoints = list(blueprint.get("api_endpoints") or [])

    return {
        "manifest_id": str(doc.get("concept_id") or f"concept_{app_id}"),
        "app_id": str(app_id),
        "app_name": app_name,
        "concept_overview": concept_overview,
        "api_endpoints": api_endpoints,
        "capability_pack_hints": list(doc.get("capability_pack_hints") or blueprint.get("capability_pack_hints") or []),
        "surface_candidate_hints": list(doc.get("surface_candidate_hints") or blueprint.get("surface_candidate_hints") or []),
        "agentic_capabilities": list(doc.get("agentic_capabilities") or blueprint.get("agentic_capabilities") or []),
        "blueprint": blueprint,
        "intent_brief": brief.model_dump(mode="json"),
        "review_id": inventory.review_id,
        "requirement_inventory": inventory.model_dump(mode="json"),
        "requirement_inventory_digest": inventory.digest(),
        "approved_scope": list(blueprint.get("core_features") or []) if doc.get("status") == "approved" else [],
        "deferred_scope": list(blueprint.get("deferred_features") or []),
        "constraints": list(blueprint.get("constraints") or []),
        "app_ui_requirements": list(blueprint.get("app_ui_requirements") or []),
        "core_jobs": list(blueprint.get("core_jobs") or []),
        "unique_differentiators": list(blueprint.get("unique_differentiators") or []),
        "brand_intent": blueprint.get("brand_intent"),
        "value_proposition": blueprint.get("value_proposition", ""),
        "target_user": blueprint.get("target_user", ""),
        "target_users": list(blueprint.get("target_users") or []),
        "updated_at": doc.get("updated_at"),
        "status": doc.get("status") or "draft",
    }


async def save_value_manifest(
    context_variables: Annotated[Any | None, "Runtime context with structured output"] = None,
) -> dict[str, Any]:
    """Return a declared tool outcome only after persistence and structured review."""
    _set_context_value(context_variables, "concept_review_outcome", "blocked")
    # A prior approval must never carry over to a newly generated proposal.
    _set_context_value(context_variables, "value_manifest", None)
    # Extract context
    chat_id = None
    binding = require_build_binding(context_variables)
    app_id = binding.target_app_id
    execution_app_id = None
    user_id = None
    workflow_name = "ValueEngine"
    build_mode = None
    structured_output = None

    if context_variables is not None and hasattr(context_variables, "get"):
        execution_app_id = context_variables.get("app_id")
        chat_id = context_variables.get("chat_id")
        user_id = context_variables.get("user_id")
        workflow_name = context_variables.get("workflow_name", "ValueEngine")
        build_mode = "revision" if binding.phase == "refinement" else "genesis"
        # Structured output from GapAnalysisAgent
        structured_output = detach(context_variables.get("structured_output"))
    if not isinstance(structured_output, dict) or not structured_output:
        return {"success": False, "outcome": "blocked", "error": "ConceptBlueprint structured output is required"}
    if not all(isinstance(value, str) and value.strip() for value in (app_id, execution_app_id, chat_id, user_id)):
        return {"success": False, "outcome": "blocked", "error": "App, chat, and user identities are required for review"}

    try:
        brief = IntentBrief.model_validate(detach(context_variables.get("intent_brief")))
        if brief.app_id != str(app_id):
            raise ValueError("Original intake belongs to another app")
    except ValueError:
        return {"success": False, "outcome": "blocked", "error": "Valid original user intake is required before concept review"}
    try:
        validate_concept_coverage(structured_output, brief, app_id=str(app_id))
    except ValueError as exc:
        # The existing tool-outcome budget and AG2 self edge own all repairs.
        # No review is offered and no approved inventory is fabricated.
        feedback = f"Correct source requirement coverage before review: {exc}"
        _set_context_value(context_variables, "concept_review_feedback", feedback)
        return {"success": False, "outcome": "changes_requested", "error": feedback}

    # Extract fields from structured output
    app_name = str(structured_output.get("app_name") or "").strip()
    if is_generic_app_name(app_name):
        return {
            "success": False,
            "outcome": "blocked",
            "error": "ConceptBlueprint.app_name must be a specific product name before the app registry can be named.",
        }
    value_proposition = structured_output.get("value_proposition", "")
    concept_overview = structured_output.get("concept_overview", "")
    target_user = structured_output.get("target_user", "")
    target_users = structured_output.get("target_users", [])
    core_jobs = structured_output.get("core_jobs", [])
    core_features = structured_output.get("core_features", [])
    deferred_features = structured_output.get("deferred_features", [])
    unique_differentiators = structured_output.get("unique_differentiators", [])
    brand_intent = structured_output.get("brand_intent")
    constraints = structured_output.get("constraints", [])
    api_endpoints = structured_output.get("api_endpoints", [])
    app_ui_requirements = structured_output.get("app_ui_requirements", [])
    capability_pack_hints = structured_output.get("capability_pack_hints", [])
    surface_candidate_hints = structured_output.get("surface_candidate_hints", [])
    agentic_capabilities = structured_output.get("agentic_capabilities", [])

    manifest_id = f"manifest_{app_id}"
    now = datetime.now(UTC)
    review_id = f"concept_review_{uuid4().hex}"
    try:
        requirement_inventory = compile_requirement_inventory(structured_output, app_id=str(app_id), review_id=review_id)
    except ValueError as exc:
        return {"success": False, "outcome": "blocked", "error": f"Concept delivery scope is invalid: {exc}"}

    # Build manifest for persistence
    manifest = {
        "manifest_id": manifest_id,
        "app_id": str(app_id),
        "app_name": app_name,
        "value_proposition": value_proposition,
        "concept_overview": concept_overview,
        "target_user": target_user,
        "target_users": target_users,
        "core_jobs": core_jobs,
        "approved_scope": [],
        "deferred_scope": deferred_features,
        "unique_differentiators": unique_differentiators,
        "brand_intent": brand_intent if isinstance(brand_intent, dict) else None,
        "constraints": constraints,
        "api_endpoints": api_endpoints,
        "app_ui_requirements": app_ui_requirements,
        "capability_pack_hints": capability_pack_hints,
        "surface_candidate_hints": surface_candidate_hints,
        "agentic_capabilities": agentic_capabilities,
        "updated_at": now.isoformat(),
        "status": "draft",  # Will be "approved" after user confirms
        "review_id": review_id,
        "blueprint": structured_output,
        "intent_brief": brief.model_dump(mode="json"),
        "requirement_inventory": requirement_inventory.model_dump(mode="json"),
        "requirement_inventory_digest": requirement_inventory.digest(),
    }
    concept_record = _build_concept_record(
        app_id=str(app_id),
        manifest_id=manifest_id,
        structured_output=structured_output,
        app_name=app_name,
        concept_overview=concept_overview,
        api_endpoints=api_endpoints,
        capability_pack_hints=capability_pack_hints,
        surface_candidate_hints=surface_candidate_hints,
        agentic_capabilities=agentic_capabilities,
        now_iso=now.isoformat(),
    )

    concept_record.update(review_id=review_id, review_owner_user_id=user_id,
                          intent_brief=brief.model_dump(mode="json"),
                          requirement_inventory=requirement_inventory.model_dump(mode="json"),
                          requirement_inventory_digest=requirement_inventory.digest())
    store = BuilderArtifactStore()
    try:
        await store.save_concept(app_id=str(app_id), concept_record=concept_record, created_at=now.isoformat())
        await persist_summary_artifact(
            app_id=str(app_id),
            artifact_kind="concept",
            artifact_key="concept",
            summary_payload=manifest,
            source_workflow=str(workflow_name or "ValueEngine"),
            source_chat_id=str(chat_id) if chat_id else None,
            author_user_id=str(user_id) if user_id else None,
            revision_mode=str(build_mode or "").strip().lower() == "revision",
        )
    except BuilderStorageCapabilityError as exc:
        return {"success": False, "outcome": "blocked", "error": str(exc)}
    except Exception as exc:
        logger.warning("[ValueEngine] Draft persistence failed: %s", exc)
        return {"success": False, "outcome": "blocked", "error": "Concept draft could not be persisted"}

    # Build UI payload matching ConceptBlueprint.js expectations
    ui_payload = {
        "title": f"Concept Blueprint: {app_name}",
        "app_id": str(app_id),
        "review_id": review_id,
        "concept_overview": concept_overview,
        "blueprint": {
            "app_name": app_name,
            "value_proposition": value_proposition,
            "target_user": target_user,
            "target_users": target_users,
            "core_jobs": core_jobs,
            "mvp_scope": {
                "core_features": core_features,
                "deferred_features": deferred_features,
            },
            "unique_differentiators": unique_differentiators,
            "brand_intent": brand_intent if isinstance(brand_intent, dict) else None,
            "app_ui_requirements": app_ui_requirements,
            "capability_pack_hints": capability_pack_hints,
            "surface_candidate_hints": surface_candidate_hints,
            "agentic_capabilities": agentic_capabilities,
            "constraints": constraints,
            "non_goals": structured_output.get("non_goals", []),
        },
        "api_endpoints": api_endpoints,
        "intent_brief": brief.model_dump(mode="json"),
        "source_intent_digest": brief.digest(),
        "requirement_coverage": structured_output["requirement_coverage"],
        "requirements": requirement_review_rows(requirement_inventory),
        "remaining_proposals": _proposal_remaining(context_variables),
        "pending_intent_request": context_variables.get("pending_intent_request"),
    }

    # Store context values for downstream routing and tools.
    _set_context_value(context_variables, "value_manifest", manifest)
    _set_context_value(context_variables, "concept_blueprint", structured_output)
    _set_context_value(context_variables, "concept_overview", concept_overview)
    _set_context_value(context_variables, "api_endpoints", api_endpoints)
    _set_context_value(context_variables, "surface_candidate_hints", surface_candidate_hints)
    _set_context_value(context_variables, "concept_presented", True)

    try:
        response = ConceptReviewResponse.model_validate(await use_ui_tool(
            "save_value_manifest", ui_payload, chat_id=str(chat_id),
            workflow_name=str(workflow_name or "ValueEngine"), display="artifact",
        ))
        if response.review_id != review_id or response.approved is not (response.action == "approve"):
            return {"success": False, "outcome": "blocked", "error": "Concept review does not match this draft"}
        outcome = {"approve": "approved", "request_changes": "changes_requested", "cancel": "cancelled"}[response.action]
        amendment = response.revised_intent
        if amendment is not None:
            validate_intent_revision(brief, amendment)
            if _proposal_remaining(context_variables) == 0:
                return {"success": False, "outcome": "blocked", "error":
                        "No proposal attempts remain. Source was not amended; re-enter ValueEngine and submit this amendment for a new proposal and review."}
        if not await store.finish_concept_review(
            app_id=str(app_id), review_id=review_id, status=outcome,
            reviewed_by=str(user_id), feedback=response.rationale,
            revised_intent=amendment.model_dump(mode="json") if amendment else None,
        ):
            return {"success": False, "outcome": "blocked", "error": "Concept draft is no longer awaiting this review"}
        reviewed_manifest = {
            **manifest, "status": outcome, "review_feedback": response.rationale,
            "approved_scope": core_features if outcome == "approved" else [],
        }
        if amendment is not None:
            # Preserve the reviewed draft's source in its artifact; the current
            # Concepts record and context hold the explicitly amended next input.
            _set_context_value(context_variables, "intent_brief", amendment.model_dump(mode="json"))
            _set_context_value(context_variables, "source_intent_digest", amendment.digest())
            _set_context_value(context_variables, "pending_intent_request", None)
        await persist_summary_artifact(
            app_id=str(app_id), artifact_kind="concept", artifact_key="concept", summary_payload=reviewed_manifest,
            source_workflow=str(workflow_name or "ValueEngine"), source_chat_id=str(chat_id),
            author_user_id=str(user_id), revision_mode=str(build_mode or "").strip().lower() == "revision",
        )
        if outcome == "approved":
            named = await AppRegistryService().apply_approved_concept_identity(
                owner_user_id=str(user_id), execution_app_id=str(execution_app_id),
                binding=binding, name=app_name, description=concept_overview,
            )
            if not named["success"]:
                return {"success": False, "outcome": "blocked", "error": "The registered build changed before its identity could be saved"}
    except ValidationError:
        return {"success": False, "outcome": "blocked", "error": "Invalid structured concept review"}
    except Exception as exc:
        logger.warning("[ValueEngine] Concept review failed: %s", exc)
        return {"success": False, "outcome": "blocked", "error": "Concept review could not be completed"}
    _set_context_value(context_variables, "value_manifest", reviewed_manifest)
    _set_context_value(context_variables, "concept_review_feedback", response.rationale)
    _set_context_value(context_variables, "app_name", app_name)
    return {
        "success": outcome == "approved",
        "outcome": outcome,
        "manifest_id": manifest_id,
        "app_id": str(app_id),
        "message": f"Concept review: {outcome}",
    }


async def get_value_manifest(
    context_variables: Annotated[Any | None, "Runtime context"] = None,
) -> dict[str, Any]:
    """
    Retrieve the Value Manifest for an app.

    Used by AgentGenerator/AppGenerator to understand what to build.
    """
    app_id = require_build_binding(context_variables).target_app_id
    # Check context first
    if context_variables and hasattr(context_variables, "get"):
        cached = context_variables.get("value_manifest")
        if cached and cached.get("app_id") == str(app_id):
            try:
                validate_concept_coverage(
                    detach(cached.get("blueprint")) or {}, require_original_intent(detach(cached.get("intent_brief"))),
                    app_id=str(app_id),
                )
                inventory = validate_requirement_inventory(
                    detach(cached.get("requirement_inventory")), detach(cached.get("blueprint")) or {},
                    app_id=str(app_id), review_id=str(cached.get("review_id") or ""),
                )
                if cached.get("requirement_inventory_digest") != inventory.digest():
                    raise ValueError("Concept requirement inventory digest mismatch")
            except ValueError as exc:
                return {"success": False, "error": str(exc)}
            return {"success": True, "manifest": cached}

    # Load from MongoDB
    try:
        store = BuilderArtifactStore()
        concept = await store.get_concept(app_id=str(app_id))
        if concept:
            return {"success": True, "manifest": _concept_record_to_manifest(concept, str(app_id))}
    except ValueError as exc:
        return {"success": False, "error": str(exc)}
    except Exception as e:
        logger.warning("[ValueEngine] Load manifest failed: %s", e)

    return {"success": False, "error": f"No manifest found for app_id={app_id}"}
