"""Validate concept intake readiness without parsing conversational control words."""

from typing import Any

from factory_app.workflows._shared.platform.build_target import require_build_binding
from mozaiksai.builder.requirements import IntentBrief
from mozaiksai.core.data.persistence.artifact_store import BuilderArtifactStore
from mozaiksai.core.data.persistence.persistence_manager import AG2PersistenceManager
from mozaiksai.core.workflow.context.frozen import detach
from mozaiksai.core.workflow.outputs.structured import load_workflow_structured_outputs


async def record_value_interview(agent_message: str, context_variables: Any = None) -> dict[str, str]:
    if context_variables is None:
        raise ValueError("Value interview requires runtime context")
    models, _ = load_workflow_structured_outputs("ValueEngine")
    result = models["ValueInterviewResult"].model_validate(
        detach(context_variables.get("structured_output"))
    ).model_dump(mode="json")
    if not result["agent_message"].strip():
        raise ValueError("Value interview requires a user-facing message")
    if agent_message != result["agent_message"]:
        raise ValueError("Value interview message must match its validated output")
    if result["outcome"] == "ready":
        binding = require_build_binding(context_variables)
        supplied = detach(context_variables.get("intent_brief"))
        prior = await BuilderArtifactStore().get_concept(app_id=binding.target_app_id)
        retained = (prior or {}).get("intent_brief")
        if supplied is None:
            if retained is not None:
                supplied = retained
            else:
                chat_id, app_id = context_variables.get("chat_id"), context_variables.get("app_id")
                if not chat_id or not app_id:
                    raise ValueError("Original intake requires authenticated run history")
                history = await AG2PersistenceManager().load_run_history(chat_id=chat_id, app_id=app_id)
                user_text = [row["content"] for row in history
                             if row.get("role") == "user" and isinstance(row.get("content"), str)
                             and row["content"].strip()]
                if not user_text:
                    raise ValueError("Original user intake is absent from run history")
                supplied = {"app_id": binding.target_app_id, "source_id": chat_id, "revision": 1,
                            "source_request": "\n\n".join(user_text), "requirements": [], "complete_categories": []}
        brief = IntentBrief.model_validate(supplied)
        if brief.app_id != binding.target_app_id:
            raise ValueError("Original intake belongs to another app")
        if retained is not None and brief.digest() != IntentBrief.model_validate(retained).digest():
            raise ValueError("Change original scope through the current owner review")
        # This tool writes only caller-authored input or the existing run's user
        # history, never structured_output. No semantic extraction is fabricated.
        from factory_app.workflows.ValueEngine.tools.manifest import _set_context_value

        pending = None
        if retained is not None and brief.source_id != context_variables.get("chat_id"):
            history = await AG2PersistenceManager().load_run_history(
                chat_id=context_variables.get("chat_id"), app_id=context_variables.get("app_id"))
            pending = "\n\n".join(row["content"] for row in history
                                   if row.get("role") == "user" and isinstance(row.get("content"), str)
                                   and row["content"].strip()) or None
        _set_context_value(context_variables, "pending_intent_request", pending)
        _set_context_value(context_variables, "intent_brief", brief.model_dump(mode="json"))
        _set_context_value(context_variables, "source_intent_digest", brief.digest())
    return {"outcome": result["outcome"]}
