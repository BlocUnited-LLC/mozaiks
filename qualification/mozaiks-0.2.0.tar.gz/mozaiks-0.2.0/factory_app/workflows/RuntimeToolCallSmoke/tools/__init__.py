"""Tools for RuntimeToolCallSmoke."""
