"""RuntimeToolCallSmoke workflow package."""
