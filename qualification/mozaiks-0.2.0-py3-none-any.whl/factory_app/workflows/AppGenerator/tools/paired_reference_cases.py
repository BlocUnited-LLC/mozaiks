"""Repository-owned finite Projects/Tasks behavior, not a generated test profile.

The original table and board presentations share domain contracts, not evidence.
Unsupported approved intent stays pending. This definition does not grant roles,
execute candidate code on the controller, or establish persisted approval.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from mozaiksai.builder.requirements import RequirementInventory
from mozaiksai.core.semantics.canonical import canonical_digest

from .storefront_reference_cases import IDENTITY_SCOPES as IDENTITY_SCOPES
from .storefront_reference_cases import ReferenceBehaviorRequest

STATEMENTS = {
    "projects": "Create, list, inspect, update, and delete user-owned projects from the projects page.",
    "tasks": "Provide user-scoped create, list, inspect, update, and delete task actions linked to projects.",
    "application": "Open the configured application at its task workspace and navigate to project details.",
    "table": "Manage tasks in a searchable paged table with create, detail, edit, and delete dialogs.",
    "board": "Plan task status on a searchable paged three-column board with selected-task context and status moves.",
    "messaging": "Read and send participant-scoped messages through the installed Messaging page.",
    "message_spaces": "Collapse repeated spaces in sent messages before they are stored. Keep every pack file and Messaging authorization unchanged.",
}
CASE_IDS = {name: f"paired-reference.{name}.backend.v1" for name in STATEMENTS}
PERSONA = {"id": "synthetic_app_participants", "roles": ["participant"],
           "claim": "test_host_role_only_not_production_issuer_login_or_browser_acceptance"}
PACK_ID = "messaging"
_PACK_KEYS = ("pack_id", "version", "digest", "authority")
MOBILE_DETAILS_REQUEST = "On mobile, open task details in a bottom panel. Preserve the desktop workspace, routes, brand, and underlying task behavior."
BOARD_PATH = "ui/pages/custom/board.jsx"


class PairedRefinementExpectation(BaseModel):
    """Finite observation input, not approval or a replacement requirement graph."""
    model_config = ConfigDict(extra="forbid", strict=True)
    kind: Literal["mobile_bottom_panel"]
    raw_user_request: Literal[MOBILE_DETAILS_REQUEST]
    selected_path: Literal[BOARD_PATH]
    parent_build_record_id: str = Field(min_length=1)
    build_id: str = Field(min_length=1)
    task_id: str = Field(min_length=1)
    authority_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    request_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


def reference_role_permissions() -> dict[str, set[str]]:
    """Synthetic host grant policy; requested scopes and generated files grant nothing."""
    import yaml

    entry = _reference_pack_entry()
    rendered = {row["filename"]: row["content"] for row in entry["files"]}
    module = yaml.safe_load(rendered["modules/messages/module.yaml"])
    permissions = {row["id"] for row in module["permissions"]}
    if permissions != {"messages.read", "messages.write"}:
        raise ValueError("The installed Messaging permission contract differs from the reviewed participant policy")
    return {"participant": permissions}


def spec_identity() -> dict[str, str]:
    return {"id": "paired-projects-tasks-reference", "version": "1",
            "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


class PairedBehaviorRequest(ReferenceBehaviorRequest):
    presentation: Literal["A", "B"]
    refinement: PairedRefinementExpectation | None = None


def refinement_expectation(reference, request, authority):
    """Called only after the candidate validator independently resolves authority."""
    from mozaiksai.control_plane.contracts import CodingWorkerRequest
    from mozaiksai.core.artifacts.models import BuildAcceptanceAuthority
    from mozaiksai.core.workflow.task_batches import task_evidence_digest

    admitted = validate_reference_request(reference)
    if admitted.presentation != "B":
        raise ValueError("Mobile details refinement requires the approved board presentation")
    if (not isinstance(request, CodingWorkerRequest) or not isinstance(authority, BuildAcceptanceAuthority)
            or request.run_build_binding != authority.binding or authority.binding.phase != "refinement"
            or request.build_record_id != authority.parent_build_record_id
            or request.artifact_app_id != admitted.inventory.app_id
            or request.artifact_app_id != authority.binding.target_app_id
            or request.user_id != authority.owner_user_id or request.app_id != authority.execution_app_id
            or authority.concept_review_id != admitted.inventory.review_id
            or request.build_family != "app_bundle" or request.change_class != "design"
            or request.raw_user_request != MOBILE_DETAILS_REQUEST or set(request.files) != {BOARD_PATH}):
        raise ValueError("Paired refinement lacks exact supported request/scope/authority binding")
    [page] = [task for task in admitted.tasks if task["task_type"] == "page_bundle"]
    value = {"kind": "mobile_bottom_panel", "raw_user_request": request.raw_user_request,
             "selected_path": BOARD_PATH, "parent_build_record_id": request.build_record_id,
             "build_id": authority.binding.build_id, "task_id": page["task_id"],
             "authority_digest": task_evidence_digest(authority.model_dump(mode="json"))}
    return PairedRefinementExpectation(**value, request_digest=canonical_digest(value)).model_dump(mode="json")


def _reference_pack_entry(configuration=None) -> dict[str, Any]:
    from .resolve_managed_capability_templates import verified_pack_template_inventory

    entries = verified_pack_template_inventory(context_variables={
        "capability_packs": [{"id": PACK_ID, "capability_source": "framework_pack",
                              **({"messaging_configuration": configuration} if configuration is not None else {})}],
    })
    if len(entries) != 1 or entries[0]["authority"] != "packaged_build_context":
        raise ValueError("Paired cases require the canonical installed Messaging pack")
    return entries[0]


def fresh_reference_pack(configuration=None) -> dict[str, Any]:
    entry = _reference_pack_entry(configuration)
    return {key: entry[key] for key in (*_PACK_KEYS, "messaging_configuration", "messaging_configuration_digest") if key in entry}


def presentation_for(inventory: RequirementInventory) -> str:
    values = [row.value for row in inventory.requirements if row.source == "core_features"]
    choices = [key for key in ("table", "board") if STATEMENTS[key] in values]
    if len(choices) != 1 or any(values.count(STATEMENTS[key]) != 1
                              for key in ("projects", "tasks", "application", "messaging")):
        raise ValueError("Paired behavior needs one unambiguous presentation and the complete reviewed domain scope")
    return "A" if choices[0] == "table" else "B"


def _semantic_cases(inventory: RequirementInventory, accounting: dict[str, Any],
                    tasks: list[dict[str, Any]], pack: dict[str, Any]) -> tuple[dict[str, str], list[str]]:
    from mozaiksai.core.workflow.generator_support.module_action_inventory import (
        SHARED_PACK_OUTPUT_PATHS,
    )

    from .module_api_template import get_module_api_template

    presentation = presentation_for(inventory)
    if (accounting.get("schema_version") != "mozaiks.requirement_delivery.v1"
            or accounting.get("inventory_digest") != inventory.digest()
            or accounting.get("review_id") != inventory.review_id):
        raise ValueError("Paired cases require current approved inventory/accounting")
    rows = accounting.get("requirements") or []
    by_id = {row["requirement_id"]: row for row in rows}
    if len(rows) != len(by_id) or set(by_id) != {row.requirement_id for row in inventory.requirements}:
        raise ValueError("Paired accounting must retain every approved requirement exactly once")
    task_map = {task["task_id"]: task for task in tasks}
    if len(task_map) != len(tasks):
        raise ValueError("Paired task identity is duplicated")
    slots = {}
    for slot, kind, surface in (("persistence", "persistence_contract", None), ("pages", "page_bundle", None),
                               *((f"{module}.{role}", kind, module) for module in ("projects", "tasks")
                                 for role, kind in (("contract", "module_contract"), ("models", "data_models"),
                                                    ("services", "business_services")))):
        matches = [task for task in tasks if task.get("task_type") == kind
                   and (surface is None or task.get("surface_id") == surface)]
        if len(matches) != 1:
            raise ValueError("Paired behavior requires exact app-owned task contracts")
        slots[slot] = matches[0]["task_id"]
    entry = _reference_pack_entry(pack.get("messaging_configuration"))
    if pack != fresh_reference_pack(pack.get("messaging_configuration")):
        raise ValueError("Paired pack identity is stale or caller-owned")
    normalization = [row for row in inventory.requirements
                     if row.source == "core_features" and row.value == STATEMENTS["message_spaces"]]
    collapse = (pack.get("messaging_configuration") or {}).get("body_spacing") == "collapse_repeated_spaces"
    if len(normalization) != int(collapse):
        raise ValueError("Messaging spacing selection requires its exact approved requirement")
    rendered = {row["filename"]: row["content"] for row in entry["files"]}
    ui_path = "ui/pages/tasks.yaml" if presentation == "A" else "ui/pages/custom/board.jsx"
    ui_route = "/tasks" if presentation == "A" else "/board"
    cases, unsupported = {}, []
    for requirement in inventory.requirements:
        name = next((key for key, value in STATEMENTS.items()
                     if requirement.source == "core_features" and requirement.value == value), None)
        if name is None:
            unsupported.append(requirement.requirement_id)
            continue
        expected: dict[tuple[str, str], set[str]] = {}
        actions: set[tuple[str, str]] = set()
        routes: set[str] = set()

        def task_part(strategy, slot, paths, *, target=expected):
            target[(strategy, "task:" + slots[slot])] = set(paths)

        if name in {"projects", "tasks"}:
            entity = name[:-1]
            prefix = f"modules/{name}/"
            task_part("schema", "persistence", ["data/contract.json"])
            task_part("schema", f"{name}.contract", [prefix + "module.yaml", prefix + "contracts/events.yaml"])
            task_part("custom_generation", f"{name}.models", [prefix + "backend/schemas.py"])
            task_part("custom_generation", f"{name}.services", [prefix + "backend/" + path for path in
                      ("handler.py", "service.py", "repo.py", "policy.py", "account_data_handler.py")])
            actions = {(name, action) for action in
                       (f"create_{entity}", f"list_{name}", f"get_{name}", f"update_{entity}", f"delete_{entity}")}
            if name == "projects":
                task_part("schema", "pages", ["ui/pages/projects.yaml"])
                routes = {"/projects"}
            else:
                task_part("schema" if presentation == "A" else "custom_generation", "pages",
                          [ui_path] if presentation == "A" else [ui_path, "ui/index.js"])
                routes = {ui_route}
        elif name == "application":
            task_part("schema", "pages", ["app.json", "config/ai.json", "config/shell.json",
                                          "ui/route_manifest.json", "ui/pages/projects.yaml"])
            routes = {"/projects"}
        elif name == "table":
            task_part("schema", "pages", [ui_path])
            routes = {ui_route}
        elif name == "board":
            task_part("custom_generation", "pages", [ui_path, "ui/index.js"])
            expected[("framework", "framework:module_api")] = {"ui/lib/moduleApi.js"}
            routes = {ui_route}
        elif name == "messaging":
            expected[("pack", "pack:messaging")] = {"modules/messages/module.yaml", "ui/pages/custom/Messages.jsx",
                                                    "ui/route_manifest.json"}
            routes = {"/messages"}
            actions = {("messages", "list_threads"), ("messages", "send_message")}
        elif name == "message_spaces":
            expected[("jinja_template", "pack:messaging")] = {"modules/messages/backend/service.py"}
            expected[("static_template", "pack:messaging")] = {"ui/pages/custom/Messages.jsx", "ui/route_manifest.json"}
            routes = {"/messages"}
            actions = {("messages", "send_message")}
        parts = by_id[requirement.requirement_id]["realizations"]
        actual = {(part["strategy"], part["owner_ref"]): set(part["output_paths"]) for part in parts}
        if (len(parts) != len(expected) or actual != expected
                or {(ref["module_id"], ref["action_id"]) for part in parts for ref in part["action_refs"]} != actions
                or {route for part in parts for route in part["page_routes"]} != routes):
            raise ValueError("Paired statement differs from its reviewed output/action/route semantics")
        for part in parts:
            if not part["acceptance_criteria"]:
                raise ValueError("Paired realization lacks acceptance criteria")
            if part["owner_ref"].startswith("task:"):
                task_id = part["owner_ref"].split(":", 1)[1]
                task = task_map[task_id]
                if (part["task_ids"] != [task_id] or not set(part["output_paths"]) <= set(task["owned_paths"])
                        or part["depends_on"] != {task_id: sorted(task.get("depends_on") or [])}
                        or part["evidence_contract"] != {"task_contract_digest": canonical_digest(task)}):
                    raise ValueError("Paired task provenance differs from approved ownership")
            else:
                if part["task_ids"] or part["depends_on"]:
                    raise ValueError("Paired reusable output cannot acquire generated task ownership")
                if part["owner_ref"] == "pack:messaging":
                    evidence = {"pack_identity": pack, "recipe_digest": None,
                                "output_digests": {path: hashlib.sha256(rendered[path].encode()).hexdigest()
                                                   for path in part["output_paths"]},
                                "composed_outputs": sorted(set(part["output_paths"]) & SHARED_PACK_OUTPUT_PATHS)}
                    evidence["pack_identity"] = {key: pack[key] for key in _PACK_KEYS}
                    if pack.get("messaging_configuration") is not None:
                        evidence["messaging_configuration_digest"] = pack["messaging_configuration_digest"]
                else:
                    evidence = {"output_digests": {"ui/lib/moduleApi.js": hashlib.sha256(get_module_api_template().encode()).hexdigest()}}
                if part["evidence_contract"] != evidence:
                    raise ValueError("Paired reusable output evidence differs from its installed owner")
        cases[CASE_IDS[name]] = requirement.requirement_id
    return cases, sorted(unsupported)


def validate_reference_request(value: Any) -> PairedBehaviorRequest:
    request = PairedBehaviorRequest.model_validate(value)
    if request.spec != spec_identity() or request.persona != PERSONA:
        raise ValueError("Paired observer spec/persona is not its installed code-owned definition")
    cases, unsupported = _semantic_cases(request.inventory, request.accounting, request.tasks, request.pack)
    if (request.presentation != presentation_for(request.inventory) or request.cases != cases
            or request.unsupported_requirement_ids != unsupported):
        raise ValueError("Paired presentation/cases are missing, ambiguous or falsely attributed")
    if request.refinement is not None:
        refinement = request.refinement.model_dump(mode="json")
        [page] = [task for task in request.tasks if task["task_type"] == "page_bundle"]
        if (request.presentation != "B" or refinement["task_id"] != page["task_id"]
                or refinement["request_digest"] != canonical_digest({key: item for key, item in refinement.items()
                                                                    if key != "request_digest"})):
            raise ValueError("Paired refinement differs from its original board task or exact request digest")
    return request


def reference_request(inventory, accounting, tasks, pack, source_digest):
    cases, unsupported = _semantic_cases(inventory, accounting, tasks, pack)
    return validate_reference_request({
        "schema_version": "mozaiks.reference_behavior_request.v1", "inventory": inventory.model_dump(mode="json"),
        "accounting": accounting, "tasks": tasks, "pack": pack, "spec": spec_identity(), "persona": PERSONA,
        "presentation": presentation_for(inventory), "source_content_sha256": source_digest,
        "cases": cases, "unsupported_requirement_ids": unsupported,
    }).model_dump(mode="json")
