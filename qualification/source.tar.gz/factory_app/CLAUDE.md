# Factory guidance for Claude Code

This is the first-party builder/reference app workspace inside Mozaiks OSS.

Read the local [AGENTS.md](AGENTS.md), repository
[AGENTS.md](../AGENTS.md), [CLAUDE.md](../CLAUDE.md), and
[shared engineering contract](../docs/agent-engineering-contract.md).
The local AGENTS file is the single owner of Factory-specific contributor
framing; this entry point does not duplicate the engineering rules.

Keep the Studio app, shared semantic workflows and Factory-owned catalogs at
their current owners. Reuse installed OSS builder resources and existing AG2
context/execution contracts. Generated customer apps must not receive private
Factory machinery.

This file is repository-owned. Generic standalone-app guidance auto-sync
does not manage the framework root or its nested Factory workspace.
