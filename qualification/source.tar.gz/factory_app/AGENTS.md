# Factory contributor guidance

This directory is the first-party builder/reference app workspace inside
Mozaiks OSS. It contains the Studio app bundle and shared semantic builder
workflows; it is not a generated standalone customer app.

Read the repository [AGENTS.md](../AGENTS.md) and
[shared engineering contract](../docs/agent-engineering-contract.md) before
editing. The [architecture reference](../ARCHITECTURE.md) and current source
define ownership; this file only narrows the local context.

## Local owners

- `app/` is the canonical Studio reference app: identity, config, modules,
  pages, brand and app-owned support code.
- `workflows/` owns Factory semantic workflows and their runtime contracts.
  `workflows/extended_orchestration/extension_registry.json` owns the existing
  build sequences; individual workflows are not the entire builder.
- `build_context/AppGenerator/` and the other Factory-owned contexts contain
  workflow-specific catalogs and contracts declared by their registries.
  Preserve these valid owners.
- Reusable installed packs/templates/profiles live in
  `mozaiksai/builder_resources/` at the repository root; generic builder tools
  live in `mozaiksai/builder/`. Do not recreate private copies here.
- Generated customer applications contain `app/` and applicable app-local
  `workflows/`, not Factory machinery. Outputs remain staged under the
  configured generated-artifact root until explicitly accepted and promoted.

Use the existing semantic workflows, requirement/delivery compiler, distinct
graphs and AG2 context/task mechanisms. Reuse faithfully matching resources;
retain novel approved behavior as bounded custom work. Do not introduce a
parallel builder, context store, graph or runtime.

## Guidance and verification

These Factory instructions are repository-owned, not a generic CLI-managed
standalone-app block. Workspace auto-sync excludes the framework root and
this exact nested Factory workspace. Generic standalone app guidance remains
owned by `mozaiks_cli/agent_guidance/`; do not specialize its templates for
Factory or copy operator-only coordination rules into this file.

Use the repository environment and the narrow tests for the files changed.
For guidance applicability, run `tests/test_cli_sync_agent_guidance.py` and
`tests/test_contributor_guidance_framing.py`; package changes also require the
existing distribution/content checks. Do not treat generated, validated,
accepted or promoted output as interchangeable states.
