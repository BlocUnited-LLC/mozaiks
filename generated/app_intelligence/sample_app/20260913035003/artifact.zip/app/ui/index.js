import ReportsOverviewPage from './pages/custom/ReportsOverviewPage.jsx';

export function register(registerComponent) {
  registerComponent('ReportsOverviewPage', ReportsOverviewPage);
}
